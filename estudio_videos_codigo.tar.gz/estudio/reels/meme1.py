from memekit import *
def P(x): return page(x)
def mbg(c): return page(svg(f'<rect width="1080" height="1920" fill="{c}"/>' + blob(900, 1700, 500, "#FFFFFF", 3, .25) + blob(100, 500, 380, "#FFFFFF", 4, .2) + '<rect width="1080" height="1920" filter="url(#grain)"/>'))
S = []
S.append(dict(dur=2.8, layers=[(mbg("#F4C9B8"), "bg", 0), (P(tag("MÃE DE BEBÊ DE 5 MESES")), "pop", 0),
    (P(card(270, "eu tentando entrar nas <span style='color:#C8735A'>trends do momento</span> com 4 horas de sono", 68)), "up", 0.05),
    (page(svg(mom(540, 1080, 1.05, "tired", "down", "coffee"))), "ill", 0.1)]))
S.append(dict(dur=3.6, layers=[(mbg("#BFD3E6"), "bg", 0), (P(tag("TREND · #GRRSEGUNDA", "#5A7AA0")), "pop", 0),
    (P(card(270, "#GrrSegunda e ele acordou <span style='color:#C8735A'>5h12</span> achando que era festa", 68)), "up", 0.05),
    (page(svg(mom(330, 1120, 0.85, "tired", "down"))), "ill", 0.15),
    (page(svg(baby(800, 1250, 1.3, "grin"))), "pop", 1.2)]))
S.append(dict(dur=6.4, layers=[(mbg("#F7E3B5"), "bg", 0), (P(tag("TREND · MEIO CHIQUE", "#C8962A")), "pop", 0),
    (P(card(270, "meio chique ter <span style='color:#C8735A'>300 fotos dele</span> e 2 minhas", 54)), "up", 0.05),
    (P(card(500, "meio chique saber <span style='color:#C8735A'>todas as músicas</span> do desenho de cor", 54)), "up", 1.7),
    (P(card(760, "meio chique chamar banho de 5 minutos de <span style='color:#C8735A'>spa</span>", 54)), "up", 3.4),
    (page(svg(mom(540, 1420, 0.7, "smug", "front"))), "ill", 0.2)]))
S.append(dict(dur=3.8, layers=[(mbg("#D9C8E8"), "bg", 0), (P(tag("TREND · NERVOSISMO SURREAL", "#7A5AA0")), "pop", 0),
    (P(card(270, "ele dormiu no carro e agora <span style='color:#C8735A'>eu preciso estacionar</span>", 68)), "up", 0.05),
    (page(svg(mom(540, 1080, 1.0, "sweat", "front", "wheel"))), "shake", 0.3)]))
S.append(dict(dur=3.8, layers=[(mbg("#BFE0BF"), "bg", 0), (P(tag("CLIMA DE COPA", "#2E8B57")), "pop", 0),
    (P(card(270, "eu quando ele <span style='color:#C8735A'>rolou sozinho</span> pela primeira vez:", 68)), "up", 0.05),
    (page(svg(confetti(5))), "pop", 1.0),
    (page(svg(mom(540, 1260, 0.9, "happy", "up"))), "ill", 0.1),
    (P('<div style="position:absolute;left:0;right:0;top:560px;text-align:center;font-family:Anton;font-size:200px;color:#F2C200;-webkit-text-stroke:8px #1A1412;transform:rotate(-6deg)">GOOOOL!</div>'), "pop", 1.0)]))
S.append(dict(dur=4.6, layers=[(mbg("#F4C9B8"), "bg", 0), (P(tag("TREND · ME GUARDA COMO...")), "pop", 0),
    (P(card(270, "como a mãe que disse <span style='color:#C8735A'>\"vou dormir quando ele dormir\"</span>", 64)), "up", 0.05),
    (P(card(640, "...e foi lavar louça 🫠", 70, "#FFF3C8")), "pop", 2.0),
    (page(svg(baby(760, 1420, 1.0, "sleep") + mom(330, 1260, 0.7, "tired", "down"))), "ill", 0.2)]))
S.append(dict(dur=3.0, layers=[(mbg("#F7E3B5"), "bg", 0),
    (P(card(300, "manda pra mãe que é <span style='color:#C8735A'>EXATAMENTE</span> assim 😂", 76)), "pop", 0.05),
    (P(card(700, "qual trend é a sua? 1, 2, 3, 4 ou 5? 👇", 56, "#FFF3C8")), "up", 0.8),
    (page(svg(mom(540, 1240, 0.85, "happy", "down", "coffee"))), "ill", 0.1)]))
