import sys, importlib, numpy as np, soundfile as sf, subprocess
mod, raw, out = sys.argv[1:4]
S = importlib.import_module(mod).S; starts = np.cumsum([0] + [s["dur"] for s in S]); total = float(starts[-1])
subprocess.run([sys.executable, "music.py", str(total), "m.wav"], check=True)
x, sr = sf.read("m.wav"); x = x[:, 0]; rng = np.random.default_rng(2)
def pop(f=880):
    tt = np.arange(int(.12 * sr)) / sr; return np.sin(2 * np.pi * f * (1 + .6 * np.exp(-tt * 40)) * tt) * np.exp(-tt * 38) * .22
def swoosh():
    L = int(.35 * sr); w = np.convolve(rng.normal(0, 1, L), np.ones(30) / 30, "same") * np.sin(np.pi * np.arange(L) / L) ** 2; return w * .12
for i, s in enumerate(S):
    for html, kind, t0 in s["layers"]:
        if kind in ("up", "pop") and not (i > 0 and t0 == 0):
            a = int((starts[i] + t0) * sr); p = pop(990 if kind == "pop" else 760); x[a:a + len(p)] += p[:max(0, len(x) - a)]
    if i: a = int((starts[i] - .2) * sr); w = swoosh(); x[a:a + len(w)] += w[:max(0, len(x) - a)]
x = x / np.abs(x).max() * .85; sf.write("mix.wav", np.stack([x, x], 1).astype(np.float32), sr)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-i", "mix.wav", "-c:v", "libx264", "-preset", "medium", "-b:v", "3500k", "-maxrate", "5000k", "-bufsize", "8000k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", out], check=True)
print(total)
