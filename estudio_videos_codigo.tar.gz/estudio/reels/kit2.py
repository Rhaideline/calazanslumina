"""Ilustrações boho extras (sem rosto) para o Reel 0 a 6 meses."""
from kit import *
def calendar(x, y, s, big, small):
    return f'''<g transform="translate({x},{y}) scale({s})"><rect x="-200" y="-220" width="400" height="430" rx="40" fill="#FFF8F0" stroke="{BROWN}" stroke-width="8"/>
<rect x="-200" y="-220" width="400" height="110" rx="40" fill="{TERRA}"/><rect x="-200" y="-150" width="400" height="40" fill="{TERRA}"/>
<circle cx="-110" cy="-235" r="18" fill="{BROWN}"/><circle cx="110" cy="-235" r="18" fill="{BROWN}"/>
<text x="0" y="90" font-family="Lora" font-weight="700" font-size="200" text-anchor="middle" fill="{BROWN}">{big}</text>
<text x="0" y="-145" font-family="Montserrat" font-weight="800" font-size="40" text-anchor="middle" fill="#FFF7EE">{small}</text></g>'''
def cloud_rain(x, y, s):
    drops = "".join(f'<path d="M{dx},{dy} q-16,30 0,44 q16,-14 0,-44" fill="{BLUE}"/>' for dx, dy in ((-120, 120), (-40, 160), (40, 120), (120, 165), (-80, 230), (80, 240)))
    return f'''<g transform="translate({x},{y}) scale({s})"><g opacity=".95"><ellipse cx="0" cy="40" rx="250" ry="90" fill="#FFFFFF"/><circle cx="-110" cy="0" r="100" fill="#FFFFFF"/><circle cx="40" cy="-40" r="130" fill="#FFFFFF"/><circle cx="160" cy="20" r="90" fill="#FFFFFF"/></g>{drops}
<g transform="translate(250,-170)"><circle r="70" fill="{MUST}"/>{"".join(f'<line x1="{math.cos(a)*85:.0f}" y1="{math.sin(a)*85:.0f}" x2="{math.cos(a)*115:.0f}" y2="{math.sin(a)*115:.0f}" stroke="{MUST}" stroke-width="12" stroke-linecap="round"/>' for a in [k*0.785 for k in range(8)])}</g></g>'''
def mom_icon(x, y, s, col):
    return f'<g transform="translate({x},{y}) scale({s})"><circle cx="0" cy="-120" r="56" fill="{col}"/><path d="M-90,120 C-100,0 -60,-50 0,-50 C60,-50 100,0 90,120 Z" fill="{col}"/></g>'
def four_moms(x, y, s):
    return f'<g transform="translate({x},{y}) scale({s})">' + "".join(mom_icon(-270 + k * 180, 0, 1, TERRA if k == 3 else SAND) for k in range(4)) + '</g>'
def baby_smile(x, y, s):
    return f'''<g transform="translate({x},{y}) scale({s})"><circle cx="0" cy="0" r="200" fill="{SKIN2}"/><path d="M-170,-90 C-150,-230 150,-240 175,-90 C120,-150 -110,-160 -170,-90 Z" fill="{HAIR}"/>
<path d="M-90,50 Q0,140 90,50" stroke="{BROWN}" stroke-width="14" fill="none" stroke-linecap="round"/><circle cx="-130" cy="40" r="26" fill="{ROSE}" opacity=".8"/><circle cx="130" cy="40" r="26" fill="{ROSE}" opacity=".8"/>
{"".join(f'<path transform="translate({dx},{dy}) scale(.8)" d="M0,30 C-40,0 -40,-30 -15,-35 C-5,-37 0,-30 0,-22 C0,-30 5,-37 15,-35 C40,-30 40,0 0,30 Z" fill="{TERRA}"/>' for dx, dy in ((260, -160), (-270, -120), (290, 80)))}</g>'''
def tummy_time(x, y, s):
    return f'''<g transform="translate({x},{y}) scale({s})"><rect x="-420" y="80" width="840" height="60" rx="30" fill="{SAGE}" opacity=".6"/>
<path d="M-260,90 C-260,20 -100,0 60,10 C160,16 220,50 220,90 Z" fill="{BLUE}"/>
<path d="M200,70 C250,40 290,-20 300,-80" stroke="{SKIN2}" stroke-width="40" stroke-linecap="round" fill="none"/>
<circle cx="300" cy="-140" r="85" fill="{SKIN2}"/><path d="M230,-170 C250,-240 350,-240 380,-170 C340,-200 270,-200 230,-170 Z" fill="{HAIR}"/>
<path d="M160,85 C200,60 240,70 260,90" stroke="{SKIN2}" stroke-width="30" stroke-linecap="round" fill="none"/>
<path d="M330,-280 C330,-330 400,-330 400,-280" stroke="{TERRA}" stroke-width="10" fill="none" stroke-linecap="round"/></g>'''
def stethoscope(x, y, s):
    return f'''<g transform="translate({x},{y}) scale({s})"><path d="M-120,-200 L-120,-60 C-120,40 120,40 120,-60 L120,-200" stroke="{BROWN}" stroke-width="22" fill="none" stroke-linecap="round"/>
<path d="M0,20 C0,140 160,160 200,80" stroke="{BROWN}" stroke-width="22" fill="none"/><circle cx="210" cy="60" r="60" fill="{TERRA}"/><circle cx="210" cy="60" r="28" fill="{CREAM}"/>
<circle cx="-120" cy="-210" r="22" fill="{TERRA}"/><circle cx="120" cy="-210" r="22" fill="{TERRA}"/></g>'''
def distance_arc(x, y, s):
    return f'''<g transform="translate({x},{y}) scale({s})"><path d="M0,0 Q120,-120 250,-40" stroke="{BROWN}" stroke-width="7" stroke-dasharray="16 12" fill="none"/>
<rect x="60" y="-180" width="230" height="74" rx="37" fill="{TERRA}"/><text x="175" y="-130" font-family="Montserrat" font-weight="800" font-size="38" text-anchor="middle" fill="#FFF7EE">20–30 cm</text></g>'''
