import sys, importlib, numpy as np, soundfile as sf, subprocess
raw, out = sys.argv[1:3]
S = importlib.import_module("polreel2").S; starts = np.cumsum([0] + [s["dur"] for s in S]); total = float(starts[-1])
v, sr = sf.read("../pol2/narracao.wav"); N = int(total * sr); t = np.arange(N) / sr; rng = np.random.default_rng(5)
pad = sum(a * np.sin(2 * np.pi * f * t + p) for f, a, p in ((55, .5, 0), (82.4, .3, 1), (110, .2, 2), (130.8, .12, .5), (164.8, .06, 1.3)))
pad *= .6 + .4 * np.sin(2 * np.pi * .07 * t)
pulse = np.zeros(N); b = 60 / 96
for k in range(int(total / b) + 1):
    i0 = int(k * b * sr); L = int(.35 * sr); tt = np.arange(L) / sr; s = np.sin(2 * np.pi * (46 + 54 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 9)
    e = min(N, i0 + L); pulse[i0:e] += s[:e - i0] * (1 if k % 4 == 0 else .5)
tick = np.zeros(N)
for k in range(int(total / (b / 2))):
    i0 = int(k * b / 2 * sr); L = int(.03 * sr); e = min(N, i0 + L); tick[i0:e] += rng.normal(0, 1, e - i0) * np.exp(-np.arange(e - i0) / sr * 120) * .3
fx = np.zeros(N)
def add(i0, sig, g):
    i0 = int(i0); e = min(N, i0 + len(sig)); fx[i0:e] += sig[:e - i0] * g
for i, s in enumerate(S):
    if i:
        L = int(.4 * sr); w = np.convolve(rng.normal(0, 1, L), np.ones(15) / 15, "same") * np.sin(np.pi * np.arange(L) / L) ** 2; add((starts[i] - .25) * sr, w, .5)
    for ly in s["layers"]:
        html, kind, t0 = ly[:3]; at = (starts[i] + t0) * sr
        if kind == "pop" and t0 > 0.05 or (kind == "pop" and i in (0, 4, 9, 14, 15)):
            L = int(1.0 * sr); tt = np.arange(L) / sr; add(at, np.sin(2 * np.pi * (40 + 70 * np.exp(-tt * 10)) * tt) * np.exp(-tt * 4), .9)
        if kind.startswith("type"):
            d = float(kind[4:] or 1.4)
            for k in range(int(d * 18)):
                L = int(.02 * sr); add(at + k / 18 * sr, rng.normal(0, 1, L) * np.exp(-np.arange(L) / sr * 300), .25)
        if "bubble" in html or "border-radius:28px" in html:
            if kind == "pop": L = int(.15 * sr); tt = np.arange(L) / sr; add(at, np.sin(2 * np.pi * 1300 * tt) * np.exp(-tt * 30), .25)
nm = lambda x, g: x / (np.abs(x).max() + 1e-9) * g
music = nm(pad, .07) + nm(pulse, .15) + nm(tick, .03) + nm(fx, .22)
vv = np.zeros(N); vv[:min(N, len(v))] = v[:N]
env = np.convolve(np.abs(vv), np.ones(int(.2 * sr)) / int(.2 * sr), "same"); duck = 1 - .4 * np.clip(env / (env.max() * .3), 0, 1)
y = vv * .95 + music * duck; y *= np.minimum(1, (total - t) / .3); y = nm(y, .92)
sf.write("polmix2.wav", y.astype(np.float32), sr)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-i", "polmix2.wav", "-c:v", "libx264", "-preset", "medium", "-b:v", "3000k", "-maxrate", "4500k", "-bufsize", "8000k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", out], check=True)
print(total)
