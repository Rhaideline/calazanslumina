from kit import *
def T(top, inner, cls="t"): return f'<div class="{cls}" style="top:{top}px">{inner}</div>'
def ill(fn, *a): return page(svg(fn(*a)))
def li(items, top):
    return T(top, "".join(f'<div class="li"><span class="dot"></span>{x}</div>' for x in items))
TAG = T(170, '<span class="pill">MATERNIDADE REAL · 5 MESES</span>')
S = []
# 1 hook
S.append(dict(dur=3.6, layers=[(page(svg(bg(1))), "bg", 0), (page(TAG), "up", 0.0),
    (page(T(300, '<div class="h" style="font-size:118px">Seu bebê tem<br><i>5 meses?</i></div>')), "up", 0.05),
    (page(T(640, '<div class="k" style="font-size:78px">então ninguém te contou isso...</div>')), "up", 0.7),
    (ill(mom_baby, 540, 1240, 1.35), "ill", 0.1)]))
# 2 cabelo
S.append(dict(dur=6.2, layers=[(page(svg(bg(2, ROSE, SAND))), "bg", 0), (page(TAG), "still", 0),
    (page(T(290, '<div class="h">Seu cabelo está<br><i>caindo aos montes?</i></div>')), "up", 0.05),
    (page(T(560, '<div class="b">Na gravidez, o <b>estrogênio alto</b> segura os fios. Depois do parto, eles caem quase de uma vez. Pode chegar a <b>500 fios por dia</b>.</div>')), "up", 0.6),
    (page(T(890, '<div class="k">é normal e passa sozinho, em geral em alguns meses</div>')), "up", 2.6),
    (ill(brush, 560, 1380, 1.25), "ill", 0.2)]))
# 3 hormonios
S.append(dict(dur=6.4, layers=[(page(svg(bg(3, SAND, SAGE))), "bg", 0), (page(TAG), "still", 0),
    (page(T(290, '<div class="h">Chora do nada?<br><i>Irritada sem motivo?</i></div>')), "up", 0.05),
    (page(T(560, '<div class="b">No parto, <b>estrogênio e progesterona despencam</b>. E se você amamenta, a <b>prolactina</b> alta mantém o estrogênio baixo por mais tempo.</div>')), "up", 0.6),
    (ill(hormone_chart, 180, 1000, 1.0), "ill", 1.4),
    (page(T(1490, '<div class="k">não é fraqueza. é química.</div>')), "pop", 3.4)]))
# 4 sono
S.append(dict(dur=6.2, layers=[(page(svg(bg(4, BLUE, SAND))), "bg", 0), (page(TAG), "still", 0),
    (page(T(290, '<div class="h">Dormia bem e agora<br><i>acorda toda hora?</i></div>')), "up", 0.05),
    (page(T(560, '<div class="b">Por volta dos <b>4 meses</b>, o sono do bebê amadurece e ele fica mais atento ao mundo. Vem mais despertar e mais pedido de colo.</div>')), "up", 0.6),
    (page(T(890, '<div class="k">é fase. não é culpa sua.</div>')), "pop", 2.8),
    (ill(moon, 560, 1300, 1.2), "ill", 0.2)]))
# 5 marcos
S.append(dict(dur=6.6, layers=[(page(svg(bg(5, SAGE, ROSE))), "bg", 0), (page(TAG), "still", 0),
    (page(T(290, '<div class="h">O que ele já<br><i>começa a fazer</i></div>')), "up", 0.05),
    (page(li(["ri alto e solta gritinhos", "leva tudo à boca", "estica o braço pra pegar brinquedos"], 560)), "up", 0.6),
    (page(li(["começa a rolar", "reconhece quem ama"], 830)), "up", 1.8),
    (page(T(1000, '<div class="k">cada bebê tem seu ritmo, viu?</div>')), "up", 3.4),
    (ill(baby_play, 560, 1420, 1.15), "ill", 0.3)]))
# 6 comida
S.append(dict(dur=5.2, layers=[(page(svg(bg(6, MUST, SAND))), "bg", 0), (page(TAG), "still", 0),
    (page(T(290, '<div class="h">Já pode<br><i>papinha?</i></div>')), "up", 0.05),
    (page(T(540, '<div class="b">Ainda não. A <b>OMS</b> e a <b>Sociedade Brasileira de Pediatria</b> recomendam começar a comida <b>a partir dos 6 meses</b>. Até lá, leite.</div>')), "up", 0.6),
    (ill(bowl, 560, 1440, 1.15), "ill", 0.3)]))
# 7 DPP
S.append(dict(dur=7.4, layers=[(page(svg(bg(7, ROSE, SAND))), "bg", 0), (page(TAG), "still", 0),
    (page(T(280, '<div class="h" style="font-size:150px;color:#C8735A">1 em cada 4</div>')), "pop", 0.05),
    (page(T(470, '<div class="b">mães no Brasil têm sintomas de <b>depressão pós-parto</b> (Fiocruz). E ela pode aparecer ao longo do <b>primeiro ano</b>, não só nos primeiros dias.</div>')), "up", 0.7),
    (page(T(830, '<div class="b" style="font-size:40px">Tristeza que não passa, culpa constante, não sentir prazer em nada, se sentir distante do bebê: <b>isso tem tratamento</b>.</div>')), "up", 2.6),
    (ill(heart_hands, 540, 1420, 1.0), "ill", 0.4),
    (page(T(1100, '<div class="b" style="font-size:38px;text-align:center"><b>UBS · seu médico · CVV 188 (24h, gratuito)</b></div>')), "up", 4.2)]))
# 8 como agir
S.append(dict(dur=6.6, layers=[(page(svg(bg(8, SAND, SAGE))), "bg", 0), (page(TAG), "still", 0),
    (page(T(290, '<div class="h">Como se cuidar<br><i>hoje</i></div>')), "up", 0.05),
    (page(li(["<span>peça ajuda concreta: <b style='color:#C8735A'>\"fica com ele 1h?\"</b></span>", "durma quando alguém assumir", "10 minutos de sol e ar livre", "fale como você se sente"], 540)), "up", 0.6),
    (ill(sun_cup, 560, 1360, 1.05), "ill", 0.4)]))
# 9 CTA
S.append(dict(dur=4.8, layers=[(page(svg(bg(9))), "bg", 0), (page(TAG), "still", 0),
    (page(T(300, '<div class="h">Salva e manda pra<br><i>uma mãe de bebê<br>de 5 meses</i></div>')), "up", 0.05),
    (page(T(740, '<div class="k" style="font-size:72px">qual dessas você está vivendo? comenta 💬</div>')), "up", 1.0),
    (ill(share, 470, 1330, 1.2), "ill", 0.3)]))
