import math, random
CREAM="#F7EFE6"; TERRA="#C8735A"; SAGE="#8FA98A"; ROSE="#E8B4A8"; BROWN="#3A2A24"; SAND="#E9D5C0"; SKIN="#E2B394"; SKIN2="#C98F6E"; HAIR="#4A3026"; MUST="#E0A84E"; BLUE="#9CB4C8"
def page(body, bg="transparent", extra_css=""):
    return f'''<html><head><style>html,body{{margin:0;width:1080px;height:1920px;background:{bg};overflow:hidden}}
.t{{position:absolute;left:90px;right:90px;color:{BROWN};font-family:Montserrat}}
.h{{font-family:Lora;font-weight:700;font-size:92px;line-height:1.05;letter-spacing:-1px}}
.h i{{color:{TERRA};font-style:italic}}
.b{{font-size:48px;line-height:1.38;font-weight:500}}
.b b{{font-weight:800;color:{TERRA}}}
.k{{font-family:Caveat;font-weight:700;font-size:64px;color:{TERRA}}}
.pill{{display:inline-block;background:{TERRA};color:#FFF7EE;font-weight:800;font-size:30px;letter-spacing:4px;padding:14px 28px;border-radius:40px}}
.li{{font-size:46px;font-weight:600;line-height:1.25;margin:0 0 22px 0;display:flex;align-items:center;gap:22px}}
.dot{{width:22px;height:22px;border-radius:50%;background:{SAGE};flex:none}}
{extra_css}</style></head><body>{body}</body></html>'''
def svg(inner, w=1080, h=1920, style="position:absolute;left:0;top:0"):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" style="{style}"><defs><filter id="grain"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="3"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .09"/></feComponentTransfer></filter><filter id="soft"><feGaussianBlur stdDeviation="40"/></filter></defs>{inner}</svg>'
def blob(cx, cy, r, col, seed=1, op=1):
    rnd = random.Random(seed); pts = []
    n = 9
    for k in range(n):
        a = k / n * 6.283; rr = r * rnd.uniform(0.82, 1.15); pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    d = f"M{(pts[0][0]+pts[-1][0])/2:.0f},{(pts[0][1]+pts[-1][1])/2:.0f}"
    for k in range(n):
        p = pts[k]; q = pts[(k + 1) % n]; d += f" Q{p[0]:.0f},{p[1]:.0f} {(p[0]+q[0])/2:.0f},{(p[1]+q[1])/2:.0f}"
    return f'<path d="{d} Z" fill="{col}" opacity="{op}"/>'
def bg(seed, c1=SAND, c2=ROSE, c3=SAGE):
    r = random.Random(seed)
    g = f'<rect width="1080" height="1920" fill="{CREAM}"/>'
    g += blob(r.uniform(-50, 200), r.uniform(-50, 300), 420, c1, seed, .55) + blob(r.uniform(850, 1150), r.uniform(1500, 1900), 460, c2, seed + 1, .35) + blob(r.uniform(900, 1100), r.uniform(200, 500), 200, c3, seed + 2, .25)
    g += "".join(f'<circle cx="{r.uniform(40,1040):.0f}" cy="{r.uniform(40,1880):.0f}" r="{r.uniform(3,7):.0f}" fill="{r.choice([TERRA,SAGE,MUST])}" opacity=".35"/>' for _ in range(14))
    g += '<rect width="1080" height="1920" filter="url(#grain)"/>'
    return g
# ---------- illustrations (faceless boho) ----------
def mom_baby(x, y, s=1.0):
    return f'''<g transform="translate({x},{y}) scale({s})">
<path d="M-210,420 C-230,200 -170,40 -60,0 L60,0 C170,40 230,200 210,420 Z" fill="{TERRA}"/>
<path d="M-40,-10 C-40,-40 40,-40 40,-10 L36,20 L-36,20 Z" fill="{SKIN}"/>
<ellipse cx="0" cy="-110" rx="92" ry="104" fill="{SKIN}"/>
<path d="M-98,-120 C-104,-230 96,-240 98,-118 C70,-170 -40,-190 -98,-120 Z" fill="{HAIR}"/>
<circle cx="-30" cy="-225" r="58" fill="{HAIR}"/>
<path d="M-98,-120 C-120,-40 -90,30 -60,40 C-80,-20 -80,-80 -70,-130 Z" fill="{HAIR}"/>
<path d="M-200,170 C-120,120 80,110 190,150 C200,240 120,300 0,300 C-120,300 -190,250 -200,170 Z" fill="{SAGE}"/>
<path d="M-180,175 C-100,145 60,140 170,160" stroke="#7A9476" stroke-width="6" fill="none"/>
<circle cx="140" cy="150" r="62" fill="{SKIN2}"/>
<path d="M95,125 C110,85 175,85 190,125 C160,108 125,108 95,125 Z" fill="{HAIR}"/>
<path d="M-150,230 C-60,270 60,260 150,215" stroke="{SKIN}" stroke-width="44" stroke-linecap="round" fill="none"/>
<path d="M-160,120 C-200,180 -190,230 -150,232" stroke="{TERRA}" stroke-width="56" stroke-linecap="round" fill="none"/>
</g>'''
def brush(x, y, s=1.0):
    strands = "".join(f'<path d="M{-40+k*14},{-60} c{20},{30} {-20},{60} {6},{100+k*6} s-10,50 8,{80+k*4}" stroke="{HAIR}" stroke-width="5" fill="none" opacity=".85"/>' for k in range(7))
    return f'''<g transform="translate({x},{y}) scale({s}) rotate(-28)"><rect x="-26" y="40" width="52" height="300" rx="26" fill="{ROSE}"/>
<rect x="-90" y="-180" width="180" height="230" rx="80" fill="{TERRA}"/>{"".join(f'<circle cx="{-55+(k%4)*37}" cy="{-140+(k//4)*40}" r="7" fill="#FFF3E6"/>' for k in range(20))}
<g transform="translate(40,-40) rotate(28)">{strands}</g></g>'''
def hormone_chart(x, y, s=1.0):
    return f'''<g transform="translate({x},{y}) scale({s})"><rect x="0" y="0" width="720" height="440" rx="36" fill="#FFF8F0" opacity=".9"/>
<line x1="60" y1="370" x2="680" y2="370" stroke="{BROWN}" stroke-width="5"/><line x1="60" y1="60" x2="60" y2="370" stroke="{BROWN}" stroke-width="5"/>
<path d="M60,330 C160,300 260,120 360,90 C372,250 380,330 420,345 C500,350 600,340 680,335" stroke="{TERRA}" stroke-width="12" fill="none" stroke-linecap="round"/>
<line x1="365" y1="60" x2="365" y2="370" stroke="{SAGE}" stroke-width="5" stroke-dasharray="14 10"/>
<text x="378" y="80" font-family="Caveat" font-weight="700" font-size="46" fill="{SAGE}">parto</text>
<text x="90" y="420" font-family="Montserrat" font-weight="700" font-size="30" fill="{BROWN}">gravidez</text><text x="520" y="420" font-family="Montserrat" font-weight="700" font-size="30" fill="{BROWN}">pós-parto</text>
<text x="80" y="120" font-family="Caveat" font-weight="700" font-size="50" fill="{TERRA}">estrogênio</text></g>'''
def moon(x, y, s=1.0):
    st = "".join(f'<path transform="translate({dx},{dy}) scale({k})" d="M0,-30 L8,-8 L30,0 L8,8 L0,30 L-8,8 L-30,0 L-8,-8 Z" fill="{MUST}"/>' for dx, dy, k in ((-230, -120, 1), (210, -170, .7), (260, 60, .9), (-180, 140, .6)))
    return f'''<g transform="translate({x},{y}) scale({s})"><circle cx="0" cy="0" r="170" fill="{MUST}"/><circle cx="70" cy="-50" r="160" fill="{CREAM}"/>{st}
<g transform="translate(-20,190)"><ellipse cx="0" cy="0" rx="200" ry="70" fill="#FFFFFF" opacity=".9"/><circle cx="-80" cy="-30" r="70" fill="#FFFFFF" opacity=".9"/><circle cx="40" cy="-50" r="90" fill="#FFFFFF" opacity=".9"/></g></g>'''
def baby_play(x, y, s=1.0):
    return f'''<g transform="translate({x},{y}) scale({s})"><ellipse cx="0" cy="120" rx="400" ry="70" fill="{SAGE}" opacity=".55"/>
<path d="M-180,90 C-190,20 -80,-20 40,-10 C140,0 200,40 190,90 Z" fill="{BLUE}"/>
<circle cx="-210" cy="20" r="80" fill="{SKIN2}"/><path d="M-280,0 C-270,-60 -170,-70 -140,-20 C-180,-40 -240,-40 -280,0 Z" fill="{HAIR}"/>
<path d="M-170,60 C-120,20 -110,-60 -60,-100" stroke="{SKIN2}" stroke-width="34" stroke-linecap="round" fill="none"/>
<path d="M150,80 C220,60 260,20 300,-10" stroke="{SKIN2}" stroke-width="36" stroke-linecap="round" fill="none"/>
<g transform="translate(-30,-150)"><circle r="56" fill="none" stroke="{TERRA}" stroke-width="18"/><rect x="-10" y="50" width="20" height="90" rx="10" fill="{MUST}"/><circle r="18" fill="{MUST}"/></g>
<g transform="translate(270,-40)"><rect x="-50" y="40" width="100" height="26" rx="13" fill="{TERRA}"/><rect x="-40" y="10" width="80" height="26" rx="13" fill="{MUST}"/><rect x="-30" y="-20" width="60" height="26" rx="13" fill="{SAGE}"/><rect x="-6" y="-60" width="12" height="40" fill="{BROWN}"/></g></g>'''
def bowl(x, y, s=1.0):
    return f'''<g transform="translate({x},{y}) scale({s})"><rect x="60" y="-330" width="300" height="300" rx="34" fill="#FFF8F0" stroke="{BROWN}" stroke-width="8"/><rect x="60" y="-330" width="300" height="80" rx="34" fill="{TERRA}"/>
<text x="210" y="-90" font-family="Lora" font-weight="700" font-size="170" text-anchor="middle" fill="{BROWN}">6</text><text x="210" y="-272" font-family="Montserrat" font-weight="800" font-size="34" text-anchor="middle" fill="#FFF7EE">MESES</text>
<path d="M-300,0 C-300,170 -150,240 -40,240 C70,240 220,170 220,0 Z" fill="{SAGE}"/><ellipse cx="-40" cy="0" rx="260" ry="46" fill="#7A9476"/><ellipse cx="-40" cy="-6" rx="230" ry="34" fill="{MUST}" opacity=".85"/>
<g transform="translate(-260,-120) rotate(-30)"><ellipse cx="0" cy="0" rx="40" ry="56" fill="{ROSE}"/><rect x="-10" y="40" width="20" height="230" rx="10" fill="{ROSE}"/></g></g>'''
def heart_hands(x, y, s=1.0):
    return f'''<g transform="translate({x},{y}) scale({s})"><path d="M0,120 C-180,10 -190,-120 -100,-150 C-50,-165 -15,-130 0,-100 C15,-130 50,-165 100,-150 C190,-120 180,10 0,120 Z" fill="{ROSE}"/>
<path d="M-60,-40 L-10,10 L80,-80" stroke="#FFF8F0" stroke-width="0" fill="none"/>
<path d="M-320,260 C-260,160 -160,140 -60,170 C-20,180 -10,210 -40,220 L-140,230" stroke="{SKIN}" stroke-width="70" stroke-linecap="round" fill="none"/>
<path d="M320,260 C260,160 160,140 60,170 C20,180 10,210 40,220 L140,230" stroke="{SKIN2}" stroke-width="70" stroke-linecap="round" fill="none"/></g>'''
def sun_cup(x, y, s=1.0):
    rays = "".join(f'<line x1="{math.cos(a)*120:.0f}" y1="{math.sin(a)*120:.0f}" x2="{math.cos(a)*170:.0f}" y2="{math.sin(a)*170:.0f}" stroke="{MUST}" stroke-width="16" stroke-linecap="round"/>' for a in [k * 0.785 for k in range(8)])
    return f'''<g transform="translate({x},{y}) scale({s})"><g transform="translate(-120,-80)"><circle r="95" fill="{MUST}"/>{rays}</g>
<g transform="translate(150,120)"><path d="M-110,-60 L110,-60 L90,120 C85,150 -85,150 -90,120 Z" fill="{TERRA}"/><path d="M110,-20 C190,-20 190,80 100,80" stroke="{TERRA}" stroke-width="22" fill="none"/>
<path d="M-40,-100 c-20,-30 20,-50 0,-90 M20,-100 c-20,-30 20,-50 0,-90" stroke="{BROWN}" stroke-width="7" fill="none" opacity=".5"/></g></g>'''
def share(x, y, s=1.0):
    return f'''<g transform="translate({x},{y}) scale({s})"><path d="M-110,-150 L110,-150 L110,170 L0,90 L-110,170 Z" fill="{TERRA}"/>
<g transform="translate(250,0)"><path d="M-120,40 L120,-90 L60,120 L20,50 Z" fill="{SAGE}"/><path d="M-120,40 L120,-90 L20,50 Z" fill="#7A9476"/></g></g>'''
