import sys, importlib, numpy as np, soundfile as sf, subprocess
mod, raw, out = sys.argv[1:4]
S = importlib.import_module(mod).S; starts = np.cumsum([0] + [s["dur"] for s in S]); total = float(starts[-1])
sr = 44100; N = int(total * sr); x = np.zeros(N + sr * 2); rng = np.random.default_rng(4)
def add(i0, sig, g=1):
    i0 = int(i0); e = min(len(x), i0 + len(sig)); x[i0:e] += sig[:e - i0] * g
def env(L, d): tt = np.arange(int(L * sr)) / sr; return tt, np.exp(-tt * d)
def kick(): tt, e = env(.3, 14); return np.sin(2 * np.pi * (50 + 120 * np.exp(-tt * 35)) * tt) * e
def clap(): tt, e = env(.18, 30); return rng.normal(0, 1, len(tt)) * e * .5
def hat(): tt, e = env(.05, 90); return rng.normal(0, 1, len(tt)) * e * .15
def pluck(f, L=.25, a=.35):
    tt, e = env(L, 9); return (np.sin(2 * np.pi * f * tt) + .4 * np.sin(4 * np.pi * f * tt)) * e * a
mid = lambda m: 440 * 2 ** ((m - 69) / 12)
bpm = 112; b = 60 / bpm; prog = [[48, 64, 67, 71], [45, 64, 67, 72], [41, 65, 69, 72], [43, 62, 67, 71]]
k = 0; t = 0.0
while t < total:
    bar = (k // 16) % 4; ch = prog[bar]; st = k % 16; i0 = t * sr
    if st in (0, 6, 8, 11): add(i0, kick(), .9)
    if st in (4, 12): add(i0, clap(), .7)
    if st % 2 == 0: add(i0, hat())
    if st in (0, 3, 6, 8, 10, 14): add(i0, pluck(mid(ch[0]), .3, .5))
    if st in (2, 7, 10, 15): add(i0, pluck(mid(ch[1 + st % 3] + 12), .2, .18))
    k += 1; t += b / 4
mus = x[:N] / np.abs(x[:N]).max() * .45
fx = np.zeros(N + sr * 2)
def fxadd(i0, sig, g=1):
    i0 = int(i0); e = min(len(fx), i0 + len(sig)); fx[i0:e] += sig[:e - i0] * g
def pop(f=900): tt, e = env(.12, 40); return np.sin(2 * np.pi * f * (1 + .7 * np.exp(-tt * 40)) * tt) * e
def boom(): tt, e = env(1.2, 3); return np.sin(2 * np.pi * (45 + 60 * np.exp(-tt * 8)) * tt) * e
def horn():
    tt = np.arange(int(.9 * sr)) / sr; e = np.minimum(1, tt / .02) * np.minimum(1, (.9 - tt) / .1)
    return sum(((2 * ((f * tt) % 1) - 1)) for f in (466, 587, 698)) * e * .12
for i, s in enumerate(S):
    if i: fxadd((starts[i] - .15) * sr, np.convolve(rng.normal(0, 1, int(.3 * sr)), np.ones(25) / 25, "same") * np.sin(np.pi * np.arange(int(.3 * sr)) / int(.3 * sr)) ** 2, .5)
    for html, kind, t0 in s["layers"]:
        tt = (starts[i] + t0) * sr
        if kind in ("up", "pop") and t0 > 0.02: fxadd(tt, pop(1000 if kind == "pop" else 800), .35)
        if kind == "shake": fxadd(tt + .3 * sr, boom(), .9)
        if "GOOOOL" in html: fxadd(tt, horn(), 1); fxadd(tt, boom(), .7)
fx = fx[:N]
y = mus + fx * .9
y *= np.minimum(1, (total - np.arange(N) / sr) / .15)
y = y / np.abs(y).max() * .9; sf.write("memmix.wav", np.stack([y, y], 1).astype(np.float32), sr)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-i", "memmix.wav", "-c:v", "libx264", "-preset", "medium", "-b:v", "4000k", "-maxrate", "6000k", "-bufsize", "9000k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", out], check=True)
print(total)
