from kit import *
INK = "#1A1412"
def mom(x, y, s=1.0, expr="tired", arms="down", prop=None):
    eyes = {
     "tired": '<path d="M-58,-20 q22,-6 44,0" stroke="#1A1412" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M14,-20 q22,-6 44,0" stroke="#1A1412" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M-62,2 q26,16 52,0 M10,2 q26,16 52,0" stroke="#9A6A8A" stroke-width="8" fill="none" opacity=".7"/><path d="M-22,62 q22,-8 44,0" stroke="#1A1412" stroke-width="8" fill="none" stroke-linecap="round"/>',
     "shock": '<circle cx="-36" cy="-16" r="26" fill="#FFF"/><circle cx="36" cy="-16" r="26" fill="#FFF"/><circle cx="-36" cy="-14" r="11" fill="#1A1412"/><circle cx="36" cy="-14" r="11" fill="#1A1412"/><ellipse cx="0" cy="62" rx="18" ry="24" fill="#5A1A14"/>',
     "happy": '<path d="M-60,-14 q24,-26 48,0 M12,-14 q24,-26 48,0" stroke="#1A1412" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M-48,40 q48,60 96,0 Z" fill="#5A1A14"/><path d="M-40,44 q40,12 80,0" stroke="#FFF" stroke-width="10"/><circle cx="-70" cy="26" r="16" fill="#E88A7A" opacity=".6"/><circle cx="70" cy="26" r="16" fill="#E88A7A" opacity=".6"/>',
     "sweat": '<circle cx="-36" cy="-16" r="24" fill="#FFF"/><circle cx="36" cy="-16" r="24" fill="#FFF"/><circle cx="-30" cy="-16" r="8" fill="#1A1412"/><circle cx="42" cy="-16" r="8" fill="#1A1412"/><rect x="-40" y="44" width="80" height="30" rx="8" fill="#FFF" stroke="#1A1412" stroke-width="6"/><line x1="-14" y1="44" x2="-14" y2="74" stroke="#1A1412" stroke-width="4"/><line x1="14" y1="44" x2="14" y2="74" stroke="#1A1412" stroke-width="4"/><path d="M96,-80 q14,30 0,44 q-14,-14 0,-44 Z M120,-20 q10,22 0,32 q-10,-10 0,-32 Z" fill="#7AB8E8"/>',
     "smug": '<path d="M-58,-16 h44 M14,-16 h44" stroke="#1A1412" stroke-width="10" stroke-linecap="round"/><path d="M-60,-30 q22,-10 44,0 M14,-30 q22,-10 44,0" stroke="#1A1412" stroke-width="5" fill="none"/><path d="M-26,56 q30,14 56,-10" stroke="#1A1412" stroke-width="8" fill="none" stroke-linecap="round"/>',
    }[expr]
    armsvg = {"down": f'<path d="M-150,330 C-190,420 -170,520 -140,560" stroke="{TERRA}" stroke-width="70" stroke-linecap="round" fill="none"/><path d="M150,330 C190,420 170,520 140,560" stroke="{TERRA}" stroke-width="70" stroke-linecap="round" fill="none"/>',
              "up": f'<path d="M-150,320 C-230,220 -260,120 -250,20" stroke="{TERRA}" stroke-width="70" stroke-linecap="round" fill="none"/><path d="M150,320 C230,220 260,120 250,20" stroke="{TERRA}" stroke-width="70" stroke-linecap="round" fill="none"/><circle cx="-250" cy="0" r="40" fill="{SKIN}"/><circle cx="250" cy="0" r="40" fill="{SKIN}"/>',
              "front": f'<path d="M-150,330 C-150,420 -60,470 0,470" stroke="{TERRA}" stroke-width="70" stroke-linecap="round" fill="none"/><path d="M150,330 C150,420 60,470 0,470" stroke="{TERRA}" stroke-width="70" stroke-linecap="round" fill="none"/>'}[arms]
    p = ""
    if prop == "coffee": p = f'<g transform="translate(120,470)"><path d="M-60,-70 L60,-70 L48,60 L-48,60 Z" fill="#FFF8F0" stroke="{INK}" stroke-width="6"/><path d="M60,-40 c50,0 50,60 -6,60" stroke="{INK}" stroke-width="10" fill="none"/><path d="M-30,-90 c-14,-24 14,-34 0,-60 M20,-90 c-14,-24 14,-34 0,-60" stroke="#8AA" stroke-width="6" fill="none"/></g>'
    if prop == "wheel": p = f'<g transform="translate(0,520)"><circle r="190" fill="none" stroke="{INK}" stroke-width="40"/><rect x="-190" y="-12" width="380" height="24" fill="{INK}"/><circle r="40" fill="{INK}"/></g><circle cx="-170" cy="470" r="44" fill="{SKIN}"/><circle cx="170" cy="470" r="44" fill="{SKIN}"/>'
    return f'''<g transform="translate({x},{y}) scale({s})">
<path d="M-230,700 C-240,450 -170,300 -60,270 L60,270 C170,300 240,450 230,700 Z" fill="{TERRA}"/>
<path d="M-40,180 L-40,280 L40,280 L40,180 Z" fill="{SKIN}"/>
<ellipse cx="0" cy="0" rx="150" ry="170" fill="{SKIN}"/>
<path d="M-158,-10 C-170,-200 160,-210 158,-10 C120,-110 -60,-150 -158,-10 Z" fill="{HAIR}"/>
<circle cx="20" cy="-205" r="80" fill="{HAIR}"/><path d="M60,-270 q40,-30 30,20 M-20,-275 q-30,-30 -40,10" stroke="{HAIR}" stroke-width="12" fill="none"/>
<path d="M-158,-10 C-180,90 -160,170 -120,190 C-140,100 -140,20 -120,-50 Z" fill="{HAIR}"/>
{eyes}{armsvg}{p}</g>'''
def baby(x, y, s=1.0, expr="grin"):
    face = {"grin": '<circle cx="-34" cy="-10" r="12" fill="#1A1412"/><circle cx="34" cy="-10" r="12" fill="#1A1412"/><circle cx="-30" cy="-14" r="4" fill="#FFF"/><circle cx="38" cy="-14" r="4" fill="#FFF"/><path d="M-44,30 q44,60 88,0 Z" fill="#5A1A14"/><circle cx="-66" cy="22" r="16" fill="#E88A7A" opacity=".6"/><circle cx="66" cy="22" r="16" fill="#E88A7A" opacity=".6"/>',
            "sleep": '<path d="M-50,-6 q16,14 32,0 M18,-6 q16,14 32,0" stroke="#1A1412" stroke-width="7" fill="none" stroke-linecap="round"/><ellipse cx="0" cy="40" rx="10" ry="8" fill="#5A1A14"/><text x="90" y="-90" font-family="Anton" font-size="70" fill="#7A9AC8">z z</text>'}[expr]
    return f'''<g transform="translate({x},{y}) scale({s})"><path d="M-130,260 C-150,150 -90,110 0,110 C90,110 150,150 130,260 Z" fill="{SAGE}"/>
<circle cx="0" cy="0" r="120" fill="{SKIN2}"/><path d="M-10,-120 q30,-40 50,-10 q-20,-10 -30,20" fill="{HAIR}"/><circle cx="-118" cy="0" r="22" fill="{SKIN2}"/><circle cx="118" cy="0" r="22" fill="{SKIN2}"/>{face}</g>'''
def confetti(seed=1):
    r = random.Random(seed)
    return "".join(f'<rect x="{r.uniform(0,1080):.0f}" y="{r.uniform(600,1700):.0f}" width="{r.uniform(14,26):.0f}" height="{r.uniform(26,44):.0f}" fill="{r.choice([TERRA,SAGE,MUST,BLUE,"#2E8B57","#F2C200"])}" transform="rotate({r.uniform(0,90):.0f} 540 960)"/>' for _ in range(60))
def card(top, text, size=62, bg="#FFFFFF"):
    return f'<div style="position:absolute;left:70px;right:70px;top:{top}px;background:{bg};border-radius:34px;padding:38px 44px;box-shadow:0 10px 0 #1A1412;border:6px solid #1A1412"><div style="font-family:Montserrat;font-weight:900;font-size:{size}px;line-height:1.12;color:#1A1412">{text}</div></div>'
def tag(text, col=TERRA): return f'<div style="position:absolute;left:70px;top:150px"><span style="display:inline-block;background:{col};color:#FFF;font-family:Montserrat;font-weight:900;font-size:34px;letter-spacing:3px;padding:14px 30px;border-radius:40px;border:5px solid #1A1412">{text}</span></div>'
