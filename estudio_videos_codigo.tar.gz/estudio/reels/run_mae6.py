"""Monta o Reel 0 a 6 meses: vídeo (engine), legenda ASS no estilo boho, trilha de ninar com a voz por cima."""
import json, re, subprocess, sys, numpy as np, soundfile as sf
import engine
EP = "../roteiros/mae6"; OUT = "../saida/Reel_Maternidade_0a6meses.mp4"
S, starts = engine.build("mae6", "layers_mae6", "mae6_raw.mp4")
total = float(starts[-1]); meta = json.load(open(f"{EP}/timing.json"))
def ts(x): x = max(0, x); return f"{int(x//3600)}:{int(x%3600//60):02d}:{x%60:05.2f}"
ev = []
for m in meta:
    words = m["text"].split(); wts = [len(re.sub(r"[^\wÀ-ú%]", "", w)) + 2 + (4 if re.search(r"[,.:?]$", w) else 0) for w in words]
    tot = sum(wts); t0 = m["start"] + 0.05; span = m["speech"] - 0.1; acc = 0; times = []
    for w in wts: times.append((t0 + span * acc / tot, t0 + span * (acc + w) / tot)); acc += w
    chunks, cur = [], []
    for i, w in enumerate(words):
        cur.append(i)
        if len(cur) == 3 or re.search(r"[,.:?]$", w) or i == len(words) - 1: chunks.append(cur); cur = []
    for ch in chunks:
        for i in ch:
            txt = " ".join((r"{\c&H5A73C8&}" + words[j] + r"{\c&H242A3A&}") if j == i else words[j] for j in ch)
            ev.append([times[i][0], times[i][1], txt])
ev.sort(key=lambda e: e[0])
for a, b in zip(ev, ev[1:]): a[1] = min(b[0], a[1] + 0.4)
head = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Montserrat,54,&H00242A3A,&H00242A3A,&H00E6EFF7,&H00E6EFF7,1,0,0,0,100,100,0,0,3,16,0,5,60,60,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
open("mae6.ass", "w").write(head + "\n".join(f"Dialogue: 1,{ts(a)},{ts(b)},Cap,,0,0,0,,{{\\pos(540,1655)}}{x}" for a, b, x in ev) + "\n")
subprocess.run([sys.executable, "music.py", str(total), "mae6_music.wav"], check=True)
mus, sr = sf.read("mae6_music.wav"); mus = mus[:, 0]
v, vsr = sf.read(f"{EP}/narracao.wav"); v = np.interp(np.arange(0, len(v), vsr / sr), np.arange(len(v)), v)
N = len(mus); voice = np.zeros(N); voice[:min(N, len(v))] = v[:N]
env = np.convolve(np.abs(voice), np.ones(int(0.25 * sr)) / int(0.25 * sr), mode="same")
duck = 1 - 0.6 * np.clip(env / (env.max() * 0.25), 0, 1)
y = voice * 0.95 + mus * 0.28 * duck
y = y / np.abs(y).max() * 0.92
sf.write("mae6_mix.wav", np.stack([y, y], 1).astype(np.float32), sr)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "mae6_raw.mp4", "-i", "mae6_mix.wav", "-vf", "ass=mae6.ass", "-c:v", "libx264", "-preset", "medium",
                "-b:v", "3000k", "-maxrate", "4500k", "-bufsize", "7000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", "-shortest", OUT], check=True)
print("done", round(total, 1))
