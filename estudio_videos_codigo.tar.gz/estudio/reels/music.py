import numpy as np, soundfile as sf, sys
sr = 44100; total = float(sys.argv[1]); out = sys.argv[2]; N = int(total * sr); t = np.arange(N) / sr
bpm = 76; beat = 60 / bpm
def note(f, L, amp):
    tt = np.arange(int(L * sr)) / sr
    s = sum(a * np.sin(2 * np.pi * f * h * tt) for h, a in ((1, 1), (2, .35), (3, .12), (4, .05)))
    return s * np.exp(-tt * 2.6) * np.minimum(1, tt / 0.005) * amp
mid = lambda m: 440 * 2 ** ((m - 69) / 12)
prog = [[60, 64, 67, 72], [55, 59, 62, 67], [57, 60, 64, 69], [53, 57, 60, 65]]  # C G Am F
mel = [76, 74, 72, 74, 76, 76, 76, None, 74, 74, 74, None, 76, 79, 79, None]
mus = np.zeros(N + sr * 3); pad = np.zeros(N + sr * 3)
k = 0; tb = 0.0
while tb < total:
    ch = prog[(k // 8) % 4]; arp = [ch[0], ch[1], ch[2], ch[3], ch[2], ch[1], ch[2], ch[3]][k % 8]
    i0 = int(tb * sr); n = note(mid(arp), 1.6, .22); mus[i0:i0 + len(n)] += n
    if k % 8 == 0:
        L = 8 * beat / 2; tt = np.arange(int(L * sr)) / sr; env = np.minimum(1, tt / .6) * np.minimum(1, (L - tt) / .6)
        pad[i0:i0 + len(tt)] += sum(np.sin(2 * np.pi * mid(m - 12) * tt) for m in ch[:3]) * env * .05
    if k % 2 == 0 and k >= 16:
        m = mel[(k // 2) % 16]
        if m: n = note(mid(m), 1.4, .13); mus[i0:i0 + len(n)] += n
    k += 1; tb += beat / 2
x = (mus + pad)[:N]
# soft reverb
ir = np.exp(-np.arange(int(1.2 * sr)) / sr * 4) * np.random.default_rng(1).normal(0, 1, int(1.2 * sr)) * .02
x = x + np.convolve(x, ir)[:N] * .6
fade = np.minimum(1, t / 0.05) * np.minimum(1, (total - t) / 0.4)
x = x * fade; x = x / np.abs(x).max() * 0.7
sf.write(out, np.stack([x, x], 1).astype(np.float32), sr)
