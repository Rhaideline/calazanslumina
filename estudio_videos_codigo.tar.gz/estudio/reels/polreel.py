import json
T = json.load(open("../pol/timing.json"))
RED = "#E63946"; YEL = "#FFD23F"; BG = "#0E0F12"
def page(body):
    return f'''<html><head><style>html,body{{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}}
.c{{position:absolute;left:80px;right:80px;color:#F4F1EA;font-family:Montserrat}}
.big{{font-family:Anton;line-height:1;letter-spacing:1px}} .k{{font-family:Montserrat;font-weight:900;text-transform:uppercase;letter-spacing:4px;font-size:34px;color:{RED}}}
.b{{font-weight:600;font-size:50px;line-height:1.3}} .b b{{color:{YEL};font-weight:800}}
.hl{{background:{YEL};color:#111;padding:0 14px;font-weight:900}}
.src{{position:absolute;left:80px;right:80px;top:1560px;font-family:'DejaVu Sans Mono',monospace;font-size:26px;color:#9A9AA2}}
.card{{background:#1A1C21;border:3px solid #2E3138;border-radius:24px;padding:34px 40px}}
</style></head><body>{body}</body></html>'''
def C(top, inner, cls="c", style=""): return f'<div class="{cls}" style="top:{top}px;{style}">{inner}</div>'
def bgsvg(seed, accent=RED):
    import random; r = random.Random(seed)
    lines = "".join(f'<line x1="0" y1="{y}" x2="1080" y2="{y}" stroke="#FFFFFF" stroke-opacity=".025" stroke-width="2"/>' for y in range(0, 1920, 8))
    return page(f'''<svg width="1080" height="1920" style="position:absolute;left:0;top:0"><defs><radialGradient id="g" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="{accent}" stop-opacity=".22"/><stop offset="1" stop-color="{accent}" stop-opacity="0"/></radialGradient>
<filter id="n"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="{seed}"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .07"/></feComponentTransfer></filter></defs>
<rect width="1080" height="1920" fill="{BG}"/><rect width="1080" height="1920" fill="url(#g)"/>{lines}<rect width="1080" height="1920" filter="url(#n)"/></svg>''')
FOOT = page(f'<div style="position:absolute;left:80px;right:80px;top:150px;display:flex;justify-content:space-between;font-family:Montserrat;font-weight:800;font-size:26px;letter-spacing:3px;color:#C9C9CF"><span>2º TURNO · 25/10</span><span style="color:{RED}">● CHECADO</span></div>'
            f'<div style="position:absolute;left:80px;right:80px;top:1640px;font-family:Montserrat;font-weight:600;font-size:22px;color:#77777F">Conteúdo produzido com auxílio de inteligência artificial · fontes na legenda</div>')
def src(t): return page(f'<div class="src">fonte: {t}</div>')
D = [m["dur"] for m in T]; D[-1] += 0.3
S = []
S.append(dict(dur=D[0], layers=[(bgsvg(1), "bg", 0), (FOOT, "still", 0),
    (page(C(380, f'<div class="big" style="font-size:300px;color:{RED}">47,03%</div>')), "pop", 0.0),
    (page(C(720, '<div class="b">dos votos válidos foram pro <b>Flávio Bolsonaro</b> no 1º turno</div>')), "up", 0.5),
    (page(C(1040, '<div class="b" style="font-size:66px;font-weight:900">mas quantos <span class="hl">leram o plano</span> dele?</div>')), "pop", 4.2),
    (src("TSE, resultado oficial do 1º turno"), "up", 0.8)]))
DOC = page(f'''<svg width="1080" height="1920" style="position:absolute;left:0;top:0">
<g transform="translate(540,1050) rotate(-4)"><rect x="-330" y="-430" width="660" height="860" fill="#E9E4D8"/><rect x="-310" y="-450" width="660" height="860" fill="#F4F1EA"/>
<text x="20" y="-350" font-family="Anton" font-size="54" text-anchor="middle" fill="#111">PARA O BRASIL</text><text x="20" y="-285" font-family="Anton" font-size="54" text-anchor="middle" fill="#111">VENCER O ATRASO</text>
<text x="20" y="-230" font-family="Montserrat" font-weight="700" font-size="28" text-anchor="middle" fill="#555">plano de governo registrado no TSE</text>
{"".join(f'<rect x="-250" y="{-170+k*52}" width="{520-(k%4)*70}" height="14" fill="#C9C4B8"/>' for k in range(11))}
<rect x="-262" y="10" width="420" height="34" fill="{YEL}" opacity=".7"/><rect x="-262" y="114" width="300" height="34" fill="{YEL}" opacity=".7"/><rect x="-262" y="270" width="380" height="34" fill="{YEL}" opacity=".7"/>
<text x="230" y="380" font-family="Anton" font-size="70" text-anchor="middle" fill="{RED}">76 PÁG.</text></g></svg>''')
S.append(dict(dur=D[1], layers=[(bgsvg(2), "bg", 0), (FOOT, "still", 0), (DOC, "ill", 0.0),
    (page(C(330, '<div class="big" style="font-size:150px">EU LI.</div>')), "pop", 0.1),
    (src("plano de governo de Flávio Bolsonaro, TSE / Agência Brasil"), "up", 0.5)]))
S.append(dict(dur=D[2], layers=[(bgsvg(3), "bg", 0), (FOOT, "still", 0),
    (page(C(330, '<div class="k">proposta 1 · segurança</div><div class="big" style="font-size:110px;margin-top:20px">MAIORIDADE PENAL</div>')), "up", 0.0),
    (page(C(620, f'<div class="big" style="font-size:330px"><span style="color:#77777F">18</span> <span style="font-size:200px;color:#77777F">→</span> <span style="color:{RED}">14</span></div>')), "pop", 1.2),
    (page(C(1080, '<div class="card b">14 anos: idade de quem ainda está no <b>ensino fundamental</b></div>')), "up", 3.6),
    (src("Agência Brasil, set/2026"), "up", 0.5)]))
DROP = page(f'''<svg width="1080" height="1920" style="position:absolute;left:0;top:0"><g transform="translate(540,1120)">
<path d="M0,-260 C90,-120 180,-20 180,80 C180,190 100,260 0,260 C-100,260 -180,190 -180,80 C-180,-20 -90,-120 0,-260 Z" fill="#3A7CA5"/>
<path d="M-40,-120 L20,-30 L-30,40 L30,140" stroke="{BG}" stroke-width="16" fill="none" stroke-linejoin="bevel"/>
<path d="M-90,60 C-90,140 -40,190 10,200" stroke="#FFFFFF" stroke-opacity=".45" stroke-width="14" fill="none" stroke-linecap="round"/></g></svg>''')
S.append(dict(dur=D[3], layers=[(bgsvg(4, "#3A7CA5"), "bg", 0), (FOOT, "still", 0),
    (page(C(330, '<div class="k">proposta 2 · meio ambiente</div><div class="big" style="font-size:120px;margin-top:20px">FRACKING<br><span style="color:#E63946">LIBERADO</span></div>')), "up", 0.0),
    (DROP, "ill", 0.8),
    (page(C(1380, '<div class="b" style="font-size:42px">proibido em países como <b>França e Irlanda</b> pelo risco à água</div>')), "up", 4.0),
    (src("Agência Brasil, set/2026"), "up", 0.5)]))
S.append(dict(dur=D[4], layers=[(bgsvg(5), "bg", 0), (FOOT, "still", 0),
    (page(C(330, '<div class="k">proposta 3 · saúde</div>')), "up", 0.0),
    (page(C(460, '<div class="card"><div class="big" style="font-size:96px">SEUS DADOS<br>DO SUS</div></div>')), "up", 0.2),
    (page(C(860, f'<div class="big" style="font-size:180px;color:{RED};text-align:center">↓</div>')), "pop", 1.4),
    (page(C(1080, '<div class="card"><div class="big" style="font-size:96px;color:#FFD23F">HOSPITAIS<br>PRIVADOS</div></div>')), "up", 1.6),
    (src("Agência Brasil, set/2026"), "up", 0.5)]))
S.append(dict(dur=D[5], layers=[(bgsvg(6), "bg", 0), (FOOT, "still", 0),
    (page(C(330, '<div class="k">o caso</div><div class="big" style="font-size:150px;margin-top:20px">BANCO<br>MASTER</div>')), "up", 0.0),
    (page(C(760, '<div class="card b">Daniel Vorcaro, o dono: <b>preso</b> tentando sair do país num jatinho <span style="color:#9A9AA2">(nov/2025)</span></div>')), "up", 1.0),
    (page(C(1130, f'<div class="b">rombo pode chegar a</div><div class="big" style="font-size:170px;color:{RED}">R$ 12 BI</div>')), "pop", 4.8),
    (src("Banco Central / imprensa; Wikipedia: Banco Master scandal"), "up", 0.5)]))
S.append(dict(dur=D[6], layers=[(bgsvg(7), "bg", 0), (FOOT, "still", 0),
    (page(C(330, '<div class="k">flávio + vorcaro</div>')), "up", 0.0),
    (page(C(430, f'<div class="b">negociado com Vorcaro:</div><div class="big" style="font-size:190px;color:{YEL}">R$ 134 MI</div>')), "pop", 3.8),
    (page(C(780, f'<div class="b">pagos, pelo menos:</div><div class="big" style="font-size:190px;color:{RED}">R$ 61 MI</div>')), "pop", 8.6),
    (page(C(1150, '<div class="card b" style="font-size:42px">para o filme <b>"Dark Horse"</b>, sobre Jair Bolsonaro</div>')), "up", 6.0),
    (src("Intercept Brasil; registros da Polícia Federal (via A Tarde)"), "up", 0.5)]))
STAMP = page(f'<div style="position:absolute;left:0;right:0;top:1040px;text-align:center"><span style="display:inline-block;transform:rotate(-7deg);border:12px solid {RED};color:{RED};font-family:Anton;font-size:120px;padding:10px 40px;border-radius:18px">INVESTIGADO NO STF</span></div>')
S.append(dict(dur=D[7], layers=[(bgsvg(8), "bg", 0), (FOOT, "still", 0),
    (page(C(330, '<div class="card b"><span style="color:#9A9AA2">antes:</span> negou conhecer Vorcaro</div>')), "up", 0.0),
    (page(C(560, '<div class="card b"><span style="color:#9A9AA2">depois:</span> <b>admitiu a aproximação</b></div>')), "up", 2.0),
    (STAMP, "pop", 4.2),
    (page(C(1380, '<div class="b" style="font-size:40px;text-align:center">suspeitas: lavagem de dinheiro · evasão de divisas · corrupção</div>')), "up", 5.2),
    (src("A Tarde; STF, inquérito autorizado em jul/2026"), "up", 0.5)]))
URNA = page(f'''<div style="position:absolute;left:0;right:0;top:1080px;text-align:center"><span style="display:inline-block;background:#2E9E4A;color:#fff;font-family:Montserrat;font-weight:900;font-size:80px;padding:34px 70px;border-radius:20px;box-shadow:0 14px 0 #1E6E32">CONFIRMA</span></div>''')
S.append(dict(dur=D[8], layers=[(bgsvg(9), "bg", 0), (FOOT, "still", 0),
    (page(C(380, f'<div class="big" style="font-size:120px">INVESTIGAÇÃO<br><span style="color:{RED}">NÃO É</span><br>CONDENAÇÃO</div>')), "up", 0.0),
    (page(C(860, '<div class="b">mas é o mínimo que você precisa saber antes de apertar</div>')), "up", 1.8),
    (URNA, "pop", 3.4)]))
S.append(dict(dur=D[9], layers=[(bgsvg(10, YEL), "bg", 0), (FOOT, "still", 0),
    (page(C(330, f'<div class="big" style="font-size:190px">25 DE<br><span style="color:{YEL}">OUTUBRO</span></div>')), "pop", 0.0),
    (page(C(830, '<div class="card b">leia os planos dos dois candidatos em <b>tse.jus.br</b> e compare</div>')), "up", 2.2),
    (page(C(1180, f'<div class="b" style="font-size:58px;font-weight:900">manda pra quem <span class="hl">ainda não leu</span></div>')), "pop", 4.6)]))
