import asyncio, os, sys, math, subprocess, importlib, numpy as np, cv2
W, H, FPS = 1080, 1920, 30
async def _render(jobs):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": W, "height": H})
        for html, out in jobs:
            await pg.set_content(html); await pg.wait_for_timeout(150)
            await pg.screenshot(path=out, omit_background=True)
        await b.close()
def ease(x): x = min(1, max(0, x)); return 1 - (1 - x) ** 3
def back(x):
    x = min(1, max(0, x)); c = 1.7; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def build(mod, outdir, out, render=True):
    S = importlib.import_module(mod).S; os.makedirs(outdir, exist_ok=True)
    if render:
        jobs = [(ly[0], f"{outdir}/{i:02d}_{k}.png") for i, s in enumerate(S) for k, ly in enumerate(s["layers"])]
        asyncio.run(_render(jobs))
    imgs = [[cv2.cvtColor(cv2.imread(f"{outdir}/{i:02d}_{k}.png", cv2.IMREAD_UNCHANGED), cv2.COLOR_BGRA2RGBA).astype(np.float32) / 255 for k in range(len(s["layers"]))] for i, s in enumerate(S)]
    starts = np.cumsum([0] + [s["dur"] for s in S]); total = starts[-1]; N = int(total * FPS)
    rng = np.random.default_rng(1); grain = [rng.normal(0, 1, (H // 2, W // 2)).astype(np.float32) for _ in range(6)]
    def frame(i, t):
        s = S[i]; out = np.zeros((H, W, 3), np.float32)
        for k, ly in enumerate(s["layers"]):
            html, kind, t0 = ly[:3]; t1 = ly[3] if len(ly) > 3 else None
            im = imgs[i][k]; lt = t - t0; a = 1.0; sc = 1.0; dx = dy = 0
            fo = max(0, 1 - (t - t1) / 0.25) if (t1 is not None and t > t1) else 1.0
            if fo <= 0: continue
            if kind.startswith("type") or kind.startswith("drop"):
                d = float(kind[4:] or 1.4); p = min(1, max(0, lt / d))
                if p <= 0: continue
                im = im.copy()
                if kind.startswith("type"): im[:, int(W * p):, 3] = 0
                else: im[int(H * p):, :, 3] = 0
            if kind == "bg": sc = 1.0 + 0.045 * t / s["dur"]
            elif kind == "up":
                p = ease(lt / 0.45); a = p; dy = 70 * (1 - p)
            elif kind == "pop":
                p = back(lt / 0.42); a = min(1, max(0, lt / 0.15)); sc = 0.7 + 0.3 * p
            elif kind == "shake":
                p = ease(lt / 0.4); a = p; dx = 14 * math.sin(t * 55) * (1 if lt > 0.3 else 0); dy = 10 * math.cos(t * 47) * (1 if lt > 0.3 else 0)
            elif kind == "ill":
                p = ease(lt / 0.7); a = p; sc = 0.92 + 0.08 * p; dy = 40 * (1 - p) + 10 * math.sin(t * 1.6)
            if a <= 0: continue
            cx, cy = W / 2, (H / 2 if kind == "bg" else (1200 if kind == "ill" else 600))
            M = np.float32([[sc, 0, (1 - sc) * cx + dx], [0, sc, (1 - sc) * cy + dy]])
            w = cv2.warpAffine(im, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) if (sc != 1 or dx or dy) else im
            al = w[:, :, 3:4] * a * fo; out = out * (1 - al) + w[:, :, :3] * al
        return out
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    XF = 0.3
    for n in range(N):
        t = n / FPS; i = int(np.searchsorted(starts, t, side="right") - 1); i = min(i, len(S) - 1); tl = t - starts[i]
        fr = frame(i, tl)
        if i + 1 < len(S) and starts[i + 1] - t < XF:
            a = 1 - (starts[i + 1] - t) / XF; a = a * a * (3 - 2 * a)
            fr = fr * (1 - a) + frame(i + 1, t - starts[i + 1]) * a
        g = cv2.resize(grain[n % 6], (W, H))[:, :, None] * 0.012; fr = fr + g
        bar = int(W * t / total); fr[H - 10:H, :bar] = (fr[H - 10:H, :bar] * 0.2 + np.array([0.78, 0.45, 0.35]) * 0.8)
        enc.stdin.write((np.clip(fr, 0, 1) * 255).astype(np.uint8).tobytes())
    enc.stdin.close(); enc.wait(); return S, starts
if __name__ == "__main__":
    build(sys.argv[1], sys.argv[2], sys.argv[3], render=len(sys.argv) < 5)
