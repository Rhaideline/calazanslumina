import json, random
T = json.load(open("../pol2/timing.json"))
RED = "#E63946"; YEL = "#FFD23F"; BG = "#0B0C10"; GRN = "#2E9E4A"; BLU = "#3A7CA5"
D = [m["dur"] for m in T]; D[-1] += 0.4

def page(body):
    return f'''<html><head><style>html,body{{margin:0;width:1080px;height:1920px;background:transparent;overflow:hidden}}
.c{{position:absolute;left:80px;right:80px;color:#F4F1EA;font-family:Montserrat}}
.big{{font-family:Anton;line-height:.98;letter-spacing:1px}}
.k{{font-family:Montserrat;font-weight:900;text-transform:uppercase;letter-spacing:5px;font-size:32px;color:{RED}}}
.b{{font-weight:600;font-size:50px;line-height:1.3}} .b b{{color:{YEL};font-weight:800}}
.hl{{background:{YEL};color:#111;padding:0 14px;font-weight:900}}
.q{{font-family:Lora;font-style:italic;font-weight:700;font-size:78px;line-height:1.15;color:#fff}}
.who{{font-family:Montserrat;font-weight:700;font-size:32px;color:#A9A9B2;margin-top:26px}}
.card{{background:#16181D;border:3px solid #2A2D35;border-radius:26px;padding:34px 40px}}
.src{{position:absolute;left:80px;right:80px;top:1555px;font-family:'DejaVu Sans Mono',monospace;font-size:25px;color:#8E8E97}}
.stamp{{display:inline-block;border:12px solid {RED};color:{RED};font-family:Anton;padding:8px 36px;border-radius:18px}}
</style></head><body>{body}</body></html>'''
def C(top, inner, style=""): return f'<div class="c" style="top:{top}px;{style}">{inner}</div>'
def P(top, inner, style=""): return page(C(top, inner, style))
def bg(seed, accent=RED, a=.22):
    lines = "".join(f'<line x1="0" y1="{y}" x2="1080" y2="{y}" stroke="#FFFFFF" stroke-opacity=".022" stroke-width="2"/>' for y in range(0, 1920, 8))
    return page(f'''<svg width="1080" height="1920" style="position:absolute;left:0;top:0"><defs><radialGradient id="g" cx=".5" cy=".38" r=".85"><stop offset="0" stop-color="{accent}" stop-opacity="{a}"/><stop offset="1" stop-color="{accent}" stop-opacity="0"/></radialGradient>
<radialGradient id="v" cx=".5" cy=".5" r=".75"><stop offset=".6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".65"/></radialGradient>
<filter id="n"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="{seed}"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .08"/></feComponentTransfer></filter></defs>
<rect width="1080" height="1920" fill="{BG}"/><rect width="1080" height="1920" fill="url(#g)"/>{lines}<rect width="1080" height="1920" filter="url(#n)"/><rect width="1080" height="1920" fill="url(#v)"/></svg>''')
HEAD = page(f'<div style="position:absolute;left:80px;right:80px;top:150px;display:flex;justify-content:space-between;font-family:Montserrat;font-weight:800;font-size:26px;letter-spacing:3px;color:#C9C9CF"><span>2º TURNO · 25/10</span><span style="color:{RED}">● CHECADO COM FONTES</span></div>'
            f'<div style="position:absolute;left:80px;right:80px;top:1640px;font-family:Montserrat;font-weight:600;font-size:22px;color:#6E6E77">Conteúdo produzido com auxílio de inteligência artificial · fontes na legenda</div>')
def src(t): return page(f'<div class="src">fonte: {t}</div>')
def chapter(n, t): return P(230, f'<div class="k" style="color:#A9A9B2">parte {n} · <span style="color:{RED}">{t}</span></div>')
def svg(inner): return page(f'<svg width="1080" height="1920" style="position:absolute;left:0;top:0">{inner}</svg>')

GAVEL = svg(f'''<g transform="translate(820,1250) rotate(-30)" fill="#C9A15A"><rect x="-40" y="-150" width="80" height="300" rx="22"/><rect x="-170" y="-60" width="340" height="120" rx="40" fill="#8A6A3A"/><rect x="-14" y="150" width="28" height="300" rx="12" fill="#6A4A2A"/></g>
<rect x="560" y="1500" width="420" height="50" rx="12" fill="#3A2A1A"/>''')
JET = svg(f'''<g transform="translate(540,960)"><path d="M-300,0 L260,-20 Q330,-20 340,0 Q330,20 260,20 L-300,10 Z" fill="#D8DCE2"/><path d="M-40,-10 L-160,-170 L-100,-170 L60,-10 Z M-40,10 L-160,170 L-100,170 L60,10 Z" fill="#B8BEC8"/><path d="M-280,-4 L-330,-110 L-290,-110 L-230,-4 Z" fill="#B8BEC8"/>{"".join(f'<circle cx="{120-k*60}" cy="-6" r="9" fill="#3A4A5A"/>' for k in range(6))}</g>
<path d="M120,1200 C340,1160 600,1120 900,1030" stroke="#FFFFFF" stroke-opacity=".4" stroke-width="6" stroke-dasharray="20 18" fill="none"/>''')

def phone(bubbles):
    # bubbles: list of (side, html, color)
    out = [f'<div style="position:absolute;left:150px;right:150px;top:330px;height:1180px;background:#0F1A14;border:10px solid #2A2D35;border-radius:60px;overflow:hidden">'
           f'<div style="background:#1F2C26;padding:26px 34px;font-family:Montserrat;font-weight:800;font-size:32px;color:#E8F0EA">Daniel Vorcaro <span style="font-weight:500;font-size:24px;color:#9AB0A4">· reprodução</span></div>']
    return out
def bubble(top, side, html, col="#1F5C40", w=560):
    x = "right:180px" if side == "r" else "left:180px"
    return page(f'<div style="position:absolute;{x};top:{top}px;max-width:{w}px;background:{col};color:#F4F8F5;font-family:Montserrat;font-weight:600;font-size:38px;line-height:1.3;padding:24px 30px;border-radius:28px">{html}</div>')
PHONE = page(f'<div style="position:absolute;left:150px;right:150px;top:300px;height:1220px;background:#0E1612;border:10px solid #2A2D35;border-radius:60px;overflow:hidden">'
             f'<div style="background:#1C2822;padding:28px 36px;font-family:Montserrat;font-weight:800;font-size:32px;color:#E8F0EA">Daniel Vorcaro</div></div>'
             f'<div style="position:absolute;left:0;right:0;top:1530px;text-align:center;font-family:Montserrat;font-weight:600;font-size:24px;color:#8E8E97">reprodução das mensagens divulgadas pela Polícia Federal</div>')
DATE = lambda top, t: page(f'<div style="position:absolute;left:0;right:0;top:{top}px;text-align:center"><span style="background:#26332C;color:#C8D8CE;font-family:Montserrat;font-weight:700;font-size:26px;padding:10px 24px;border-radius:14px">{t}</span></div>')

def ground_section(contam=False):
    g = f'<rect x="0" y="900" width="1080" height="140" fill="#5A4632"/><rect x="0" y="1040" width="1080" height="130" fill="{BLU}"/><text x="60" y="1120" font-family="Montserrat" font-weight="800" font-size="34" fill="#E8F4FF">ÁGUA SUBTERRÂNEA</text>'
    g += f'<rect x="0" y="1170" width="1080" height="160" fill="#4A3A2A"/><rect x="0" y="1330" width="1080" height="200" fill="#3A2C20"/>'
    g += f'<rect x="0" y="880" width="1080" height="24" fill="#6A8A3A"/>'
    return g
WELL = (f'<rect x="520" y="760" width="40" height="140" fill="#9AA0A8"/><path d="M490,760 L590,760 L560,660 L520,660 Z" fill="#7A8088"/>'
        f'<rect x="530" y="900" width="20" height="560" fill="#C8CED6"/><rect x="530" y="1440" width="420" height="20" fill="#C8CED6"/>')
FRACT = "".join(f'<path d="M{600+k*70},1450 l{-20+k%3*10},-60 l20,-30 M{600+k*70},1450 l{10},55 l-15,30" stroke="{YEL}" stroke-width="5" fill="none"/>' for k in range(5))
PLUME = "".join(f'<path d="M{620+k*70},1430 C{600+k*60},1300 {560+k*50},1200 {520+k*60},1080" stroke="{RED}" stroke-width="{16-k*2}" stroke-opacity=".7" fill="none" stroke-linecap="round"/>' for k in range(5))

S = []
# 1 hook
S.append(dict(dur=D[0], layers=[(bg(1), "bg", 0), (HEAD, "still", 0),
    (P(420, '<div class="big" style="font-size:118px">SE O FLÁVIO<br>GANHAR, QUAL É<br>O <span style="color:#E63946">1º ATO</span><br>DELE?</div>'), "pop", 0.0),
    (P(1080, '<div class="b" style="font-size:60px;font-weight:900">ele mesmo <span class="hl">respondeu.</span></div>'), "up", 2.6)]))
# 2 condenação
S.append(dict(dur=D[1], layers=[(bg(2), "bg", 0), (HEAD, "still", 0), (chapter(1, "o perdão"), "up", 0),
    (P(380, '<div class="k">STF · setembro de 2025</div>'), "up", 0.2),
    (P(460, f'<div class="big" style="font-size:230px;color:{RED}">27 ANOS</div>'), "pop", 1.9),
    (GAVEL, "ill", 0.6),
    (P(780, '<div class="card b" style="max-width:560px">Jair Bolsonaro condenado por <b>liderar tentativa de golpe de Estado</b></div>'), "up", 3.8),
    (src("Euronews, 29/08/2026; STF"), "up", 0.5)]))
# 3 farsa / anistia
S.append(dict(dur=D[2], layers=[(bg(3), "bg", 0), (HEAD, "still", 0), (chapter(1, "o perdão"), "still", 0),
    (P(380, '<div class="q">“uma grande farsa”</div><div class="who">Flávio, sobre o julgamento do pai</div>'), "type1.2", 0.3),
    (P(760, '<div class="k" style="color:#A9A9B2">no Jornal Nacional, 28/08/2026</div>'), "up", 2.6),
    (P(840, f'<div class="card"><div class="big" style="font-size:100px">ANISTIA</div><div class="b" style="font-size:42px">“ainda na transição”</div></div>'), "up", 3.4),
    (P(1180, f'<div class="card" style="border-color:{RED}"><div class="b" style="font-size:42px">se não passar:</div><div class="big" style="font-size:110px;color:{RED}">INDULTO</div></div>'), "pop", 5.6),
    (src("Euronews; Bem Paraná (entrevista ao Jornal Nacional)"), "up", 0.5)]))
# 4 indulto 8/1
S.append(dict(dur=D[3], layers=[(bg(4), "bg", 0), (HEAD, "still", 0), (chapter(1, "o perdão"), "still", 0),
    (P(380, '<div class="k">sobre os presos do 8 de janeiro</div>'), "up", 0),
    (P(520, '<div class="q" style="font-size:104px">“vou dar indulto para todo mundo”</div><div class="who">Flávio Bolsonaro, 29/09/2026</div>'), "type1.8", 2.6),
    (src("SBT News, 29/09/2026"), "up", 0.5)]))
# 5 1º ato
S.append(dict(dur=D[4], layers=[(bg(5, RED, .32), "bg", 0), (HEAD, "still", 0),
    (P(400, '<div class="big" style="font-size:150px">1º ATO:</div>'), "pop", 0.4),
    (P(620, '<div class="b" style="font-size:66px;font-weight:800">perdoar quem tentou <span style="color:#E63946">derrubar a democracia</span></div>'), "up", 1.2),
    (P(1060, '<div style="text-align:center"><span class="stamp" style="font-size:96px;transform:rotate(-6deg)">INCLUSIVE O PAI</span></div>'), "pop", 4.2)]))
# 6 master
S.append(dict(dur=D[5], layers=[(bg(6, YEL, .14), "bg", 0), (HEAD, "still", 0), (chapter(2, "o amigo banqueiro"), "up", 0),
    (P(380, '<div class="big" style="font-size:170px">BANCO<br>MASTER</div>'), "up", 0.2),
    (P(760, '<div class="card b">dono: <b>Daniel Vorcaro</b></div>'), "up", 1.6),
    (P(960, f'<div class="b">rombo de até</div><div class="big" style="font-size:180px;color:{RED}">R$ 12 BI</div>'), "pop", 4.0),
    (P(1330, f'<div class="b"><b>1,6 milhão</b> de pessoas atingidas</div>'), "up", 6.2),
    (src("Banco Central / imprensa; Wikipedia: Banco Master scandal"), "up", 0.5)]))
# 7 134 / 61
S.append(dict(dur=D[6], layers=[(bg(7, YEL, .14), "bg", 0), (HEAD, "still", 0), (chapter(2, "o amigo banqueiro"), "still", 0),
    (P(380, f'<div class="b">Flávio pediu a Vorcaro:</div><div class="big" style="font-size:210px;color:{YEL}">R$ 134 MI</div>'), "pop", 0.8),
    (P(800, '<div class="card b" style="font-size:44px">pra um filme sobre o pai: <b>“Dark Horse”</b></div>'), "up", 2.4),
    (P(1030, f'<div class="b">pagos, pelo menos:</div><div class="big" style="font-size:210px;color:{RED}">R$ 61 MI</div>'), "pop", 4.6),
    (src("Intercept Brasil; CNN Brasil; A Tarde"), "up", 0.5)]))
# 8 phone 1
S.append(dict(dur=D[7], layers=[(bg(8, GRN, .14), "bg", 0), (HEAD, "still", 0), (PHONE, "up", 0),
    (DATE(450, "8 de setembro de 2025"), "up", 1.6),
    (bubble(520, "r", "🎤 áudio<br><span style='font-size:28px;color:#BFE0CC'>cobrando os pagamentos do filme</span>"), "pop", 2.4),
    (DATE(740, "16 de novembro de 2025"), "up", 4.8),
    (bubble(810, "r", "Irmão, não tem meia conversa entre a gente. Só preciso que me dê uma luz! Abs!"), "type2.6", 6.0),
    (src("CNN Brasil: PF mostra conversas de Flávio com Vorcaro"), "up", 0.5)]))
# 9 phone 2 (amém)
S.append(dict(dur=D[8], layers=[(bg(8, GRN, .14), "bg", 0), (HEAD, "still", 0), (PHONE, "still", 0),
    (DATE(450, "8 de setembro de 2025"), "still", 0), (bubble(520, "r", "🎤 áudio<br><span style='font-size:28px;color:#BFE0CC'>cobrando os pagamentos do filme</span>"), "still", 0),
    (DATE(740, "16 de novembro de 2025"), "still", 0), (bubble(810, "r", "Irmão, não tem meia conversa entre a gente. Só preciso que me dê uma luz! Abs!"), "still", 0),
    (bubble(1080, "l", "📷 foto · visualização única", "#26332C"), "pop", 0.6),
    (bubble(1230, "r", "Amém", "#1F5C40"), "pop", 2.4),
    (src("CNN Brasil: PF mostra conversas de Flávio com Vorcaro"), "still", 0)]))
# 10 preso
S.append(dict(dur=D[9], layers=[(bg(10, RED, .3), "bg", 0), (HEAD, "still", 0),
    (P(360, f'<div class="k" style="color:#A9A9B2">no dia seguinte</div><div class="big" style="font-size:250px">17 NOV</div>'), "pop", 0),
    (JET, "ill", 0.6),
    (P(1340, '<div style="text-align:center"><span class="stamp" style="font-size:110px;transform:rotate(-5deg)">PRESO</span></div>'), "pop", 1.6),
    (P(1500, '<div class="b" style="font-size:36px;text-align:center">tentando sair do país num jatinho para Malta</div>'), "up", 2.4)]))
# 11 negou / investigado / contrataria
S.append(dict(dur=D[10], layers=[(bg(11), "bg", 0), (HEAD, "still", 0),
    (P(360, '<div class="card b"><span style="color:#8E8E97">antes:</span> negou conhecer Vorcaro</div>'), "up", 0.2, 8.6),
    (P(560, '<div class="card b"><span style="color:#8E8E97">depois:</span> <b>admitiu a aproximação</b></div>'), "up", 1.8, 8.6),
    (P(820, '<div style="text-align:center"><span class="stamp" style="font-size:104px;transform:rotate(-6deg)">INVESTIGADO NO STF</span></div>'), "pop", 3.4, 8.6),
    (P(1080, '<div class="b" style="font-size:40px;text-align:center">suspeitas: lavagem de dinheiro · evasão de divisas · corrupção</div>'), "up", 4.6, 8.6),
    (P(1230, '<div class="b" style="font-size:36px;text-align:center;color:#A9A9B2">investigação não é condenação</div>'), "up", 6.6, 8.6),
    (P(560, '<div class="big" style="font-size:150px;text-align:center">VOCÊ<br>CONTRATARIA<br><span style="color:#E63946">ALGUÉM</span><br>ASSIM?</div>'), "pop", 8.9),
    (src("A Tarde; CNN Brasil; STF (inquérito autorizado em jul/2026)"), "up", 0.5)]))
# 12 fracking: what
S.append(dict(dur=D[11], layers=[(bg(12, BLU, .25), "bg", 0), (HEAD, "still", 0), (chapter(3, "o plano"), "up", 0),
    (P(330, '<div class="big" style="font-size:150px">FRACKING<br><span style="color:#E63946">LIBERADO</span></div>'), "up", 0.3),
    (svg(ground_section()), "up", 1.6),
    (svg(WELL), "drop2.6", 3.0),
    (svg(FRACT), "pop", 6.4),
    (P(660, '<div class="b" style="font-size:38px">+3.000 m de profundidade · água + <b>químicos</b> sob pressão</div>'), "up", 4.4),
    (src("Assembleia Legislativa do Paraná; plano de governo (Agência Brasil)"), "up", 0.5)]))
# 13 fracking: risk
S.append(dict(dur=D[12], layers=[(bg(12, BLU, .25), "bg", 0), (HEAD, "still", 0), (chapter(3, "o plano"), "still", 0),
    (svg(ground_section() + WELL + FRACT), "still", 0),
    (svg(PLUME), "drop1.0", 0.0),
    (P(330, f'<div class="big" style="font-size:200px;color:{RED}">+90%</div><div class="b" style="font-size:42px">do fluido fica no subsolo</div>'), "pop", 0.4),
    (P(700, f'<div class="card b" style="font-size:40px;border-color:{GRN}">✔ Paraná proibiu (2019) &nbsp;·&nbsp; ✔ +380 cidades proibiram</div>'), "up", 5.0),
    (src("Assembleia Legislativa do Paraná, Lei 19.878/2019"), "up", 0.5)]))
# 14 SUS
PRONT = page(f'''<div style="position:absolute;left:150px;right:150px;top:560px;background:#F4F1EA;border-radius:18px;padding:40px;transform:rotate(-2deg);font-family:Montserrat;color:#222">
<div style="font-weight:900;font-size:44px;letter-spacing:2px">PRONTUÁRIO · SUS</div>
{"".join(f'<div style="margin-top:22px;font-size:30px;font-weight:700;color:#666">{k}</div><div style="height:30px;background:#C9C4B8;border-radius:6px;margin-top:8px;width:{w}%"></div>' for k, w in (("nome", 70), ("diagnósticos", 90), ("exames", 80), ("medicamentos", 60)))}</div>''')
S.append(dict(dur=D[13], layers=[(bg(14), "bg", 0), (HEAD, "still", 0), (chapter(3, "o plano"), "still", 0),
    (P(330, '<div class="big" style="font-size:92px">SEUS DADOS DO SUS<br><span style="color:#FFD23F">→ HOSPITAIS PRIVADOS</span></div>'), "up", 0.2),
    (PRONT, "ill", 1.4, 6.6),
    (P(700, f'<div class="card" style="border-color:{YEL}"><div class="k" style="color:{YEL}">LGPD · art. 11, §4</div><div class="b" style="font-size:44px;margin-top:16px">“é vedada a comunicação ou o uso compartilhado (...) de dados pessoais sensíveis referentes à saúde com objetivo de obter <b>vantagem econômica</b>”</div></div>'), "up", 6.9),
    (src("Agência Brasil (plano de governo); Lei 13.709/2018 (LGPD)"), "up", 0.5)]))
# 15 recap
S.append(dict(dur=D[14], layers=[(bg(15, RED, .3), "bg", 0), (HEAD, "still", 0),
    (P(380, '<div class="card b" style="font-size:54px">⚖️ perdão pra golpe</div>'), "pop", 0.0),
    (P(600, '<div class="card b" style="font-size:54px">🏦 banqueiro preso chamado de “irmão”</div>'), "pop", 1.2),
    (P(880, '<div class="card b" style="font-size:54px">💧 risco na sua água</div>'), "pop", 2.6),
    (P(1100, '<div class="card b" style="font-size:54px">🩺 seus dados de saúde fora do SUS</div>'), "pop", 3.8)]))
# 16 CTA
S.append(dict(dur=D[15], layers=[(bg(16, YEL, .18), "bg", 0), (HEAD, "still", 0),
    (P(360, f'<div class="big" style="font-size:200px">25 DE<br><span style="color:{YEL}">OUTUBRO</span></div>'), "pop", 0.0),
    (P(880, '<div class="b">não é sobre gostar ou não do outro lado.</div>'), "up", 1.4),
    (P(1060, '<div class="b" style="font-size:58px;font-weight:900">é sobre saber <span class="hl">quem você coloca lá.</span></div>'), "up", 3.0),
    (P(1330, '<div class="b" style="font-size:44px">manda pra quem ainda não sabe ➜</div>'), "up", 5.0)]))
