import sys, importlib, numpy as np, soundfile as sf, subprocess
raw, out = sys.argv[1:3]
S = importlib.import_module("polreel").S; starts = np.cumsum([0] + [s["dur"] for s in S]); total = float(starts[-1])
v, sr = sf.read("../pol/narracao.wav"); N = int(total * sr); t = np.arange(N) / sr; rng = np.random.default_rng(5)
pad = sum(a * np.sin(2 * np.pi * f * t + p) for f, a, p in ((55, .5, 0), (82.4, .3, 1), (110, .2, 2), (130.8, .12, .5)))
pad *= .6 + .4 * np.sin(2 * np.pi * .08 * t)
pulse = np.zeros(N); b = 60 / 92
for k in range(int(total / b) + 1):
    i0 = int(k * b * sr); L = int(.35 * sr); tt = np.arange(L) / sr; s = np.sin(2 * np.pi * (48 + 50 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 9)
    e = min(N, i0 + L); pulse[i0:e] += s[:e - i0] * (1 if k % 4 == 0 else .55)
tick = np.zeros(N)
for k in range(int(total / (b / 2))):
    i0 = int(k * b / 2 * sr); L = int(.03 * sr); e = min(N, i0 + L); tick[i0:e] += rng.normal(0, 1, e - i0) * np.exp(-np.arange(e - i0) / sr * 120) * .3
fx = np.zeros(N)
for i, s in enumerate(S):
    if i:
        L = int(.4 * sr); w = np.convolve(rng.normal(0, 1, L), np.ones(15) / 15, "same") * np.sin(np.pi * np.arange(L) / L) ** 2; i0 = int((starts[i] - .25) * sr); e = min(N, i0 + L); fx[i0:e] += w[:e - i0] * .5
    for html, kind, t0 in s["layers"]:
        if kind == "pop":
            L = int(1.0 * sr); tt = np.arange(L) / sr; bm = np.sin(2 * np.pi * (40 + 70 * np.exp(-tt * 10)) * tt) * np.exp(-tt * 4); i0 = int((starts[i] + t0) * sr); e = min(N, i0 + L); fx[i0:e] += bm[:e - i0] * .9
nm = lambda x, g: x / (np.abs(x).max() + 1e-9) * g
music = nm(pad, .07) + nm(pulse, .16) + nm(tick, .03) + nm(fx, .22)
vv = np.zeros(N); vv[:min(N, len(v))] = v[:N]
env = np.convolve(np.abs(vv), np.ones(int(.2 * sr)) / int(.2 * sr), "same"); duck = 1 - .4 * np.clip(env / (env.max() * .3), 0, 1)
y = vv * .95 + music * duck; y *= np.minimum(1, (total - t) / .3); y = nm(y, .92)
sf.write("polmix.wav", y.astype(np.float32), sr)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-i", "polmix.wav", "-c:v", "libx264", "-preset", "medium", "-b:v", "3500k", "-maxrate", "5000k", "-bufsize", "8000k",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", out], check=True)
print(total)
