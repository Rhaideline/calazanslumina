"""Reel: os primeiros 6 meses do bebê e da mãe. Tempos sincronizados com roteiros/mae6/timing.json."""
import json, os
from kit import *
from kit2 import *
TM = json.load(open(os.path.join(os.path.dirname(__file__), "..", "roteiros", "mae6", "timing.json")))
def T(top, inner, cls="t"): return f'<div class="{cls}" style="top:{top}px">{inner}</div>'
def ill(svgs): return page(svg(svgs))
def pill(txt, col): return T(170, f'<span class="pill" style="background:{col}">{txt}</span>')
def src(txt): return page(T(1770, f'<div style="font-family:Montserrat;font-weight:600;font-size:26px;color:#7A6458;text-align:center">{txt}</div>'))
BEBE, MAE = pill("BEBÊ", "#7E9A79"), pill("VOCÊ, MÃE", TERRA)
def li(items, top):
    return T(top, "".join(f'<div class="li"><span class="dot"></span>{x}</div>' for x in items))
SC = [
 (bg(1), page(pill("OS PRIMEIROS 6 MESES", TERRA)), [(page(T(300, '<div class="h" style="font-size:104px">O bebê<br><i>e a mãe</i></div>')), "up", 0.05),
   (page(T(560, '<div class="k" style="font-size:72px">porque a mãe também está nascendo</div>')), "up", 3.0), (ill(mom_baby(540, 1240, 1.3)), "ill", 0.1)], ""),
 (bg(2, SAND, SAGE), page(BEBE), [(page(T(290, '<div class="h">Ele te enxerga<br><i>de pertinho</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Enxerga melhor a uns <b>20 a 30 cm</b>: a distância do seu rosto, no colo.</div>')), "up", 0.8),
   (ill(mom_baby(470, 1280, 1.15) + distance_arc(560, 1060, 1.0)), "ill", 0.2)], "Fonte: KidsHealth (Nemours) · Unasus"),
 (bg(3, ROSE, SAND), page(MAE), [(page(T(290, '<div class="h">Seu corpo<br><i>ainda se refaz</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">O sangramento do pós-parto pode durar <b>até 6 semanas</b>, o tempo do útero voltar ao tamanho.</div>')), "up", 0.8),
   (ill(calendar(540, 1280, 1.1, "6", "SEMANAS")), "ill", 0.4)], "Fonte: protocolo de puerpério, Maternidade-Escola UFRJ"),
 (bg(4, BLUE, SAND), page(MAE), [(page(T(290, '<div class="h">Chorar do nada<br><i>nos primeiros dias?</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">É o <b>baby blues</b>. É comum e costuma passar em <b>até 2 semanas</b>.</div>')), "up", 1.6),
   (ill(cloud_rain(540, 1250, 1.2)), "ill", 0.3)], "Fonte: Portal de Boas Práticas · Fiocruz"),
 (bg(5, ROSE, SAND), page(MAE), [(page(T(280, '<div class="h" style="font-size:150px;color:#C8735A">1 em cada 4</div>')), "pop", 1.6),
   (page(T(480, '<div class="b">mães no Brasil têm sintomas de <b>depressão pós-parto</b>. Tem tratamento.</div>')), "up", 2.4),
   (page(T(700, '<div class="k">pedir ajuda é coragem</div>')), "up", 6.0), (ill(four_moms(540, 1300, 1.3)), "ill", 1.8)], "Fonte: pesquisa Nascer no Brasil · Fiocruz"),
 (bg(6, MUST, SAND), page(BEBE), [(page(T(290, '<div class="h">O primeiro<br><i>sorriso de verdade</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Entre <b>1 e 2 meses</b>: o sorriso social, em resposta a você.</div>')), "up", 0.8),
   (ill(baby_smile(540, 1260, 1.1)), "ill", 0.3)], "Fonte: Sociedade Brasileira de Pediatria"),
 (bg(7, SAGE, SAND), page(BEBE), [(page(T(290, '<div class="h">De barriga<br><i>pra baixo</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Com <b>2 meses</b>, ele já levanta a cabeça.</div>')), "up", 0.6),
   (ill(tummy_time(480, 1300, 1.2)), "ill", 0.2)], "Fonte: CDC, marcos do desenvolvimento"),
 (bg(8, ROSE, SAND), page(MAE), [(page(T(290, '<div class="h">Seu cabelo<br><i>está caindo?</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Por volta do <b>3º mês</b> é comum. É hormonal, e passa.</div>')), "up", 0.8),
   (ill(brush(560, 1300, 1.2)), "ill", 0.2)], "Fonte: Cleveland Clinic (eflúvio telógeno)"),
 (bg(9, BLUE, SAGE), page(BEBE), [(page(T(290, '<div class="h">Cabeça firme<br><i>e as primeiras roladas</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Com <b>4 meses</b>, segura a cabeça sozinho e pode começar a rolar.</div>')), "up", 0.7),
   (ill(baby_play(560, 1330, 1.1)), "ill", 0.2)], "Fonte: CDC, marcos do desenvolvimento"),
 (bg(10, SAND, ROSE), page(MAE), [(page(T(290, '<div class="h">Amamentar<br><i>evita gravidez?</i></div>')), "up", 0.05),
   (page(T(540, '<div class="b">Só com <b>as 3 juntas</b>:</div>')), "up", 1.8),
   (page(li(["sem menstruação", "amamentação exclusiva, dia e noite", "bebê com menos de 6 meses"], 660)), "up", 4.8),
   (page(T(1000, '<div class="k">converse sobre contracepção</div>')), "up", 7.6)], "Fonte: método da amenorreia lactacional · Rede D'Or · Afya"),
 (bg(11, MUST, SAND), page(BEBE), [(page(T(290, '<div class="h">6 meses:<br><i>hora da comida</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Senta <b>com apoio</b>. Começa a introdução alimentar, e o <b>leite materno continua</b>.</div>')), "up", 0.8),
   (ill(bowl(560, 1380, 1.1)), "ill", 0.3)], "Fonte: OMS · Ministério da Saúde · CDC"),
 (bg(12, SAGE, SAND), page(BEBE), [(page(T(290, '<div class="h">Cada bebê<br><i>tem seu tempo</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Se algo te preocupar, fale com o <b>pediatra</b>.</div>')), "up", 1.6),
   (ill(stethoscope(520, 1260, 1.3)), "ill", 0.2)], "Fonte: CDC · Sociedade Brasileira de Pediatria"),
 (bg(13, ROSE, SAND), page(MAE), [(page(T(290, '<div class="h">E a mãe<br><i>também</i></div>')), "up", 0.05),
   (page(T(560, '<div class="b">Precisa de ajuda? <b>Unidade de saúde</b> ou <b>CVV 188</b>, 24h e gratuito.</div>')), "up", 2.2),
   (ill(heart_hands(540, 1300, 1.0)), "ill", 0.3)], ""),
 (bg(14), page(pill("SALVA E COMPARTILHA", TERRA)), [(page(T(300, '<div class="h">Manda pra<br><i>uma mãe que<br>precisa ouvir isso</i></div>')), "up", 0.05),
   (page(T(780, '<div class="k" style="font-size:70px">como você está hoje? comenta 💬</div>')), "up", 1.2), (ill(share(470, 1330, 1.2)), "ill", 0.3)], ""),
]
S = []
for (b, tag, lays, fonte), m in zip(SC, TM):
    layers = [(page(svg(b)), "bg", 0), (tag, "still", 0)] + lays
    if fonte: layers.append((src(fonte), "still", 0))
    S.append(dict(dur=m["dur"], layers=layers))
