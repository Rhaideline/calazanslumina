"""Transcreve cada fala da narração (Whisper) e aponta as que divergem do roteiro. Uso: python3 verifica_voz.py roteiros/ep1 [limite]"""
import sys, json, re, difflib, unicodedata, numpy as np, soundfile as sf, sherpa_onnx
ep = sys.argv[1]; lim = float(sys.argv[2]) if len(sys.argv) > 2 else 0.86
d = "voz/sherpa-onnx-whisper-small"
rec = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=f"{d}/small-encoder.int8.onnx", decoder=f"{d}/small-decoder.int8.onnx", tokens=f"{d}/small-tokens.txt", language="pt", task="transcribe", num_threads=4)
def norm(s):
    s = unicodedata.normalize("NFD", s.lower()); s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = s.replace("pra ", "para ").replace("pro ", "para o ")
    return re.sub(r"[^a-z0-9 ]", " ", re.sub(r"\s+", " ", s)).split()
x, sr = sf.read(f"{ep}/narracao.wav", dtype="float32"); bad = 0
for m in json.load(open(f"{ep}/timing.json")):
    seg = x[int(m["start"] * sr):int((m["start"] + m["dur"]) * sr)]
    seg = np.interp(np.arange(0, len(seg), sr / 16000), np.arange(len(seg)), seg).astype(np.float32)
    s = rec.create_stream(); s.accept_waveform(16000, seg); rec.decode_stream(s); got = s.result.text.strip()
    r = difflib.SequenceMatcher(None, norm(m["text"]), norm(got)).ratio()
    if r < lim:
        bad += 1; print(f"[{m['i']}] {r:.2f}\n  roteiro: {m['text']}\n  ouvido:  {got}")
print(f"{ep}: {bad} fala(s) para revisar")
