import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 43, 1.05
L = [
 ("Antes de votar no Flávio Bolsonaro, escute o que ele mesmo disse. E veja o que ele fez.", None, 0.4),
 ("Dois mil e cinco. Deputado no Rio, ele entrega a maior medalha da Assembleia a um policial chamado Adriano da Nóbrega.", "2005. Deputado no Rio, ele entrega a maior medalha da Assembleia a um policial chamado Adriano da Nóbrega.", 0.3),
 ("Naquele momento, Adriano estava preso, acusado de homicídio. Anos depois, o Ministério Público apontou Adriano como chefe de milícia.", None, 0.35),
 ("A mãe e a ex-mulher dele trabalharam no gabinete do Flávio.", None, 0.35),
 ("No Jornal Nacional, Flávio respondeu: na época, era um policial exemplar.", "No Jornal Nacional, Flávio respondeu: “na época, era um policial exemplar”.", 0.45),
 ("Dois mil e vinte. Denunciado por rachadinha. No ano seguinte, o STJ anulou as provas. Ele nunca foi condenado, e nega tudo.", "2020. Denunciado por rachadinha. No ano seguinte, o STJ anulou as provas. Ele nunca foi condenado, e nega tudo.", 0.4),
 ("Maio de dois mil e vinte e seis. Sobre o dinheiro do dono do Banco Master, ele disse que era mentira. No mesmo dia, admitiu.", "Maio de 2026. Sobre o dinheiro do dono do Banco Master, ele disse: “é mentira”. No mesmo dia, admitiu.", 0.4),
 ("Dois dias depois, ele disse: não tenho que justificar nada.", "Dois dias depois, ele disse: “não tenho que justificar nada”.", 0.45),
 ("Em setembro, ele disse: sem anistia, darei indulto a todo mundo.", "Em setembro, ele disse: “sem anistia, darei indulto a todo mundo”.", 0.45),
 ("Outubro: com maioria no Congresso, vai mudar a Constituição. Não disse o quê.", "Outubro: com maioria no Congresso, vai “mudar a Constituição”. Não disse o quê.", 0.45),
 ("Não sou eu que estou dizendo. São as palavras dele. Dia vinte e cinco, você decide.", "Não sou eu que estou dizendo. São as palavras dele. Dia 25, você decide.", 0.9),
]
tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
