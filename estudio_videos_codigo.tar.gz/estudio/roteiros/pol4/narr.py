import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Mil novecentos e setenta e nove: o Brasil perdoou os militares. Dois mil e vinte e cinco: condenou um golpe pela primeira vez. E agora um candidato promete perdoar de novo.", "1979: o Brasil perdoou os militares. 2025: condenou um golpe pela primeira vez. E agora um candidato promete perdoar de novo.", 0.3),
 ("Em setembro de dois mil e vinte e cinco, o Supremo condenou Jair Bolsonaro a mais de vinte e sete anos de prisão, por tentativa de golpe de Estado.", "Em setembro de 2025, o Supremo condenou Jair Bolsonaro a mais de 27 anos de prisão, por tentativa de golpe de Estado.", 0.3),
 ("O filho, Flávio, promete: se eleito, vai trabalhar pela anistia ainda na transição. E, se não passar, indulto pros condenados do oito de janeiro.", "O filho, Flávio, promete: se eleito, vai trabalhar pela anistia ainda na transição. E, se não passar, indulto pros condenados do 8 de janeiro.", 0.35),
 ("Agora, o banqueiro. Daniel Vorcaro, dono do Banco Master, foi preso pela Polícia Federal em novembro de dois mil e vinte e cinco.", "Agora, o banqueiro. Daniel Vorcaro, dono do Banco Master, foi preso pela Polícia Federal em novembro de 2025.", 0.3),
 ("Mensagens reveladas pelo Intercept mostram Flávio negociando com ele vinte e quatro milhões de dólares pro filme sobre o pai.", "Mensagens reveladas pelo Intercept mostram Flávio negociando com ele 24 milhões de dólares pro filme sobre o pai.", 0.3),
 ("A Polícia Federal investiga repasses de sessenta e um milhões de reais, que teriam sido feitos a pedido dele.", "A Polícia Federal investiga repasses de 61 milhões de reais, que teriam sido feitos a pedido dele.", 0.35),
 ("No começo, Flávio negou contato com Vorcaro. Depois das mensagens, admitiu. A agência de checagem Aos Fatos contou quarenta e três declarações enganosas dele sobre o caso.", "No começo, Flávio negou contato com Vorcaro. Depois das mensagens, admitiu. A agência de checagem Aos Fatos contou 43 declarações enganosas dele sobre o caso.", 0.3),
 ("Hoje ele é investigado no Supremo, por suspeita de lavagem de dinheiro, evasão de divisas e corrupção. Ele nega irregularidades. E investigação não é condenação.", None, 0.4),
 ("Terceiro ponto: o plano de governo. Ele quer liberar o fracking, técnica proibida em países como França, Alemanha e Irlanda.", None, 0.3),
 ("E propõe compartilhar dados do SUS com a rede privada, num prontuário eletrônico ligado ao seu CPF.", None, 0.35),
 ("E tem mais. O próximo presidente vai indicar três ministros do Supremo até dois mil e trinta. Quase um terço da Corte.", "E tem mais. O próximo presidente vai indicar três ministros do Supremo até 2030. Quase um terço da Corte.", 0.35),
 ("Não é torcida. É o que está escrito: numa decisão do Supremo, num inquérito da Polícia Federal e no plano de governo dele.", None, 0.3),
 ("Leia o plano dele e o do Lula no site do TSE. Compare. E dia vinte e cinco, vote com informação.", "Leia o plano dele e o do Lula no site do TSE. Compare. E dia 25, vote com informação.", 0.3),
 ("A última vez que o Brasil perdoou tudo, foi em...", None, 0.1),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.12); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
