import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("O primeiro europeu a pisar no Brasil não foi Cabral.", None, 0.25),
 ("Foi um espanhol. Vicente Pinzón chegou ao litoral do Nordeste em janeiro de mil e quinhentos. Três meses antes.", "Foi um espanhol. Vicente Pinzón chegou ao litoral do Nordeste em janeiro de 1500. Três meses antes.", 0.25),
 ("Mas a Espanha não podia ficar com a terra, por causa de um acordo assinado seis anos antes: o Tratado de Tordesilhas, que dividia o mundo entre Espanha e Portugal.", None, 0.3),
 ("Aí entra Portugal. Treze navios, cerca de mil e quinhentos homens, saindo de Lisboa rumo à Índia.", "Aí entra Portugal. 13 navios, cerca de 1.500 homens, saindo de Lisboa rumo à Índia.", 0.25),
 ("Vinte e dois de abril, fim de tarde. Eles avistam um monte alto e redondo. Chamam de Monte Pascoal.", "22 de abril, fim de tarde. Eles avistam um monte alto e redondo. Chamam de Monte Pascoal.", 0.3),
 ("Só que essa terra já tinha dono. Milhões de pessoas, falando mais de mil línguas.", None, 0.3),
 ("Ali, na Bahia, viviam os Tupiniquim: aldeias com grandes casas coletivas, roças de mandioca, e redes pra dormir.", None, 0.25),
 ("No dia seguinte, o primeiro encontro. Na praia, troca de presentes: um chapéu português, por um cocar de penas.", None, 0.3),
 ("O escrivão Pero Vaz de Caminha escreveu ao rei: eram pardos, todos nus, e traziam arcos com suas setas.", None, 0.25),
 ("E completou: se a gente os entendesse, seriam logo cristãos. O plano já estava ali. Converter, e ocupar.", None, 0.35),
 ("No dia vinte e seis, a primeira missa. Os indígenas acompanharam tudo da praia.", "No dia 26, a primeira missa. Os indígenas acompanharam tudo da praia.", 0.3),
 ("Mas o pior veio depois. Os europeus trouxeram doenças que os indígenas nunca tinham enfrentado.", None, 0.25),
 ("Em mil quinhentos e sessenta e três, só na Bahia, a varíola matou cerca de trinta mil indígenas em três meses, segundo os jesuítas.", "Em 1563, só na Bahia, a varíola matou cerca de 30 mil indígenas em três meses, segundo os jesuítas.", 0.35),
 ("De mais de mil línguas, hoje restam duzentas e noventa e cinco.", "De mais de mil línguas, hoje restam 295.", 0.35),
 ("Mas eles não desapareceram. Hoje são mais de um milhão e seiscentos mil indígenas, de trezentos e noventa e um povos.", "Mas eles não desapareceram. Hoje são mais de 1,6 milhão de indígenas, de 391 povos.", 0.35),
 ("Então, foi descobrimento, encontro, ou invasão? Comenta aqui.", None, 0.3),
 ("E se você ainda acha que conhece essa história, lembra:", None, 0.15),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.1); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
