import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Uma jovem viveu em Minas Gerais há mais de onze mil anos. E ela não era a primeira.", "Uma jovem viveu em Minas Gerais há mais de 11 mil anos. E ela não era a primeira.", 0.6),
 ("Essa é a história do Brasil, antes do Brasil ter nome.", None, 0.5),
 ("Tudo começa na Era do Gelo. O mar estava tão baixo que a Ásia e a América eram ligadas por terra.", None, 0.35),
 ("Grupos humanos atravessaram essa ponte, e desceram pela costa. Há pelo menos dezesseis mil anos.", "Grupos humanos atravessaram essa ponte, e desceram pela costa. Há pelo menos 16 mil anos.", 0.4),
 ("Nos Estados Unidos, pegadas mostram gente caminhando por lá há mais de vinte e um mil anos.", "Nos Estados Unidos, pegadas mostram gente caminhando por lá há mais de 21 mil anos.", 0.35),
 ("Mas aqui no Brasil, as pistas são ainda mais antigas.", None, 0.5),
 ("No Mato Grosso, cientistas acharam ossos de uma preguiça-gigante, um bicho de uns seiscentos quilos.", "No Mato Grosso, cientistas acharam ossos de uma preguiça-gigante, um bicho de uns 600 quilos.", 0.3),
 ("E alguém furou e poliu esses ossos pra usar como pingente. Há uns vinte e cinco mil anos.", "E alguém furou e poliu esses ossos pra usar como pingente. Há uns 25 mil anos.", 0.45),
 ("No Piauí, a Serra da Capivara guarda pinturas nas rochas que, segundo a UNESCO, passam de vinte e cinco mil anos.", "No Piauí, a Serra da Capivara guarda pinturas nas rochas que, segundo a UNESCO, passam de 25 mil anos.", 0.35),
 ("São mais de mil sítios arqueológicos, com cenas de caça, de rituais, e de bichos que já não existem.", None, 0.35),
 ("Tem cientista que defende que havia gente ali há cinquenta mil anos. Mas isso ainda é muito debatido.", "Tem cientista que defende que havia gente ali há 50 mil anos. Mas isso ainda é muito debatido.", 0.45),
 ("Agora, de volta pra Luzia. Ela foi encontrada nos anos setenta, numa caverna perto de Belo Horizonte.", "Agora, de volta pra Luzia. Ela foi encontrada nos anos 70, numa caverna perto de Belo Horizonte.", 0.35),
 ("Era uma jovem de uns vinte anos, que viveu há cerca de onze mil e quatrocentos anos. É o esqueleto mais antigo do Brasil.", "Era uma jovem de uns 20 anos, que viveu há cerca de 11.400 anos. É o esqueleto mais antigo do Brasil.", 0.4),
 ("Por muito tempo, disseram que ela tinha traços africanos. Mas em dois mil e dezoito, o DNA revelou: o povo de Luzia era cem por cento indígena americano.", "Por muito tempo, disseram que ela tinha traços africanos. Mas em 2018, o DNA revelou: o povo de Luzia era 100% indígena americano.", 0.45),
 ("No mesmo ano, o Museu Nacional pegou fogo. E o crânio de Luzia, sobreviveu.", "No mesmo ano, o Museu Nacional pegou fogo. E o crânio de Luzia... sobreviveu.", 0.6),
 ("Perto de onde ela foi achada, está a gravura de figura humana mais antiga das Américas. Mais de nove mil anos.", "Perto de onde ela foi achada, está a gravura de figura humana mais antiga das Américas. Mais de 9 mil anos.", 0.45),
 ("Ou seja: quando os portugueses chegaram, em mil e quinhentos, gente vivia aqui há pelo menos doze mil anos. Provavelmente muito mais.", "Ou seja: quando os portugueses chegaram, em 1500, gente vivia aqui há pelo menos 12 mil anos. Provavelmente muito mais.", 0.45),
 ("Então, quando disserem que o Brasil foi descoberto, lembra: ele já tinha gente. Milhões de pessoas.", None, 0.6),
 ("No episódio dois: a Amazônia que foi plantada por mãos humanas. Me segue pra não perder.", "No episódio 2: a Amazônia que foi plantada por mãos humanas. Me segue pra não perder.", 0.3),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.06); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
