import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 43, 1.05
L = [
 ("Mil novecentos e setenta e nove. A Lei da Anistia perdoou também quem torturou em nome do Estado.", "1979. A Lei da Anistia perdoou também quem torturou em nome do Estado.", 0.35),
 ("E os crimes da ditadura ficaram sem julgamento.", None, 0.45),
 ("Dois mil e vinte e cinco. Pela primeira vez, um ex-presidente foi condenado por tentativa de golpe. Jair Bolsonaro: vinte e sete anos e três meses.", "2025. Pela primeira vez, um ex-presidente foi condenado por tentativa de golpe. Jair Bolsonaro: 27 anos e 3 meses.", 0.4),
 ("Dois mil e vinte e seis. O filho dele, candidato, promete anistia ainda na transição. E, se não passar, um indulto pros condenados do oito de janeiro.", "2026. O filho dele, candidato, promete anistia ainda na transição. E, se não passar, um indulto pros condenados do 8 de janeiro.", 0.45),
 ("Dia vinte e cinco, você decide se o Brasil perdoa de novo.", "Dia 25, você decide se o Brasil perdoa de novo.", 0.9),
]

tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
