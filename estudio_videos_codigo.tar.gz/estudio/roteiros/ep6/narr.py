import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("O primeiro bispo do Brasil se chamava Sardinha. E ele terminou do jeito que você está pensando: devorado.", None, 0.3),
 ("Mas, pra chegar nele, volta comigo pra mil quinhentos e quarenta e nove. As capitanias tinham fracassado, e o rei mudou o jogo: agora ia ter um chefe só pro Brasil inteiro.", "Mas, pra chegar nele, volta comigo pra 1549. As capitanias tinham fracassado, e o rei mudou o jogo: agora ia ter um chefe só pro Brasil inteiro.", 0.25),
 ("O governador-geral. O escolhido foi Tomé de Sousa, que chegou na Bahia em vinte e nove de março, com seis navios e cerca de mil pessoas.", "O governador-geral. O escolhido foi Tomé de Sousa, que chegou na Bahia em 29 de março, com 6 navios e cerca de mil pessoas.", 0.25),
 ("Soldados, carpinteiros, pedreiros... e uns quatrocentos degredados: condenados expulsos de Portugal.", "Soldados, carpinteiros, pedreiros... e uns 400 degredados: condenados expulsos de Portugal.", 0.3),
 ("Também vieram seis jesuítas, liderados por Manuel da Nóbrega. Os primeiros do Brasil.", "Também vieram 6 jesuítas, liderados por Manuel da Nóbrega. Os primeiros do Brasil.", 0.25),
 ("E na praia, adivinha quem estava esperando? Um português. Diogo Álvares, que tinha naufragado ali quase quarenta anos antes.", None, 0.25),
 ("Os Tupinambá deram um apelido pra ele: Caramuru. Que quer dizer moreia. Isso mesmo: um peixe.", None, 0.3),
 ("Ele tinha casado com Paraguaçu, filha de um chefe tupinambá, e virou o tradutor dos portugueses.", None, 0.25),
 ("Com o trabalho dos indígenas, ergueram em poucos meses uma cidade-fortaleza, com muralhas de taipa. Nascia Salvador, a primeira capital do Brasil.", None, 0.3),
 ("O governo ganhou até ministério: um ouvidor pra justiça, um provedor pro dinheiro, e um capitão-mor pra defender a costa.", None, 0.25),
 ("Os jesuítas aprenderam tupi, criaram aldeias e escolas. Ensinavam, mas também apagavam a cultura indígena.", None, 0.3),
 ("Em mil quinhentos e cinquenta e um, chega o primeiro bispo: Pero Fernandes Sardinha. E ele arrumou briga até com os jesuítas.", "Em 1551, chega o primeiro bispo: Pero Fernandes Sardinha. E ele arrumou briga até com os jesuítas.", 0.25),
 ("Em mil quinhentos e cinquenta e seis, voltando pra Portugal, o navio dele naufragou no litoral de Alagoas.", "Em 1556, voltando pra Portugal, o navio dele naufragou no litoral de Alagoas.", 0.2),
 ("Ele foi capturado pelos Caeté. E devorado num ritual.", None, 0.35),
 ("A resposta dos portugueses foi brutal: os Caeté viraram alvo de guerra e de escravização.", None, 0.3),
 ("Quase quatrocentos anos depois, o escritor Oswald de Andrade datou o Manifesto Antropófago assim: ano trezentos e setenta e quatro da deglutição do bispo Sardinha.", "Quase 400 anos depois, o escritor Oswald de Andrade datou o Manifesto Antropófago assim: ano 374 da deglutição do bispo Sardinha.", 0.3),
 ("E Salvador? Foi capital do Brasil por duzentos e catorze anos. Você sabia dessa? Comenta aqui.", "E Salvador? Foi capital do Brasil por 214 anos. Você sabia dessa? Comenta aqui.", 0.3),
 ("No próximo episódio, os franceses invadem o Rio de Janeiro. Mas antes, nunca esquece:", None, 0.1),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.14); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
