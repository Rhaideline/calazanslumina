import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Já existiu uma colônia francesa no Rio de Janeiro. O nome dela era França Antártica.", None, 0.3),
 ("Em mil quinhentos e cinquenta e cinco, um cavaleiro de Malta chamado Villegaignon entra na baía de Guanabara com navios cheios de franceses.", "Em 1555, um cavaleiro de Malta chamado Villegaignon entra na baía de Guanabara com navios cheios de franceses.", 0.25),
 ("Ele escolhe uma ilha bem no meio da baía e ergue o Forte Coligny, com o nome do almirante que bancou a viagem.", None, 0.3),
 ("E aqui vem o que a escola nem sempre conta: os franceses não chegaram sozinhos. Eles se aliaram aos Tupinambá, que já odiavam os portugueses.", None, 0.25),
 ("Esses indígenas, junto com outros povos, formaram a Confederação dos Tamoios. Uma resistência que se estendeu da região de Bertioga até Cabo Frio.", None, 0.3),
 ("Foi nessa época que um alemão, Hans Staden, que tinha sido capturado pelos Tupinambá, fugiu num navio francês. E depois escreveu um livro sobre isso.", None, 0.3),
 ("Mas a colônia tinha um problema: a briga interna. Em mil quinhentos e cinquenta e sete chegam protestantes calvinistas, e logo racha tudo.", "Mas a colônia tinha um problema: a briga interna. Em 1557 chegam protestantes calvinistas, e logo racha tudo.", 0.25),
 ("O motivo? A religião. Eles brigaram até sobre como se fazia a comunhão. Os calvinistas acabaram expulsos da ilha.", None, 0.3),
 ("Um deles, Jean de Léry, voltou pra França e escreveu um dos relatos mais famosos sobre os Tupinambá.", None, 0.3),
 ("Do lado português, a ordem era clara: expulsar os franceses. Em março de mil quinhentos e sessenta, o governador Mem de Sá ataca o forte e destrói tudo.", "Do lado português, a ordem era clara: expulsar os franceses. Em março de 1560, o governador Mem de Sá ataca o forte e destrói tudo.", 0.25),
 ("Só que os franceses fugiram pro continente, com os aliados indígenas. E voltaram. A guerra continuou.", None, 0.3),
 ("Aí entra o sobrinho do governador: Estácio de Sá. Em primeiro de março de mil quinhentos e sessenta e cinco, ele funda a cidade de São Sebastião do Rio de Janeiro.", "Aí entra o sobrinho do governador: Estácio de Sá. Em 1º de março de 1565, ele funda a cidade de São Sebastião do Rio de Janeiro.", 0.25),
 ("Repara: o Rio nasceu como base de guerra. Entre o Pão de Açúcar e o morro Cara de Cão.", None, 0.3),
 ("Dois anos de luta depois, vinte de janeiro de mil quinhentos e sessenta e sete, dia de São Sebastião. A batalha decisiva, no Uruçumirim, onde hoje fica o morro da Glória.", "Dois anos de luta depois, 20 de janeiro de 1567, dia de São Sebastião. A batalha decisiva, no Uruçumirim, onde hoje fica o morro da Glória.", 0.25),
 ("Os portugueses venceram com a ajuda de um chefe indígena: Araribóia, dos Temiminó, inimigos dos Tupinambá.", None, 0.3),
 ("Estácio de Sá foi atingido por uma flecha no rosto. E morreu cerca de um mês depois.", None, 0.35),
 ("Ou seja: o Rio de Janeiro nasceu de uma guerra entre potências, e de uma guerra entre povos indígenas. Você já sabia disso? Comenta aqui.", None, 0.3),
 ("E o nome daquela colônia francesa, você lembra? Por pouco o Rio não se chamava assim:", None, 0.1),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.14); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
