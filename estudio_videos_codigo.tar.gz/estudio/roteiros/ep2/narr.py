import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("A maior floresta tropical do mundo esconde um segredo. Ela não é uma mata virgem. Boa parte dela foi cuidada, e plantada, por gente.", None, 0.6),
 ("História do Brasil, episódio dois: a floresta que foi plantada.", "História do Brasil, episódio 2: a floresta que foi plantada.", 0.5),
 ("Tudo começa com uma raiz. Há cerca de nove mil anos, onde hoje é Rondônia, povos indígenas domesticaram a mandioca.", "Tudo começa com uma raiz. Há cerca de 9 mil anos, onde hoje é Rondônia, povos indígenas domesticaram a mandioca.", 0.35),
 ("A mandioca brava é venenosa. E eles descobriram como tirar o veneno, e transformar a raiz em farinha, beiju e tucupi.", None, 0.35),
 ("Hoje, mais de oitocentos milhões de pessoas no mundo dependem dessa planta.", "Hoje, mais de 800 milhões de pessoas no mundo dependem dessa planta.", 0.45),
 ("Da mesma região vieram também o amendoim, a pupunha, pimentas e o urucum.", None, 0.4),
 ("Agora olha pro chão. Em vários pontos da Amazônia existe uma terra escura e muito fértil, a terra preta de índio.", None, 0.35),
 ("Em dois mil e vinte e três, cientistas, junto com o povo Kuikuro, mostraram que ela foi feita de propósito. Restos de comida, cinzas e carvão, virando adubo.", "Em 2023, cientistas, junto com o povo Kuikuro, mostraram que ela foi feita de propósito. Restos de comida, cinzas e carvão, virando adubo.", 0.35),
 ("E pra fazer esse solo, era preciso muita gente, vivendo muito tempo no mesmo lugar.", None, 0.45),
 ("E tem mais. Com um laser disparado de aviões, o LiDAR, cientistas conseguiram enxergar por baixo das árvores.", None, 0.35),
 ("Acharam obras de terra que ninguém conhecia. E estimaram que mais de dez mil ainda estão escondidas sob a floresta.", "Acharam obras de terra que ninguém conhecia. E estimaram que mais de 10 mil ainda estão escondidas sob a floresta.", 0.4),
 ("Perto desses lugares, aparecem árvores domesticadas pelos indígenas. Cinquenta e três espécies.", "Perto desses lugares, aparecem árvores domesticadas pelos indígenas. 53 espécies.", 0.45),
 ("No Acre, quando a floresta foi derrubada, surgiram desenhos gigantes no chão. Círculos e quadrados perfeitos: os geoglifos.", None, 0.35),
 ("Muitos foram construídos entre dois mil e setecentos anos atrás. E os cientistas acreditam que eram lugares de cerimônia.", "Muitos foram construídos entre 2 mil e 700 anos atrás. E os cientistas acreditam que eram lugares de cerimônia.", 0.4),
 ("E no Alto Xingu, entre os anos mil e duzentos e mil e seiscentos, existiam aldeias ligadas por estradas retas, com praças, valas e lagos de peixe.", "E no Alto Xingu, entre os anos 1200 e 1600, existiam aldeias ligadas por estradas retas, com praças, valas e lagos de peixe.", 0.35),
 ("Os pesquisadores chamam isso de urbanismo de floresta. E os Kuikuro de hoje provavelmente descendem de quem construiu tudo isso.", None, 0.45),
 ("Um explorador inglês sumiu na Amazônia em mil novecentos e vinte e cinco, procurando uma cidade perdida de pedra. Mas as cidades da Amazônia eram feitas de terra e de floresta.", "Um explorador inglês sumiu na Amazônia em 1925, procurando uma cidade perdida de pedra. Mas as cidades da Amazônia eram feitas de terra e de floresta.", 0.5),
 ("Então, quando disserem que a Amazônia é mata virgem, lembra: ela também é uma obra dos povos indígenas.", None, 0.6),
 ("No episódio três: montanhas de conchas, com gente enterrada dentro, no litoral do Brasil. Me segue pra não perder.", "No episódio 3: montanhas de conchas, com gente enterrada dentro, no litoral do Brasil. Me segue pra não perder.", 0.3),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.06); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
