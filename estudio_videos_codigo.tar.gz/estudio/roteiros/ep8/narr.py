import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 43, 1.05
L = [
 ("Traidor. Foi assim que ele entrou pra história do Brasil. Mas será que ele traiu mesmo?", None, 0.4),
 ("Mil seiscentos e trinta. Navios holandeses tomam Olinda e o Recife. O alvo era o açúcar de Pernambuco.", "1630. Navios holandeses tomam Olinda e o Recife. O alvo era o açúcar de Pernambuco.", 0.3),
 ("E por que a Holanda? Porque, desde mil quinhentos e oitenta, Portugal tinha o mesmo rei da Espanha. E a Holanda estava em guerra com a Espanha.", "E por que a Holanda? Porque, desde 1580, Portugal tinha o mesmo rei da Espanha. E a Holanda estava em guerra com a Espanha.", 0.35),
 ("Domingos Fernandes Calabar, um homem de Porto Calvo, nas Alagoas, lutou primeiro do lado português.", None, 0.3),
 ("Em mil seiscentos e trinta e dois, ele trocou de lado. Conhecia cada trilha, cada rio, cada engenho. E os holandeses começaram a vencer.", "Em 1632, ele trocou de lado. Conhecia cada trilha, cada rio, cada engenho. E os holandeses começaram a vencer.", 0.35),
 ("Em mil seiscentos e trinta e cinco, foi capturado em Porto Calvo. Foi estrangulado, e o corpo, esquartejado e exposto.", "Em 1635, foi capturado em Porto Calvo. Foi estrangulado, e o corpo, esquartejado e exposto.", 0.5),
 ("Mas pensa comigo: o rei dele, naquela época, era o rei da Espanha. Ele traiu o Brasil, que nem existia como país? Ou traiu um rei estrangeiro?", None, 0.45),
 ("Os holandeses ficaram vinte e quatro anos. O Recife virou capital, e ganhou a primeira sinagoga das Américas.", "Os holandeses ficaram 24 anos. O Recife virou capital, e ganhou a primeira sinagoga das Américas.", 0.35),
 ("Até que os senhores de engenho se revoltaram. Nos Guararapes, lutaram juntos portugueses, negros liderados por Henrique Dias, e indígenas liderados por Felipe Camarão.", None, 0.35),
 ("Em mil seiscentos e cinquenta e quatro, os holandeses se renderam. E Portugal ainda pagou uma fortuna à Holanda, pra ficar de vez com o Brasil.", "Em 1654, os holandeses se renderam. E Portugal ainda pagou uma fortuna à Holanda, pra ficar de vez com o Brasil.", 0.4),
 ("E Calabar? Em mil novecentos e setenta e três, Chico Buarque e Ruy Guerra escreveram uma peça sobre ele. A ditadura proibiu.", "E Calabar? Em 1973, Chico Buarque e Ruy Guerra escreveram uma peça sobre ele. A ditadura proibiu.", 0.4),
 ("E você? Acha que ele foi herói ou traidor? Comenta aqui.", None, 0.3),
 ("Porque até hoje, o nome dele é sinônimo de...", None, 0.15),
]
tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
