import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 43, 1.05
L = [
 ("Você votou no Flávio porque cansou de corrupção?", None, 0.45),
 ("Então você precisa saber disso.", None, 0.3),
 ("O dono do Banco Master, Daniel Vorcaro, foi preso pela Polícia Federal.", None, 0.3),
 ("Mensagens mostram o Flávio negociando com ele vinte e quatro milhões de dólares, pra um filme sobre o pai.", "Mensagens mostram o Flávio negociando com ele 24 milhões de dólares, pra um filme sobre o pai.", 0.35),
 ("Primeiro, ele negou qualquer contato com o banqueiro. Depois das mensagens, admitiu.", None, 0.35),
 ("Hoje, ele é investigado no Supremo. Ele nega irregularidades.", None, 0.5),
 ("A pergunta não é minha. É sua.", None, 0.35),
 ("Era isso que você queria combater?", None, 0.9),
]

tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
