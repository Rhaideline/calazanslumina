import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Brasileiro, no começo, não era nacionalidade. Era profissão.", None, 0.25),
 ("E o nome do país? Veio de uma árvore. Bora entender essa bagunça.", None, 0.25),
 ("Mil e quinhentos. Cabral chega e batiza a terra de Ilha de Vera Cruz.", "1500. Cabral chega e batiza a terra de Ilha de Vera Cruz.", 0.2),
 ("Só um detalhe: não era ilha.", None, 0.3),
 ("Trocaram pra Terra de Santa Cruz. Nome bonito, nome santo. E não pegou.", None, 0.25),
 ("Porque no litoral tinha uma árvore com um segredo. Por fora, espinhos e flores amarelas. Por dentro, um miolo vermelho, cor de brasa.", None, 0.25),
 ("Dessa madeira saía tinta vermelha. E na Europa, roupa vermelha era coisa de rei, de nobre, de gente rica.", None, 0.25),
 ("E aqui vem o plot twist: a palavra brasil já existia antes do país. Era o nome de uma tinta vermelha que vinha da Ásia.", None, 0.25),
 ("Então o português olhou essa árvore e pensou: achei brasil! O nome do produto engoliu o nome do santo. Teve cronista que reclamou por escrito. Não adiantou nada.", None, 0.25),
 ("Mas quem cortava as árvores? Os indígenas. Toras de até trinta quilos, carregadas no ombro por quilômetros até os navios.", "Mas quem cortava as árvores? Os indígenas. Toras de até 30 quilos, carregadas no ombro por quilômetros até os navios.", 0.25),
 ("Em troca, recebiam espelhos, miçangas, facas e machados de ferro. Pra quem usava machado de pedra, era tipo ganhar o celular mais novo do mercado.", None, 0.3),
 ("Só que essa troca virou exploração. Os navios levavam milhares de toras, e também indígenas escravizados.", None, 0.3),
 ("A Coroa transformou o pau-brasil em monopólio e alugou o negócio pra um comerciante chamado Fernão de Noronha. Sim, o da ilha.", None, 0.3),
 ("Quem trabalhava nesse comércio ganhou um nome: brasileiro. Com eiro no final, igual pedreiro, padeiro, sapateiro.", None, 0.25),
 ("Os franceses também queriam. Viraram aliados dos Tupinambá e levavam madeira escondido. Os indígenas chamavam os portugueses de peró, e os franceses de mair.", None, 0.25),
 ("Resultado: só no primeiro século, cerca de dois milhões de árvores derrubadas. Mais de cinquenta por dia.", "Resultado: só no primeiro século, cerca de 2 milhões de árvores derrubadas. Mais de 50 por dia.", 0.3),
 ("Hoje o pau-brasil está ameaçado de extinção. E é a madeira preferida pra fazer arcos de violino no mundo inteiro.", None, 0.25),
 ("Desde mil novecentos e setenta e oito, ele é a árvore nacional. Mas me conta: você já viu um de perto?", "Desde 1978, ele é a árvore nacional. Mas me conta: você já viu um de perto?", 0.3),
 ("E da próxima vez que alguém perguntar a sua profissão, responde com orgulho:", None, 0.1),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.14); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
