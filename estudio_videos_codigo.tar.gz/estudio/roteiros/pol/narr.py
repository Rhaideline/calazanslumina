import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Quarenta e sete por cento dos votos válidos foram pro Flávio Bolsonaro no primeiro turno. Mas quantos desses eleitores leram o que ele propõe?", None, 0.3),
 ("Eu li. São setenta e seis páginas. E tem coisa ali que pouca gente está te contando.", None, 0.3),
 ("Ele propõe reduzir a maioridade penal de dezoito pra catorze anos. Catorze. Idade de quem ainda está no ensino fundamental.", None, 0.35),
 ("Propõe liberar o fracking e flexibilizar o licenciamento ambiental. O fracking é proibido em países como França e Irlanda, pelo risco de contaminar a água.", None, 0.3),
 ("E propõe compartilhar dados do SUS com hospitais privados. Os seus dados de saúde.", None, 0.35),
 ("Agora, o Banco Master. O dono, Daniel Vorcaro, foi preso tentando sair do país num jatinho. O rombo pode chegar a doze bilhões de reais.", None, 0.3),
 ("Mensagens reveladas pelo Intercept e registros da Polícia Federal mostram Flávio negociando cento e trinta e quatro milhões de reais com Vorcaro, pra um filme sobre o pai. Pelo menos sessenta e um milhões foram pagos.", None, 0.3),
 ("Primeiro, ele disse que não conhecia Vorcaro. Depois, admitiu a aproximação. Hoje, é investigado no Supremo por suspeita de lavagem de dinheiro, evasão de divisas e corrupção.", None, 0.35),
 ("Investigação não é condenação. Mas é o mínimo que você precisa saber antes de apertar confirma.", None, 0.3),
 ("Vinte e cinco de outubro, o Brasil decide. Leia os planos no site do TSE, compare, e manda esse vídeo pra quem ainda não leu.", None, 0.4),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.1); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
