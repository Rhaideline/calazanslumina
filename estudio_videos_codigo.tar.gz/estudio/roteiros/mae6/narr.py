import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 42, 1.0
L = [
 ("Todo mundo pergunta como o bebê está. Quase ninguém pergunta como a mãe está. Esse vídeo é sobre os dois.", None, 0.5),
 ("No primeiro mês, ele enxerga melhor a uns vinte, trinta centímetros. A distância do seu rosto, no colo.", "No primeiro mês, ele enxerga melhor a uns 20, 30 centímetros. A distância do seu rosto, no colo.", 0.45),
 ("E você: o sangramento do pós-parto pode durar até seis semanas. É mais ou menos o tempo que o útero leva pra voltar ao tamanho.", "E você: o sangramento do pós-parto pode durar até 6 semanas. É mais ou menos o tempo que o útero leva pra voltar ao tamanho.", 0.45),
 ("Nos primeiros dias, chorar sem motivo é comum. É o baby blues, e costuma passar em até duas semanas.", None, 0.45),
 ("Se não passar, não é frescura. No Brasil, uma em cada quatro mães tem sintomas de depressão pós-parto. Tem tratamento, e pedir ajuda é coragem.", "Se não passar, não é frescura. No Brasil, 1 em cada 4 mães tem sintomas de depressão pós-parto. Tem tratamento, e pedir ajuda é coragem.", 0.5),
 ("Entre um e dois meses, vem o primeiro sorriso de verdade. O sorriso social.", "Entre 1 e 2 meses, vem o primeiro sorriso de verdade. O sorriso social.", 0.45),
 ("Com dois meses, de barriga pra baixo, ele já levanta a cabeça.", "Com 2 meses, de barriga pra baixo, ele já levanta a cabeça.", 0.4),
 ("Lá pelo terceiro mês, o seu cabelo pode começar a cair. Assusta, mas é hormonal, e passa.", None, 0.45),
 ("Com quatro meses, ele segura a cabeça sozinho, e pode começar a rolar.", "Com 4 meses, ele segura a cabeça sozinho, e pode começar a rolar.", 0.45),
 ("E atenção: amamentar só protege contra gravidez se três coisas acontecerem juntas. Sem menstruação, amamentação exclusiva, e o bebê com menos de seis meses.", "E atenção: amamentar só protege contra gravidez se 3 coisas acontecerem juntas. Sem menstruação, amamentação exclusiva, e o bebê com menos de 6 meses.", 0.5),
 ("Com seis meses, ele senta com apoio. E começa a introdução alimentar, com o leite materno continuando.", "Com 6 meses, ele senta com apoio. E começa a introdução alimentar, com o leite materno continuando.", 0.45),
 ("Cada bebê tem o seu tempo. Se algo te preocupar, fale com o pediatra.", None, 0.4),
 ("E a mãe também tem o seu tempo. Se precisar, procure a unidade de saúde, ou ligue cento e oitenta e oito.", "E a mãe também tem o seu tempo. Se precisar, procure a unidade de saúde, ou ligue 188.", 0.45),
 ("Salva esse vídeo, e manda pra uma mãe que precisa ouvir isso.", None, 0.9),
]
tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
