import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 43, 1.12
L = [
 ("Todo mundo fala em fascismo. Mas o que ele foi de verdade? Senta aí, que é rapidinho.", None, 0.3),
 ("Itália, mil novecentos e dezenove. País em crise depois da guerra. Aí um jornalista chamado Benito Mussolini funda os Fasci de Combate.", "Itália, 1919. País em crise depois da guerra. Aí um jornalista chamado Benito Mussolini funda os Fasci de Combate.", 0.3),
 ("O nome vem de fasces: um feixe de varas, símbolo de poder na Roma Antiga. Sozinho você quebra, junto ninguém quebra. Lindo, né? Calma.", None, 0.3),
 ("Os seguidores usavam camisa preta e espancavam opositores. Tipo um fã-clube, só que com porrete.", None, 0.3),
 ("Mil novecentos e vinte e dois: a Marcha sobre Roma. O rei podia ter barrado. Mas não barrou. E chamou Mussolini pra governar.", "1922: a Marcha sobre Roma. O rei podia ter barrado. Mas não barrou. E chamou Mussolini pra governar.", 0.3),
 ("Detalhe: o chefe da marcha não marchou. Chegou de trem. De vagão-leito.", None, 0.45),
 ("Mil novecentos e vinte e quatro: o deputado Giacomo Matteotti denuncia fraude e violência nas eleições. Dias depois, é assassinado por fascistas.", "1924: o deputado Giacomo Matteotti denuncia fraude e violência nas eleições. Dias depois, é assassinado por fascistas.", 0.35),
 ("Mussolini assume a culpa em público. E, em vez de cair, fecha tudo: sem outros partidos, sem imprensa livre.", None, 0.3),
 ("A receita: um líder que nunca erra, um inimigo pra culpar por tudo, propaganda o dia inteiro, e quem discorda vira traidor.", None, 0.35),
 ("Mil novecentos e trinta e oito: leis raciais. Crianças judias expulsas das escolas. Aqui não tem piada.", "1938: leis raciais. Crianças judias expulsas das escolas. Aqui não tem piada.", 0.55),
 ("Aí, o Mussolini fecha aliança com Hitler, entra na Segunda Guerra, e perde. Em quarenta e cinco, é capturado e morto por guerrilheiros italianos.", "Aí, o Mussolini fecha aliança com Hitler, entra na Segunda Guerra, e perde. Em 1945, é capturado e morto por guerrilheiros italianos.", 0.35),
 ("E o Brasil? Teve os integralistas, os camisas verdes. Em trinta e oito, tentaram um golpe no Rio. Deu errado em poucas horas.", "E o Brasil? Teve os integralistas, os camisas verdes. Em 1938, tentaram um golpe no Rio. Deu errado em poucas horas.", 0.35),
 ("Plot twist: o Brasil mandou vinte e cinco mil soldados pra lutar contra o fascismo na Itália. A Força Expedicionária Brasileira tomou Monte Castelo.", "Plot twist: o Brasil mandou 25 mil soldados pra lutar contra o fascismo na Itália. A Força Expedicionária Brasileira tomou Monte Castelo.", 0.35),
 ("O escritor italiano Umberto Eco fez uma lista com catorze sinais do fascismo. E avisou: basta um só desses sinais pra coisa começar a crescer.", "O escritor italiano Umberto Eco fez uma lista com 14 sinais do fascismo. E avisou: basta um só desses sinais pra coisa começar a crescer.", 0.35),
 ("Agora você sabe do que tá falando. Manda pra aquele amigo que acha que fascismo é só uma palavra.", None, 0.9),
]
tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
