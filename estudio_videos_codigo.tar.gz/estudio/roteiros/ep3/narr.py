import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("No litoral do Brasil existem montanhas feitas à mão. E dentro delas, tem gente enterrada.", None, 0.6),
 ("História do Brasil, episódio três: montanhas de conchas, e urnas de barro.", "História do Brasil, episódio 3: montanhas de conchas e urnas de barro.", 0.5),
 ("Essas montanhas se chamam sambaquis. Em tupi, quer dizer: amontoado de conchas.", None, 0.4),
 ("Por milhares de anos, povos do litoral foram empilhando conchas, areia, ossos de peixe e restos de fogueira.", None, 0.35),
 ("Mas não era um lixão. Os sambaquis eram cemitérios, monumentos, e lugares de ritual.", None, 0.45),
 ("E alguns são gigantes. Em Santa Catarina, os maiores passam de trinta metros de altura, e quinhentos metros de comprimento.", "E alguns são gigantes. Em Santa Catarina, os maiores passam de 30 metros de altura e 500 metros de comprimento.", 0.45),
 ("Tem sambaqui mais antigo que as pirâmides do Egito.", None, 0.6),
 ("Um deles, o Jabuticabeira dois, foi usado por cerca de mil anos. Gerações e gerações enterrando seus mortos no mesmo lugar.", "Um deles, o Jabuticabeira II, foi usado por cerca de mil anos. Gerações e gerações enterrando seus mortos no mesmo lugar.", 0.4),
 ("Hoje, são cerca de mil sambaquis registrados. Mas os arqueólogos acham que o número real pode ser muito maior.", None, 0.4),
 ("E muitos foram destruídos. No século dezenove, as conchas eram queimadas em fornos, pra virar cal de construção.", "E muitos foram destruídos. No século 19, as conchas eram queimadas em fornos, pra virar cal de construção.", 0.4),
 ("Por isso, desde mil novecentos e sessenta e um, os sambaquis são protegidos por lei.", "Por isso, desde 1961, os sambaquis são protegidos por lei.", 0.5),
 ("Agora, vamos pro norte. Na foz do Amazonas fica Marajó, a maior ilha fluviomarinha do mundo.", None, 0.35),
 ("Ali, entre os anos quatrocentos e mil e quatrocentos, viveu um povo que criou uma das cerâmicas mais impressionantes das Américas.", "Ali, entre os anos 400 e 1400, viveu um povo que criou uma das cerâmicas mais impressionantes das Américas.", 0.4),
 ("Como a ilha alaga na época das chuvas, eles construíram morros artificiais, os tesos, com até dez metros de altura. Em cima, casas, oficinas e cemitérios.", "Como a ilha alaga na época das chuvas, eles construíram morros artificiais, os tesos, com até 10 metros de altura. Em cima, casas, oficinas e cemitérios.", 0.4),
 ("As urnas funerárias eram pintadas de vermelho e preto, com figuras de mulheres, cobras, escorpiões e jacarés.", None, 0.4),
 ("E eles faziam até tangas de cerâmica.", None, 0.5),
 ("Essa cultura foi revelada à ciência em mil oitocentos e setenta e um. E o maior acervo está no Museu Goeldi, em Belém.", "Essa cultura foi revelada à ciência em 1871. E o maior acervo está no Museu Goeldi, em Belém.", 0.4),
 ("E a tradição não morreu. Em Icoaraci, artesãos ainda fazem cerâmica inspirada na marajoara.", None, 0.45),
 ("Então, muito antes de mil e quinhentos, o Brasil já tinha monumentos, cemitérios gigantes, e arte que atravessou os séculos.", "Então, muito antes de 1500, o Brasil já tinha monumentos, cemitérios gigantes, e arte que atravessou os séculos.", 0.6),
 ("No episódio quatro: vinte e dois de abril de mil e quinhentos. O dia em que dois mundos se encontraram. Me segue pra não perder.", "No episódio 4: 22 de abril de 1500. O dia em que dois mundos se encontraram. Me segue pra não perder.", 0.3),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.06); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
