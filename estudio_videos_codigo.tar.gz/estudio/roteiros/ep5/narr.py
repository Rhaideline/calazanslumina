import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("O rei de Portugal fatiou o Brasil igual pizza e deu as fatias pros amigos. Spoiler: quase todo mundo se deu mal.", None, 0.25),
 ("Mil quinhentos e trinta. Portugal tinha um problemão: uma terra gigante, quase ninguém pra ocupar, e os franceses rondando o litoral.", "1530. Portugal tinha um problemão: uma terra gigante, quase ninguém pra ocupar, e os franceses rondando o litoral.", 0.25),
 ("E o rei, Dom João Terceiro, não tinha dinheiro pra colonizar tudo sozinho.", "E o rei, Dom João III, não tinha dinheiro pra colonizar tudo sozinho.", 0.25),
 ("Solução? Terceirizar. Ele dividiu a terra em quinze faixas e entregou pra doze homens de confiança: os donatários.", "Solução? Terceirizar. Ele dividiu a terra em 15 faixas e entregou pra 12 homens de confiança: os donatários.", 0.25),
 ("Cada donatário virava quase um mini rei. Podia fundar vilas, cobrar impostos, fazer justiça e distribuir terras.", None, 0.25),
 ("E era hereditário: quando o donatário morria, a capitania passava pro filho. Daí o nome, capitanias hereditárias.", None, 0.25),
 ("Só tinha um detalhe. O rei não mandava um centavo. Navio, gente, arma e comida, tudo por conta do donatário.", None, 0.3),
 ("Aí começou o desastre. Aires da Cunha partiu com dez navios e novecentos homens rumo ao Maranhão. O navio naufragou, e ele morreu.", "Aí começou o desastre. Aires da Cunha partiu com 10 navios e 900 homens rumo ao Maranhão. O navio naufragou, e ele morreu.", 0.25),
 ("O sócio dele, João de Barros, era cronista do rei. Ele nem veio. Mandou os filhos.", None, 0.25),
 ("Martim Afonso, dono de São Vicente, foi lutar na Índia e nunca mais pisou no Brasil.", None, 0.3),
 ("Na Bahia, Francisco Pereira Coutinho maltratou os Tupinambá. Eles reagiram. Ele foi capturado e morto num ritual.", None, 0.3),
 ("Resultado: só duas capitanias deram certo de verdade. Pernambuco, com o açúcar de Duarte Coelho, e São Vicente.", None, 0.3),
 ("E agora a parte que a escola não te contou: aquele mapa com as faixas todas retinhas, deitadas, está errado.", None, 0.25),
 ("Em dois mil e treze, um pesquisador da USP refez o mapa usando os documentos da época. No norte, as divisas eram verticais.", "Em 2013, um pesquisador da USP refez o mapa usando os documentos da época. No norte, as divisas eram verticais.", 0.3),
 ("Mas muitos nomes daquelas capitanias continuam vivos: Pernambuco, Bahia, Espírito Santo, Maranhão.", None, 0.25),
 ("O sistema só acabou de vez em mil setecentos e cinquenta e nove, com o Marquês de Pombal.", "O sistema só acabou de vez em 1759, com o Marquês de Pombal.", 0.3),
 ("E aí, se o rei te oferecesse uma capitania, você aceitava? Comenta aqui.", None, 0.3),
 ("No próximo episódio, o rei muda o jogo. Mas antes, nunca esquece:", None, 0.1),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.12); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
