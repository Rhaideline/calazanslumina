import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Se o Flávio Bolsonaro ganhar, qual vai ser o primeiro ato dele? Ele mesmo respondeu. E é por isso que eu fiz esse vídeo.", None, 0.3),
 ("Em setembro de dois mil e vinte e cinco, o Supremo condenou Jair Bolsonaro a vinte e sete anos de prisão, por liderar uma tentativa de golpe de Estado.", "Em setembro de 2025, o Supremo condenou Jair Bolsonaro a 27 anos de prisão, por liderar uma tentativa de golpe de Estado.", 0.3),
 ("O filho chama o julgamento de farsa. E no Jornal Nacional, prometeu: vai trabalhar pela anistia ainda na transição. Se não passar, indulto.", None, 0.3),
 ("E sobre os presos do oito de janeiro, ele disse, com todas as letras: vou dar indulto para todo mundo.", "E sobre os presos do 8 de janeiro, ele disse, com todas as letras: vou dar indulto para todo mundo.", 0.4),
 ("Pensa nisso. O primeiro ato de um presidente, perdoar quem tentou derrubar a democracia. Inclusive o próprio pai.", None, 0.45),
 ("Agora, o amigo banqueiro. Daniel Vorcaro, dono do Banco Master. O rombo pode chegar a doze bilhões de reais, e atinge um milhão e seiscentas mil pessoas.", "Agora, o amigo banqueiro. Daniel Vorcaro, dono do Banco Master. O rombo pode chegar a 12 bilhões de reais, e atinge 1,6 milhão de pessoas.", 0.3),
 ("Flávio pediu a ele cento e trinta e quatro milhões de reais, pra um filme sobre o pai. Pelo menos sessenta e um milhões foram pagos.", "Flávio pediu a ele 134 milhões de reais, pra um filme sobre o pai. Pelo menos 61 milhões foram pagos.", 0.3),
 ("A Polícia Federal achou as mensagens. Em setembro, áudio cobrando pagamento. Em dezesseis de novembro, Flávio escreveu: Irmão, não tem meia conversa entre a gente. Só preciso que me dê uma luz.", "A Polícia Federal achou as mensagens. Em setembro, áudio cobrando pagamento. Em 16 de novembro, Flávio escreveu: Irmão, não tem meia conversa entre a gente. Só preciso que me dê uma luz.", 0.3),
 ("Vorcaro respondeu com uma imagem que se apaga. Flávio respondeu: Amém.", None, 0.5),
 ("No dia seguinte, Vorcaro foi preso, tentando sair do país num jatinho pra Malta.", None, 0.4),
 ("Primeiro, Flávio disse que não conhecia Vorcaro. Depois, admitiu. Hoje é investigado no Supremo por suspeita de lavagem de dinheiro, evasão de divisas e corrupção. Investigação não é condenação. Mas você contrataria alguém assim?", None, 0.4),
 ("E tem o plano de governo. Ele quer liberar o fracking: perfurar mais de três mil metros e injetar água com produtos químicos sob pressão, pra quebrar a rocha e tirar gás.", None, 0.3),
 ("Mais de noventa por cento desse fluido fica no subsolo, com risco de contaminar a água que a gente bebe. O Paraná proibiu. Mais de trezentas e oitenta cidades proibiram. Ele quer liberar.", "Mais de 90% desse fluido fica no subsolo, com risco de contaminar a água que a gente bebe. O Paraná proibiu. Mais de 380 cidades proibiram. Ele quer liberar.", 0.3),
 ("E quer compartilhar os dados do SUS com hospitais privados. Seu prontuário. Seus diagnósticos. O dado mais sensível que existe. A própria lei de proteção de dados proíbe usar dado de saúde pra lucrar.", None, 0.4),
 ("Perdão pra golpe. Banqueiro preso chamado de irmão. Risco na sua água. Seus dados de saúde fora do SUS.", None, 0.4),
 ("Vinte e cinco de outubro. Não é sobre gostar ou não do outro lado. É sobre saber quem você está colocando lá. Manda esse vídeo pra quem ainda não sabe.", "25 de outubro. Não é sobre gostar ou não do outro lado. É sobre saber quem você está colocando lá. Manda esse vídeo pra quem ainda não sabe.", 0.5),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.12); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
