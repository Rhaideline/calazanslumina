import json, numpy as np, soundfile as sf
from tts import load
L = [
 ("Pra entender o que está em jogo no dia vinte e cinco, você precisa voltar sessenta e dois anos.", "Pra entender o que está em jogo no dia 25, você precisa voltar 62 anos.", 0.3),
 ("Trinta e um de março de mil novecentos e sessenta e quatro. Tanques saem de Minas Gerais. O presidente João Goulart é derrubado.", "31 de março de 1964. Tanques saem de Minas Gerais. O presidente João Goulart é derrubado.", 0.3),
 ("Os militares prometeram que seria rápido. Que em mil novecentos e sessenta e cinco teria eleição. A eleição não veio.", "Os militares prometeram que seria rápido. Que em 1965 teria eleição. A eleição não veio.", 0.4),
 ("Em sessenta e oito, o AI-5 fechou o Congresso, censurou a imprensa e suspendeu o habeas corpus pra crimes políticos.", "Em 68, o AI-5 fechou o Congresso, censurou a imprensa e suspendeu o habeas corpus pra crimes políticos.", 0.3),
 ("Foram vinte e um anos. A Comissão Nacional da Verdade contou quatrocentos e trinta e quatro mortos e desaparecidos políticos, e apontou trezentos e setenta e sete responsáveis.", "Foram 21 anos. A Comissão Nacional da Verdade contou 434 mortos e desaparecidos políticos, e apontou 377 responsáveis.", 0.3),
 ("E aí veio mil novecentos e setenta e nove. A Lei da Anistia. Ela perdoou também os agentes do Estado. Torturadores voltaram pra casa sem julgamento.", "E aí veio 1979. A Lei da Anistia. Ela perdoou também os agentes do Estado. Torturadores voltaram pra casa sem julgamento.", 0.4),
 ("Quem não é punido, não desaparece. Em dois mil e dezesseis, um deputado dedicou seu voto ao coronel Brilhante Ustra, o primeiro militar reconhecido pela Justiça como torturador. Esse deputado era Jair Bolsonaro.", "Quem não é punido, não desaparece. Em 2016, um deputado dedicou seu voto ao coronel Brilhante Ustra, o primeiro militar reconhecido pela Justiça como torturador. Esse deputado era Jair Bolsonaro.", 0.4),
 ("Em dois mil e vinte e cinco, aconteceu o que nunca tinha acontecido. O Supremo condenou um ex-presidente e generais por tentativa de golpe de Estado.", "Em 2025, aconteceu o que nunca tinha acontecido. O Supremo condenou um ex-presidente e generais por tentativa de golpe de Estado.", 0.3),
 ("Os golpes de trinta, de trinta e sete e de sessenta e quatro nunca foram punidos. Esse foi. Pela primeira vez na nossa história.", "Os golpes de 30, de 37 e de 64 nunca foram punidos. Esse foi. Pela primeira vez na nossa história.", 0.4),
 ("E agora o filho promete desfazer isso. Anistia ainda na transição. Se não passar, indulto. Pra todo mundo.", None, 0.4),
 ("É mil novecentos e setenta e nove de novo. Golpe, e depois perdão.", "É 1979 de novo. Golpe, e depois perdão.", 0.4),
 ("E não são só quatro anos. O próximo presidente vai indicar três ministros do Supremo, porque Fux, Cármen Lúcia e Gilmar Mendes se aposentam até dois mil e trinta.", "E não são só quatro anos. O próximo presidente vai indicar três ministros do Supremo, porque Fux, Cármen Lúcia e Gilmar Mendes se aposentam até 2030.", 0.3),
 ("Quase um terço do tribunal que julgou o golpe. E um ministro pode ficar mais de vinte anos no cargo.", None, 0.3),
 ("Além disso, o presidente comanda as Forças Armadas e escolhe o diretor da Polícia Federal. A mesma Polícia Federal que achou as mensagens do caso Master.", None, 0.4),
 ("Em sessenta e quatro, prometeram um ano. Durou vinte e um. Em setenta e nove, perdoaram. E tentaram de novo.", "Em 64, prometeram um ano. Durou 21. Em 79, perdoaram. E tentaram de novo.", 0.4),
 ("Dia vinte e cinco de outubro, o Brasil decide se aprende com a própria história, ou se repete. Manda pra quem precisa lembrar.", "Dia 25 de outubro, o Brasil decide se aprende com a própria história, ou se repete. Manda pra quem precisa lembrar.", 0.5),
]
tts=load("faber"); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=0,speed=1.1); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-400):nz[-1]+800]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(t)
