import json, numpy as np, soundfile as sf
from tts import load_kokoro
SID, SPEED = 42, 1.0
L = [
 ("Seu diagnóstico. Sua gravidez. Sua depressão pós-parto.", None, 0.5),
 ("Pela lei, dado de saúde é dado sensível. O mais protegido que existe.", None, 0.35),
 ("O plano de governo do Flávio propõe um prontuário eletrônico ligado ao seu CPF, interligado entre o sus e a rede privada.", "O plano de governo do Flávio propõe um prontuário eletrônico ligado ao seu CPF, interligado entre o SUS e a rede privada.", 0.45),
 ("Antes de votar, vale perguntar: quem vai ter acesso aos seus dados?", None, 0.45),
 ("Está escrito no plano. Leia, compare com o do Lula, e decida.", None, 0.9),
]

tts=load_kokoro(); out=[]; meta=[]; t=0.0
for i,(s,d,gap) in enumerate(L):
    a=tts.generate(s,sid=SID,speed=SPEED); sr=a.sample_rate; x=np.array(a.samples,dtype=np.float32)
    nz=np.where(np.abs(x)>0.01)[0]; x=x[max(0,nz[0]-300):nz[-1]+600]
    x=np.concatenate([x,np.zeros(int(gap*sr),dtype=np.float32)])
    dur=len(x)/sr; meta.append(dict(i=i+1,start=t,dur=dur,speech=dur-gap,text=d or s)); t+=dur; out.append(x)
y=np.concatenate(out); y=y/np.abs(y).max()*0.9
sf.write("narracao.wav",y,sr); json.dump(meta,open("timing.json","w"),ensure_ascii=False,indent=1); print(round(t,1))
