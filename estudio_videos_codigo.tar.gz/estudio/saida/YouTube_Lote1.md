# Canal Calazans Lumina · História do Brasil · Lote 1

## Como publicar

- **Formato:** YouTube Shorts (vídeo vertical de até 3 minutos). Os três episódios têm entre 115 e 132 segundos.
- **Playlist:** crie "História do Brasil · a série" e coloque os episódios em ordem. No Shorts, use "Vídeo relacionado" apontando para o episódio seguinte.
- **Ritmo sugerido:** um episódio a cada 2 dias, às 18h ou 19h (horário em que estudantes e professores estão no celular). Ep1 numa terça, Ep2 na quinta, Ep3 no sábado.
- **Capa:** no app do YouTube, ao publicar o Short, escolha o quadro do título (os primeiros 2 segundos têm o título amarelo). Também mando as capas em PNG.
- **Transparência:** a narração é feita com voz sintética. Diga isso na descrição. Como as imagens são ilustrações e não imitam pessoas reais, o selo de "conteúdo alterado ou sintético" do YouTube não é obrigatório, mas você pode marcar por transparência.
- **Comentário fixado:** fixe sempre uma pergunta. Comentário puxa o algoritmo.

---

## Ep1 · O Brasil antes do Brasil

**Título**
```
Quem vivia no Brasil há 11 mil anos? | História do Brasil Ep1 #shorts
```

**Descrição**
```
Muito antes de 1500, o Brasil já tinha gente. Muita gente.
Neste episódio: a travessia da Era do Gelo, os pingentes de osso de preguiça-gigante no Mato Grosso, as pinturas da Serra da Capivara, e Luzia, o esqueleto mais antigo do Brasil, que sobreviveu ao incêndio do Museu Nacional.

Série História do Brasil, episódio 1 de 8. Se inscreve no canal pra não perder o próximo.

Fontes: Serra da Capivara (UNESCO, Patrimônio Mundial) · DNA do povo de Luzia (estudos publicados em 2018 nas revistas Cell e Science) · Museu Nacional/UFRJ · pegadas de White Sands, EUA (Science, 2021) · pingentes de preguiça-gigante de Santa Elina, MT (Proceedings of the Royal Society B, 2023).
Narração com voz sintética · ilustrações originais Calazans Lumina.

#historiadobrasil #luzia #serradacapivara #arqueologia #shorts
```

**Tags**
```
história do brasil, luzia, serra da capivara, arqueologia, brasil pré-histórico, povos indígenas, museu nacional, era do gelo, história para enem
```

**Comentário fixado**
```
Você sabia que a Luzia sobreviveu ao incêndio do Museu Nacional? Comenta aqui 👇
```

---

## Ep2 · A floresta que foi plantada

**Título**
```
A Amazônia não é mata virgem | História do Brasil Ep2 #shorts
```

**Descrição**
```
Boa parte da maior floresta tropical do mundo foi cuidada e plantada por povos indígenas.
Neste episódio: a domesticação da mandioca há 9 mil anos, a terra preta de índio, as obras de terra reveladas por LiDAR, os geoglifos do Acre e as aldeias com estradas e praças do Alto Xingu.

Série História do Brasil, episódio 2 de 8. Se inscreve no canal pra não perder o próximo.

Fontes: estudo sobre a terra preta com o povo Kuikuro (Science Advances, 2023) · estimativa de mais de 10 mil obras de terra escondidas na Amazônia (Science, 2023) · pesquisas de Michael Heckenberger no Alto Xingu · domesticação da mandioca no sudoeste da Amazônia.
Narração com voz sintética · ilustrações originais Calazans Lumina.

#historiadobrasil #amazonia #povosindigenas #arqueologia #shorts
```

**Tags**
```
história do brasil, amazônia, terra preta de índio, geoglifos do acre, mandioca, kuikuro, alto xingu, arqueologia amazônica, povos indígenas
```

**Comentário fixado**
```
Você achava que a Amazônia era mata virgem? Comenta aqui 👇
```

---

## Ep3 · Montanhas de conchas e urnas de barro

**Título**
```
Montanhas de conchas com gente enterrada dentro | História do Brasil Ep3 #shorts
```

**Descrição**
```
No litoral do Brasil existem montanhas feitas à mão, e algumas são mais antigas que as pirâmides do Egito.
Neste episódio: os sambaquis, cemitérios e monumentos de conchas, e a cerâmica marajoara, com urnas pintadas, tesos e até tangas de cerâmica.

Série História do Brasil, episódio 3 de 8. Se inscreve no canal pra não perder o próximo.

Fontes: Lei nº 3.924/1961 (proteção dos sambaquis) · pesquisas no sambaqui Jabuticabeira II (SC) · Museu Paraense Emílio Goeldi (acervo marajoara) · artesanato de Icoaraci (PA).
Narração com voz sintética · ilustrações originais Calazans Lumina.

#historiadobrasil #sambaqui #marajoara #arqueologia #shorts
```

**Tags**
```
história do brasil, sambaqui, cerâmica marajoara, ilha de marajó, arqueologia, museu goeldi, santa catarina, brasil antes de 1500
```

**Comentário fixado**
```
Tem sambaqui perto da sua cidade? Comenta aqui 👇
```

---

## Próximos passos do canal

1. **Lote 2:** episódios 4 a 8 com a mesma voz e a chamada "Se inscreve no canal". Os episódios 7 e 8 já estão prontos no código.
2. **Primeiro vídeo longo:** "A história do Brasil antes e depois de 1500", juntando os episódios 1 a 8 em formato horizontal (16:9), com capítulos, em torno de 15 minutos. É o tipo de vídeo que soma horas assistidas para monetizar.
3. **Trailer do canal:** 30 segundos com os melhores momentos da série.
