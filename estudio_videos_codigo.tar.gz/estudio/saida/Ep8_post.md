# Ep8 · Calabar: o maior traidor do Brasil?

## Legenda do post

Traidor. Foi assim que Domingos Fernandes Calabar entrou para a história do Brasil.

Em 1630, os holandeses tomaram Olinda e o Recife atrás do açúcar de Pernambuco. Calabar lutou primeiro do lado português, depois trocou de lado e foi executado em 1635. Mas naquela época o rei de Portugal era o rei da Espanha, e o Brasil nem existia como país. Ele traiu quem?

Herói ou traidor? Comenta aqui 👇
Siga para o episódio 9 da série História do Brasil.

#históriadobrasil #calabar #holandesesnobrasil #pernambuco #recife #brasilcolonial #aprendanotiktok #professoresdehistória

## Comentário para fixar

Fontes que usei:
- Invasão de 1630, Olinda e Recife, União Ibérica: Toda Matéria, "Invasões Holandesas" e Politize, "As invasões holandesas no Brasil colonial"
- Calabar (troca de lado em 1632, execução em Porto Calvo em 1635): eBiografia e artigo da revista História Pública (UEMG) sobre frei Manoel Calado
- Primeira sinagoga das Américas, Kahal Zur Israel, Recife: Revista Pesquisa FAPESP
- Guararapes, 1654 e Tratado de Haia de 1661: Toda Matéria, "Insurreição Pernambucana" e anais da ANPUH
- Peça "Calabar, o elogio da traição" (Chico Buarque e Ruy Guerra), proibida pela censura em 1974: dissertação da UFRGS, "Censura e cultura nos anos 1970"

Conteúdo produzido com auxílio de IA.

## O que ficou de fora de propósito (as fontes divergem)

- Ano de nascimento de Calabar (1600 ou 1609).
- Valor pago por Portugal em 1661 (8 milhões de florins ou 4 milhões de cruzados). O vídeo diz só "uma fortuna".
- Quem comandou qual batalhão em Guararapes. Fontes oficiais divergem em detalhes. O vídeo segue a versão da ANPUH: Henrique Dias com os negros, Felipe Camarão com os indígenas.
- Os motivos de Calabar para trocar de lado são desconhecidos. O vídeo não inventa motivo.

## Detalhes técnicos

- Voz nova (Kokoro, pt-BR), conferida por transcrição automática linha a linha.
- 88 segundos, 13 cenas, o final emenda no começo ("o nome dele é sinônimo de..." vira "Traidor.").
