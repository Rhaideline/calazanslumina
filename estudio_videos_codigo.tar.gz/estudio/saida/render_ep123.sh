#!/usr/bin/env bash
cd /home/user/calazanslumina/estudio/cine
for n in 1 2 3; do
  python3 preview_any.py scenes_ep$n layers_ep$n > ../saida/prev_ep$n.log 2>&1
  python3 run_ep$n.py > ../saida/run_ep$n.log 2>&1
  echo "ep$n $(tail -1 ../saida/run_ep$n.log)" >> ../saida/render_ep123.progress
done
echo FIM > ../saida/render_ep123.done
