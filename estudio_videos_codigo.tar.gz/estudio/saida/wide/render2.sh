cd /home/user/calazanslumina/estudio/cine
export WIDE=1
ln -sfn layers_ep5w layers_capw  # run_ep5w procura layers_cap(+w)
P=../saida/wide/render2.progress; : > $P
for n in 5 6 7 8; do python3 preview_any.py scenes_ep$n layers_ep${n}w > /dev/null 2>&1; echo "layers ep$n" >> $P; done
for n in 1 2 3 4 5 6 7 8; do
  python3 run_ep${n}w.py > ../saida/wide/run_ep${n}w.log 2>&1 && echo "ep$n done $(ffprobe -v error -show_entries format=duration -of csv=p=0 ../saida/wide/Ep${n}_16x9.mp4)" >> $P || echo "ep$n FAIL" >> $P
done
touch ../saida/wide/render2.done
