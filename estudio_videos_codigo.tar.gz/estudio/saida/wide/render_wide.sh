#!/usr/bin/env bash
cd /home/user/calazanslumina/estudio/cine
export WIDE=1
for n in 2 3 4 5 6 7 8; do
  python3 preview_any.py scenes_ep$n layers_ep${n}w > ../saida/wide/prev_ep$n.log 2>&1
  python3 run_ep${n}w.py > ../saida/wide/run_ep${n}w.log 2>&1
  echo "ep$n $(tail -1 ../saida/wide/run_ep${n}w.log)" >> ../saida/wide/render_wide.progress
done
echo FIM > ../saida/wide/render_wide.done
