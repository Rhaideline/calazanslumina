cd /home/user/calazanslumina/estudio/cine
while pgrep -f run_ep5w.py >/dev/null; do sleep 15; done
export WIDE=1
python3 rl_some.py scenes_ep1 layers_ep1w 17 && python3 run_ep1w.py > ../saida/wide/run_ep1w.log 2>&1 && echo ep1 ok >> ../saida/wide/fix.progress
python3 rl_some.py scenes_ep8 layers_ep8w 8 && python3 run_ep8w.py > ../saida/wide/run_ep8w.log 2>&1 && echo ep8 ok >> ../saida/wide/fix.progress
touch ../saida/wide/fix.done
