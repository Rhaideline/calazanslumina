# Ep7 · França Antártica (o Rio já foi francês)

## Legenda do post (TikTok)

O Rio de Janeiro já teve uma colônia francesa. Ela se chamava França Antártica 🇫🇷

Em 1555, Villegaignon entrou na baía de Guanabara, ergueu o Forte Coligny e se aliou aos Tupinambá. Mas a colônia rachou por causa de religião, os portugueses atacaram, e o Rio acabou nascendo como base de guerra, em 1565.

Você já sabia disso? Comenta aqui 👇
Siga para o episódio 8 da série História do Brasil.

#históriadobrasil #riodejaneiro #françaantártica #brasilcolonial #tamoios #aprendanotiktok #professoresdehistória #curiosidades #historia #brasil

## Comentário para fixar

Fontes que usei para conferir os fatos:
- Revista do Instituto de Geografia e História Militar do Brasil (IGHMB), artigo sobre a França Antártica e a fundação do Rio
- Revista Pesquisa FAPESP, "Short stay, long legacy"
- Musée protestant, "Protestants and the Conquest of the New World" (calvinistas e Jean de Léry)
- InfoEscola, "Confederação dos Tamoios"
- Duke University Press, edição de "Hans Staden's True History"

Alguns pontos têm versões diferentes entre os historiadores (número de colonos, local exato e data da morte de Estácio de Sá). No vídeo eu só usei o que as fontes concordam. Conteúdo produzido com auxílio de IA.

## Pontos para você conferir antes de publicar

1. "Cavaleiro de Malta": confirmado (Hérodote, herodote.net). A mesma fonte diz que ele tinha se convertido ao protestantismo e foi vice-almirante da Bretanha.
2. Morte de Estácio de Sá: o vídeo diz "uma flecha no rosto" e "morreu cerca de um mês depois". As fontes divergem sobre rosto ou olho e sobre o local do tiro. A data exata da morte não foi confirmada, por isso o vídeo não a cita.
3. Número de colonos: as fontes dizem de 200 a 600. O vídeo não cita número.
4. A página da Marinha, a Wikipédia em português e o Arquivo Nacional estavam bloqueados neste ambiente. A conferência foi feita por resultados de busca, não pela leitura completa das fontes.
5. As ilustrações são silhuetas estilizadas, sem rostos reais.
