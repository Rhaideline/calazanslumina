# Reel 2º turno · "O perdão que o Brasil já deu"

Vídeo de 98 segundos, 14 cenas, com a fonte escrita na tela em cada fato e o aviso fixo "Conteúdo produzido com auxílio de inteligência artificial".

## Legenda do post

1979: o Brasil perdoou os militares. 2025: condenou um golpe pela primeira vez. Em 2026, um candidato promete perdoar de novo.

Tudo que está no vídeo tem fonte na tela e nos links do comentário fixado. Investigação não é condenação, e ele nega irregularidades. Leia o plano de governo dele e o do Lula no site do TSE, compare, e vote com informação no dia 25.

#eleições2026 #segundoturno #históriadobrasil #voteconsciente #anistia #supremo

## Comentário para fixar

Fontes (leia e confira você mesmo):
- Resultado do 1º turno, TSE: https://www.tse.jus.br/comunicacao/noticias/2026/Outubro/flavio-bolsonaro-e-lula-vao-disputar-o-2o-turno-para-a-presidencia-da-republica
- Anistia e indulto, InfoMoney: https://www.infomoney.com.br/politica/flavio-diz-que-buscara-anistia-para-bolsonaro-ainda-durante-governo-de-transicao/
- Indulto, SBT News: https://sbtnews.sbt.com.br/noticia/politica/8-1-sem-anistia-darei-indulto-a-todo-mundo-diz-flavio
- Inquérito no STF, CNN Brasil: https://www.cnnbrasil.com.br/blogs/teo-cury/politica/flavio-bolsonaro-e-investigado-no-stf-sobre-financiamento-de-dark-horse/
- Repasses e investigação, A Pública: https://apublica.org/2026/10/escandalo-master-pesa-na-urna-para-uns-e-passa-batido-para-outros/
- Mensagens apreendidas pela PF, Brasil de Fato: https://www.brasildefato.com.br/2026/09/21/mensagens-apreendidas-pela-pf-mostram-pressao-de-flavio-bolsonaro-e-neymar-pai-sobre-vorcaro/
- 43 declarações enganosas, Aos Fatos: https://www.aosfatos.org/noticias/flavio-mentiu-ao-menos-43-vezes-sobre-envolvimento-com-vorcaro/
- Plano de governo (íntegra), Poder360: https://www.poder360.com.br/poder-flash/leia-a-integra-do-plano-de-governo-de-flavio-bolsonaro/
- Fracking e dados do SUS no plano, Agência Brasil: https://agenciabrasil.ebc.com.br/politica/noticia/2026-09/flavio-bolsonaro-propoe-enxugar-estado-e-endurecer-acoes-de-seguranca
- Vagas no STF até 2030, Gazeta SP: https://www.gazetasp.com.br/politica/eleicoes-2026-o-peso-da-indicacao-de-novos-ministros-ao-stf/
- Fracking proibido em países, IHU Unisinos: https://ihu.unisinos.br/570197

Investigação não é condenação. Flávio Bolsonaro nega irregularidades. Conteúdo produzido com auxílio de IA.

## Recortes de notícia no vídeo

Nos segundos takes de 10 cenas, aparecem recortes redesenhados com o título real da matéria e o nome do veículo em texto, sem logotipo: InfoMoney, SBT News, A Pública, Brasil de Fato, Carta Capital, Portal Salvador FM, Aos Fatos, CNN Brasil, Agência Brasil, Folha de Pernambuco e TSE. Os títulos foram copiados dos resultados de busca, não de uma leitura da página. Os dois com "trecho citado" vêm do plano de governo, como reproduzidos pela Agência Brasil. Antes de publicar, abra cada link do comentário fixado e confira se o título está igual. Este ambiente não consegue abrir os sites das matérias nem baixar as fotos.

## O que mudei em relação ao seu roteiro antigo (pol e pol2)

1. **Maioridade penal:** o roteiro antigo dizia "de 18 para 14 anos". O plano diz 16 anos como regra geral e punição a partir dos 14 só em crimes graves (estupro, tráfico, tortura, assassinato). Quem dizer "14 anos" sem explicar vai ser desmentido. Por isso esse ponto ficou fora do vídeo.
2. **Jatinho para Malta:** a PF fala em Malta, a defesa diz que o destino era Dubai com escala em Malta. Tirei o detalhe.
3. **"Rombo de 12 bilhões":** é uma estimativa inicial da PF sobre títulos falsos. Não é o prejuízo total. Tirei o número.
4. **Frases entre aspas** ("Amém", "não tem meia conversa"): não consegui confirmar nas fontes, então não usei.
5. **"Primeiro ato do presidente seria perdoar o pai":** ele prometeu anistia na transição e, se não passar, indulto aos condenados do 8 de janeiro. Especialistas citados pela Folha dizem que indultar o pai a tempo é improvável, e que o pai continuaria inelegível mesmo com perdão. Não afirmei isso no vídeo.

## Conferido nesta rodada (com fonte)

- **Condenação de Bolsonaro:** a Primeira Turma do STF condenou em 11/09/2025, por 4 votos a 1, a 27 anos e 3 meses de prisão (24 anos e 9 meses de reclusão e 2 anos e 6 meses de detenção). Fux foi o único voto contrário. A execução só começa após o trânsito em julgado. Fontes: Poder360 https://poder360.com.br/poder-justica/stf-condena-bolsonaro-27-anos-e-3-meses-por-tentativa-de-golpe/ e CNN Brasil https://www.cnnbrasil.com.br/politica/stf-pena-jair-bolsonaro/
- **"Primeira vez":** a InfoMoney registra que é a primeira vez que um ex-presidente é punido por esse tipo de acusação. O vídeo diz isso na abertura.
- **Lei da Anistia:** a Lei 6.683/1979 foi interpretada como cobrindo crimes conexos aos políticos, inclusive de agentes do Estado. O STF manteve essa leitura em 2010 (ADPF 153, 7 votos a 2) e reafirmou em 2018. Fonte: JusBrasil https://jus.com.br/artigos/14681/lei-de-anistia-e-sua-interpretacao-o-caso-da-adpf-n-153
- **Fracking na França:** a Lei nº 2011-835, de 13/07/2011 (Lei Jacob), proíbe a fraturação hidráulica no território, e o Conselho Constitucional a validou em 2013. Fonte: Banque des Territoires https://www.banquedesterritoires.fr/gaz-de-schiste-le-conseil-constitutionnel-valide-la-loi-du-13-juillet-2011 . Alemanha e Irlanda: IHU Unisinos https://ihu.unisinos.br/570197

## Ainda sem fonte primária

- **R$ 61 milhões:** vem de reportagens e da investigação da PF, com variação entre US$ 12,3 e 14 milhões pagos. O vídeo diz "investiga repasses", que é o que as fontes sustentam. Não consegui abrir o Intercept.
- **Títulos dos recortes:** copiados de resultados de busca. Abra cada link e confira antes de postar.
- **Inelegibilidade de Bolsonaro:** as fontes divergem (Reuters fala em até 2060, InfoMoney em 8 anos após a pena). O vídeo não afirma isso.

## Regras eleitorais para não ter problema

- Pessoa física não pode pagar impulsionamento de conteúdo político. Só o orgânico.
- Conteúdo feito com IA precisa de aviso. O vídeo já tem o aviso fixo na tela.
- Não há rosto de ninguém, deepfake nem logotipo de veículo.
- Se alguém pedir direito de resposta ou a Justiça mandar remover, a fonte de cada afirmação está no comentário fixado.
- É conteúdo de opinião. Vale deixar claro no perfil que o ponto de vista é seu.
