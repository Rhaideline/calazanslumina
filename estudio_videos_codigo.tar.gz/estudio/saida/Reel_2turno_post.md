# Reel 2º turno · "O perdão que o Brasil já deu"

Vídeo de 98 segundos, 14 cenas, com a fonte escrita na tela em cada fato e o aviso fixo "Conteúdo produzido com auxílio de inteligência artificial".

## Legenda do post

1979: o Brasil perdoou os militares. 2025: condenou um golpe pela primeira vez. Em 2026, um candidato promete perdoar de novo.

Tudo que está no vídeo tem fonte na tela e nos links do comentário fixado. Investigação não é condenação, e ele nega irregularidades. Leia o plano de governo dele e o do Lula no site do TSE, compare, e vote com informação no dia 25.

#eleições2026 #segundoturno #históriadobrasil #voteconsciente #anistia #supremo

## Comentário para fixar

Fontes (leia e confira você mesmo):
- Resultado do 1º turno, TSE: https://www.tse.jus.br/comunicacao/noticias/2026/Outubro/flavio-bolsonaro-e-lula-vao-disputar-o-2o-turno-para-a-presidencia-da-republica
- Anistia e indulto, InfoMoney: https://www.infomoney.com.br/politica/flavio-diz-que-buscara-anistia-para-bolsonaro-ainda-durante-governo-de-transicao/
- Indulto, SBT News: https://sbtnews.sbt.com.br/noticia/politica/8-1-sem-anistia-darei-indulto-a-todo-mundo-diz-flavio
- Inquérito no STF, CNN Brasil: https://www.cnnbrasil.com.br/blogs/teo-cury/politica/flavio-bolsonaro-e-investigado-no-stf-sobre-financiamento-de-dark-horse/
- Repasses e investigação, A Pública: https://apublica.org/2026/10/escandalo-master-pesa-na-urna-para-uns-e-passa-batido-para-outros/
- Mensagens apreendidas pela PF, Brasil de Fato: https://www.brasildefato.com.br/2026/09/21/mensagens-apreendidas-pela-pf-mostram-pressao-de-flavio-bolsonaro-e-neymar-pai-sobre-vorcaro/
- 43 declarações enganosas, Aos Fatos: https://www.aosfatos.org/noticias/flavio-mentiu-ao-menos-43-vezes-sobre-envolvimento-com-vorcaro/
- Plano de governo (íntegra), Poder360: https://www.poder360.com.br/poder-flash/leia-a-integra-do-plano-de-governo-de-flavio-bolsonaro/
- Fracking e dados do SUS no plano, Agência Brasil: https://agenciabrasil.ebc.com.br/politica/noticia/2026-09/flavio-bolsonaro-propoe-enxugar-estado-e-endurecer-acoes-de-seguranca
- Vagas no STF até 2030, Gazeta SP: https://www.gazetasp.com.br/politica/eleicoes-2026-o-peso-da-indicacao-de-novos-ministros-ao-stf/
- Fracking proibido em países, IHU Unisinos: https://ihu.unisinos.br/570197

Investigação não é condenação. Flávio Bolsonaro nega irregularidades. Conteúdo produzido com auxílio de IA.

## Recortes de notícia no vídeo

Nos segundos takes de 10 cenas, aparecem recortes redesenhados com o título real da matéria e o nome do veículo em texto, sem logotipo: InfoMoney, SBT News, A Pública, Brasil de Fato, Carta Capital, Portal Salvador FM, Aos Fatos, CNN Brasil, Agência Brasil, Folha de Pernambuco e TSE. Os títulos foram copiados dos resultados de busca, não de uma leitura da página. Os dois com "trecho citado" vêm do plano de governo, como reproduzidos pela Agência Brasil. Antes de publicar, abra cada link do comentário fixado e confira se o título está igual. Este ambiente não consegue abrir os sites das matérias nem baixar as fotos.

## O que mudei em relação ao seu roteiro antigo (pol e pol2)

1. **Maioridade penal:** o roteiro antigo dizia "de 18 para 14 anos". O plano diz 16 anos como regra geral e punição a partir dos 14 só em crimes graves (estupro, tráfico, tortura, assassinato). Quem dizer "14 anos" sem explicar vai ser desmentido. Por isso esse ponto ficou fora do vídeo.
2. **Jatinho para Malta:** a PF fala em Malta, a defesa diz que o destino era Dubai com escala em Malta. Tirei o detalhe.
3. **"Rombo de 12 bilhões":** é uma estimativa inicial da PF sobre títulos falsos. Não é o prejuízo total. Tirei o número.
4. **Frases entre aspas** ("Amém", "não tem meia conversa"): não consegui confirmar nas fontes, então não usei.
5. **"Primeiro ato do presidente seria perdoar o pai":** ele prometeu anistia na transição e, se não passar, indulto aos condenados do 8 de janeiro. Especialistas citados pela Folha dizem que indultar o pai a tempo é improvável, e que o pai continuaria inelegível mesmo com perdão. Não afirmei isso no vídeo.

## Confira antes de publicar

- "Primeira vez que um golpe é condenado" e "mais de 27 anos": é o que a imprensa registrou na condenação de setembro de 2025, mas não reconferi na fonte primária nesta sessão.
- "1979: perdoou os militares": a Lei da Anistia de 1979 perdoou crimes políticos e conexos, e foi interpretada como cobrindo agentes do Estado. Confira se quer essa redação.
- França proibir fracking: a fonte que achei lista França, Alemanha, Irlanda e Bulgária. Confirme a lei francesa antes de publicar, porque ela veio de uma fonte secundária.
- R$ 61 milhões: as fontes variam entre US$ 12,3 e 14 milhões pagos, e o que a PF investiga são esses repasses. O vídeo diz "investiga repasses de R$ 61 milhões", que é o que as fontes sustentam.

## Regras eleitorais para não ter problema

- Pessoa física não pode pagar impulsionamento de conteúdo político. Só o orgânico.
- Conteúdo feito com IA precisa de aviso. O vídeo já tem o aviso fixo na tela.
- Não há rosto de ninguém, deepfake nem logotipo de veículo.
- Se alguém pedir direito de resposta ou a Justiça mandar remover, a fonte de cada afirmação está no comentário fixado.
- É conteúdo de opinião. Vale deixar claro no perfil que o ponto de vista é seu.
