import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../roteiros/ep8"; OUT = "../saida/Historia_do_Brasil_Ep8.mp4"
meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {6: 4, 9: 5}; flash = {1: [0, .2], 6: [0, .25], 9: [1, .2]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_ep8", "layers_ep8", EP, str(a), str(b), f"ep8_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
m = meta[12]
extra = [f"Dialogue: 3,{ts(m['start'])},{ts(total)},Chap,,0,0,0,,{{\\pos(40,150)\\fad(150,0)}}SIGA PARA O EPISÓDIO 9"]
make_ass(meta, total, "O MAIOR TRAIDOR\\NDO BRASIL?", "HISTÓRIA DO BRASIL · EPISÓDIO 8",
         {2: "CAPÍTULO 1 · A INVASÃO", 4: "CAPÍTULO 2 · CALABAR", 8: "CAPÍTULO 3 · A EXPULSÃO"}, {}, extra, "ep8.ass")
make_audio(meta, total, EP, "ep8_mix.wav", booms=(1, 6, 9), sea=(1, 2, 8, 10, 13), fire=(9,), drum_boost=(1, 5, 6, 9))
for p in procs: p.wait()
open("ep8_list.txt", "w").write("".join(f"file 'ep8_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep8_list.txt", "-c", "copy", "ep8_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep8_raw.mp4", "-i", "ep8_mix.wav", "-vf", "ass=ep8.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1900k", "-maxrate", "2800k", "-bufsize", "4800k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", OUT], check=True)
print("done", total)
