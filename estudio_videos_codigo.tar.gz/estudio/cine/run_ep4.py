import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../ep4"; meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {12: 4, 13: 3}; flash = {3: [1, .15], 12: [0, .25]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_ep4", "layers_ep4", EP, str(a), str(b), f"ep4_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
m16 = meta[15]; s = m16["start"]; d = m16["speech"]
q = [(0.28, 620, "DESCOBRIMENTO?"), (0.48, 790, "ENCONTRO?"), (0.62, 960, "OU INVASÃO?")]
extra = [f"Dialogue: 2,{ts(s + d * f)},{ts(s + m16['dur'] - 0.05)},Big,,0,0,0,,{{\\pos(540,{y})\\fs118\\fscx40\\fscy40\\t(0,160,\\fscx110\\fscy110)\\t(160,260,\\fscx100\\fscy100)}}{w}" for f, y, w in q]
m17 = meta[16]
extra.append(f"Dialogue: 3,{ts(m17['start'])},{ts(total)},Chap,,0,0,0,,{{\\pos(40,150)\\fad(150,0)}}PRÓXIMO EPISÓDIO · A ÁRVORE QUE DEU NOME AO BRASIL")
make_ass(meta, total, "O 1º EUROPEU\\NA PISAR NO BRASIL\\NNÃO FOI CABRAL", "HISTÓRIA DO BRASIL · EPISÓDIO 4",
         {4: "CAPÍTULO 1 · A CHEGADA", 8: "CAPÍTULO 2 · O ENCONTRO", 12: "CAPÍTULO 3 · O DEPOIS"},
         {2: "JANEIRO DE 1500", 3: "1494", 4: "13 NAVIOS", 5: "22 DE ABRIL", 6: "+1.000 LÍNGUAS", 13: "30 MIL", 14: "1.175 → 295", 15: "391 POVOS"},
         extra, "ep4.ass")
make_audio(meta, total, EP, "ep4_mix.wav", booms=(2, 5, 12, 13), sea=(1, 2, 4, 5, 8, 10, 11, 16, 17), fire=(7,), drum_boost=(4, 5, 8, 10, 15, 16))
for p in procs: p.wait()
open("ep4_list.txt", "w").write("".join(f"file 'ep4_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep4_list.txt", "-c", "copy", "ep4_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep4_raw.mp4", "-i", "ep4_mix.wav", "-vf", "ass=ep4.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "2000k", "-maxrate", "2800k", "-bufsize", "4500k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "/home/claude/Historia_do_Brasil_Ep4.mp4"], check=True)
print("done", total)
