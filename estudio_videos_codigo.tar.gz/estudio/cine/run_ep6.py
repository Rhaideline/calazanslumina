import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../ep6"; meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {13: 5, 14: 3}; flash = {1: [0, .2], 13: [1, .3], 14: [0, .25], 16: [1, .12]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_ep6", "layers_ep6", EP, str(a), str(b), f"ep6_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
m = meta[16]
extra = [f"Dialogue: 2,{ts(m['start'] + m['speech'] * 0.6)},{ts(m['start'] + m['dur'] - 0.05)},Big,,0,0,0,,{{\\pos(540,1000)\\fs110\\fscx40\\fscy40\\t(0,160,\\fscx110\\fscy110)\\t(160,260,\\fscx100\\fscy100)}}VOCÊ SABIA?"]
m = meta[17]
extra.append(f"Dialogue: 3,{ts(m['start'])},{ts(total)},Chap,,0,0,0,,{{\\pos(40,150)\\fad(150,0)}}PRÓXIMO EPISÓDIO · FRANCESES NO RIO")
make_ass(meta, total, "O 1º BISPO DO BRASIL\\NSE CHAMAVA SARDINHA\\N(E FOI DEVORADO)", "HISTÓRIA DO BRASIL · EPISÓDIO 6",
         {2: "CAPÍTULO 1 · UM CHEFE SÓ", 6: "CAPÍTULO 2 · O CARAMURU", 12: "CAPÍTULO 3 · O BISPO"},
         {3: "6 NAVIOS", 9: "1ª CAPITAL", 12: "1551", 13: "1556"},
         extra, "ep6.ass")
make_audio(meta, total, EP, "ep6_mix.wav", booms=(1, 13, 14), sea=(3, 5, 6, 13, 17), fire=(1, 14, 18), drum_boost=(1, 3, 9, 13, 14, 15))
for p in procs: p.wait()
open("ep6_list.txt", "w").write("".join(f"file 'ep6_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep6_list.txt", "-c", "copy", "ep6_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep6_raw.mp4", "-i", "ep6_mix.wav", "-vf", "ass=ep6.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1750k", "-maxrate", "2600k", "-bufsize", "4500k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "/home/claude/Historia_do_Brasil_Ep6.mp4"], check=True)
print("done", total)
