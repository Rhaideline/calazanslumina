from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep1 import maloca
from scenes_ep2 import jtree, palm, jungle, canopy_top
from scenes_ep4 import nau, sea, cross_big
import random, math

RED = "#B0261A"; EMBER = "#FF5A1E"; GOLD = "#F5C21B"

# ---------- helpers ----------
def pau_brasil(x, y, h, trunk="#2A1C16", leaf="#1E3A22", flower=GOLD, seed=1, flowers=60, thorns=True, lit=None):
    r = random.Random(seed); tw = h * 0.045; g = []
    g.append(f'<path d="M{x-tw*2.4},{y} C{x-tw*1.2},{y-h*0.08} {x-tw*1.1},{y-h*0.25} {x-tw*0.9},{y-h*0.45} C{x-tw*0.8},{y-h*0.55} {x-tw*0.4},{y-h*0.6} {x-tw*0.3},{y-h*0.62} L{x+tw*0.5},{y-h*0.62} C{x+tw*0.7},{y-h*0.5} {x+tw*1.1},{y-h*0.3} {x+tw*1.0},{y-h*0.15} C{x+tw*1.2},{y-h*0.06} {x+tw*1.8},{y-h*0.02} {x+tw*2.6},{y} Z" fill="{trunk}"/>')
    tops = []
    for k in range(7):
        a = -150 + k * 20 + r.uniform(-6, 6); Lb = h * r.uniform(0.22, 0.36)
        sx, sy = x + r.uniform(-tw * 0.3, tw * 0.3), y - h * r.uniform(0.5, 0.62)
        ex, ey = sx + Lb * math.cos(math.radians(a)), sy + Lb * math.sin(math.radians(a)) * 0.8
        mx, my = (sx + ex) / 2 + r.uniform(-20, 20), (sy + ey) / 2 + 30
        g.append(f'<path d="M{sx:.0f},{sy:.0f} Q{mx:.0f},{my:.0f} {ex:.0f},{ey:.0f}" stroke="{trunk}" stroke-width="{tw*r.uniform(0.35,0.6):.0f}" fill="none" stroke-linecap="round"/>')
        tops.append((ex, ey))
    if thorns:
        for k in range(46):
            ty = y - r.uniform(0.04, 0.58) * h; side = r.choice([-1, 1]); wx = tw * (1.0 - (y - ty) / h * 0.6) * side
            g.append(f'<path d="M{x+wx:.0f},{ty-5:.0f} L{x+wx+side*h*0.012:.0f},{ty-h*0.006:.0f} L{x+wx:.0f},{ty+5:.0f} Z" fill="{trunk}"/>')
    # canopy: clusters of fine pinnate leaves
    cl = []
    for (ex, ey) in tops:
        for j in range(9):
            cx, cy = ex + r.uniform(-h * 0.12, h * 0.12), ey + r.uniform(-h * 0.08, h * 0.05)
            rr = h * r.uniform(0.05, 0.09); cl.append((cx, cy, rr))
    for cx, cy, rr in cl:
        g.append(f'<ellipse cx="{cx:.0f}" cy="{cy:.0f}" rx="{rr*1.3:.0f}" ry="{rr*0.8:.0f}" fill="{leaf}"/>')
        for j in range(6):
            a = r.uniform(0, 6.28); lx, ly = cx + math.cos(a) * rr * 1.25, cy + math.sin(a) * rr * 0.75
            g.append(f'<ellipse cx="{lx:.0f}" cy="{ly:.0f}" rx="{h*0.012:.0f}" ry="{h*0.006:.0f}" fill="{leaf}" transform="rotate({math.degrees(a):.0f} {lx:.0f} {ly:.0f})"/>')
    if lit:
        for cx, cy, rr in cl[::2]:
            g.append(f'<ellipse cx="{cx-rr*0.3:.0f}" cy="{cy-rr*0.35:.0f}" rx="{rr*0.7:.0f}" ry="{rr*0.35:.0f}" fill="{lit}" opacity=".45"/>')
    for k in range(flowers):
        cx, cy, rr = r.choice(cl); fx, fy = cx + r.uniform(-rr, rr) * 1.2, cy + r.uniform(-rr, rr) * 0.7
        s = h * r.uniform(0.008, 0.013)
        g.append(f'<g transform="translate({fx:.0f},{fy:.0f})">' + "".join(f'<circle cx="{math.cos(a)*s*1.3:.1f}" cy="{math.sin(a)*s*1.3:.1f}" r="{s:.1f}" fill="{flower}"/>' for a in (0, 1.26, 2.51, 3.77, 5.03)) + f'<circle r="{s*0.55:.1f}" fill="#C8281A"/></g>')
    return "".join(g)

def log_end(cx, cy, R_, seed=1, glow_=True):
    i = gid("le"); r = random.Random(seed)
    g = [f'<defs><radialGradient id="{i}"><stop offset="0" stop-color="#FFB060"/><stop offset=".25" stop-color="#F0501E"/><stop offset=".7" stop-color="#B0200E"/><stop offset=".9" stop-color="#7A1408"/><stop offset="1" stop-color="#3A1A10"/></radialGradient></defs>']
    g.append(f'<ellipse cx="{cx}" cy="{cy}" rx="{R_*1.06}" ry="{R_*1.06}" fill="#3A2418"/><circle cx="{cx}" cy="{cy}" r="{R_}" fill="url(#{i})"/>')
    for k in range(1, 12):
        rr = R_ * k / 12; pts = []
        for j in range(37):
            a = j / 36 * 6.283; w = 1 + 0.03 * math.sin(a * 3 + k) + r.uniform(-0.01, 0.01)
            pts.append(f"{cx+math.cos(a)*rr*w:.1f},{cy+math.sin(a)*rr*w:.1f}")
        g.append(f'<polyline points="{" ".join(pts)}" fill="none" stroke="#5A0A04" stroke-opacity="{0.25+0.03*k:.2f}" stroke-width="{2+k*0.25:.1f}"/>')
    for k in range(5):
        a = r.uniform(0, 6.28); g.append(f'<line x1="{cx+math.cos(a)*R_*0.15:.0f}" y1="{cy+math.sin(a)*R_*0.15:.0f}" x2="{cx+math.cos(a)*R_*0.8:.0f}" y2="{cy+math.sin(a)*R_*0.8:.0f}" stroke="#3A0804" stroke-width="3" opacity=".5"/>')
    return "".join(g)

def log(x, y, length, rad, ang, bark="#3A2418", seed=1):
    r = random.Random(seed)
    g = [f'<g transform="translate({x},{y}) rotate({ang})"><rect x="0" y="{-rad}" width="{length}" height="{rad*2}" rx="{rad*0.25}" fill="{bark}"/>']
    for k in range(6):
        yy = r.uniform(-rad * 0.8, rad * 0.8); g.append(f'<path d="M{r.uniform(10,length*0.3):.0f},{yy:.0f} q{length*0.3:.0f},{r.uniform(-6,6):.0f} {length*0.6:.0f},0" stroke="{mix(bark,"#000000",.35)}" stroke-width="3" fill="none"/>')
    g.append(f'<ellipse cx="{length}" cy="0" rx="{rad*0.45}" ry="{rad}" fill="#A8240F"/><ellipse cx="{length}" cy="0" rx="{rad*0.25}" ry="{rad*0.6}" fill="#E0501C"/><ellipse cx="{length}" cy="0" rx="{rad*0.08}" ry="{rad*0.2}" fill="#FF9A4A"/></g>')
    return "".join(g)

def violin(x, y, s, ang=0):
    i = gid("vn")
    body = "M0,-260 C70,-260 120,-240 125,-170 C128,-120 95,-100 85,-60 C80,-30 95,-5 140,40 C185,90 175,220 0,240 C-175,220 -185,90 -140,40 C-95,-5 -80,-30 -85,-60 C-95,-100 -128,-120 -125,-170 C-120,-240 -70,-260 0,-260 Z"
    return (f'<defs><radialGradient id="{i}" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#F0A040"/><stop offset=".5" stop-color="#B85A1A"/><stop offset="1" stop-color="#4A1A08"/></radialGradient></defs>'
            f'<g transform="translate({x},{y}) rotate({ang}) scale({s})"><path d="{body}" fill="url(#{i})" stroke="#2A0E04" stroke-width="6"/>'
            f'<rect x="-22" y="-560" width="44" height="320" rx="10" fill="#1A0C06"/><circle cx="0" cy="-585" r="34" fill="#4A1A08"/><circle cx="0" cy="-585" r="16" fill="#2A0E04"/>'
            + "".join(f'<rect x="{sx-6}" y="-540" width="12" height="20" fill="#1A0C06" transform="rotate(90 {sx} -530)"/>' for sx in (-34, 34))
            + "".join(f'<path d="M{sx},-60 q{12*d},40 0,80 q-{12*d},40 0,80" stroke="#1A0804" stroke-width="7" fill="none"/>' for sx, d in ((-55, 1), (55, -1)))
            + f'<rect x="-30" y="50" width="60" height="12" fill="#E8D4A8"/><path d="M-26,100 L26,100 L16,220 L-16,220 Z" fill="#1A0C06"/>'
            + "".join(f'<line x1="{xx}" y1="-560" x2="{xx*1.6}" y2="210" stroke="#F4E8D0" stroke-width="2" opacity=".85"/>' for xx in (-12, -4, 4, 12))
            + '</g>')

def bow(x0, y0, x1, y1, stick="#8A1A0C"):
    return (f'<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y1}" stroke="{stick}" stroke-width="9" stroke-linecap="round"/>'
            f'<line x1="{x0+8}" y1="{y0+14}" x2="{x1+8}" y2="{y1+14}" stroke="#F6F0E2" stroke-width="5" opacity=".9"/>'
            f'<rect x="{x0-20}" y="{y0-6}" width="44" height="34" rx="6" fill="#1A0C06" transform="rotate({math.degrees(math.atan2(y1-y0,x1-x0)):.0f} {x0} {y0})"/>')

def parchment():
    return sky([(0, "#ECDDB6"), (1, "#D4BA86")]) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>' + glow(540, 960, 900, "#FFF4D8", .35)

def stamp(x, y, txt, ang=-12, size=110, col=RED):
    w = len(txt) * size * 0.52 + 60
    return (f'<g transform="translate({x},{y}) rotate({ang})"><rect x="{-w/2}" y="{-size*0.75}" width="{w}" height="{size*1.35}" rx="14" fill="none" stroke="{col}" stroke-width="12"/>'
            f'<text x="0" y="{size*0.38}" font-family="Anton" font-size="{size}" text-anchor="middle" fill="{col}">{txt}</text></g>')

def bubble(x, y, w, h, txt, size=72, tail=(-1, 1)):
    return (f'<g><path d="M{x-w/2+30},{y-h/2} L{x+w/2-30},{y-h/2} Q{x+w/2},{y-h/2} {x+w/2},{y-h/2+30} L{x+w/2},{y+h/2-30} Q{x+w/2},{y+h/2} {x+w/2-30},{y+h/2} '
            f'L{x+tail[0]*40+20},{y+h/2} L{x+tail[0]*120},{y+h/2+90} L{x+tail[0]*40-30},{y+h/2} L{x-w/2+30},{y+h/2} Q{x-w/2},{y+h/2} {x-w/2},{y+h/2-30} L{x-w/2},{y-h/2+30} Q{x-w/2},{y-h/2} {x-w/2+30},{y-h/2} Z" fill="#FFF8E8" stroke="#1A0E08" stroke-width="8"/>'
            f'<text x="{x}" y="{y+size*0.36}" font-family="Anton" font-size="{size}" text-anchor="middle" fill="#1A0E08">{txt}</text></g>')

def carrier(x, y, h, col, face=1, seed=1):
    # indigenous man carrying a log on the shoulder
    p = person(x, y, h, col, "shirt", "hair", la=(-70 if face > 0 else -110, -100), ra=(-60 if face > 0 else -120, -80), ll=(75, 100) if seed % 2 else (100, 85), rl=(105, 92) if seed % 2 else (80, 95), face=face)
    lg = log(x - h * 0.42, y - h * 0.93, h * 0.85, h * 0.06, -4 if face > 0 else 4, "#2A1810", seed)
    return p + lg

def ember_sky():
    return sky([(0, "#140806"), (0.5, "#3A0E08"), (1, "#7A1E0C")])

# ---------- scenes ----------
S = {}
def hook(cam):
    pile = ""
    for row, n in enumerate((5, 4, 3)):
        for k in range(n):
            cx = 600 + (k - (n - 1) / 2) * 150 + row * 0; cy = 1830 - row * 130
            pile += log_end(cx + 200, cy, 78, 70 + row * 10 + k, False)
    axeman = person(170, 1960, 980, "#0A0404", "shirt", "hair", la=(95, 100), ra=(-50, -120), face=1)
    axe = f'<g transform="translate(250,1020) rotate(-35)"><rect x="-12" y="-40" width="24" height="420" rx="8" fill="#0A0404"/><path d="M-12,-40 L-130,-80 Q-155,0 -130,80 L-12,40 Z" fill="#0A0404"/></g>'
    return dict(light="#FF9A50", rim_dx=4, cam=cam, particles="embers",
        layers=[L(0.0, ember_sky() + glow(600, 820, 900, "#FF5A1E", .45)),
                L(0.1, R(jungle(1350, "#1E0A08", 12, 300, 520, 501, 3)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#1E0A08"/>'),
                L(0.35, log_end(600, 820, 330, 5) + glow(600, 820, 520, "#FF7A30", .35), flicker=0.08),
                L(0.36, glow(600, 820, 420, "#FFB060", .4), mode="screen", flicker=0.18),
                L(0.7, Rr(pile)),
                L(0.9, R(axeman + axe) + ground(1950, "#140806", "#0A0404", 8, 2))])
S[1] = lambda: hook((1.0, 1.14, (0, 20), (20, -20)))

def s2():
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.12, (0, 40), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A7AA0"), (0.5, "#F0C890"), (1, "#F8A860")]) + sun(820, 1150, 90, halo_r=800)),
                L(0.05, godrays(820, 1150, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=52), mode="screen"),
                L(0.15, jungle(1400, "#8A6A5A", 14, 220, 340, 52, 4) + f'<rect x="{X0}" y="1390" width="{BW}" height="800" fill="#8A6A5A"/>'),
                L(0.4, R(pau_brasil(540, 1700, 1500, "#24160F", "#1A3020", GOLD, 52, 120, lit="#6A8A40")) + ground(1680, "#3A2818", "#1E140C", 8, 3)),
                L(0.9, R(palm(-60, 2050, 1200, "#0A0806", 53) + palm(1160, 2050, 1000, "#0A0806", 54)))])
S[2] = s2

def s3():
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-30, 20), (30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#8AA8C0"), (0.55, "#F0D0A0"), (1, "#F0B070")]) + sun(300, 1000, 80, halo_r=700)),
                L(0.05, godrays(300, 1000, "#FFF4D0", n=12, spread=160, a0=-80, op=.22, seed=53), mode="screen"),
                L(0.2, sea(1150, "#9AB0B8", "#5A7888", "#FFF0D8") + R(jungle(1160, "#4A5A48", 12, 160, 260, 53, 4))),
                L(0.45, R(nau(600, 1450, 0.8, "#1A1418", sails="#EFE2C8")), drift=(50, 0)),
                L(0.85, sea(1720, "#4A6070", "#1A2430", "#FFF0D0", 10))])
S[3] = s3

SAM_OLD = "M300,520 C420,470 560,500 640,600 C760,640 860,720 900,860 C920,980 860,1100 780,1220 C700,1340 620,1440 560,1560 C520,1640 470,1700 430,1720 C420,1600 400,1440 380,1300 C340,1150 280,1000 230,880 C190,760 210,600 300,520 Z"
SAM = ("M330,470 C380,440 450,450 520,470 C600,480 680,500 760,560 C820,600 900,640 960,700 C990,740 990,790 960,840 "
       "C930,900 900,960 870,1030 C840,1100 800,1150 740,1190 C700,1220 670,1260 650,1320 C630,1400 600,1470 560,1530 "
       "C530,1580 500,1630 480,1700 C470,1740 450,1770 420,1760 C410,1720 420,1680 410,1640 C400,1560 410,1480 420,1400 "
       "C430,1320 440,1240 430,1160 C410,1080 360,1020 300,960 C250,910 220,850 230,780 C240,720 230,660 260,600 C280,540 300,500 330,470 Z")
def s4():
    base = parchment() + f'<path d="{SAM}" fill="#C8B080" stroke="#5A3A26" stroke-width="6"/>' + f'<g transform="translate(150,1700)"><circle r="70" fill="none" stroke="#4A2E1C" stroke-width="4"/><path d="M0,-86 L12,0 L0,86 L-12,0 Z" fill="#4A2E1C"/></g>'
    tiny = f'<ellipse cx="930" cy="900" rx="60" ry="40" fill="none" stroke="#2A4A8A" stroke-width="8" stroke-dasharray="14 10"/><text x="900" y="820" font-family="Caveat" font-weight="700" font-size="70" text-anchor="middle" fill="#2A4A8A">"ilha"</text>'
    big = f'<path d="{SAM}" fill="none" stroke="{RED}" stroke-width="16" stroke-linejoin="round"/>' + stamp(560, 300, "NÃO ERA ILHA", -8, 104)
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, base, rough=False), L(0.05, tiny, rough=False), L(0.08, big, reveal=(0.15, 0.9, "center"), rough=False)])
S[4] = s4

def s5():
    banner = (f'<g transform="translate(540,620)"><path d="M-420,-70 L420,-70 L380,0 L420,70 L-420,70 L-380,0 Z" fill="#EFE2C4" stroke="#5A3A26" stroke-width="6"/>'
              f'<text x="0" y="24" font-family="Old Standard TT" font-weight="700" font-size="64" text-anchor="middle" fill="#3A2214">TERRA DE SANTA CRUZ</text></g>')
    return dict(light="#FFE0B0", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C4D8"), (0.6, "#F0E4C8"), (1, "#F8D8A8")]) + sun(820, 900, 70, halo_r=700)),
                L(0.05, godrays(820, 900, "#FFF8E0", n=12, spread=160, a0=-110, op=.22, seed=55), mode="screen"),
                L(0.2, sea(1350, "#A8C0C8", "#6A8898", "#FFF6E0")),
                L(0.45, f'<path d="M{X0},1560 C300,1520 700,1530 {X1},1570 L{X1},{Y1} L{X0},{Y1} Z" fill="#D8B888"/>' + R(cross_big(540, 1580, 1.25, "#1A120C"))),
                L(0.55, banner, rough=False),
                L(0.56, stamp(560, 820, "NÃO PEGOU", -10, 120), reveal=(0.62, 0.15, "center"), rough=False),
                L(0.9, R(palm(1100, 2050, 1100, "#0A0806", 55)))])
S[5] = s5

def s6():
    inset = (f'<circle cx="760" cy="760" r="300" fill="#1A0A06" stroke="#F4E2B8" stroke-width="10"/>' + log_end(760, 760, 270, 6)
             + f'<line x1="540" y1="1100" x2="600" y2="980" stroke="#F4E2B8" stroke-width="6"/>')
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.14, (-20, 40), (20, -40)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A5A40"), (0.6, "#8AA860"), (1, "#C8C080")]) + glow(800, 600, 800, "#FFF0B0", .5)),
                L(0.15, R(jungle(1500, "#2A4A30", 10, 400, 700, 56, 2)) + f'<rect x="{X0}" y="1490" width="{BW}" height="700" fill="#2A4A30"/>'),
                L(0.55, R(pau_brasil(380, 2300, 2600, "#2A1A12", "#1E3A22", GOLD, 56, 90, lit="#6A9A40"))),
                L(0.7, inset, reveal=(0.35, 0.6, "center"), rough=False),
                L(0.71, glow(760, 760, 340, "#FF7A30", .35), mode="screen", flicker=0.12)])
S[6] = s6

def s7():
    arches = "".join(f'<path d="M{x},1500 L{x},700 Q{x+110},560 {x+220},700 L{x+220},1500 Z" fill="#F4D8A0" opacity=".55"/>' for x in (-60, 430, 920))
    drape = "".join(f'<path d="M{x},{Y0} C{x+40},500 {x-30},900 {x+20},1400 L{x+170},1400 C{x+140},900 {x+200},500 {x+160},{Y0} Z" fill="{c}"/>' for x, c in ((-120, "#8A140C"), (980, "#8A140C")))
    folds = "".join(f'<path d="M{x},{Y0} C{x+20},600 {x-10},1000 {x+10},1400" stroke="#5A0806" stroke-width="10" fill="none"/>' for x in (-60, -20, 1030, 1070))
    king = person(540, 1720, 820, "#A8180E", "robe", None, la=(110, 95), ra=(70, 85), face=1, beard=True)
    crown = f'<path d="M490,960 L500,900 L520,935 L540,885 L560,935 L580,900 L590,960 Z" fill="{GOLD}"/>'
    return dict(light="#FFD08A", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A140C"), (1, "#4A2414")]) + glow(540, 900, 900, "#FFC070", .5)),
                L(0.1, arches + ground(1500, "#5A3A24", "#2A1A10", 4, 1)),
                L(0.4, R(f'<rect x="380" y="1100" width="320" height="520" rx="20" fill="#3A1A10"/><rect x="360" y="1060" width="360" height="60" fill="{GOLD}" opacity=".8"/>' + king + crown)),
                L(0.85, drape + folds)])
S[7] = s7

def s8():
    base = parchment()
    asia = "M650,980 C760,900 900,920 980,1000 C1040,1080 1000,1180 920,1220 C860,1250 780,1230 720,1180 C660,1120 620,1040 650,980 Z"
    eur = "M120,620 C220,560 360,580 420,660 C450,720 400,780 320,790 C230,800 150,740 120,620 Z"
    route = f'<path d="M820,1080 C700,1000 560,900 300,700" stroke="{RED}" stroke-width="10" fill="none" stroke-dasharray="30 18"/><path d="M300,700 l40,-6 l-14,36 Z" fill="{RED}"/>'
    word = (f'<text x="540" y="1520" font-family="Old Standard TT" font-style="italic" font-weight="700" font-size="190" text-anchor="middle" fill="{RED}">brasil</text>'
            f'<text x="540" y="1620" font-family="Montserrat" font-weight="800" font-size="44" letter-spacing="6" text-anchor="middle" fill="#4A2E1C">TINTA VERMELHA DA ÁSIA</text>')
    lbl = f'<text x="270" y="560" font-family="Old Standard TT" font-weight="700" font-size="54" text-anchor="middle" fill="#4A2E1C">EUROPA</text><text x="830" y="900" font-family="Old Standard TT" font-weight="700" font-size="54" text-anchor="middle" fill="#4A2E1C">ÁSIA</text>'
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, -20), (0, 20)), particles="dust",
        layers=[L(0.0, base + f'<path d="{asia}" fill="#C8B080" stroke="#5A3A26" stroke-width="5"/><path d="{eur}" fill="#C8B080" stroke="#5A3A26" stroke-width="5"/>' + lbl, rough=False),
                L(0.05, route, reveal=(0.1, 1.2, "rtl"), rough=False),
                L(0.1, word, reveal=(0.3, 0.6, "center"), rough=False)])
S[8] = s8

def s9():
    sign = (f'<g transform="translate(560,1560) rotate(-14) scale(.85)"><rect x="-12" y="0" width="24" height="420" fill="#2A1A10"/><rect x="-230" y="-120" width="460" height="130" fill="#D8C090" stroke="#3A2214" stroke-width="6"/>'
            f'<text x="0" y="-36" font-family="Old Standard TT" font-weight="700" font-size="46" text-anchor="middle" fill="#3A2214">TERRA DE SANTA CRUZ</text>'
            f'<line x1="-210" y1="-55" x2="210" y2="-55" stroke="{RED}" stroke-width="12"/></g>')
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A90B0"), (0.55, "#F0D8A8"), (1, "#F4B878")]) + sun(200, 900, 70, halo_r=700)),
                L(0.15, sea(1300, "#A8C0C8", "#6A8898", "#FFF6E0") + R(nau(820, 1340, 0.35, "#1E1A1E", sails="#E8DCC8"))),
                L(0.4, R(pau_brasil(300, 1720, 1200, "#24160F", "#1E3A22", GOLD, 59, 70, lit="#6A9A40")) + ground(1700, "#C8A070", "#8A6A48", 6, 2)),
                L(0.6, R(sign)),
                L(0.8, R(person(860, 1950, 760, "#120A06", "coat", "morion", la=(100, 90), ra=(-150, -165), face=-1, beard=True)) + ground(1930, "#3A2818", "#1E140C", 6, 1)),
                L(0.82, bubble(700, 560, 640, 220, "ACHEI BRASIL!", 104, (1, 1)), reveal=(0.1, 0.2, "center"), rough=False)])
S[9] = s9

def s10():
    r = random.Random(10)
    carriers = "".join(carrier(x, 1600 + (k % 2) * 30, h, mix("#1A0E08", "#5A4A40", 1 - h / 520), 1, k) for k, (x, h) in enumerate([(120, 300), (330, 340), (560, 380), (820, 430)]))
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.12, (-30, 20), (30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A6A90"), (0.5, "#F0B880"), (1, "#F8A060")]) + sun(880, 1100, 90, halo_r=800)),
                L(0.05, godrays(880, 1100, "#FFEFC8", n=13, spread=170, a0=-90, op=.24, seed=510), mode="screen"),
                L(0.2, sea(1250, "#C08068", "#5A3A48", "#FFE0B8") + R(nau(900, 1300, 0.38, "#1A1014", sails="#E8D2B8"))),
                L(0.4, f'<path d="M{X0},1380 C300,1350 700,1370 {X1},1400 L{X1},{Y1} L{X0},{Y1} Z" fill="#D8A878"/>' + R(carriers)),
                L(0.85, R(carrier(380, 2000, 860, "#0A0604", 1, 3) + palm(-80, 2100, 1100, "#0A0604", 511)) + ground(1980, "#2A1A10", "#0A0604", 6, 2))])
S[10] = s10

def s11():
    leaf = f'<path d="M80,1500 C300,1300 800,1300 1000,1500 C800,1700 300,1720 80,1500 Z" fill="#2E5A2A"/><path d="M80,1500 L1000,1500" stroke="#1A3A18" stroke-width="8"/>' + "".join(f'<path d="M{200+k*90},1500 L{240+k*90},{1400 if k%2 else 1600}" stroke="#1A3A18" stroke-width="4"/>' for k in range(9))
    mirror = f'<ellipse cx="300" cy="1360" rx="110" ry="140" fill="#B8C8D8" stroke="#C8A040" stroke-width="16"/><path d="M250,1290 L330,1250 L350,1280 L270,1330 Z" fill="#FFFFFF" opacity=".8"/>'
    beads = "".join(f'<circle cx="{520+math.cos(a)*120:.0f}" cy="{1520+math.sin(a)*55:.0f}" r="18" fill="{["#C82A1E","#2A6AC8","#F0C030","#FFFFFF"][k%4]}" stroke="#1A0E08" stroke-width="2"/>' for k, a in enumerate([j * 0.33 for j in range(19)]))
    knife = f'<g transform="translate(760,1400) rotate(-30)"><path d="M0,0 L260,-10 Q300,0 260,20 L0,20 Z" fill="#D8DCE0" stroke="#5A5A60" stroke-width="3"/><rect x="-110" y="-4" width="110" height="30" rx="8" fill="#5A3A20"/></g>'
    axe = f'<g transform="translate(560,1110) rotate(18)"><rect x="-14" y="-40" width="28" height="420" rx="10" fill="#7A5030"/><path d="M-14,-40 L-150,-90 Q-180,10 -150,110 L-14,60 Z" fill="#9AA0A8" stroke="#4A4E54" stroke-width="5"/><path d="M-150,-90 Q-180,10 -150,110" stroke="#F4F8FF" stroke-width="8" fill="none"/></g>'
    tag = f'<g transform="translate(830,880) rotate(10)"><path d="M-170,-60 L150,-60 L200,0 L150,60 L-170,60 Z" fill="{GOLD}" stroke="#1A0E08" stroke-width="6"/><circle cx="150" cy="0" r="12" fill="#1A0E08"/><text x="-10" y="20" font-family="Anton" font-size="62" text-anchor="middle" fill="#1A0E08">LANÇAMENTO</text></g>'
    return dict(light="#FFE8B0", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8C890"), (1, "#C89A60")]) + glow(540, 1300, 800, "#FFF4D0", .6)),
                L(0.2, f'<rect x="{X0}" y="1200" width="{BW}" height="1000" fill="#D8B080"/>' + Rr(leaf)),
                L(0.45, R(mirror + beads + knife + axe)),
                L(0.5, glow(560, 1100, 260, "#FFFFFF", .5) + glow(300, 1360, 200, "#FFFFFF", .45), mode="screen", flicker=0.25),
                L(0.6, tag, reveal=(0.45, 0.12, "center"), rough=False)])
S[11] = s11

def s12():
    logs = "".join(log(80 + (k % 4) * 40, 1350 + k * 55, 820, 40, 0, "#1A100C", 120 + k) for k in range(8))
    return dict(light="#A0B4D0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#0A0E18"), (0.6, "#2A3448"), (1, "#5A4A58")]) + glow(800, 900, 600, "#6A7A9A", .35)),
                L(0.2, sea(1150, "#3A4458", "#141824", "#A0B0C8") + R(nau(620, 1200, 0.6, "#05060A", sails="#5A6070"))),
                L(0.45, R(logs)),
                L(0.6, fogband(1250, "#5A6A80", .4, 300, 12), drift=(70, 0)),
                L(0.85, R(person(230, 1950, 700, "#020306", "shirt", "hair", la=(95, 100), ra=(85, 80), face=1) + person(860, 1960, 640, "#020306", "dress", "hair", la=(60, 20), ra=(120, 160), face=-1)) + ground(1930, "#0A0E14", "#040608", 4, 1))])
S[12] = s12

def s13():
    window = (f'<rect x="560" y="420" width="440" height="620" fill="#7AB0D0"/><path d="M560,860 C680,820 760,640 820,600 C860,680 900,820 1000,860 L1000,1040 L560,1040 Z" fill="#2A4A3A"/>'
              f'<rect x="560" y="900" width="440" height="140" fill="#3A7AA0"/><rect x="560" y="420" width="440" height="620" fill="none" stroke="#2A1A10" stroke-width="22"/><line x1="780" y1="420" x2="780" y2="1040" stroke="#2A1A10" stroke-width="14"/>')
    coins = "".join(f'<ellipse cx="{620+(k%5)*50+(k//5)*20}" cy="{1460-(k//5)*22}" rx="30" ry="12" fill="{GOLD}" stroke="#8A6A10" stroke-width="3"/>' for k in range(14))
    scroll = (f'<g transform="translate(330,1430) rotate(-6)"><rect x="-200" y="-60" width="400" height="160" fill="#EFE0BC"/>'
              f'<text x="0" y="0" font-family="Caveat" font-weight="700" font-size="44" text-anchor="middle" fill="#3A2214">contrato do pau-brasil</text><text x="0" y="60" font-family="Caveat" font-weight="700" font-size="40" text-anchor="middle" fill="{RED}">exclusivo · 1502</text></g>')
    return dict(light="#FFC878", rim_dx=-5, cam=(1.0, 1.12, (20, 20), (-20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1A10"), (1, "#3E2616")]) + "".join(f'<rect x="{X0}" y="{y}" width="{BW}" height="22" fill="#4A3020" opacity=".6"/>' for y in range(Y0, Y1, 70)) + window),
                L(0.05, glow(780, 700, 600, "#FFE8B0", .45), mode="screen"),
                L(0.4, f'<rect x="{X0}" y="1380" width="{BW}" height="800" fill="#4A2A18"/>' + R(scroll + coins)),
                L(0.75, R(person(220, 1950, 980, "#0E0806", "coat", "brim", la=(70, 40), ra=(30, -20), face=1, beard=True)))])
S[13] = s13

def s14():
    jobs = [("PEDREIRO", 560), ("PADEIRO", 820), ("SAPATEIRO", 1080)]
    plank = lambda y, t, c, tc: (f'<g transform="translate(540,{y})"><rect x="-380" y="-100" width="760" height="200" rx="18" fill="{c}" stroke="#2A1A10" stroke-width="8"/>'
                                 + "".join(f'<line x1="-360" y1="{yy}" x2="360" y2="{yy}" stroke="#2A1A10" stroke-opacity=".18" stroke-width="4"/>' for yy in (-50, 0, 50))
                                 + f'<text x="0" y="40" font-family="Anton" font-size="120" text-anchor="middle" fill="{tc}">{t}</text></g>')
    base = sky([(0, "#2A1A10"), (1, "#140C08")]) + glow(540, 1000, 900, "#FFC070", .4)
    ps = "".join(plank(y, t, "#C8A070", "#3A2214") for t, y in jobs)
    big = plank(1400, "BRASILEIRO", "#B0261A", "#FFF4E0") + f'<text x="540" y="1580" font-family="Montserrat" font-weight="800" font-size="34" letter-spacing="2" text-anchor="middle" fill="{GOLD}">PROFISSÃO: CORTAR E VENDER PAU-BRASIL</text>'
    return dict(light="#FFD090", rim_dx=4, cam=(1.0, 1.08, (0, -40), (0, 40)), particles="sawdust",
        layers=[L(0.0, base, rough=False), L(0.2, Rr(ps), reveal=(0.05, 1.2, "ltr")), L(0.3, Rr(big), reveal=(0.45, 0.3, "center"))])
S[14] = s14

def s15():
    fr = nau(700, 1330, 0.62, "#141020", sails="#E8E6F0", cross=False)
    fleur = "".join(f'<g transform="translate({x},{y})"><path d="M0,-30 C14,-14 14,8 0,26 C-14,8 -14,-14 0,-30 Z M-26,-6 C-10,-10 -4,10 -6,26 C-20,20 -30,8 -26,-6 Z M26,-6 C10,-10 4,10 6,26 C20,20 30,8 26,-6 Z" fill="#2A4AA8"/></g>' for x, y in ((700 - 80 * 0.62 + 0, 1330 - 560 * 0.62 * 0.55 + 20), (700 + 120 * 0.62, 1330 - 640 * 0.62 * 0.5 + 30)))
    lab = lambda x, y, t, c: f'<g transform="translate({x},{y})"><rect x="-130" y="-56" width="260" height="96" rx="16" fill="{c}"/><text x="0" y="22" font-family="Anton" font-size="70" text-anchor="middle" fill="#FFF8E8">{t}</text></g>'
    return dict(light="#FFD8A0", rim_dx=5, cam=(1.0, 1.12, (20, 20), (-20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A4A70"), (0.5, "#E8A070"), (1, "#F8C890")]) + sun(540, 1180, 100, halo_r=800)),
                L(0.05, godrays(540, 1180, "#FFEFC8", n=14, spread=180, a0=-90, op=.24, seed=515), mode="screen"),
                L(0.15, sea(1220, "#C88068", "#3A2A40", "#FFE0B8") + R(nau(150, 1240, 0.25, "#2A2028", sails="#D8C8B8"))),
                L(0.17, lab(150, 950, "PERÓ", "#1E5A3A"), rough=False),
                L(0.4, R(fr) + fleur),
                L(0.42, lab(760, 560, "MAIR", "#2A4AA8"), rough=False),
                L(0.85, R(f'<path d="M{X0},1700 C300,1660 600,1690 {X1},1720 L{X1},{Y1} L{X0},{Y1} Z" fill="#1A1010"/>'
                         + person(140, 1960, 640, "#0A0606", "shirt", "cocar", la=(100, 90), ra=(-20, -40), face=1)
                         + person(420, 1990, 600, "#0A0606", "coat", "brim", la=(120, 100), ra=(-30, -60), face=-1)
                         + carrier(820, 1990, 620, "#0A0606", -1, 4)))])
S[15] = s15

def s16():
    r = random.Random(16)
    stumps = "".join(stump(r.uniform(-60, 1140), y, 0.6 + (y - 1300) / 500, mix("#3A3A3A", "#140E0A", (y - 1300) / 650), "#A8341A") for y in sorted(r.uniform(1300, 1950) for _ in range(30)))
    axe = f'<g transform="translate(560,1780) rotate(-25)"><rect x="-12" y="-300" width="24" height="320" rx="8" fill="#3A2416"/><path d="M-12,-300 L-120,-330 Q-140,-260 -120,-200 L-12,-240 Z" fill="#6A6E74"/></g>'
    return dict(light="#C8C0B8", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#2A2A30"), (0.6, "#6A6260"), (1, "#8A7A70")]) + glow(540, 900, 700, "#C0A890", .3)),
                L(0.15, R(jungle(1250, "#3A3A38", 6, 160, 240, 516, 1)) + f'<rect x="{X0}" y="1240" width="{BW}" height="900" fill="#4A4440"/>'),
                L(0.4, fogband(1300, "#8A8480", .45, 260, 16), drift=(60, 0)),
                L(0.55, R(stumps) + stump(560, 1800, 2.2, "#140E0A", "#B0361A") + R(axe))])
S[16] = s16

def s17():
    return dict(light="#FFC070", rim_dx=4, cam=(1.0, 1.14, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#0A0604"), (1, "#1E0E08")]) + glow(540, 900, 800, "#A84A1A", .35)),
                L(0.1, f'<path d="M540,{Y0} L140,{Y1} L940,{Y1} Z" fill="#FFE0A8" opacity=".09" filter="url(#blur30)"/>', mode="screen"),
                L(0.3, R(f'<ellipse cx="540" cy="1650" rx="560" ry="140" fill="#3A0A08"/>' + pau_brasil(860, 1660, 420, "#2A1A12", "#2A5A2A", GOLD, 517, 18, thorns=False))),
                L(0.5, R(violin(470, 1060, 1.05, -14) + bow(140, 1560, 930, 380))),
                L(0.52, glow(560, 900, 380, "#FFC070", .3), mode="screen", flicker=0.06)])
S[17] = s17

def s18():
    bld = "".join(f'<rect x="{x}" y="{y}" width="{w}" height="{2000-y}" fill="#5A6A80"/>' + "".join(f'<rect x="{x+18+i*34}" y="{y+30+j*60}" width="18" height="30" fill="#F4E0A0" opacity=".55"/>' for i in range(int((w-30)//34)) for j in range(int((1300-y)//60))) for x, y, w in ((-100, 600, 220), (150, 820, 180), (360, 520, 200), (600, 760, 160), (790, 480, 230), (1040, 700, 160)))
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A80B0"), (0.6, "#F0C8A0"), (1, "#F8B080")]) + sun(820, 1100, 80, halo_r=700)),
                L(0.1, bld + f'<rect x="{X0}" y="1300" width="{BW}" height="900" fill="#5A6A80"/>'),
                L(0.15, haze(900, 1400, "#F4C8A0", .45)),
                L(0.45, R(pau_brasil(540, 1760, 1250, "#24160F", "#1E3A22", GOLD, 518, 140, lit="#7AA040")) + ground(1740, "#6A8A48", "#3A5A2A", 6, 3)),
                L(0.9, R(f'<rect x="{X0}" y="1880" width="{BW}" height="300" fill="#2A2A2A"/>' + person(120, 1960, 560, "#0A0A0C", "shirt", "hair", la=(100, 90), ra=(-60, -70), face=1)
                         + person(960, 1960, 520, "#0A0A0C", "dress", "hair", la=(100, 90), ra=(80, 85), face=-1)))])
S[18] = s18

S[19] = lambda: hook((1.0, 1.0, (0, 20), (0, 20)))
SC = S
