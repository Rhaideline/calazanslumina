import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../roteiros/pol6"; OUT = "../saida/Reel_2turno_Nas_Palavras_Dele.mp4"; mod, ld = "scenes_pol6", "layers_pol6"
meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", mod, ld, EP, str(a), str(b), f"pol6_part{k}.mp4", json.dumps({}), json.dumps({7: [1, .12]})]))
SRC = {2: "FONTE: Alerj · Jornal do Brasil (2020) · Metrópoles", 3: "FONTE: Jornal do Brasil · MP-RJ", 4: "FONTE: O Globo, via Jornal do Brasil (2019)",
       5: "FONTE: sabatina do Jornal Nacional, 28/08/2026 · NSC Total", 6: "FONTE: STJ, 5ª Turma (2021) · Carta Capital",
       7: "FONTE: Intercept Brasil · Aos Fatos · Folha PE", 8: "FONTE: SBT News · Poder360, 15/05/2026", 9: "FONTE: SBT News, 29/09/2026",
       10: "FONTE: Jornal Opção · Diário de Pernambuco, 06/10/2026"}
extra = [f"Dialogue: 1,{ts(m['start'])},{ts(m['start'] + m['dur'])},Cap,,0,0,0,,{{\\an2\\pos(540,1690)\\fnMontserrat\\fs36\\bord3\\shad0\\fad(120,120)}}{SRC[m['i']]}" for m in meta if m["i"] in SRC]
extra.append(f"Dialogue: 1,{ts(0)},{ts(total)},Cap,,0,0,0,,{{\\an2\\pos(540,1790)\\fnMontserrat\\fs30\\bord2\\shad0\\alpha&H30&}}Conteúdo produzido com auxílio de inteligência artificial")
make_ass(meta, total, "NAS PALAVRAS\\NDO FLÁVIO", "2º TURNO · 25 DE OUTUBRO", {}, {}, extra, "pol6.ass")
make_audio(meta, total, EP, "pol6_mix.wav", booms=(3, 7), sea=(), fire=(), drum_boost=(3, 7, 9))
for p in procs: p.wait()
open("pol6_list.txt", "w").write("".join(f"file 'pol6_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "pol6_list.txt", "-c", "copy", "pol6_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "pol6_raw.mp4", "-i", "pol6_mix.wav", "-vf", "ass=pol6.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "2200k", "-maxrate", "3200k", "-bufsize", "5000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", OUT], check=True)
print("done", total)
