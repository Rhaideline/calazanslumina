"""Re-renderiza só algumas cenas. Uso: python3 rl_some.py scenes_epN layers_dir 3,17"""
import sys, importlib
from cine import render_layers
SC = importlib.import_module(sys.argv[1]).SC
render_layers(SC, [int(x) for x in sys.argv[3].split(",")], sys.argv[2])
