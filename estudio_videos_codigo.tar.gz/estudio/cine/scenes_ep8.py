"""Ep8 · Calabar e os holandeses em Pernambuco (1630 a 1654)."""
from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep2 import jungle, palm
from scenes_ep4 import nau, sea, batel
from scenes_ep5 import parchment, stamp, label, crown, chest, engenho, cane, throne_room, drapes, RED, GOLD, INKB, waves
from scenes_ep6 import church
from scenes_ep7 import hills, pt_flag, bubble
import random, math

ORANGE, NLBLUE = "#E8762B", "#1F3F8F"
PAPER = "#FFF4E0"

def nl_flag(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><line x1="0" y1="0" x2="0" y2="-180" stroke="#2A1A10" stroke-width="7"/>'
            f'<path d="M0,-180 C40,-196 80,-160 120,-178 L120,-154 C80,-136 40,-172 0,-156 Z" fill="{ORANGE}"/>'
            f'<path d="M0,-156 C40,-172 80,-136 120,-154 L120,-130 C80,-112 40,-148 0,-132 Z" fill="#F4F0E4"/>'
            f'<path d="M0,-132 C40,-148 80,-112 120,-130 L120,-106 C80,-88 40,-124 0,-108 Z" fill="{NLBLUE}"/></g>')

def dutch_ship(x, y, s, col="#1A1418", sails="#EFE2C8"):
    return R(nau(x, y, s, col, sails=sails, cross=False)) + nl_flag(x + 300 * s, y - 420 * s, s * 1.4)

def gabled(x, y, w, h, col, win="#FFD890"):
    st = w / 6
    g = (f'<path d="M{x},{y} L{x},{y-h} L{x+st},{y-h} L{x+st},{y-h-st} L{x+2*st},{y-h-st} L{x+2*st},{y-h-2*st} L{x+4*st},{y-h-2*st} '
         f'L{x+4*st},{y-h-st} L{x+5*st},{y-h-st} L{x+5*st},{y-h} L{x+w},{y-h} L{x+w},{y} Z" fill="{col}"/>')
    for r_ in range(int(h // 70)):
        for c in range(2):
            g += f'<rect x="{x + w*0.2 + c*w*0.38:.0f}" y="{y - h + 30 + r_*70:.0f}" width="{w*0.2:.0f}" height="34" fill="{win}" opacity=".55"/>'
    return g

def calabar(x, y, h, face=1, col="#0E0806", ra=(-30, -60), prop=("rifle", -70)):
    return person(x, y, h, col, "shirt", "brim", la=(100, 92), ra=ra, face=face, beard=True, prop=prop)

def olinda(y, col):
    g = f'<path d="M{X0},{y} C150,{y-170} 360,{y-260} 560,{y-240} C760,{y-220} 900,{y-120} {X1},{y-60} L{X1},{y+40} L{X0},{y+40} Z" fill="{col}"/>'
    g += church(420, y - 230, 0.42, col) + church(700, y - 200, 0.34, col)
    g += "".join(f'<g transform="translate({x},{y - yy})"><rect x="-34" y="-50" width="68" height="50" fill="{col}"/><path d="M-42,-50 L0,-86 L42,-50 Z" fill="{col}"/></g>' for x, yy in ((260, 170), (540, 230), (860, 150), (160, 120)))
    return g

S = {}
def hook(cam):
    fleet = "".join(dutch_ship(x, y, s, "#0A0405", "#3A2A2A") for x, y, s in ((760, 1300, .24), (930, 1330, .3)))
    return dict(light="#FF9A50", rim_dx=4, cam=cam, particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.5, "#4A1A14"), (1, "#C8582A")]) + sun(820, 1260, 110, halo_r=900, halo="#FF8A40") + godrays(820, 1260, "#FFB070", n=12, spread=150, a0=-90, op=.2, seed=81)),
                L(0.15, sea(1360, "#6A2A24", "#1A0A0C", "#FFB070")),
                L(0.3, fleet, drift=(-30, 0)),
                L(0.6, R(f'<path d="M{X0},1700 C200,1560 420,1520 640,1600 C820,1660 1000,1700 {X1},1720 L{X1},{Y1} L{X0},{Y1} Z" fill="#0A0405"/>' + calabar(330, 1640, 820, 1, "#050203", (100, 92), ("rifle", -80)))),
                L(0.62, stamp(560, 640, "TRAIDOR?", -8, 140), reveal=(3.0, 0.15, "center"), rough=False)])
S[1] = lambda: hook((1.0, 1.12, (0, 30), (0, -20)))

def s2():
    fleet = "".join(dutch_ship(x, y, s) for x, y, s in ((880, 1290, .2), (700, 1310, .26), (520, 1350, .34), (300, 1400, .44)))
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A6AA0"), (0.55, "#F4D0A0"), (1, "#F8B878")]) + sun(220, 1050, 90, halo_r=800)),
                L(0.05, godrays(220, 1050, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=82), mode="screen"),
                L(0.12, Rr(olinda(1230, "#6A6A70"))),
                L(0.2, sea(1260, "#B8B0B0", "#5A6878", "#FFF0D8")),
                L(0.4, fleet, drift=(-60, 0)),
                L(0.8, R(cane(1980, "#3A4A20", 70, 82, 300)) + ground(1960, "#2A3A18", "#141C0C", 4, 1)),
                L(0.86, label(540, 470, "1630", 180, PAPER, "Anton"), reveal=(0.4, 0.3, "center"), rough=False),
                L(0.87, label(540, 580, "OLINDA E RECIFE · AÇÚCAR", 54, "#5A1A10", "Anton"), reveal=(3.6, 0.3, "center"), rough=False)])
S[2] = s2

def s3():
    return dict(light="#FFC070", rim_dx=5, cam=(1.0, 1.1, (0, 10), (0, -30)), particles="dust",
        layers=[L(0.0, throne_room()),
                L(0.3, crown(540, 760, 1.4), rough=False),
                L(0.35, label(330, 1020, "PORTUGAL", 70, PAPER, "Anton") + label(750, 1020, "ESPANHA", 70, PAPER, "Anton") + label(540, 1020, "+", 70, GOLD, "Anton"), rough=False),
                L(0.36, label(540, 1130, "1 REI · DESDE 1580", 64, GOLD, "Anton"), reveal=(2.4, 0.3, "center"), rough=False),
                L(0.4, nl_flag(780, 1560, 1.6), reveal=(5.2, 0.2, "center"), rough=False),
                L(0.41, stamp(440, 1430, "EM GUERRA", -6, 90), reveal=(5.6, 0.15, "center"), rough=False),
                L(0.9, drapes())])
S[3] = s3

def s4():
    sol = "".join(person(x, 1960, h, "#0E0806", "shirt", "morion", la=(100, 92), ra=(-30, -60), face=1, prop=("rifle", -20)) for x, h in ((640, 600), (820, 640)))
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A7AA8"), (0.6, "#E8C8A0"), (1, "#F0B880")]) + sun(800, 1100, 80, halo_r=700)),
                L(0.2, R(jungle(1420, "#4A5A40", 12, 240, 360, 84, 4)) + f'<rect x="{X0}" y="1410" width="{BW}" height="800" fill="#6A5A38"/>'),
                L(0.8, R(calabar(300, 1980, 900, 1) + sol + pt_flag(870, 1960, 1.6)) + ground(1950, "#3A2A18", "#1E140C", 6, 1)),
                L(0.86, label(540, 440, "DOMINGOS FERNANDES CALABAR", 54, "#1A0E08", "Anton"), reveal=(0.4, 0.3, "center"), rough=False),
                L(0.87, label(540, 540, "PORTO CALVO · LADO PORTUGUÊS", 44, "#5A1A10", "Anton"), reveal=(2.6, 0.3, "center"), rough=False)])
S[4] = s4

def s5():
    sol = "".join(person(x, 1960 + (k % 2) * 20, h, "#0E0806", "shirt", "morion", la=(100, 92), ra=(-30, -60), face=1, prop=("rifle", -20)) for k, (x, h) in enumerate(((520, 560), (680, 600), (840, 580))))
    river = f'<path d="M{X0},1560 C250,1500 420,1620 620,1560 C820,1500 980,1600 {X1},1540 L{X1},1640 C980,1700 820,1600 620,1660 C420,1720 250,1600 {X0},1660 Z" fill="#5A8AA0" opacity=".9"/>'
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A2A48"), (0.5, "#D8805A"), (1, "#F0A860")]) + sun(700, 1250, 110, halo_r=900)),
                L(0.2, R(jungle(1440, "#5A3A40", 12, 220, 340, 85, 4)) + f'<rect x="{X0}" y="1430" width="{BW}" height="800" fill="#4A2A28"/>' + river),
                L(0.8, R(calabar(250, 1980, 880, 1, ra=(-20, -10), prop=None) + sol + nl_flag(880, 1950, 1.5)) + ground(1950, "#2A1814", "#140A08", 6, 1)),
                L(0.86, label(540, 440, "1632", 160, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
                L(0.87, label(540, 550, "TROCOU DE LADO", 74, GOLD, "Anton"), reveal=(1.2, 0.3, "center"), rough=False)])
S[5] = s5

def s6():
    doc = (f'<g transform="translate(540,1000) rotate(-3)"><rect x="-330" y="-420" width="660" height="840" fill="#E8DCC0"/>'
           f'<text x="0" y="-320" font-family="Old Standard TT" font-weight="700" font-size="60" text-anchor="middle" fill="#2A1A10">SENTENÇA</text>'
           f'<text x="0" y="-250" font-family="Old Standard TT" font-style="italic" font-size="40" text-anchor="middle" fill="#2A1A10">Porto Calvo, 1635</text>'
           + "".join(f'<rect x="-270" y="{-180+k*48}" width="{540-(k%3)*90}" height="14" fill="#9A8A70"/>' for k in range(11)) + '</g>')
    return dict(light="#FFB070", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#0A0606"), (1, "#1E1210")]) + glow(540, 1000, 700, "#C87A3A", .35)),
                L(0.3, doc, rough=False),
                L(0.4, stamp(540, 1180, "TRAIDOR", -8, 130), reveal=(1.6, 0.15, "center"), rough=False),
                L(0.5, label(540, 470, "CAPTURADO E EXECUTADO", 70, PAPER, "Anton"), rough=False)])
S[6] = s6

def s7():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#14101A"), (0.6, "#2A1E2A"), (1, "#4A2A20")]) + glow(540, 1100, 700, "#C89A5A", .3)),
                L(0.5, R(calabar(540, 1980, 900, 1, "#0A0606", (100, 92), None)) + ground(1950, "#120A08", "#060404", 4, 1)),
                L(0.6, bubble(540, 760, "?", "#1A0E08"), reveal=(0.6, 0.15, "center"), rough=False),
                L(0.7, label(540, 420, "TRAIU O BRASIL", 76, PAPER, "Anton"), reveal=(2.6, 0.3, "center"), rough=False),
                L(0.71, label(540, 510, "QUE NEM EXISTIA COMO PAÍS?", 46, "#D8D0C4", "Anton"), reveal=(3.4, 0.3, "center"), rough=False),
                L(0.72, label(540, 1000, "OU O REI DA ESPANHA?", 76, GOLD, "Anton"), reveal=(5.6, 0.3, "center"), rough=False)])
S[7] = s7

def s8():
    town = "".join(gabled(x, 1380, w, h, c) for x, w, h, c in ((-60, 150, 300, "#5A3A2A"), (95, 130, 360, "#6A4A34"), (230, 150, 280, "#5A3428"), (390, 140, 340, "#4A3024"),
                                                              (690, 150, 300, "#5A3A2A"), (845, 130, 360, "#6A4A34"), (980, 160, 280, "#5A3428")))
    syn = gabled(535, 1380, 150, 420, "#8A6A48", "#FFE8B0")
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.55, "#F0B080"), (1, "#F8C890")]) + sun(540, 900, 90, halo_r=800)),
                L(0.05, godrays(540, 900, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=88), mode="screen"),
                L(0.3, R(town + syn) + nl_flag(470, 1060, 1.3)),
                L(0.32, glow(610, 1200, 220, "#FFE0A0", .5), mode="screen", reveal=(4.0, 0.4, "center")),
                L(0.45, sea(1380, "#C88068", "#3A2A40", "#FFE0B8") + R(batel(300, 1560, 0.6, "#1A1012", 3))),
                L(0.6, label(540, 430, "24 ANOS · RECIFE", 84, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
                L(0.61, label(540, 540, "E A 1ª SINAGOGA DAS AMÉRICAS", 50, GOLD, "Anton"), reveal=(4.2, 0.3, "center"), rough=False)])
S[8] = s8

def s9():
    def grp(xs, hat, face):
        return "".join(person(x, 1960 + (k % 2) * 20, h, "#060404", "shirt", hat, la=(-60, -100), ra=(-100, -80), face=face, prop=("staff",) if hat == "cocar" else ("rifle", -40)) for k, (x, h) in enumerate(xs))
    men = grp(((80, 660), (220, 620)), "brim", 1) + grp(((400, 700), (520, 640)), "hair", 1) + grp(((700, 680), (840, 640)), "cocar", 1)
    return dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, 40)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.55, "#6A1A10"), (1, "#E8682A")]) + glow(540, 1200, 900, "#FFA050", .45)),
                L(0.15, Rr(hills(1400, "#3A0E0C", 89, 4, 300, 520))),
                L(0.4, smoke_puffs(800, 1200, "#5A4A44", n=10, s=1.5, seed=19, drift=1), drift=(0, -80)),
                L(0.85, R(men) + ground(1950, "#0A0404", "#030102", 6, 2)),
                L(0.9, label(540, 430, "GUARARAPES · 1648", 80, PAPER, "Anton"), reveal=(1.0, 0.3, "center"), rough=False),
                L(0.91, label(540, 540, "HENRIQUE DIAS · FELIPE CAMARÃO", 46, GOLD, "Anton"), reveal=(4.4, 0.3, "center"), rough=False)])
S[9] = s9

def s10():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A2A48"), (0.55, "#D8906A"), (1, "#F0B880")]) + sun(760, 1200, 100, halo_r=900)),
                L(0.2, sea(1300, "#C88068", "#3A2A40", "#FFE0B8") + dutch_ship(820, 1360, .32, "#140C10", "#C8B8A8"), drift=(80, 0)),
                L(0.5, R(chest(540, 1640, 1.1, empty=False))),
                L(0.6, label(540, 440, "1654 · RENDIÇÃO", 84, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
                L(0.61, label(540, 550, "E PORTUGAL AINDA PAGOU", 56, GOLD, "Anton"), reveal=(3.4, 0.3, "center"), rough=False)])
S[10] = s10

def s11():
    poster = (f'<g transform="translate(540,1000) rotate(-2)"><rect x="-300" y="-400" width="600" height="800" fill="#E8DCC0"/>'
              f'<rect x="-270" y="-370" width="540" height="740" fill="none" stroke="#2A1A10" stroke-width="6"/>'
              f'<text x="0" y="-220" font-family="Anton" font-size="130" text-anchor="middle" fill="#2A1A10">CALABAR</text>'
              f'<text x="0" y="-140" font-family="Old Standard TT" font-style="italic" font-size="44" text-anchor="middle" fill="#2A1A10">o elogio da traição</text>'
              f'<text x="0" y="220" font-family="Montserrat" font-weight="800" font-size="30" text-anchor="middle" fill="#5A4A38">CHICO BUARQUE · RUY GUERRA</text>'
              f'<text x="0" y="280" font-family="Montserrat" font-weight="800" font-size="30" text-anchor="middle" fill="#5A4A38">1973</text></g>')
    return dict(light="#FFC070", rim_dx=5, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#1A0A08"), (1, "#3A140C")]) + glow(540, 1000, 700, "#FFB060", .45)),
                L(0.3, poster, rough=False),
                L(0.4, stamp(540, 1080, "PROIBIDA", -10, 140), reveal=(5.2, 0.15, "center"), rough=False),
                L(0.9, drapes())])
S[11] = s11

def s12():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.08, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#14101A"), (0.6, "#2A1E2A"), (1, "#4A2A20")]) + glow(540, 1100, 700, "#C89A5A", .3)),
                L(0.5, R(calabar(540, 1980, 900, 1, "#0A0606", (100, 92), None)) + ground(1950, "#120A08", "#060404", 4, 1)),
                L(0.6, label(320, 700, "HERÓI", 110, GOLD, "Anton"), reveal=(1.0, 0.2, "center"), rough=False),
                L(0.61, label(760, 700, "TRAIDOR", 110, RED, "Anton"), reveal=(1.4, 0.2, "center"), rough=False),
                L(0.62, label(540, 820, "?", 120, PAPER, "Anton"), reveal=(1.8, 0.2, "center"), rough=False)])
S[12] = s12

S[13] = lambda: hook((1.0, 1.0, (0, 30), (0, 30)))
SC = S
