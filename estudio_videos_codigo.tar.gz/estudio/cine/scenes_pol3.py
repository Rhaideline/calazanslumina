from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep5 import parchment, stamp, label, RED, GOLD, INKB
import random, math

def tank(x, y, s, col, face=1):
    return (f'<g transform="translate({x},{y}) scale({s*face},{s})">'
            f'<rect x="-260" y="-70" width="520" height="90" rx="40" fill="{col}"/>'
            + "".join(f'<circle cx="{-210+k*84}" cy="-25" r="34" fill="{mix(col,"#000000",.4)}"/>' for k in range(6))
            + f'<path d="M-230,-70 L-200,-150 L210,-150 L240,-70 Z" fill="{col}"/><path d="M-120,-150 L-90,-230 L120,-230 L150,-150 Z" fill="{col}"/>'
            f'<rect x="140" y="-205" width="300" height="26" rx="8" fill="{col}"/><rect x="-20" y="-270" width="60" height="44" rx="6" fill="{col}"/></g>')

def congresso(x, y, s, col, lit=None):
    w = lit or col
    return (f'<g transform="translate({x},{y}) scale({s})">'
            f'<rect x="-60" y="-520" width="54" height="520" fill="{col}"/><rect x="6" y="-520" width="54" height="520" fill="{col}"/><rect x="-60" y="-300" width="120" height="16" fill="{col}"/>'
            + "".join(f'<rect x="{-54+j*60}" y="{-510+k*22}" width="42" height="10" fill="{w}" opacity=".35"/>' for k in range(22) for j in range(2))
            + f'<rect x="-460" y="-20" width="920" height="40" fill="{col}"/>'
            f'<path d="M-380,-20 Q-280,-130 -180,-20 Z" fill="{col}"/>'
            f'<path d="M150,-20 L180,-110 Q280,-140 380,-110 L410,-20 Z" fill="{col}"/></g>')

def stf_building(x, y, s, col):
    cols = "".join(f'<path d="M{-380+k*95},0 L{-360+k*95},-250 Q{-332+k*95},-270 {-305+k*95},-250 L{-285+k*95},0 Z" fill="{col}"/>' for k in range(9))
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-460" y="-300" width="920" height="40" fill="{col}"/>{cols}'
            f'<rect x="-360" y="-250" width="720" height="250" fill="{col}" opacity=".55"/><rect x="-480" y="0" width="960" height="30" fill="{col}"/>'
            f'<g transform="translate(-560,0)"><rect x="-14" y="-260" width="28" height="200" fill="{col}"/><circle cx="0" cy="-280" r="34" fill="{col}"/><rect x="-60" y="-60" width="120" height="60" fill="{col}"/></g></g>')

def candles(n, y0, seed=1):
    r = random.Random(seed); g = []
    for k in range(n):
        x = r.uniform(-60, 1140); y = y0 + r.uniform(0, 520); s = 0.5 + (y - y0) / 520 * 0.9
        g.append(f'<g transform="translate({x:.0f},{y:.0f}) scale({s:.2f})"><rect x="-10" y="-60" width="20" height="60" fill="#E8DCC4"/><path d="M0,-96 q14,22 0,34 q-14,-12 0,-34" fill="#FFB347"/></g>')
    return "".join(g)
def candle_glow(n, y0, seed=1):
    r = random.Random(seed); g = []
    for k in range(n):
        x = r.uniform(-60, 1140); y = y0 + r.uniform(0, 520); s = 0.5 + (y - y0) / 520 * 0.9
        g.append(glow(x, y - 80 * s, 70 * s, "#FFB060", .55))
    return "".join(g)

def newspaper(x, y, s, ang, title):
    bars = "".join(f'<rect x="-250" y="{-60+k*46}" width="{500-(k%3)*80}" height="26" fill="#111"/>' for k in range(7))
    return (f'<g transform="translate({x},{y}) rotate({ang}) scale({s})"><rect x="-300" y="-260" width="600" height="760" fill="#E8E2D4"/>'
            f'<text x="0" y="-170" font-family="Old Standard TT" font-weight="700" font-size="64" text-anchor="middle" fill="#111">{title}</text><line x1="-270" y1="-140" x2="270" y2="-140" stroke="#111" stroke-width="4"/>'
            f'<rect x="-250" y="-120" width="500" height="40" fill="#8A8478"/>{bars}</g>')

def calendar(x, y, s, year, crossed=True):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-200" y="-220" width="400" height="440" rx="24" fill="#F4F1EA"/><rect x="-200" y="-220" width="400" height="110" rx="24" fill="{RED}"/>'
            f'<text x="0" y="-145" font-family="Montserrat" font-weight="900" font-size="46" text-anchor="middle" fill="#FFF">ELEIÇÃO</text>'
            f'<text x="0" y="90" font-family="Anton" font-size="170" text-anchor="middle" fill="#1A1412">{year}</text></g>')

def chairs(n_hi, y=1560):
    g = []
    for k in range(11):
        x = 140 + k * 80; hi = k >= 11 - n_hi
        c = GOLD if hi else "#3A3A44"
        g.append(f'<g transform="translate({x},{y})"><rect x="-32" y="-150" width="64" height="110" rx="12" fill="{c}"/><rect x="-38" y="-46" width="76" height="22" rx="8" fill="{c}"/><rect x="-30" y="-24" width="10" height="60" fill="{c}"/><rect x="20" y="-24" width="10" height="60" fill="{c}"/></g>')
    return "".join(g)

def mic_scene():
    rows = "".join(f'<rect x="{X0}" y="{1400+k*90}" width="{BW}" height="70" rx="20" fill="{mix("#1A1420","#2A2030",k/5)}"/>' for k in range(6))
    ppl = "".join(person(x, 1460 + (k % 3) * 90, 230, "#0A0810", "coat", None, la=(100, 92), ra=(80, 85), face=random.Random(k).choice([1, -1])) for k, x in enumerate(range(-40, 1180, 70)))
    return rows, ppl

def hourglass(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-170" y="-300" width="340" height="30" rx="10" fill="{GOLD}"/><rect x="-170" y="270" width="340" height="30" rx="10" fill="{GOLD}"/>'
            f'<path d="M-140,-270 L140,-270 C140,-120 20,-40 20,0 C20,40 140,120 140,270 L-140,270 C-140,120 -20,40 -20,0 C-20,-40 -140,-120 -140,-270 Z" fill="#CFE4F0" opacity=".35" stroke="#E8F0F4" stroke-width="6"/>'
            f'<path d="M-90,-160 L90,-160 C70,-100 10,-40 0,-10 C-10,-40 -70,-100 -90,-160 Z" fill="#E8C070"/><path d="M-130,260 L130,260 C110,170 30,140 0,130 C-30,140 -110,170 -130,260 Z" fill="#E8C070"/><line x1="0" y1="-10" x2="0" y2="130" stroke="#E8C070" stroke-width="6"/></g>')

def timeline(items, y=960):
    g = f'<line x1="80" y1="{y}" x2="1000" y2="{y}" stroke="#C8C0B0" stroke-width="8"/>'
    for k, (yr, txt, col) in enumerate(items):
        x = 140 + k * (800 / max(1, len(items) - 1))
        g += f'<circle cx="{x:.0f}" cy="{y}" r="26" fill="{col}"/><text x="{x:.0f}" y="{y-60}" font-family="Anton" font-size="78" text-anchor="middle" fill="#F4F1EA">{yr}</text><text x="{x:.0f}" y="{y+90}" font-family="Montserrat" font-weight="800" font-size="44" text-anchor="middle" fill="{col}">{txt}</text>'
    return g

def urna(x, y, s):
    keys = "".join(f'<rect x="{60+(k%3)*70}" y="{-170+(k//3)*60}" width="56" height="44" rx="8" fill="#2A2A30"/>' for k in range(9))
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-320" y="-260" width="640" height="420" rx="30" fill="#D8D4CC"/><rect x="-290" y="-230" width="320" height="250" rx="12" fill="#1A3A5A"/>'
            f'<text x="-130" y="-90" font-family="Anton" font-size="90" text-anchor="middle" fill="#FFF">25/10</text>{keys}'
            f'<rect x="60" y="20" width="76" height="50" rx="8" fill="#FFF"/><rect x="146" y="20" width="76" height="50" rx="8" fill="{RED}"/><rect x="232" y="20" width="76" height="50" rx="8" fill="#2E9E4A"/></g>')

S = {}
def s1():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.14, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#0A0A12"), (0.6, "#2A1E2A"), (1, "#4A2A20")]) + glow(540, 900, 700, "#C89A5A", .3)),
                L(0.2, timeline([("1964", "golpe", RED), ("2026", "você decide", GOLD)], 1000), reveal=(0.3, 2.4, "ltr"), rough=False),
                L(0.3, label(540, 600, "62 ANOS", 200, "#F4F1EA", "Anton"), rough=False)])
S[1] = s1

def s2():
    return dict(light="#C8D0E0", rim_dx=4, cam=(1.0, 1.14, (-30, 20), (30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A3448"), (0.55, "#8A8A98"), (1, "#C8A888")]) + sun(820, 1100, 70, halo_r=600, op=.5)),
                L(0.15, ridge(1250, "#4A4E58", 120, 21) + f'<rect x="{X0}" y="1240" width="{BW}" height="900" fill="#4A4E58"/>'),
                L(0.35, fogband(1300, "#B8BCC4", .5, 260, 2), drift=(60, 0)),
                L(0.5, f'<path d="M300,1400 L780,1400 L1190,2115 L-110,2115 Z" fill="#3A3A40"/>' + R(tank(600, 1470, 0.5, "#1A1C18") + tank(380, 1620, 0.75, "#141612", -1)), drift=(0, 40)),
                L(0.85, R(tank(620, 2010, 1.5, "#0A0B08")) + ground(1940, "#1A1A16", "#0A0A08", 6, 2)),
                L(0.86, label(540, 520, "31 DE MARÇO DE 1964", 70, "#F4F1EA", "Anton"), reveal=(0.3, 0.3, "center"), rough=False)])
S[2] = s2

def s3():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, calendar(540, 1000, 1.3, "1965"), rough=False),
                L(0.4, f'<line x1="300" y1="760" x2="780" y2="1260" stroke="{RED}" stroke-width="34" stroke-linecap="round"/><line x1="780" y1="760" x2="300" y2="1260" stroke="{RED}" stroke-width="34" stroke-linecap="round"/>', reveal=(4.4, 0.25, "center"), rough=False),
                L(0.5, label(540, 480, "A PROMESSA", 110, "#F4F1EA", "Anton"), rough=False)])
S[3] = s3

def s4():
    return dict(light="#C8D0E0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#0A0E18"), (0.6, "#2A3448"), (1, "#5A5A68")])),
                L(0.2, R(congresso(540, 1350, 1.2, "#06080C", "#FFE8B0")) + ground(1340, "#1A1E28", "#0A0C12", 4, 1)),
                L(0.4, f'<g transform="translate(540,1180)"><rect x="-90" y="-40" width="180" height="150" rx="20" fill="#7A7E88"/><path d="M-56,-40 L-56,-110 Q0,-190 56,-110 L56,-40" stroke="#7A7E88" stroke-width="30" fill="none"/></g>', reveal=(1.0, 0.25, "center")),
                L(0.6, newspaper(260, 1600, 0.8, -8, "CENSURADO") + newspaper(800, 1660, 0.75, 7, "JORNAL"), reveal=(2.6, 0.4, "center")),
                L(0.7, label(540, 520, "AI-5 · 1968", 140, RED, "Anton"), rough=False)])
S[4] = s4

def s5():
    return dict(light="#FFB070", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, -40)), particles="dust",
        layers=[L(0.0, sky([(0, "#06060A"), (1, "#1A1012")])),
                L(0.2, candle_glow(40, 1250, 5), mode="screen", flicker=0.2),
                L(0.3, candles(40, 1250, 5), rough=False),
                L(0.5, label(540, 560, "21 ANOS", 170, "#F4F1EA", "Anton"), rough=False),
                L(0.52, label(540, 820, "434", 230, RED, "Anton") + label(540, 900, "mortos e desaparecidos políticos", 44, "#E8E0D0", "Montserrat"), reveal=(3.2, 0.3, "center"), rough=False),
                L(0.53, label(540, 1080, "377 responsáveis apontados · CNV, 2014", 40, GOLD, "Montserrat"), reveal=(7.0, 0.3, "center"), rough=False)])
S[5] = s5

def s6():
    doc = (f'<g transform="translate(540,1000) rotate(-3)"><rect x="-340" y="-420" width="680" height="840" fill="#F2EAD8"/>'
           f'<text x="0" y="-320" font-family="Old Standard TT" font-weight="700" font-size="52" text-anchor="middle" fill="#1A1412">LEI Nº 6.683</text><text x="0" y="-260" font-family="Old Standard TT" font-weight="700" font-size="40" text-anchor="middle" fill="#1A1412">28 de agosto de 1979</text>'
           + "".join(f'<rect x="-280" y="{-190+k*50}" width="{560-(k%3)*90}" height="16" fill="#A89A80"/>' for k in range(11)) + '</g>')
    walk = "".join(person(x, 1960, 560, "#0A0806", "coat", "kepi", la=(100, 92), ra=(80, 85), face=1) for x in (120, 330))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, -20), (0, 30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, doc, rough=False),
                L(0.4, stamp(560, 1160, "ANISTIA", -8, 150), reveal=(2.0, 0.15, "center"), rough=False),
                L(0.8, R(walk), reveal=(5.6, 0.6, "ltr")),
                L(0.82, label(760, 1640, "sem julgamento", 64, GOLD, "Caveat"), reveal=(6.4, 0.3, "center"), rough=False)])
S[6] = s6

def s7():
    rows, ppl = mic_scene()
    mic = f'<g transform="translate(540,1420)"><rect x="-8" y="-260" width="16" height="260" fill="#9AA0A8"/><ellipse cx="0" cy="-270" rx="26" ry="36" fill="#2A2A30"/><rect x="-120" y="0" width="240" height="60" rx="10" fill="#3A3A44"/></g>'
    return dict(light="#E8D0B0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#140E18"), (1, "#2A1E28")]) + glow(540, 700, 800, "#E8C090", .25)),
                L(0.3, rows + R(ppl)),
                L(0.6, R(mic) + R(person(540, 1960, 820, "#050407", "coat", None, la=(100, 92), ra=(-60, -100), face=1))),
                L(0.62, label(540, 500, "17 DE ABRIL DE 2016", 76, "#F4F1EA", "Anton"), rough=False),
                L(0.63, label(540, 640, "voto dedicado a Brilhante Ustra", 42, GOLD, "Montserrat"), reveal=(2.2, 0.3, "center"), rough=False),
                L(0.64, label(540, 860, "JAIR BOLSONARO", 120, RED, "Anton"), reveal=(9.6, 0.25, "center"), rough=False)])
S[7] = s7

def s8():
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.6, "#E8B080"), (1, "#F0C890")]) + sun(820, 1000, 80, halo_r=700)),
                L(0.05, godrays(820, 1000, "#FFF0C8", n=14, spread=180, a0=-100, op=.22, seed=8), mode="screen"),
                L(0.3, R(stf_building(540, 1400, 0.95, "#1A1614")) + ground(1420, "#C8B898", "#8A7A60", 4, 1)),
                L(0.6, label(540, 520, "SETEMBRO DE 2025", 90, "#1A1412", "Anton"), rough=False),
                L(0.62, stamp(540, 760, "CONDENADOS", -6, 130), reveal=(4.2, 0.15, "center"), rough=False),
                L(0.63, label(540, 980, "ex-presidente + generais", 54, "#1A1412", "Montserrat"), reveal=(5.0, 0.3, "center"), rough=False)])
S[8] = s8

def s9():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#0E0E14"), (1, "#1E1A20")])),
                L(0.2, timeline([("1930", "impune", "#8A8A92"), ("1937", "impune", "#8A8A92"), ("1964", "impune", "#8A8A92"), ("2025", "PUNIDO", GOLD)], 1000), reveal=(0.3, 3.4, "ltr"), rough=False),
                L(0.3, label(540, 600, "1ª VEZ NA HISTÓRIA", 110, GOLD, "Anton"), reveal=(4.6, 0.3, "center"), rough=False)])
S[9] = s9

def s10():
    doc = (f'<g transform="translate(540,1050) rotate(2)"><rect x="-340" y="-400" width="680" height="800" fill="#F2EAD8"/>'
           + "".join(f'<rect x="-280" y="{-300+k*50}" width="{560-(k%3)*90}" height="16" fill="#A89A80"/>' for k in range(13)) + '</g>')
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)), L(0.3, doc, rough=False),
                L(0.4, stamp(540, 900, "ANISTIA", -8, 150), reveal=(2.0, 0.15, "center"), rough=False),
                L(0.41, stamp(540, 1200, "INDULTO", 6, 150), reveal=(3.6, 0.15, "center"), rough=False),
                L(0.42, label(540, 480, "A PROMESSA DO FILHO", 96, "#F4F1EA", "Anton"), rough=False)])
S[10] = s10

def s11():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, -20)), particles="ash",
        layers=[L(0.0, sky([(0, "#0E0E14"), (1, "#2A1A1A")]) + glow(540, 960, 700, RED, .2)),
                L(0.3, label(270, 960, "1979", 190, "#8A8A92", "Anton"), rough=False),
                L(0.31, label(540, 960, "=", 200, "#F4F1EA", "Anton"), reveal=(0.6, 0.2, "center"), rough=False),
                L(0.32, label(800, 960, "2027?", 180, RED, "Anton"), reveal=(1.2, 0.2, "center"), rough=False),
                L(0.33, label(540, 1200, "golpe → perdão", 80, GOLD, "Montserrat"), reveal=(2.2, 0.3, "center"), rough=False)])
S[11] = s11

def s12():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#0E0E14"), (1, "#1E1A20")]) + glow(540, 1200, 700, GOLD, .15)),
                L(0.2, label(540, 520, "STF · 11 CADEIRAS", 100, "#F4F1EA", "Anton"), rough=False),
                L(0.3, chairs(0), rough=False),
                L(0.31, chairs(3), reveal=(4.0, 1.4, "rtl"), rough=False),
                L(0.32, label(540, 1660, "Fux 2028 · Cármen Lúcia 2029 · Gilmar 2030", 36, GOLD, "Montserrat"), reveal=(5.0, 0.3, "center"), rough=False)])
S[12] = s12

def s13():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#0E0E14"), (1, "#1E1A20")]) + glow(540, 1200, 700, GOLD, .15)),
                L(0.3, chairs(3), rough=False),
                L(0.4, label(540, 620, "QUASE 1/3", 190, GOLD, "Anton"), rough=False),
                L(0.41, label(540, 820, "do tribunal que julgou o golpe", 50, "#F4F1EA", "Montserrat"), reveal=(0.6, 0.3, "center"), rough=False),
                L(0.51, label(540, 1000, "um ministro pode ficar +20 anos", 56, "#F4F1EA", "Montserrat"), reveal=(2.6, 0.3, "center"), rough=False)])
S[13] = s13

def s14():
    sol = "".join(person(x, 1960, 520, "#0A0C08", "shirt", "kepi", la=(100, 92), ra=(-30, -60), face=1, prop=("rifle", -75)) for x in (90, 260, 430))
    return dict(light="#C8D0E0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#141A28"), (0.6, "#3A4458"), (1, "#6A6A78")])),
                L(0.3, R(congresso(760, 1420, 0.8, "#0A0C12", "#FFE8B0")) + ground(1420, "#1A1E28", "#0A0C12", 4, 1)),
                L(0.7, R(sol) + ground(1940, "#0A0C10", "#050608", 4, 1)),
                L(0.72, label(540, 480, "FORÇAS ARMADAS", 100, "#F4F1EA", "Anton"), rough=False),
                L(0.73, label(540, 640, "+ DIRETOR DA POLÍCIA FEDERAL", 66, GOLD, "Anton"), reveal=(2.6, 0.3, "center"), rough=False),
                L(0.74, label(540, 760, "a mesma PF do caso Master", 48, "#F4F1EA", "Montserrat"), reveal=(5.0, 0.3, "center"), rough=False)])
S[14] = s14

def s15():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="ash",
        layers=[L(0.0, sky([(0, "#0E0E14"), (1, "#2A1A1A")]) + glow(540, 960, 800, RED, .18)),
                L(0.2, timeline([("1964", "\"1 ano\"", RED), ("1979", "perdão", "#8A8A92"), ("1985", "21 anos", RED), ("2022", "de novo", RED)], 1000), reveal=(0.2, 5.2, "ltr"), rough=False)])
S[15] = s15

def s16():
    flag = (f'<g transform="translate(540,760)"><rect x="-320" y="-220" width="640" height="440" fill="#1E8A3A"/><path d="M0,-190 L290,0 L0,190 L-290,0 Z" fill="#F2C200"/><circle r="120" fill="#1A3A8A"/>'
            f'<path d="M-120,-10 Q0,-60 120,20" stroke="#FFF" stroke-width="18" fill="none"/></g>')
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#0E0E14"), (1, "#1A1A22")]) + glow(540, 900, 800, GOLD, .18)),
                L(0.3, flag, rough=False),
                L(0.5, R(urna(540, 1450, 0.85)), reveal=(1.4, 0.4, "center")),
                L(0.6, label(540, 330, "APRENDE OU REPETE?", 96, "#F4F1EA", "Anton"), reveal=(2.4, 0.3, "center"), rough=False)])
S[16] = s16
SC = S

# ---------- newspaper clippings + split screens ----------
def clipping(x, y, w, h, ang, head, quote, credit, hsize=120, paper="#E9E2CF", ink="#151210"):
    lines = "".join(f'<rect x="{-w/2+40}" y="{h/2-200+k*34}" width="{w-80-(k%3)*60}" height="12" fill="#B8AE98"/>' for k in range(5))
    i = gid("cl")
    return (f'<g transform="translate({x},{y}) rotate({ang})"><defs><filter id="{i}"><feTurbulence type="fractalNoise" baseFrequency=".7" numOctaves="3" seed="4"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .18"/></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"/></filter></defs>'
            f'<rect x="{-w/2+10}" y="{-h/2+14}" width="{w}" height="{h}" fill="#000" opacity=".35"/>'
            f'<path d="M{-w/2},{-h/2} L{w/2},{-h/2+6} L{w/2-4},{h/2} L{-w/2+6},{h/2-4} Z" fill="{paper}"/>'
            f'<path d="M{-w/2},{-h/2} L{w/2},{-h/2+6} L{w/2-4},{h/2} L{-w/2+6},{h/2-4} Z" fill="#000" filter="url(#{i})"/>'
            f'<text x="{-w/2+40}" y="{-h/2+58}" font-family="Montserrat" font-weight="800" font-size="26" letter-spacing="3" fill="#6A5E4A">{credit}</text>'
            f'<line x1="{-w/2+40}" y1="{-h/2+76}" x2="{w/2-40}" y2="{-h/2+76}" stroke="{ink}" stroke-width="3"/>'
            f'<text x="0" y="{-h/2+76+hsize}" font-family="Old Standard TT" font-weight="700" font-size="{hsize}" text-anchor="middle" fill="{ink}">{head}</text>'
            + "".join(f'<text x="0" y="{-h/2+120+hsize+k*50}" font-family="Old Standard TT" font-style="italic" font-size="40" text-anchor="middle" fill="#2A2420">{q}</text>' for k, q in enumerate(quote))
            + lines + '</g>')

def desk(dark="#1A120C"):
    return sky([(0, "#2A1A10"), (1, "#120A06")]) + glow(540, 800, 900, "#FFC070", .35) + "".join(f'<rect x="{X0}" y="{y}" width="{BW}" height="6" fill="#3A2416" opacity=".5"/>' for y in range(Y0, Y1, 46))

def n102():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, -20), (0, 30)), particles="dust",
        layers=[L(0.0, desk()),
                L(0.2, clipping(520, 640, 820, 560, -4, "BASTA!", ["“O Brasil já sofreu demasiado", "com o governo atual. Agora, basta!”"], "CORREIO DA MANHÃ · 31/03/1964 · EDITORIAL"), rough=False),
                L(0.3, clipping(560, 1120, 820, 520, 3, "FORA!", ["“Só há uma coisa a dizer", "ao senhor João Goulart: Saia!”"], "CORREIO DA MANHÃ · 01/04/1964 · EDITORIAL"), reveal=(0.9, 0.25, "center"), rough=False),
                L(0.4, clipping(520, 1540, 860, 420, -2, "RESSURGE A DEMOCRACIA!", ["(manchete, 4 de abril de 1964)"], "O GLOBO · 04/04/1964", hsize=58), reveal=(2.0, 0.25, "center"), rough=False),
                L(0.5, label(540, 300, "A IMPRENSA APOIOU", 92, "#F4F1EA", "Anton"), rough=False)])
S[102] = n102

def n104():
    box = (f'<g transform="translate(540,980) rotate(-2)"><rect x="-380" y="-330" width="760" height="660" fill="#E9E2CF"/><rect x="-350" y="-300" width="700" height="600" fill="none" stroke="#151210" stroke-width="5"/>'
           f'<text x="0" y="-220" font-family="Montserrat" font-weight="900" font-size="38" letter-spacing="6" text-anchor="middle" fill="#151210">PREVISÃO DO TEMPO</text>'
           + "".join(f'<text x="0" y="{-120+k*78}" font-family="Old Standard TT" font-weight="700" font-size="54" text-anchor="middle" fill="#151210">{t}</text>' for k, t in enumerate(["Tempo negro.", "Temperatura sufocante.", "O ar está irrespirável."]))
           + f'<text x="0" y="170" font-family="Old Standard TT" font-style="italic" font-size="38" text-anchor="middle" fill="#2A2420">“O país está sendo varrido</text><text x="0" y="218" font-family="Old Standard TT" font-style="italic" font-size="38" text-anchor="middle" fill="#2A2420">por fortes ventos.”</text>'
           + f'<text x="0" y="280" font-family="Montserrat" font-weight="700" font-size="28" text-anchor="middle" fill="#6A5E4A">Máx.: 38º em Brasília · Mín.: 5º nas Laranjeiras</text></g>')
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, desk()), L(0.3, box, rough=False),
                L(0.4, label(540, 420, "JORNAL DO BRASIL · DEZ/1968", 60, GOLD, "Anton") + label(540, 1460, "o recado driblando a censura do AI-5", 44, "#F4F1EA", "Montserrat"), rough=False)])
S[104] = n104

def n108():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, -20), (0, 30)), particles="dust",
        layers=[L(0.0, desk()),
                L(0.2, clipping(540, 820, 900, 640, -3, "STF CONDENA BOLSONARO", ["a 27 anos e 3 meses de prisão", "em regime fechado"], "IMPRENSA · 11/09/2025", hsize=62), rough=False),
                L(0.3, clipping(540, 1380, 900, 520, 2, "PUNIÇÃO INÉDITA", ["1 ex-presidente, 3 generais e 1 almirante", "começam a cumprir pena"], "O POVO · 25/11/2025", hsize=72), reveal=(1.2, 0.25, "center"), rough=False)])
S[108] = n108

def n110():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, -20), (0, 30)), particles="dust",
        layers=[L(0.0, desk()),
                L(0.2, clipping(540, 900, 920, 640, -2, "DAREI INDULTO", ["“Sem anistia, darei indulto", "a todo mundo”, diz Flávio"], "SBT NEWS · 29/09/2026", hsize=100), rough=False),
                L(0.3, stamp(560, 1420, "8 DE JANEIRO", -6, 100), reveal=(1.2, 0.15, "center"), rough=False)])
S[110] = n110

_s1, _s2, _s4, _s8, _s9, _s10, _s11, _s15 = S[1], S[2], S[4], S[8], S[9], S[10], S[11], S[15]
def _with(f, **kw):
    def g():
        d = f(); d.update(kw); return d
    return g
S[1] = _with(_s1, split=(2, 16, "1964", "2026"), split_shot=1)
S[2] = _with(_s2, alt=102)
S[4] = _with(_s4, alt=104)
S[8] = _with(_s8, alt=108)
S[9] = _with(_s9, split=(2, 8, "1964 · IMPUNE", "2025 · PUNIDO"))
S[10] = _with(_s10, alt=110)
S[11] = _with(_s11, split=(6, 10, "1979", "2027?"))
S[15] = _with(_s15, split=(2, 16, "1964", "2026"), split_shot=1)
SC = S
