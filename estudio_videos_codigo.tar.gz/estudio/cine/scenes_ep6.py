from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep1 import maloca
from scenes_ep2 import jtree, palm, jungle
from scenes_ep4 import nau, sea, cross_big, batel
from scenes_ep5 import (map_base, stripes_h, parchment, stamp, label, crown, throne_room, drapes, lightning, waves, RED, GOLD, INKB)
import random, math

def head(x, y, h, face=1, lean=0):
    hcx = x + lean + face * h * 0.008; hcy = y - h * 0.81 - h * 0.095; return hcx, hcy, h * 0.062

def bishop(x, y, h, col, face=1, gold=GOLD):
    p = person(x, y, h, col, "robe", None, la=(100, 92), ra=(-40, -70), face=face)
    hcx, hcy, hr = head(x, y, h, face)
    t = hcy - hr * 0.6
    mitre = f'<path d="M{hcx-hr*0.95:.0f},{t+hr*0.2:.0f} L{hcx-hr*0.8:.0f},{t-hr*1.6:.0f} Q{hcx:.0f},{t-hr*2.8:.0f} {hcx+hr*0.8:.0f},{t-hr*1.6:.0f} L{hcx+hr*0.95:.0f},{t+hr*0.2:.0f} Z" fill="{col}"/>'
    mitre += f'<line x1="{hcx:.0f}" y1="{t-hr*2.3:.0f}" x2="{hcx:.0f}" y2="{t:.0f}" stroke="{gold}" stroke-width="{hr*0.18:.1f}"/><line x1="{hcx-hr*0.5:.0f}" y1="{t-hr*1.2:.0f}" x2="{hcx+hr*0.5:.0f}" y2="{t-hr*1.2:.0f}" stroke="{gold}" stroke-width="{hr*0.18:.1f}"/>'
    hx = x + face * h * 0.17; ty = y - h * 1.25
    croz = f'<line x1="{hx:.0f}" y1="{y:.0f}" x2="{hx:.0f}" y2="{ty:.0f}" stroke="{col}" stroke-width="{h*0.016:.1f}"/><path d="M{hx:.0f},{ty:.0f} C{hx:.0f},{ty-h*0.12:.0f} {hx+face*h*0.12:.0f},{ty-h*0.12:.0f} {hx+face*h*0.1:.0f},{ty-h*0.03:.0f}" stroke="{col}" stroke-width="{h*0.016:.1f}" fill="none"/>'
    return p + mitre + croz

def jesuit(x, y, h, col, face=1, arms=((100, 92), (80, 85))):
    p = person(x, y, h, col, "robe", "hair" if False else None, la=arms[0], ra=arms[1], face=face)
    hcx, hcy, hr = head(x, y, h, face)
    cap = f'<path d="M{hcx-hr*1.0:.0f},{hcy-hr*0.2:.0f} C{hcx-hr*1.1:.0f},{hcy-hr*1.5:.0f} {hcx+hr*1.1:.0f},{hcy-hr*1.5:.0f} {hcx+hr*1.0:.0f},{hcy-hr*0.2:.0f} Z" fill="{col}"/>'
    return p + cap

def chained(x, y, h, col, face=1):
    p = person(x, y, h, col, "shirt", None, la=(60, 30), ra=(120, 150), face=face)
    hy = y - h * 0.58
    return p + f'<path d="M{x-h*0.09:.0f},{hy:.0f} q{h*0.09:.0f},{h*0.05:.0f} {h*0.18:.0f},0" stroke="#8A8A90" stroke-width="{h*0.012:.1f}" stroke-dasharray="{h*0.02:.1f} {h*0.01:.1f}" fill="none"/>'

def moray(x, y, s, col="#6A7A3A", spot="#E8D890"):
    r = random.Random(7)
    body = "M-420,60 C-300,-60 -150,120 0,20 C150,-80 280,40 360,-40 C400,-80 450,-90 480,-70 C500,-40 470,0 430,10 C350,40 250,140 100,140 C-60,140 -200,220 -420,100 Z"
    spots = "".join(f'<circle cx="{r.uniform(-380,380):.0f}" cy="{r.uniform(0,120) - (abs(r.uniform(-1,1))*0):.0f}" r="{r.uniform(8,18):.0f}" fill="{spot}" opacity=".7"/>' for _ in range(40))
    i = gid("mc")
    return (f'<g transform="translate({x},{y}) scale({s})"><defs><clipPath id="{i}"><path d="{body}"/></clipPath></defs><path d="{body}" fill="{col}"/><g clip-path="url(#{i})">{spots}</g>'
            f'<path d="M430,-60 L520,-110 L520,-20 Z" fill="#3A1A10"/><path d="M440,-50 l12,-14 l8,14 l10,-16 l8,14 l10,-14" stroke="#FFF" stroke-width="5" fill="none"/>'
            f'<circle cx="420" cy="-60" r="16" fill="#FFF"/><circle cx="424" cy="-60" r="8" fill="#1A1412"/>'
            f'<path d="M-200,40 C-100,-30 0,60 120,0" stroke="{mix(col,"#000000",.3)}" stroke-width="10" fill="none"/></g>')

def taipa_wall(y, col, x0=-110, x1=1190, h=120):
    g = f'<rect x="{x0}" y="{y-h}" width="{x1-x0}" height="{h}" fill="{col}"/>'
    g += "".join(f'<rect x="{x}" y="{y-h-40}" width="50" height="40" fill="{col}"/>' for x in range(x0, x1, 90))
    g += "".join(f'<line x1="{x0}" y1="{y-h+k*30}" x2="{x1}" y2="{y-h+k*30}" stroke="{mix(col,"#000000",.25)}" stroke-width="3"/>' for k in range(1, 4))
    return g

def church(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-120" y="-260" width="240" height="260" fill="{col}"/><path d="M-130,-260 L0,-360 L130,-260 Z" fill="{col}"/>'
            f'<rect x="80" y="-420" width="70" height="420" fill="{col}"/><path d="M75,-420 L115,-480 L155,-420 Z" fill="{col}"/><rect x="110" y="-540" width="10" height="60" fill="{col}"/><rect x="96" y="-522" width="38" height="9" fill="{col}"/>'
            f'<path d="M-30,0 L-30,-90 Q0,-120 30,-90 L30,0 Z" fill="{mix(col,"#000000",.5)}"/></g>')

def icon_card(x, y, title, sym):
    return (f'<g transform="translate({x},{y})"><rect x="-150" y="-190" width="300" height="380" rx="26" fill="#EFE0BC" stroke="{INKB}" stroke-width="6"/>{sym}'
            f'<text x="0" y="150" font-family="Anton" font-size="46" text-anchor="middle" fill="{INKB}">{title}</text></g>')
SCALE_SYM = f'<g fill="none" stroke="{INKB}" stroke-width="8"><line x1="0" y1="-140" x2="0" y2="60"/><line x1="-90" y1="-110" x2="90" y2="-110"/><path d="M-90,-110 L-120,-20 L-60,-20 Z M90,-110 L60,-20 L120,-20 Z"/><line x1="-50" y1="60" x2="50" y2="60"/></g>'
COIN_SYM = "".join(f'<ellipse cx="{-40+(k%3)*40}" cy="{40-(k//3)*26}" rx="44" ry="16" fill="{GOLD}" stroke="#8A6A10" stroke-width="4"/>' for k in range(9))
CANNON_SYM = f'<g><rect x="-110" y="-80" width="200" height="56" rx="20" fill="{INKB}" transform="rotate(-14)"/><circle cx="-30" cy="10" r="50" fill="none" stroke="{INKB}" stroke-width="12"/><circle cx="-30" cy="10" r="10" fill="{INKB}"/></g>'

S = {}
def hook(cam):
    r = random.Random(61)
    shadows = "".join(person(x, 1990 + r.uniform(-10, 10), r.uniform(520, 620), "#050203", "shirt", r.choice(["cocar", "hair"]), la=(100, 92), ra=(80, 85), face=-1 if x > 540 else 1) for x in (40, 150, 930, 1050))
    return dict(light="#FF9A50", rim_dx=4, cam=cam, particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.55, "#3A1010"), (1, "#7A2A14")]) + glow(540, 1500, 900, "#FF6A20", .4)),
                L(0.15, sea(1320, "#3A1A1A", "#140808", "#FF9A60") + R(nau(860, 1330, 0.3, "#0A0405", sails="#3A2A2A", cross=False))),
                L(0.3, f'<path d="M{X0},1500 C300,1460 700,1480 {X1},1510 L{X1},{Y1} L{X0},{Y1} Z" fill="#1A0A08"/>'),
                L(0.45, fire(760, 1740, 130, 220, 61), flicker=0.25, rough=False),
                L(0.46, glow(780, 1660, 460, "#FFA050", .55), mode="screen", flicker=0.2),
                L(0.6, R(bishop(400, 1720, 780, "#0A0406"))),
                L(0.9, R(shadows) + ground(1980, "#0A0404", "#030102", 6, 2))])
S[1] = lambda: hook((1.0, 1.12, (0, 30), (0, -20)))

def s2():
    base = parchment() + map_base()
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, base + stripes_h(.6), rough=False),
                L(0.05, f'<line x1="200" y1="420" x2="1000" y2="1500" stroke="{RED}" stroke-width="22" stroke-linecap="round"/><line x1="1000" y1="420" x2="200" y2="1500" stroke="{RED}" stroke-width="22" stroke-linecap="round"/>', reveal=(0.6, 0.4, "center"), rough=False),
                L(0.1, label(540, 170, "1549", 120, RED, "Anton"), rough=False),
                L(0.12, crown(540, 900, 1.6), reveal=(4.2, 0.3, "center"), rough=False),
                L(0.13, stamp(540, 1200, "UM CHEFE SÓ", -6, 120), reveal=(4.6, 0.15, "center"), rough=False)])
S[2] = s2

def s3():
    fleet = "".join(R(nau(x, y, s, mix("#1A1418", "#6A6A74", 1 - s * 1.6), sails="#EFE2C8")) for x, y, s in [(880, 1230, .18), (720, 1245, .22), (980, 1265, .26), (560, 1290, .32), (820, 1330, .4), (400, 1400, .55)])
    gov = person(170, 1960, 720, "#0E0806", "coat", "brim", la=(100, 92), ra=(-40, -70), face=1, beard=True, prop=("staff",))
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A8AB8"), (0.55, "#F4D0A0"), (1, "#F8B878")]) + sun(760, 1050, 90, halo_r=800)),
                L(0.05, godrays(760, 1050, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=63), mode="screen"),
                L(0.15, sea(1180, "#B8B0B0", "#5A6878", "#FFF0D8") + R(jungle(1190, "#5A5A50", 12, 160, 260, 63, 5))),
                L(0.4, fleet, drift=(-50, 0)),
                L(0.85, R(gov) + sea(1820, "#3A4858", "#141C28", "#FFF0D0", 8))])
S[3] = s3

def s4():
    crew = (chained(170, 1960, 620, "#0E0806", 1) + chained(420, 1990, 680, "#0E0806", 1) + person(700, 1960, 640, "#0E0806", "shirt", "morion", la=(100, 92), ra=(-30, -60), face=-1, prop=("rifle", -70))
            + person(930, 1980, 660, "#0E0806", "shirt", "brim", la=(100, 92), ra=(60, 30), face=-1, prop=("hammer", -40)))
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.55, "#E8A878"), (1, "#F0C088")]) + sun(540, 1100, 90, halo_r=700)),
                L(0.1, sea(1200, "#B88878", "#4A3848", "#FFE0B8")),
                L(0.35, R(f'<rect x="{X0}" y="1480" width="{BW}" height="80" fill="#2A1A10"/><rect x="520" y="300" width="22" height="1200" fill="#2A1A10"/><path d="M300,420 Q540,470 780,420 L800,900 Q540,960 280,900 Z" fill="#E8D8B8"/>')),
                L(0.8, R(crew) + ground(1960, "#2A1A10", "#140A06", 4, 1)),
                L(0.82, label(540, 1240, "~400 DEGREDADOS", 96, "#FFF4E0", "Anton"), reveal=(2.6, 0.3, "center"), rough=False)])
S[4] = s4

def s5():
    js = "".join(jesuit(140 + k * 160, 1940 + (k % 2) * 20, 560 + (k % 3) * 40, "#0A0608", 1 if k < 3 else -1) for k in range(6))
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#8AA8C8"), (0.6, "#F4DCB8"), (1, "#F8C890")]) + sun(540, 1000, 100, halo_r=800)),
                L(0.05, godrays(540, 1000, "#FFF8E0", n=14, spread=170, a0=-90, op=.24, seed=65), mode="screen"),
                L(0.2, sea(1250, "#A8C0C8", "#6A8898", "#FFF6E0")),
                L(0.45, R(cross_big(540, 1500, 0.9, "#1A120C")) + f'<path d="M{X0},1500 C300,1460 700,1480 {X1},1510 L{X1},{Y1} L{X0},{Y1} Z" fill="#D8B888"/>'),
                L(0.8, R(js) + ground(1930, "#B89868", "#8A6A48", 4, 1))])
S[5] = s5

def caramuru(x, y, h, face=1):
    p = person(x, y, h, "#120A06", "shirt", "hair", la=(100, 92), ra=(-30, -60), face=face, beard=True)
    hcx, hcy, hr = head(x, y, h, face)
    feathers = "".join(f'<path d="M{hcx-hr*0.6+k*hr*0.4:.0f},{hcy-hr*0.9:.0f} l{-hr*0.2+k*hr*0.1:.0f},{-hr*1.4:.0f} l{hr*0.25:.0f},{hr*0.1:.0f} Z" fill="#120A06"/>' for k in range(4))
    return p + feathers

def s6():
    return dict(light="#FFD8A0", rim_dx=5, cam=(1.0, 1.14, (-30, 20), (20, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A8AB8"), (0.55, "#F4D0A0"), (1, "#F8B878")]) + sun(820, 1050, 90, halo_r=800)),
                L(0.05, godrays(820, 1050, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=66), mode="screen"),
                L(0.2, sea(1220, "#B8B8B8", "#5A6878", "#FFF0D8") + R(nau(760, 1280, 0.35, "#1A1418", sails="#EFE2C8"))),
                L(0.4, R(batel(560, 1420, 0.6, "#161214", 3))),
                L(0.5, f'<path d="M{X0},1480 C300,1450 700,1470 {X1},1500 L{X1},{Y1} L{X0},{Y1} Z" fill="#E0C898"/>' + R(palm(-30, 1600, 900, "#2A1E14", 66))),
                L(0.85, R(caramuru(300, 1990, 860, 1)) + ground(1960, "#C8A070", "#8A6A48", 6, 1)),
                L(0.86, label(320, 1080, "?", 220, "#FFF4E0", "Anton"), reveal=(1.0, 0.2, "center"), rough=False)])
S[6] = s6

def s7():
    return dict(light="#C8E8F0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -20)), particles=None,
        layers=[L(0.0, sky([(0, "#0A3A58"), (0.6, "#0A5A78"), (1, "#1A7A88")]) + glow(540, 300, 900, "#9AE0F0", .35) + godrays(540, -100, "#CFF4FF", n=10, spread=60, a0=90, op=.18, seed=67)),
                L(0.2, Rr("".join(f'<circle cx="{random.Random(k).uniform(0,1080):.0f}" cy="{random.Random(k+50).uniform(300,1800):.0f}" r="{random.Random(k+9).uniform(6,16):.0f}" fill="none" stroke="#CFF4FF" stroke-width="3" opacity=".6"/>' for k in range(30))), drift=(0, -160)),
                L(0.4, Rr(f'<path d="M{X0},1700 C200,1600 400,1680 600,1620 C800,1560 1000,1660 {X1},1600 L{X1},{Y1} L{X0},{Y1} Z" fill="#0A2A38"/>' + "".join(f'<path d="M{x},1680 q-20,-120 10,-220 q30,100 -10,220" fill="#2A5A3A"/>' for x in range(-80, 1200, 110)))),
                L(0.6, R(moray(560, 1050, 1.05)), drift=(-40, 0)),
                L(0.62, label(540, 560, "CARAMURU = MOREIA", 92, "#FFF4E0", "Anton"), reveal=(1.2, 0.3, "center"), rough=False)])
S[7] = s7

def s8():
    para = person(700, 1960, 760, "#120A06", "dress", "hair", la=(100, 92), ra=(150, 170), face=-1)
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A2A48"), (0.5, "#D8805A"), (1, "#F0A860")]) + sun(540, 1250, 110, halo_r=900)),
                L(0.05, godrays(540, 1250, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=68), mode="screen"),
                L(0.25, R(jungle(1420, "#5A3A40", 12, 220, 340, 68, 4)) + f'<rect x="{X0}" y="1410" width="{BW}" height="800" fill="#4A2A28"/>' + R(maloca(860, 1480, 0.8, "#2A1A18"))),
                L(0.8, R(caramuru(380, 1960, 820, 1) + para) + ground(1940, "#2A1814", "#140A08", 6, 1)),
                L(0.82, label(540, 600, "TRADUTOR", 110, "#FFF4E0", "Anton"), reveal=(2.4, 0.3, "center"), rough=False)])
S[8] = s8

def s9():
    workers = "".join(person(x, 1700 + (k % 2) * 20, 230, "#1A120C", "shirt", r_, la=(-60, -100), ra=(-100, -80), face=1) for k, (x, r_) in enumerate([(160, "hair"), (330, "cocar"), (520, "hair"), (700, "cocar"), (880, "hair")]))
    city = taipa_wall(1180, "#8A6A48", 60, 1100, 110) + church(380, 1070, 0.6, "#6A4A30") + church(820, 1070, 0.45, "#6A4A30") + "".join(f'<g transform="translate({x},1070)"><rect x="-50" y="-70" width="100" height="70" fill="#7A5A3A"/><path d="M-60,-70 L0,-120 L60,-70 Z" fill="#8A3A20"/></g>' for x in (180, 560, 680, 980))
    return dict(light="#FFE0A0", rim_dx=5, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A90C0"), (0.6, "#F0D0A0"), (1, "#F8B878")]) + sun(880, 760, 80, halo_r=700)),
                L(0.15, sea(1500, "#9AB8C8", "#5A7888", "#FFF0D8")),
                L(0.3, R(f'<path d="M{X0},1250 C200,1180 300,1060 500,1050 C700,1040 900,1060 {X1},1100 L{X1},1520 L{X0},1520 Z" fill="#6A5A3A"/>' + city), reveal=(0.3, 2.4, "ltr")),
                L(0.5, R(f'<path d="M{X0},1520 L{X1},1520 L{X1},1560 L{X0},1560 Z" fill="#5A4A30"/>' + workers)),
                L(0.6, smoke_puffs(500, 1000, "#EDE4D8", n=6, s=0.6, seed=69, drift=1), drift=(30, -60)),
                L(0.62, label(540, 560, "SALVADOR · 1549", 96, "#1A0E08", "Anton"), reveal=(4.4, 0.3, "center"), rough=False)])
S[9] = s9

def s10():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.1, icon_card(220, 900, "JUSTIÇA", SCALE_SYM), reveal=(0.3, 0.2, "center"), rough=False),
                L(0.11, icon_card(540, 1000, "DINHEIRO", COIN_SYM), reveal=(2.0, 0.2, "center"), rough=False),
                L(0.12, icon_card(860, 900, "DEFESA", CANNON_SYM), reveal=(3.6, 0.2, "center"), rough=False),
                L(0.13, label(540, 520, "O 1º MINISTÉRIO", 96, GOLD, "Anton"), rough=False)])
S[10] = s10

def s11():
    kids = "".join(person(x, 1900, h, "#120A06", "shirt", "hair", la=(100, 92), ra=(80, 85), face=-1) for x, h in ((560, 380), (700, 420), (840, 360), (980, 400)))
    board = f'<g transform="translate(720,900) rotate(-2)"><rect x="-260" y="-160" width="520" height="320" fill="#2A3A2A" stroke="#5A3A20" stroke-width="16"/><text x="0" y="-40" font-family="Caveat" font-weight="700" font-size="80" text-anchor="middle" fill="#F4F0E0">Tupã = Deus</text><text x="0" y="70" font-family="Caveat" font-weight="700" font-size="80" text-anchor="middle" fill="#F4F0E0">abá = homem</text></g>'
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.12, (20, 20), (-20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#7AA0C8"), (0.6, "#F0D8A8"), (1, "#F4C080")]) + sun(200, 1000, 80, halo_r=700)),
                L(0.2, R(jungle(1350, "#5A6A50", 12, 220, 340, 611, 4)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#B89A68"/>'),
                L(0.4, R(maloca(200, 1420, 0.7, "#3A2A1A") + board)),
                L(0.8, R(jesuit(260, 1960, 820, "#0A0608", 1, ((100, 92), (-30, -60))) + kids) + ground(1930, "#3A2818", "#1E140C", 6, 1))])
S[11] = s11

def s12():
    b = bishop(330, 1720, 780, "#A8180E")
    j = jesuit(800, 1720, 740, "#120A08", -1, ((100, 92), (-150, -170)))
    bub = lambda x, y, t: f'<g transform="translate({x},{y})"><path d="M-120,-70 L120,-70 Q150,-70 150,-40 L150,40 Q150,70 120,70 L20,70 L-10,120 L-20,70 L-120,70 Q-150,70 -150,40 L-150,-40 Q-150,-70 -120,-70 Z" fill="#FFF8E8" stroke="#1A0E08" stroke-width="7"/><text x="0" y="34" font-family="Anton" font-size="96" text-anchor="middle" fill="{RED}">{t}</text></g>'
    return dict(light="#FFC070", rim_dx=5, cam=(1.0, 1.12, (0, 10), (0, -30)), particles="dust",
        layers=[L(0.0, throne_room()),
                L(0.5, R(b + j)),
                L(0.52, bub(380, 520, "!!"), reveal=(3.6, 0.15, "center"), rough=False),
                L(0.53, bub(780, 560, "?!"), reveal=(4.2, 0.15, "center"), rough=False),
                L(0.9, drapes())])
S[12] = s12

def s13():
    return dict(light="#B8C8E0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="ash",
        layers=[L(0.0, sky([(0, "#06080E"), (0.6, "#1E2838"), (1, "#3A4658")]) + glow(700, 500, 600, "#8AA0C8", .3)),
                L(0.05, lightning(300, 120), flicker=0.9, rough=False),
                L(0.2, waves(1250, "#2A3448", 90, 63)),
                L(0.45, f'<g transform="rotate(18 540 1300)">' + R(nau(540, 1300, 0.85, "#05060A", sails="#8A90A0")) + '</g>', drift=(0, 40)),
                L(0.7, waves(1500, "#141A28", 140, 64), drift=(-60, 0)),
                L(0.95, waves(1800, "#0A0E16", 120, 65))])
S[13] = s13

def s14():
    mitre = f'<g transform="translate(560,1760) rotate(-24)"><path d="M-80,0 L-66,-140 Q0,-240 66,-140 L80,0 Z" fill="#E8DCC8" stroke="#5A3A20" stroke-width="5"/><line x1="0" y1="-200" x2="0" y2="0" stroke="{GOLD}" stroke-width="12"/><line x1="-44" y1="-100" x2="44" y2="-100" stroke="{GOLD}" stroke-width="12"/></g>'
    return dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, 40)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.6, "#2A0E10"), (1, "#5A1A10")]) + glow(540, 1400, 800, "#FF6A20", .4)),
                L(0.2, R(jungle(1350, "#140608", 12, 300, 500, 614, 4)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#1A0A08"/>'),
                L(0.4, fire(780, 1560, 140, 220, 14), flicker=0.25, rough=False),
                L(0.41, glow(800, 1500, 420, "#FFA050", .5), mode="screen", flicker=0.2),
                L(0.6, R(mitre)),
                L(0.9, R("".join(person(x, 2000, h, "#030102", "shirt", "cocar", la=(100, 92), ra=(-60, -90), face=f, prop=("staff",)) for x, h, f in ((90, 900, 1), (1000, 860, -1)))) + ground(1980, "#0A0404", "#030102", 6, 2))])
S[14] = s14

def s15():
    sol = "".join(person(x, 1960, h, "#060404", "shirt", "morion", la=(100, 92), ra=(-30, -60), face=1, prop=("rifle", -20)) for x, h in ((120, 700), (330, 660), (540, 620)))
    return dict(light="#C8A890", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#1A1418"), (0.6, "#4A3434"), (1, "#7A5A48")])),
                L(0.2, R(jungle(1350, "#2A2024", 12, 240, 380, 615, 4)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#2A2024"/>'),
                L(0.4, smoke_puffs(800, 1200, "#8A8080", n=10, s=1.2, seed=15, drift=1), drift=(-60, -80)),
                L(0.85, R(sol) + ground(1940, "#140E0E", "#060404", 6, 1))])
S[15] = s15

def s16():
    page_ = (f'<g transform="translate(540,860) rotate(-2)"><rect x="-400" y="-560" width="800" height="1100" fill="#F2EAD8" stroke="#3A2214" stroke-width="5"/>'
             f'<text x="0" y="-420" font-family="Old Standard TT" font-weight="700" font-size="58" text-anchor="middle" fill="#1A1412">MANIFESTO</text>'
             f'<text x="0" y="-340" font-family="Old Standard TT" font-weight="700" font-size="58" text-anchor="middle" fill="#1A1412">ANTROPÓFAGO</text>'
             + "".join(f'<line x1="-320" y1="{-240+k*48}" x2="{320 - (k%3)*60}" y2="{-240+k*48}" stroke="#9A8A70" stroke-width="6"/>' for k in range(9))
             + '</g>')
    date_ = f'<g transform="translate(540,860) rotate(-2)"><text x="0" y="170" font-family="Courier New, monospace" font-weight="700" font-size="40" text-anchor="middle" fill="{RED}">Ano 374 da Deglutição</text><text x="0" y="226" font-family="Courier New, monospace" font-weight="700" font-size="40" text-anchor="middle" fill="{RED}">do Bispo Sardinha.</text><text x="0" y="310" font-family="Caveat" font-weight="700" font-size="56" text-anchor="middle" fill="#1A1412">Oswald de Andrade, 1928</text></g>'
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, -40), (0, 60)), particles="dust",
        layers=[L(0.0, parchment(dark=True)), L(0.2, page_, rough=False), L(0.21, date_, reveal=(4.0, 2.4, "ltr"), rough=False)])
S[16] = s16

def s17():
    city = (taipa_wall(1300, "#6A5A48", -110, 1190, 90) + church(220, 1220, 0.8, "#4A3A2A") + church(620, 1210, 0.6, "#4A3A2A") + church(940, 1230, 0.7, "#4A3A2A")
            + "".join(f'<g transform="translate({x},1240)"><rect x="-50" y="-80" width="100" height="80" fill="#5A4A3A"/><path d="M-60,-80 L0,-130 L60,-80 Z" fill="#7A3A20"/></g>' for x in (420, 780, 1080, 60)))
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.55, "#F0B080"), (1, "#F8C890")]) + sun(540, 1080, 100, halo_r=900)),
                L(0.05, godrays(540, 1080, "#FFF0C8", n=16, spread=190, a0=-90, op=.26, seed=617), mode="screen"),
                L(0.3, R(f'<path d="M{X0},1300 L{X1},1300 L{X1},1500 L{X0},1500 Z" fill="#5A4A38"/>' + city)),
                L(0.45, sea(1500, "#C88068", "#3A2A40", "#FFE0B8") + R(nau(780, 1600, 0.35, "#140C10", sails="#E8D2B8"))),
                L(0.6, label(540, 600, "1549 → 1763", 120, "#FFF4E0", "Anton"), rough=False),
                L(0.61, label(540, 760, "214 ANOS DE CAPITAL", 92, GOLD, "Anton"), reveal=(1.0, 0.3, "center"), rough=False)])
S[17] = s17

S[18] = lambda: hook((1.0, 1.0, (0, 30), (0, 30)))
SC = S
