import sys, numpy as np, cv2
from scenes_ep2 import SC
from cine import render_layers, Scene, compose, post, Particles
ids = [int(a) for a in sys.argv[1:]] or sorted(SC)
render_layers(SC, ids, "layers_ep2")
tiles = []
for n in ids:
    sc = Scene(n, SC[n](), "layers_ep2"); fr = compose(sc, 0.6, 3.0)
    img = post(fr, 3.0, Particles(sc.sc.get("particles"), n), 10)
    cv2.imwrite(f"prev2/p{n:02d}.jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    tiles.append(cv2.resize(img, (270, 480)))
while len(tiles) % 7: tiles.append(np.zeros_like(tiles[0]))
rows = [np.hstack(tiles[i:i+7]) for i in range(0, len(tiles), 7)]
cv2.imwrite("prev2/sheet.jpg", cv2.cvtColor(np.vstack(rows), cv2.COLOR_RGB2BGR))
