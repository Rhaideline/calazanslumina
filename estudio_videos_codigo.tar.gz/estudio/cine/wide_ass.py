"""Converte uma legenda ASS feita para 1080x1920 (vertical) em 1920x1080 (horizontal)."""
import re
FS = 0.58  # escala de fontes
STY = {"Cap": (960, 940), "Title": (960, 300), "Big": (960, 430)}
def _y(y): return round(y * 1080 / 1920)
def _x(x): return round(960 + (x - 540)) if x > 200 else round(x)
def convert(path):
    out = []
    for ln in open(path).read().split("\n"):
        if ln.startswith("PlayResX:"): ln = "PlayResX: 1920"
        elif ln.startswith("PlayResY:"): ln = "PlayResY: 1080"
        elif ln.startswith("Style:"):
            p = ln.split(",")
            p[2] = str(round(float(p[2]) * FS))            # tamanho da fonte
            p[16] = str(round(float(p[16]) * FS, 1))        # contorno
            p[17] = str(round(float(p[17]) * FS, 1))        # sombra
            p[21] = str(round(float(p[21]) * 1080 / 1920))  # margem vertical
            ln = ",".join(p)
        elif ln.startswith("Dialogue:"):
            style = ln.split(",")[3]
            def pos(m):
                x, y = float(m.group(1)), float(m.group(2))
                if style in STY and abs(x - 540) < 1 and style != "Big":
                    nx, ny = STY[style] if style != "Title" else (960, _y(y))
                    if style == "Cap": nx, ny = STY["Cap"] if y > 1100 else (960, _y(y))
                else: nx, ny = _x(x), _y(y)
                return f"\\pos({nx},{ny})"
            ln = re.sub(r"\\pos\(([-\d.]+),([-\d.]+)\)", pos, ln)
            ln = re.sub(r"\\move\(([-\d.]+),([-\d.]+),([-\d.]+),([-\d.]+)", lambda m: f"\\move({_x(float(m.group(1)))},{_y(float(m.group(2)))},{_x(float(m.group(3)))},{_y(float(m.group(4)))}", ln)
            ln = re.sub(r"\\fs([\d.]+)", lambda m: f"\\fs{round(float(m.group(1)) * FS)}", ln)
        out.append(ln)
    open(path, "w").write("\n".join(out))
