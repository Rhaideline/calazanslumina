"""High-quality SVG art primitives for layered cinematic scenes.
Drawing space: 1080x1920 frame, with bleed. Layer canvas covers x in [-110,1190], y in [-195,2115]."""
import math, random
BX0, BY0, BW, BH = -110, -195, 1300, 2310
X0, X1, Y0, Y1 = BX0, BX0 + BW, BY0, BY0 + BH

def lerp(a, b, t): return a + (b - a) * t
def hx(c): c = c.lstrip("#"); return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
def mix(c1, c2, t):
    a, b = hx(c1), hx(c2); return "#%02x%02x%02x" % tuple(int(lerp(a[i], b[i], t)) for i in range(3))

# ---------------- filters ----------------
def filters(light="#FFD9A0", rim_dx=-3, rough=4, seed=2):
    return f'''<defs>
<filter id="rim" x="-20%" y="-20%" width="140%" height="140%">
 <feOffset in="SourceAlpha" dx="{rim_dx}" dy="3" result="off"/>
 <feComposite in="SourceAlpha" in2="off" operator="out" result="edge"/>
 <feGaussianBlur in="edge" stdDeviation="0.9" result="edgeb"/>
 <feFlood flood-color="{light}" flood-opacity="0.6"/>
 <feComposite in2="edgeb" operator="in" result="rimc"/>
 <feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="rimc"/></feMerge>
</filter>
<filter id="rough" x="-5%" y="-5%" width="110%" height="110%">
 <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="2" seed="{seed}" result="n"/>
 <feDisplacementMap in="SourceGraphic" in2="n" scale="{rough}" xChannelSelector="R" yChannelSelector="G"/>
</filter>
<filter id="roughrim" x="-20%" y="-20%" width="140%" height="140%">
 <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="2" seed="{seed}" result="n"/>
 <feDisplacementMap in="SourceGraphic" in2="n" scale="{rough}" xChannelSelector="R" yChannelSelector="G" result="d"/>
 <feColorMatrix in="d" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" result="da"/>
 <feOffset in="da" dx="{rim_dx}" dy="3" result="off"/>
 <feComposite in="da" in2="off" operator="out" result="edge"/>
 <feGaussianBlur in="edge" stdDeviation="0.9" result="edgeb"/>
 <feFlood flood-color="{light}" flood-opacity="0.6"/>
 <feComposite in2="edgeb" operator="in" result="rimc"/>
 <feMerge><feMergeNode in="d"/><feMergeNode in="rimc"/></feMerge>
</filter>
<filter id="blur6"><feGaussianBlur stdDeviation="6"/></filter>
<filter id="blur14" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="14"/></filter>
<filter id="blur30" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="30"/></filter>
<filter id="blur60" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="60"/></filter>
<filter id="grainy" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="5"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 0.25"/></feComponentTransfer><feComposite in2="SourceAlpha" operator="in"/></filter>
</defs>'''

def page(body, light="#FFD9A0", rim_dx=-7, rough=4):
    return (f'<html><head><style>html,body{{margin:0;background:transparent}}</style></head><body>'
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{BW}" height="{BH}" viewBox="{BX0} {BY0} {BW} {BH}">'
            f'{filters(light, rim_dx, rough)}{body}</svg></body></html>')

# ---------------- sky & atmosphere ----------------
_gid = [0]
def gid(p="g"): _gid[0] += 1; return f"{p}{_gid[0]}"

def sky(stops):
    i = gid("sk"); s = "".join(f'<stop offset="{o}" stop-color="{c}"/>' for o, c in stops)
    return f'<defs><linearGradient id="{i}" x1="0" y1="0" x2="0" y2="1">{s}</linearGradient></defs><rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="url(#{i})"/>'

def sun(x, y, r, core="#FFF4D6", halo="#FFD08A", halo_r=None, op=0.8):
    i = gid("sun"); hr = halo_r or r * 5
    return (f'<defs><radialGradient id="{i}"><stop offset="0" stop-color="{halo}" stop-opacity="{op}"/><stop offset="0.35" stop-color="{halo}" stop-opacity="{op*0.35}"/><stop offset="1" stop-color="{halo}" stop-opacity="0"/></radialGradient></defs>'
            f'<circle cx="{x}" cy="{y}" r="{hr}" fill="url(#{i})"/><circle cx="{x}" cy="{y}" r="{r}" fill="{core}"/>')

def glow(x, y, r, col, op=0.7):
    i = gid("gl")
    return f'<defs><radialGradient id="{i}"><stop offset="0" stop-color="{col}" stop-opacity="{op}"/><stop offset="1" stop-color="{col}" stop-opacity="0"/></radialGradient></defs><circle cx="{x}" cy="{y}" r="{r}" fill="url(#{i})"/>'

def godrays(x, y, col="#FFE7B0", n=9, spread=70, length=2600, op=0.22, a0=90, seed=1):
    r = random.Random(seed); g = []
    for k in range(n):
        a = math.radians(a0 - spread / 2 + spread * k / (n - 1) + r.uniform(-3, 3))
        w = math.radians(r.uniform(1.2, 3.2))
        p1 = (x + length * math.cos(a - w), y + length * math.sin(a - w)); p2 = (x + length * math.cos(a + w), y + length * math.sin(a + w))
        g.append(f'<path d="M{x},{y} L{p1[0]:.0f},{p1[1]:.0f} L{p2[0]:.0f},{p2[1]:.0f} Z" fill="{col}" opacity="{op*r.uniform(0.5,1):.2f}"/>')
    return f'<g filter="url(#blur14)">{"".join(g)}</g>'

def clouds(y, col, op=0.5, n=6, seed=1, scale=1.0, spread=None):
    r = random.Random(seed); g = []
    for k in range(n):
        cx = r.uniform(X0, X1); cy = y + r.uniform(-60, 60) * scale
        for j in range(5):
            g.append(f'<ellipse cx="{cx + r.uniform(-160,160)*scale:.0f}" cy="{cy + r.uniform(-30,30)*scale:.0f}" rx="{r.uniform(120,260)*scale:.0f}" ry="{r.uniform(40,80)*scale:.0f}" fill="{col}"/>')
    return f'<g opacity="{op}" filter="url(#blur30)">{"".join(g)}</g>'

def fogband(y, col="#E9EEE8", op=0.45, h=180, seed=1):
    r = random.Random(seed)
    g = "".join(f'<ellipse cx="{X0 + k*230 + r.uniform(-60,60):.0f}" cy="{y + r.uniform(-h*0.3,h*0.3):.0f}" rx="{r.uniform(260,420):.0f}" ry="{h*r.uniform(0.35,0.6):.0f}" fill="{col}"/>' for k in range(8))
    return f'<g opacity="{op}" filter="url(#blur30)">{g}</g>'

def haze(y0, y1, col, op=0.6):
    i = gid("hz")
    return f'<defs><linearGradient id="{i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{col}" stop-opacity="0"/><stop offset="1" stop-color="{col}" stop-opacity="{op}"/></linearGradient></defs><rect x="{X0}" y="{y0}" width="{BW}" height="{y1-y0}" fill="url(#{i})"/>'

def ground(y, c1, c2, wav=30, seed=1):
    i = gid("gr"); r = random.Random(seed)
    pts = " ".join(f"L{x},{y + r.uniform(-wav, wav):.0f}" for x in range(X0, X1 + 101, 100))
    return (f'<defs><linearGradient id="{i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient></defs>'
            f'<path d="M{X0},{Y1} L{X0},{y} {pts} L{X1},{Y1} Z" fill="url(#{i})"/>')

def ridge(y, col, amp=80, seed=1, step=60):
    r = random.Random(seed); pts = []; v = 0
    for x in range(X0, X1 + step, step):
        v = v * 0.7 + r.uniform(-1, 1) * amp * 0.5
        pts.append(f"L{x},{y + v:.0f}")
    return f'<path d="M{X0},{Y1} L{X0},{y} {" ".join(pts)} L{X1},{Y1} Z" fill="{col}"/>'

# ---------------- trees ----------------
def araucaria(x, y, h, col, seed=1, lean=0):
    r = random.Random(seed); g = []
    tw = h * 0.028
    topx, topy = x + lean * h * 0.05, y - h * 0.78
    g.append(f'<path d="M{x-tw*1.3},{y} C{x-tw},{y-h*0.4} {topx-tw*0.6},{topy+h*0.2} {topx-tw*0.4},{topy} L{topx+tw*0.4},{topy} C{topx+tw*0.6},{topy+h*0.2} {x+tw},{y-h*0.4} {x+tw*1.3},{y} Z" fill="{col}"/>')
    # dead lower branch stubs
    for k in range(3):
        yy = y - h * r.uniform(0.35, 0.65); s = r.choice([-1, 1])
        g.append(f'<line x1="{x}" y1="{yy:.0f}" x2="{x + s*h*0.06:.0f}" y2="{yy - h*0.03:.0f}" stroke="{col}" stroke-width="{tw*0.4:.1f}" stroke-linecap="round"/>')
    span = h * r.uniform(0.38, 0.48)
    tiers = [(0.0, 1.0, 11), (0.07, 0.78, 9), (0.14, 0.52, 6)]
    for dy, wf, n in tiers:
        by = topy - h * dy
        for k in range(n):
            a = -1 + 2 * k / (n - 1)
            ex = topx + a * span * wf + r.uniform(-8, 8)
            ey = by - h * 0.13 * (1 - abs(a) ** 1.6) - h * 0.03 + r.uniform(-6, 6)
            cx1 = topx + a * span * wf * 0.35; cy1 = by + h * 0.03
            g.append(f'<path d="M{topx},{by + h*0.015:.0f} Q{cx1:.0f},{cy1:.0f} {ex:.0f},{ey:.0f}" fill="none" stroke="{col}" stroke-width="{tw*0.55:.1f}" stroke-linecap="round"/>')
            tr = h * r.uniform(0.045, 0.065)
            for j in range(4):
                g.append(f'<ellipse cx="{ex + r.uniform(-tr, tr):.0f}" cy="{ey - r.uniform(0, tr*0.5):.0f}" rx="{tr*r.uniform(0.8,1.3):.0f}" ry="{tr*r.uniform(0.35,0.55):.0f}" fill="{col}"/>')
    return "".join(g)

def forest(y, col, n=8, hmin=300, hmax=520, seed=1, x0=X0, x1=X1, jitter=30):
    r = random.Random(seed); g = []
    for i in range(n):
        x = x0 + (x1 - x0) * (i + r.uniform(0.1, 0.9)) / n
        g.append(araucaria(x, y + r.uniform(-jitter, jitter), r.uniform(hmin, hmax), col, seed * 100 + i, r.uniform(-1, 1)))
    return "".join(g)

def forest_depth(y_back, y_front, c_far, c_near, rows=4, seed=1, hscale=1.0):
    g = []
    for k in range(rows):
        t = k / max(1, rows - 1)
        col = mix(c_far, c_near, t)
        y = lerp(y_back, y_front, t)
        g.append(forest(y + 40, col, n=int(lerp(14, 6, t)), hmin=lerp(120, 380, t) * hscale, hmax=lerp(220, 620, t) * hscale, seed=seed + k))
        g.append(f'<rect x="{X0}" y="{y+30}" width="{BW}" height="{Y1-y}" fill="{col}"/>')
    return "".join(g)

def stump(x, y, s, col, cut="#C79A62"):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-40,0 L-34,-60 L34,-60 L40,0 Z" fill="{col}"/>'
            f'<ellipse cx="0" cy="-60" rx="34" ry="11" fill="{cut}"/><ellipse cx="0" cy="-60" rx="18" ry="6" fill="none" stroke="{mix(cut,col,0.4)}" stroke-width="2"/>'
            f'<path d="M-40,0 q-20,4 -30,10 M40,0 q20,4 30,10" stroke="{col}" stroke-width="10" stroke-linecap="round"/></g>')

# ---------------- humans ----------------
def _seg(a, b, wa, wb, col):
    dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy) or 1
    nx, ny = -dy / L, dx / L
    p = [(a[0] + nx * wa / 2, a[1] + ny * wa / 2), (b[0] + nx * wb / 2, b[1] + ny * wb / 2), (b[0] - nx * wb / 2, b[1] - ny * wb / 2), (a[0] - nx * wa / 2, a[1] - ny * wa / 2)]
    return f'<path d="M{p[0][0]:.1f},{p[0][1]:.1f} L{p[1][0]:.1f},{p[1][1]:.1f} L{p[2][0]:.1f},{p[2][1]:.1f} L{p[3][0]:.1f},{p[3][1]:.1f} Z" fill="{col}"/><circle cx="{b[0]:.1f}" cy="{b[1]:.1f}" r="{wb/2:.1f}" fill="{col}"/>'

def P(p, L, a): return (p[0] + L * math.cos(math.radians(a)), p[1] + L * math.sin(math.radians(a)))

def person(x, y, h, col, outfit="shirt", hat=None, la=(100, 95), ra=(80, 85), ll=(95, 92), rl=(85, 88), face=1, lean=0, prop=None, beard=False, kneel=False):
    """y = feet. angles in degrees (90 = down). face=1 looks right."""
    g = []
    if kneel:
        y = y  # legs given by angles
    hip = (x, y - h * 0.47); sh = (x + lean, y - h * 0.81)
    sw = h * 0.105  # half shoulder width
    Ls, Rs = (sh[0] - sw, sh[1] + h * 0.01), (sh[0] + sw, sh[1] + h * 0.01)
    Lh, Rh = (hip[0] - h * 0.055, hip[1]), (hip[0] + h * 0.055, hip[1])
    # legs
    legs = []
    for hp, (a1, a2) in ((Lh, ll), (Rh, rl)):
        k = P(hp, h * 0.245, a1); f = P(k, h * 0.235, a2)
        legs.append(_seg(hp, k, h * 0.1, h * 0.065, col) + _seg(k, f, h * 0.062, h * 0.044, col) +
                    f'<path d="M{f[0]-h*0.025:.1f},{f[1]-h*0.02:.1f} L{f[0]+face*h*0.075:.1f},{f[1]-h*0.005:.1f} L{f[0]+face*h*0.07:.1f},{f[1]+h*0.018:.1f} L{f[0]-h*0.03:.1f},{f[1]+h*0.018:.1f} Z" fill="{col}"/>')
    if outfit not in ("dress", "robe"):
        g += legs
    # torso
    wx = h * 0.07; nk = h * 0.028
    g.append(f'<path d="M{sh[0]-nk:.1f},{sh[1]-h*0.025:.1f} C{sh[0]-nk*2:.1f},{sh[1]-h*0.01:.1f} {Ls[0]+h*0.01:.1f},{Ls[1]-h*0.03:.1f} {Ls[0]-h*0.008:.1f},{Ls[1]+h*0.02:.1f} '
             f'C{Ls[0]-h*0.012:.1f},{Ls[1]+h*0.12:.1f} {hip[0]-wx:.1f},{hip[1]-h*0.12:.1f} {Lh[0]-h*0.03:.1f},{Lh[1]+h*0.03:.1f} L{Rh[0]+h*0.03:.1f},{Rh[1]+h*0.03:.1f} '
             f'C{hip[0]+wx:.1f},{hip[1]-h*0.12:.1f} {Rs[0]+h*0.012:.1f},{Rs[1]+h*0.12:.1f} {Rs[0]+h*0.008:.1f},{Rs[1]+h*0.02:.1f} '
             f'C{Rs[0]-h*0.01:.1f},{Rs[1]-h*0.03:.1f} {sh[0]+nk*2:.1f},{sh[1]-h*0.01:.1f} {sh[0]+nk:.1f},{sh[1]-h*0.025:.1f} Z" fill="{col}"/>')
    if outfit == "dress":
        g.append(f'<path d="M{hip[0]-h*0.08:.1f},{hip[1]-h*0.06:.1f} C{hip[0]-h*0.14:.1f},{y-h*0.2:.1f} {x-h*0.22:.1f},{y-h*0.05:.1f} {x-h*0.24:.1f},{y:.1f} Q{x},{y+h*0.03:.1f} {x+h*0.24:.1f},{y:.1f} C{x+h*0.22:.1f},{y-h*0.05:.1f} {hip[0]+h*0.14:.1f},{y-h*0.2:.1f} {hip[0]+h*0.08:.1f},{hip[1]-h*0.06:.1f} Z" fill="{col}"/>')
    if outfit == "robe":
        g.append(f'<path d="M{Ls[0]:.1f},{Ls[1]+h*0.02:.1f} L{Rs[0]:.1f},{Rs[1]+h*0.02:.1f} C{Rs[0]+h*0.05:.1f},{y-h*0.3:.1f} {x+h*0.2:.1f},{y-h*0.08:.1f} {x+h*0.21:.1f},{y:.1f} L{x-h*0.21:.1f},{y:.1f} C{x-h*0.2:.1f},{y-h*0.08:.1f} {Ls[0]-h*0.05:.1f},{y-h*0.3:.1f} {Ls[0]:.1f},{Ls[1]+h*0.02:.1f} Z" fill="{col}"/>')
    if outfit == "coat":
        g.append(f'<path d="M{Ls[0]:.1f},{Ls[1]+h*0.03:.1f} L{Rs[0]:.1f},{Rs[1]+h*0.03:.1f} L{x+h*0.14:.1f},{y-h*0.28:.1f} L{x-h*0.14:.1f},{y-h*0.28:.1f} Z" fill="{col}"/>')
    # arms
    for spt, (a1, a2) in ((Ls, la), (Rs, ra)):
        e = P(spt, h * 0.165, a1); hd = P(e, h * 0.155, a2)
        g.append(_seg(spt, e, h * 0.055, h * 0.045, col) + _seg(e, hd, h * 0.045, h * 0.035, col) + f'<ellipse cx="{hd[0]:.1f}" cy="{hd[1]:.1f}" rx="{h*0.026:.1f}" ry="{h*0.032:.1f}" fill="{col}"/>')
    if outfit == "poncho":
        g.append(f'<path d="M{sh[0]-h*0.04:.1f},{sh[1]-h*0.02:.1f} L{sh[0]+h*0.04:.1f},{sh[1]-h*0.02:.1f} L{sh[0]+h*0.2:.1f},{hip[1]+h*0.02:.1f} Q{sh[0]:.1f},{hip[1]+h*0.07:.1f} {sh[0]-h*0.2:.1f},{hip[1]+h*0.02:.1f} Z" fill="{col}"/>')
        g.append("".join(f'<line x1="{sh[0]-h*0.19+k*h*0.038:.1f}" y1="{hip[1]+h*0.02+ (h*0.05 if 3<=k<=7 else h*0.02):.1f}" x2="{sh[0]-h*0.19+k*h*0.038:.1f}" y2="{hip[1]+h*0.05+(h*0.05 if 3<=k<=7 else h*0.02):.1f}" stroke="{col}" stroke-width="{h*0.008:.1f}"/>' for k in range(11)))
    # neck + head
    hr = h * 0.062; hcx, hcy = sh[0] + face * h * 0.008, sh[1] - h * 0.095
    g.append(f'<path d="M{sh[0]-h*0.025:.1f},{sh[1]+h*0.01:.1f} L{sh[0]-h*0.022:.1f},{hcy+hr*0.6:.1f} L{sh[0]+h*0.022:.1f},{hcy+hr*0.6:.1f} L{sh[0]+h*0.025:.1f},{sh[1]+h*0.01:.1f} Z" fill="{col}"/>')
    g.append(f'<ellipse cx="{hcx:.1f}" cy="{hcy:.1f}" rx="{hr*0.92:.1f}" ry="{hr:.1f}" fill="{col}"/>')
    g.append(f'<path d="M{hcx+face*hr*0.7:.1f},{hcy-hr*0.2:.1f} L{hcx+face*hr*1.12:.1f},{hcy+hr*0.18:.1f} L{hcx+face*hr*0.8:.1f},{hcy+hr*0.3:.1f} Q{hcx+face*hr*0.7:.1f},{hcy+hr*0.9:.1f} {hcx:.1f},{hcy+hr:.1f} Z" fill="{col}"/>')
    if beard:
        g.append(f'<path d="M{hcx-face*hr*0.3:.1f},{hcy+hr*0.3:.1f} Q{hcx+face*hr*0.6:.1f},{hcy+hr*0.5:.1f} {hcx+face*hr*0.85:.1f},{hcy+hr*0.35:.1f} Q{hcx+face*hr*0.6:.1f},{hcy+hr*1.9:.1f} {hcx:.1f},{hcy+hr*1.7:.1f} Z" fill="{col}"/>')
    t = hcy - hr * 0.55
    if hat == "brim":
        g.append(f'<path d="M{hcx-hr*2.5:.1f},{t+hr*0.3:.1f} Q{hcx:.1f},{t-hr*0.25:.1f} {hcx+hr*2.5:.1f},{t+hr*0.3:.1f} Q{hcx:.1f},{t+hr*0.6:.1f} {hcx-hr*2.5:.1f},{t+hr*0.3:.1f} Z" fill="{col}"/>'
                 f'<path d="M{hcx-hr*1.05:.1f},{t+hr*0.2:.1f} C{hcx-hr*1.1:.1f},{t-hr*1.3:.1f} {hcx+hr*1.1:.1f},{t-hr*1.3:.1f} {hcx+hr*1.05:.1f},{t+hr*0.2:.1f} Z" fill="{col}"/>')
    elif hat == "kepi":
        g.append(f'<path d="M{hcx-hr*0.98:.1f},{t+hr*0.45:.1f} L{hcx-hr*0.9:.1f},{t-hr*0.7:.1f} Q{hcx:.1f},{t-hr*0.95:.1f} {hcx+hr*0.95:.1f},{t-hr*0.55:.1f} L{hcx+hr*1.0:.1f},{t+hr*0.45:.1f} Z" fill="{col}"/>'
                 f'<path d="M{hcx+face*hr*0.5:.1f},{t+hr*0.35:.1f} Q{hcx+face*hr*1.3:.1f},{t+hr*0.4:.1f} {hcx+face*hr*1.8:.1f},{t+hr*0.75:.1f} L{hcx+face*hr*0.5:.1f},{t+hr*0.62:.1f} Z" fill="{col}"/>')
    elif hat == "cocar":
        for k in range(9):
            a = math.radians(-160 + k * 17.5); L2 = hr * 2.1
            ex, ey = hcx + L2 * math.cos(a), t + hr * 0.3 + L2 * math.sin(a)
            g.append(f'<path d="M{hcx:.1f},{t+hr*0.4:.1f} L{ex-hr*0.18:.1f},{ey:.1f} Q{ex:.1f},{ey-hr*0.3:.1f} {ex+hr*0.18:.1f},{ey:.1f} Z" fill="{col}"/>')
        g.append(f'<path d="M{hcx-hr*1.0:.1f},{t+hr*0.5:.1f} Q{hcx:.1f},{t+hr*0.1:.1f} {hcx+hr*1.0:.1f},{t+hr*0.5:.1f} L{hcx+hr*1.0:.1f},{t+hr*0.8:.1f} Q{hcx:.1f},{t+hr*0.4:.1f} {hcx-hr*1.0:.1f},{t+hr*0.8:.1f} Z" fill="{col}"/>')
    elif hat == "morion":
        g.append(f'<path d="M{hcx-hr*1.9:.1f},{t+hr*0.35:.1f} Q{hcx-hr*1.2:.1f},{t-hr*0.1:.1f} {hcx-hr*0.9:.1f},{t-hr*0.3:.1f} Q{hcx:.1f},{t-hr*1.9:.1f} {hcx+hr*0.9:.1f},{t-hr*0.3:.1f} Q{hcx+hr*1.2:.1f},{t-hr*0.1:.1f} {hcx+hr*1.9:.1f},{t+hr*0.35:.1f} Q{hcx:.1f},{t:.1f} {hcx-hr*1.9:.1f},{t+hr*0.35:.1f} Z" fill="{col}"/>'
                 f'<path d="M{hcx-hr*0.1:.1f},{t-hr*1.5:.1f} Q{hcx+hr*0.3:.1f},{t-hr*2.1:.1f} {hcx+hr*0.8:.1f},{t-hr*1.4:.1f} L{hcx+hr*0.6:.1f},{t-hr*0.9:.1f} Z" fill="{col}"/>')
    elif hat == "scarf":
        g.append(f'<path d="M{hcx-hr*1.05:.1f},{hcy+hr*0.4:.1f} C{hcx-hr*1.25:.1f},{t-hr*1.2:.1f} {hcx+hr*1.1:.1f},{t-hr*1.2:.1f} {hcx+hr*0.9:.1f},{hcy-hr*0.1:.1f} L{hcx-face*hr*1.6:.1f},{hcy+hr*1.6:.1f} Z" fill="{col}"/>')
    elif hat == "hair":
        g.append(f'<path d="M{hcx-hr*1.0:.1f},{hcy+hr*0.2:.1f} C{hcx-hr*1.2:.1f},{t-hr*1.0:.1f} {hcx+hr*1.1:.1f},{t-hr*1.0:.1f} {hcx+hr*0.8:.1f},{hcy-hr*0.2:.1f} Z" fill="{col}"/><path d="M{hcx-face*hr*0.8:.1f},{hcy:.1f} C{hcx-face*hr*1.6:.1f},{hcy+hr*1.2:.1f} {hcx-face*hr*1.8:.1f},{hcy+hr*2.4:.1f} {hcx-face*hr*2.4:.1f},{hcy+hr*3.0:.1f} C{hcx-face*hr*1.2:.1f},{hcy+hr*2.2:.1f} {hcx-face*hr*0.6:.1f},{hcy+hr*1.4:.1f} {hcx-face*hr*0.2:.1f},{hcy+hr*0.6:.1f} Z" fill="{col}"/>')
    # props
    if prop:
        kind = prop[0]
        if kind == "rifle":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1]); ang = prop[1] if len(prop) > 1 else -60
            tip = P(hand, h * 0.55, ang); butt = P(hand, -h * 0.18, ang)
            g.append(f'<line x1="{butt[0]:.1f}" y1="{butt[1]:.1f}" x2="{tip[0]:.1f}" y2="{tip[1]:.1f}" stroke="{col}" stroke-width="{h*0.018:.1f}" stroke-linecap="round"/>' + _seg(butt, P(butt, h * 0.12, ang), h * 0.04, h * 0.022, col))
            if len(prop) > 2 and prop[2]:
                bt = P(tip, h * 0.1, ang); g.append(f'<line x1="{tip[0]:.1f}" y1="{tip[1]:.1f}" x2="{bt[0]:.1f}" y2="{bt[1]:.1f}" stroke="{col}" stroke-width="{h*0.008:.1f}"/>')
        elif kind == "facao":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1]); ang = prop[1] if len(prop) > 1 else -60
            tip = P(hand, h * 0.3, ang); mid = P(hand, h * 0.16, ang + 8)
            g.append(f'<path d="M{hand[0]:.1f},{hand[1]:.1f} Q{mid[0]:.1f},{mid[1]:.1f} {tip[0]:.1f},{tip[1]:.1f} L{P(tip,-h*0.05,ang+30)[0]:.1f},{P(tip,-h*0.05,ang+30)[1]:.1f} Z" fill="{col}" stroke="{col}" stroke-width="{h*0.02:.1f}"/>')
        elif kind == "staff":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1])
            g.append(f'<line x1="{hand[0]:.1f}" y1="{hand[1]-h*0.25:.1f}" x2="{hand[0]+h*0.03:.1f}" y2="{y:.1f}" stroke="{col}" stroke-width="{h*0.018:.1f}" stroke-linecap="round"/>')
        elif kind == "flag":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1]); fc, cc = prop[1], prop[2]
            top = (hand[0] + h * 0.05, hand[1] - h * 0.75)
            g.append(f'<line x1="{hand[0]:.1f}" y1="{hand[1]+h*0.3:.1f}" x2="{top[0]:.1f}" y2="{top[1]:.1f}" stroke="{col}" stroke-width="{h*0.014:.1f}" stroke-linecap="round"/>')
            fx, fy, fw, fh = top[0], top[1], h * 0.42, h * 0.26
            g.append(f'<path d="M{fx:.1f},{fy:.1f} C{fx+fw*0.3:.1f},{fy-fh*0.25:.1f} {fx+fw*0.6:.1f},{fy+fh*0.2:.1f} {fx+fw:.1f},{fy:.1f} L{fx+fw*0.95:.1f},{fy+fh:.1f} C{fx+fw*0.6:.1f},{fy+fh*1.2:.1f} {fx+fw*0.3:.1f},{fy+fh*0.75:.1f} {fx:.1f},{fy+fh:.1f} Z" fill="{fc}"/>')
            cx, cy = fx + fw * 0.5, fy + fh * 0.5
            g.append(f'<rect x="{cx-fw*0.05:.1f}" y="{cy-fh*0.35:.1f}" width="{fw*0.1:.1f}" height="{fh*0.7:.1f}" fill="{cc}"/><rect x="{cx-fw*0.2:.1f}" y="{cy-fh*0.08:.1f}" width="{fw*0.4:.1f}" height="{fh*0.16:.1f}" fill="{cc}"/>')
        elif kind == "herbs":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1]); c2 = prop[1]
            g.append("".join(f'<ellipse cx="{hand[0]+math.cos(a)*h*0.05:.1f}" cy="{hand[1]-h*0.03+math.sin(a)*h*0.03:.1f}" rx="{h*0.022:.1f}" ry="{h*0.01:.1f}" fill="{c2}" transform="rotate({math.degrees(a):.0f} {hand[0]+math.cos(a)*h*0.05:.1f} {hand[1]-h*0.03+math.sin(a)*h*0.03:.1f})"/>' for a in [-2.6, -2.0, -1.4, -0.9, -0.3]))
        elif kind == "bundle":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1])
            g.append(f'<ellipse cx="{hand[0]:.1f}" cy="{hand[1]-h*0.06:.1f}" rx="{h*0.11:.1f}" ry="{h*0.08:.1f}" fill="{col}"/>')
        elif kind == "hammer":
            hand = P(P(Rs, h * 0.165, ra[0]), h * 0.155, ra[1]); ang = prop[1]
            tip = P(hand, h * 0.2, ang)
            g.append(f'<line x1="{hand[0]:.1f}" y1="{hand[1]:.1f}" x2="{tip[0]:.1f}" y2="{tip[1]:.1f}" stroke="{col}" stroke-width="{h*0.014:.1f}"/>' + _seg(P(tip, h * 0.05, ang + 90), P(tip, h * 0.05, ang - 90), h * 0.035, h * 0.035, col))
    return "".join(g)

# ---------------- props & buildings ----------------
def locomotive(x, y, s, col, lamp=None, face=1):
    g = [f'<g transform="translate({x},{y}) scale({s*face},{s})">']
    g.append(f'<rect x="-40" y="-190" width="420" height="150" rx="60" fill="{col}"/>')
    g.append(f'<rect x="-230" y="-300" width="210" height="260" rx="10" fill="{col}"/><rect x="-250" y="-320" width="250" height="34" rx="8" fill="{col}"/>')
    g.append(f'<path d="M260,-190 L250,-330 L330,-330 L310,-190 Z" fill="{col}"/><rect x="238" y="-350" width="104" height="30" rx="8" fill="{col}"/>')
    g.append(f'<path d="M110,-190 Q110,-250 150,-250 Q190,-250 190,-190 Z" fill="{col}"/>')
    g.append(f'<path d="M380,-40 L470,20 L380,20 Z" fill="{col}"/><rect x="-250" y="-40" width="640" height="40" fill="{col}"/>')
    for cx, r in ((-150, 85), (40, 85), (230, 85)):
        g.append(f'<circle cx="{cx}" cy="10" r="{r}" fill="none" stroke="{col}" stroke-width="18"/><circle cx="{cx}" cy="10" r="16" fill="{col}"/>' + "".join(f'<line x1="{cx}" y1="10" x2="{cx+r*math.cos(k*math.pi/6):.0f}" y2="{10+r*math.sin(k*math.pi/6):.0f}" stroke="{col}" stroke-width="7"/>' for k in range(12)))
    g.append(f'<rect x="-160" y="0" width="400" height="16" rx="8" fill="{col}"/>')
    g.append(f'<rect x="355" y="-170" width="46" height="46" rx="10" fill="{lamp or col}"/>')
    g.append('</g>')
    return "".join(g)

def railcar_logs(x, y, s, col, wood="#8A5E3A", ring="#C79A62"):
    g = [f'<g transform="translate({x},{y}) scale({s})"><rect x="0" y="-40" width="420" height="40" fill="{col}"/>']
    for c in (70, 350): g.append(f'<circle cx="{c}" cy="10" r="36" fill="{col}"/>')
    for r2 in range(3):
        for k in range(8 - r2):
            cx = 40 + k * 50 + r2 * 25; cy = -65 - r2 * 44
            g.append(f'<circle cx="{cx}" cy="{cy}" r="24" fill="{wood}" stroke="{col}" stroke-width="4"/><circle cx="{cx}" cy="{cy}" r="10" fill="none" stroke="{ring}" stroke-width="3"/>')
    g.append(f'<rect x="-6" y="-190" width="12" height="160" fill="{col}"/><rect x="414" y="-190" width="12" height="160" fill="{col}"/></g>')
    return "".join(g)

def rails(vx, vy, y_bottom, col, tie="#3A2A1C", width=900, n=26):
    g = []
    for k in range(n):
        t = (k / n) ** 1.8; yy = lerp(vy, y_bottom, t); w = lerp(20, width, t)
        g.append(f'<rect x="{vx - w*0.62:.0f}" y="{yy:.0f}" width="{w*1.24:.0f}" height="{max(2, 22*t):.0f}" fill="{tie}"/>')
    g.append(f'<path d="M{vx-6},{vy} L{vx-width*0.5},{y_bottom} L{vx-width*0.5+22},{y_bottom} L{vx-3},{vy} Z" fill="{col}"/>')
    g.append(f'<path d="M{vx+6},{vy} L{vx+width*0.5},{y_bottom} L{vx+width*0.5-22},{y_bottom} L{vx+3},{vy} Z" fill="{col}"/>')
    return "".join(g)

def cabin(x, y, s, col, win=None, smoke=False):
    g = f'<g transform="translate({x},{y}) scale({s})"><rect x="-150" y="-170" width="300" height="170" fill="{col}"/>'
    g += "".join(f'<line x1="-150" y1="{-170+k*24}" x2="150" y2="{-170+k*24}" stroke="{mix(col,"#000000",0.25)}" stroke-width="3"/>' for k in range(1, 7))
    g += f'<path d="M-185,-165 L0,-300 L185,-165 Z" fill="{mix(col,"#000000",0.2)}"/><rect x="70" y="-290" width="34" height="90" fill="{col}"/>'
    g += f'<rect x="-40" y="-110" width="70" height="110" fill="{win or mix(col,"#000000",0.5)}"/><rect x="-120" y="-130" width="54" height="46" fill="{win or mix(col,"#000000",0.5)}"/>'
    return g + '</g>'

def palisade(y, col, x0=X0, x1=X1, h=160, seed=1):
    r = random.Random(seed)
    return "".join(f'<path d="M{x},{y} L{x},{y-h*r.uniform(0.85,1.1):.0f} L{x+13},{y-h*r.uniform(1.1,1.25):.0f} L{x+26},{y-h*r.uniform(0.85,1.1):.0f} L{x+26},{y} Z" fill="{col}"/>' for x in range(int(x0), int(x1), 28))

def cross(x, y, s, col):
    return f'<rect x="{x-5*s:.0f}" y="{y-120*s:.0f}" width="{10*s:.0f}" height="{120*s:.0f}" fill="{col}"/><rect x="{x-38*s:.0f}" y="{y-92*s:.0f}" width="{76*s:.0f}" height="{10*s:.0f}" fill="{col}"/>'

def biplane(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-160,0 C-120,-20 120,-26 180,-8 L200,6 C140,18 -110,20 -160,10 Z" fill="{col}"/>'
            f'<path d="M-150,-4 L-190,-60 L-160,-60 L-120,-6 Z" fill="{col}"/><rect x="-80" y="-80" width="200" height="12" rx="6" fill="{col}"/><rect x="-90" y="10" width="220" height="12" rx="6" fill="{col}"/>'
            f'<line x1="-40" y1="-70" x2="-40" y2="12" stroke="{col}" stroke-width="5"/><line x1="80" y1="-70" x2="80" y2="12" stroke="{col}" stroke-width="5"/><line x1="-40" y1="-70" x2="80" y2="12" stroke="{col}" stroke-width="2"/>'
            f'<circle cx="202" cy="0" r="8" fill="{col}"/><ellipse cx="206" cy="0" rx="6" ry="60" fill="{col}" opacity=".35"/><path d="M20,26 L0,60 M60,26 L80,60" stroke="{col}" stroke-width="5"/><circle cx="0" cy="62" r="10" fill="{col}"/><circle cx="80" cy="62" r="10" fill="{col}"/></g>')

def smoke_puffs(x, y, col, n=8, s=1.0, seed=1, drift=-1):
    r = random.Random(seed)
    return f'<g filter="url(#blur14)">' + "".join(f'<circle cx="{x + drift*k*55*s + r.uniform(-30,30)*s:.0f}" cy="{y - k*95*s:.0f}" r="{(50 + k*28)*s:.0f}" fill="{col}" opacity="{max(0.12, 0.8 - k*0.08):.2f}"/>' for k in range(n)) + '</g>'

def fire(x, y, w, h, seed=1):
    r = random.Random(seed); g = []
    for k in range(int(w / 40)):
        xx = x + k * 40 + r.uniform(-10, 10); hh = h * r.uniform(0.5, 1.0)
        for c, sc in (("#B8321A", 1.0), ("#FF7A2E", 0.75), ("#FFD27A", 0.45)):
            g.append(f'<path d="M{xx-24*sc:.0f},{y} C{xx-30*sc:.0f},{y-hh*0.4*sc:.0f} {xx-5:.0f},{y-hh*0.7*sc:.0f} {xx:.0f},{y-hh*sc:.0f} C{xx+5:.0f},{y-hh*0.7*sc:.0f} {xx+30*sc:.0f},{y-hh*0.4*sc:.0f} {xx+24*sc:.0f},{y} Z" fill="{c}"/>')
    return "".join(g)
