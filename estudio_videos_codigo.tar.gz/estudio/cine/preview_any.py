"""Renderiza as camadas de todas as cenas de um módulo e gera uma folha de contato. Uso: python3 preview_any.py scenes_epN layers_epN"""
import sys, os, importlib, numpy as np, cv2
mod, ld = sys.argv[1], sys.argv[2]
SC = importlib.import_module(mod).SC; ids = sorted(SC)
os.makedirs(f"prev_{mod}", exist_ok=True)
from cine import render_layers, Particles
from cine2 import Scene, compose, post
render_layers(SC, ids, ld)
tiles = []
for n in ids:
    sc = Scene(n, SC[n](), ld); img = post(compose(sc, 0.6, 6.0), 3.0, Particles(sc.sc.get("particles"), n), 10)
    tiles.append(cv2.resize(img, (240, 427)))
while len(tiles) % 6: tiles.append(np.zeros_like(tiles[0]))
cv2.imwrite(f"prev_{mod}/sheet.jpg", cv2.cvtColor(np.vstack([np.hstack(tiles[i:i+6]) for i in range(0, len(tiles), 6)]), cv2.COLOR_RGB2BGR))
