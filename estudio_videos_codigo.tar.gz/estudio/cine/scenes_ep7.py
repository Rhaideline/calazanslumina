from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep2 import jtree, palm, jungle
from scenes_ep4 import nau, sea, batel
from scenes_ep5 import (map_base, parchment, stamp, label, pj, RED, GOLD, INKB, waves, lightning)
from scenes_ep6 import taipa_wall, church
import random, math

def sugarloaf(x, y, w, h, col):
    return (f'<path d="M{x-w/2:.0f},{y:.0f} C{x-w/2:.0f},{y-h*0.55:.0f} {x-w*0.34:.0f},{y-h*0.98:.0f} {x-w*0.04:.0f},{y-h:.0f} '
            f'C{x+w*0.3:.0f},{y-h*1.0:.0f} {x+w*0.5:.0f},{y-h*0.5:.0f} {x+w/2:.0f},{y:.0f} Z" fill="{col}"/>')

def hills(y, col, seed, n=7, hmin=160, hmax=380):
    r = random.Random(seed); g = []
    for k in range(n):
        x = -60 + k * 1250 / n + r.uniform(-60, 60); w = r.uniform(380, 640); h = r.uniform(hmin, hmax)
        g.append(f'<path d="M{x-w/2:.0f},{y:.0f} Q{x-w*0.15:.0f},{y-h*1.1:.0f} {x:.0f},{y-h:.0f} Q{x+w*0.2:.0f},{y-h*0.9:.0f} {x+w/2:.0f},{y:.0f} Z" fill="{col}"/>')
    return "".join(g) + f'<rect x="{X0}" y="{y-2}" width="{BW}" height="900" fill="{col}"/>'

def isle(x, y, w, h, col):
    return f'<path d="M{x-w/2:.0f},{y:.0f} Q{x-w*0.3:.0f},{y-h:.0f} {x:.0f},{y-h*0.9:.0f} Q{x+w*0.3:.0f},{y-h:.0f} {x+w/2:.0f},{y:.0f} Z" fill="{col}"/>'

def fort(x, y, s, col, flag=True):
    g = f'<g transform="translate({x},{y}) scale({s})"><rect x="-260" y="-130" width="520" height="130" fill="{col}"/>'
    g += "".join(f'<rect x="{k}" y="-170" width="46" height="42" fill="{col}"/>' for k in range(-260, 260, 84))
    g += f'<rect x="-60" y="-300" width="120" height="180" fill="{col}"/><path d="M-76,-300 L0,-370 L76,-300 Z" fill="{col}"/>'
    if flag: g += fr_flag(0, -370, 1.0)
    return g + '</g>'

def fr_flag(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><line x1="0" y1="0" x2="0" y2="-170" stroke="#2A1A10" stroke-width="7"/>'
            f'<path d="M0,-170 C40,-190 80,-150 120,-170 L120,-100 C80,-80 40,-120 0,-100 Z" fill="#F4F0E4" stroke="#2A1A10" stroke-width="4"/>'
            f'<circle cx="60" cy="-136" r="14" fill="#2A4A9A"/></g>')

def pt_flag(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><line x1="0" y1="0" x2="0" y2="-170" stroke="#2A1A10" stroke-width="7"/>'
            f'<path d="M0,-170 C40,-190 80,-150 120,-170 L120,-100 C80,-80 40,-120 0,-100 Z" fill="#F4F0E4" stroke="#2A1A10" stroke-width="4"/>'
            f'<rect x="54" y="-148" width="12" height="40" fill="{RED}"/><rect x="40" y="-136" width="40" height="12" fill="{RED}"/></g>')

def arrow(x, y, ang, L_=300, col="#1A100A"):
    a = math.radians(ang); x2 = x + L_ * math.cos(a); y2 = y + L_ * math.sin(a)
    return (f'<line x1="{x:.0f}" y1="{y:.0f}" x2="{x2:.0f}" y2="{y2:.0f}" stroke="{col}" stroke-width="8" stroke-linecap="round"/>'
            f'<path d="M{x2:.0f},{y2:.0f} l{-34*math.cos(a-0.4):.0f},{-34*math.sin(a-0.4):.0f} l{34*math.cos(a-0.4)-34*math.cos(a+0.4):.0f},{34*math.sin(a-0.4)-34*math.sin(a+0.4):.0f} Z" fill="{col}"/>'
            f'<path d="M{x:.0f},{y:.0f} l{50*math.cos(a+2.6):.0f},{50*math.sin(a+2.6):.0f} M{x:.0f},{y:.0f} l{50*math.cos(a-2.6):.0f},{50*math.sin(a-2.6):.0f}" stroke="{col}" stroke-width="6"/>')

def villeg(x, y, h, face=1, col="#0E0806"):
    return person(x, y, h, col, "coat", "brim", la=(100, 92), ra=(-40, -70), face=face, beard=True, prop=("staff",))

def bubble(x, y, t, col=RED):
    return f'<g transform="translate({x},{y})"><path d="M-120,-70 L120,-70 Q150,-70 150,-40 L150,40 Q150,70 120,70 L20,70 L-10,120 L-20,70 L-120,70 Q-150,70 -150,40 L-150,-40 Q-150,-70 -120,-70 Z" fill="#FFF8E8" stroke="#1A0E08" stroke-width="7"/><text x="0" y="34" font-family="Anton" font-size="96" text-anchor="middle" fill="{col}">{t}</text></g>'

S = {}
def bay_dusk(cam, seed, fl=True):
    return dict(light="#FF9A50", rim_dx=4, cam=cam, particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.5, "#4A1A14"), (1, "#C8582A")]) + sun(700, 1250, 120, halo_r=900, halo="#FF8A40") + godrays(700, 1250, "#FFB070", n=12, spread=150, a0=-90, op=.2, seed=seed), ),
                L(0.12, Rr(sugarloaf(220, 1380, 520, 560, "#2A0E10") + hills(1380, "#1E0A0C", seed, 6, 120, 260))),
                L(0.25, sea(1380, "#6A2A24", "#1A0A0C", "#FFB070")),
                L(0.4, R(isle(760, 1520, 520, 120, "#0A0405") + fort(760, 1470, 0.9, "#0A0405", fl))),
                L(0.9, R("".join(person(x, 2010, h, "#050203", "shirt", "morion", la=(100, 92), ra=(-30, -60), face=f_, prop=("rifle", -80)) for x, h, f_ in ((70, 800, 1), (1010, 760, -1)))) + ground(1990, "#0A0404", "#030102", 6, 2))])
S[1] = lambda: bay_dusk((1.0, 1.12, (0, 30), (0, -20)), 71)

def s2():
    fleet = "".join(R(nau(x, y, s, mix("#1A1418", "#6A6A74", 1 - s * 1.5), sails="#EFE2C8", cross=False)) for x, y, s in [(860, 1260, .2), (700, 1280, .28), (950, 1320, .34), (500, 1380, .5)])
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A6AA0"), (0.55, "#F4D0A0"), (1, "#F8B878")]) + sun(300, 1050, 90, halo_r=800)),
                L(0.05, godrays(300, 1050, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=72), mode="screen"),
                L(0.12, Rr(sugarloaf(820, 1240, 460, 520, "#6A7A78") + hills(1240, "#5A6A68", 72, 6, 120, 260))),
                L(0.2, sea(1230, "#B8B0B0", "#5A6878", "#FFF0D8")),
                L(0.4, fleet, drift=(-50, 0)),
                L(0.85, R(villeg(190, 1960, 760, 1)) + sea(1850, "#3A4858", "#141C28", "#FFF0D0", 8)),
                L(0.86, label(700, 560, "1555", 200, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False)])
S[2] = s2

def s3():
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A7AB0"), (0.6, "#F4D8A8"), (1, "#F8C890")]) + sun(220, 1000, 90, halo_r=800)),
                L(0.12, Rr(hills(1300, "#5A7A68", 73, 6, 140, 300))),
                L(0.25, sea(1300, "#B8C8C0", "#5A7888", "#FFF0D8")),
                L(0.45, R(isle(540, 1560, 900, 180, "#2A1E14") + fort(540, 1500, 1.25, "#2A1E14", True))),
                L(0.7, sea(1760, "#3A5868", "#142430", "#FFF0D0", 8)),
                L(0.8, label(540, 520, "FORTE COLIGNY", 108, "#1A0E08", "Anton"), reveal=(1.2, 0.3, "center"), rough=False)])
S[3] = s3

def s4():
    fr = person(250, 1960, 760, "#0E0806", "coat", "brim", la=(100, 92), ra=(120, 100), face=1, beard=True)
    tp = person(830, 1960, 800, "#0E0806", "shirt", "cocar", la=(100, 92), ra=(60, 80), face=-1)
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A2A48"), (0.5, "#D8805A"), (1, "#F0A860")]) + sun(540, 1250, 110, halo_r=900)),
                L(0.05, godrays(540, 1250, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=74), mode="screen"),
                L(0.25, R(jungle(1420, "#5A3A40", 12, 220, 340, 74, 4)) + f'<rect x="{X0}" y="1410" width="{BW}" height="800" fill="#4A2A28"/>'),
                L(0.8, R(fr + tp) + ground(1940, "#2A1814", "#140A08", 6, 1)),
                L(0.82, label(540, 560, "FRANCESES + TUPINAMBÁ", 62, "#FFF4E0", "Anton"), reveal=(2.2, 0.3, "center"), rough=False)])
S[4] = s4

def s5():
    base = parchment() + map_base()
    p0, p1 = pj(-46.0, -23.9), pj(-42.0, -22.9)
    coast = f'<path d="M{p0[0]:.0f},{p0[1]:.0f} L{pj(-45.0,-23.6)[0]:.0f},{pj(-45.0,-23.6)[1]:.0f} L{pj(-43.2,-23.0)[0]:.0f},{pj(-43.2,-23.0)[1]:.0f} L{p1[0]:.0f},{p1[1]:.0f}" stroke="{RED}" stroke-width="34" fill="none" stroke-linecap="round"/>'
    dots = f'<circle cx="{p0[0]:.0f}" cy="{p0[1]:.0f}" r="26" fill="{INKB}"/><circle cx="{p1[0]:.0f}" cy="{p1[1]:.0f}" r="26" fill="{INKB}"/>'
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, base, rough=False),
                L(0.05, coast, reveal=(0.8, 2.6, "ltr"), rough=False), L(0.06, dots, reveal=(0.8, 0.3, "center"), rough=False),
                L(0.1, label(540, 300, "CONFEDERAÇÃO DOS TAMOIOS", 40, RED, "Anton"), rough=False),
                L(0.11, label(p0[0] - 50, p0[1] + 90, "BERTIOGA", 44, INKB, "Anton", "end"), rough=False),
                L(0.11, label(p1[0] + 50, p1[1] + 90, "CABO FRIO", 44, INKB, "Anton", "start"), rough=False)])
S[5] = s5

def book(x, y, s, col="#3A2214", pg="#F2EAD8"):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-170,-120 L0,-90 L170,-120 L170,100 L0,130 L-170,100 Z" fill="{col}"/><path d="M-150,-100 L0,-72 L0,112 L-150,84 Z" fill="{pg}"/><path d="M150,-100 L0,-72 L0,112 L150,84 Z" fill="{pg}"/>'
            + "".join(f'<line x1="{-120}" y1="{-70+k*28}" x2="{-30}" y2="{-52+k*28}" stroke="#9A8A70" stroke-width="5"/><line x1="{120}" y1="{-70+k*28}" x2="{30}" y2="{-52+k*28}" stroke="#9A8A70" stroke-width="5"/>' for k in range(5)) + '</g>')

def s6():
    return dict(light="#B8C8E0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="ash",
        layers=[L(0.0, sky([(0, "#06080E"), (0.6, "#1E2838"), (1, "#3A4658")]) + glow(760, 600, 600, "#8AA0C8", .3)),
                L(0.2, waves(1250, "#2A3448", 70, 76)),
                L(0.35, R(nau(800, 1300, 0.5, "#05060A", sails="#8A90A0", cross=False)), drift=(-30, 0)),
                L(0.55, R(batel(380, 1500, 0.9, "#05060A", 2)), drift=(40, 0)),
                L(0.7, waves(1600, "#141A28", 120, 77)),
                L(0.95, waves(1850, "#0A0E16", 100, 78)),
                L(0.9, label(540, 560, "HANS STADEN", 120, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.91, label(540, 690, "O LIVRO · 1557", 64, GOLD, "Anton"), reveal=(3.0, 0.3, "center"), rough=False)])
S[6] = s6

def s7():
    k1 = villeg(300, 1730, 780, 1, "#0A0406")
    cal = person(790, 1730, 740, "#0A0406", "coat", "brim", la=(100, 92), ra=(-150, -170), face=-1, beard=True)
    return dict(light="#FFC070", rim_dx=5, cam=(1.0, 1.12, (0, 10), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1A1A"), (0.6, "#6A3A2A"), (1, "#C8784A")]) + glow(540, 1300, 800, "#FFB070", .4)),
                L(0.3, R(f'<rect x="{X0}" y="1760" width="{BW}" height="400" fill="#1A0E0A"/>' + fort(540, 1200, 1.4, "#2A1A14", False))),
                L(0.5, R(k1 + cal)),
                L(0.52, bubble(400, 520, "!!"), reveal=(3.2, 0.15, "center"), rough=False),
                L(0.53, bubble(800, 580, "?!"), reveal=(3.8, 0.15, "center"), rough=False),
                L(0.6, label(540, 250, "1557 · CALVINISTAS", 66, "#FFF4E0", "Anton"), rough=False)])
S[7] = s7

def s8():
    table = (f'<rect x="170" y="1500" width="740" height="40" fill="#3A2214"/><rect x="230" y="1540" width="40" height="400" fill="#3A2214"/><rect x="810" y="1540" width="40" height="400" fill="#3A2214"/>'
             f'<ellipse cx="400" cy="1480" rx="110" ry="30" fill="#E8D8B0"/><path d="M640,1500 L660,1380 L700,1380 L720,1500 Z M620,1380 L740,1380 L720,1330 L640,1330 Z" fill="#D8B050"/>')
    a = person(110, 1960, 780, "#0A0406", "coat", "brim", la=(100, 92), ra=(-30, -60), face=1, beard=True)
    b = person(970, 1960, 760, "#0A0406", "coat", None, la=(100, 92), ra=(150, 170), face=-1, beard=True)
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.4, R(table)),
                L(0.8, R(a + b)),
                L(0.82, label(540, 560, "PÃO + VINHO = ?", 110, GOLD, "Anton"), reveal=(1.2, 0.3, "center"), rough=False),
                L(0.83, stamp(540, 960, "EXPULSOS", -8, 120), reveal=(5.0, 0.15, "center"), rough=False)])
S[8] = s8

def s9():
    desk = (f'<rect x="120" y="1500" width="840" height="60" fill="#3A2214"/><rect x="170" y="1560" width="50" height="480" fill="#3A2214"/><rect x="860" y="1560" width="50" height="480" fill="#3A2214"/>'
            + book(540, 1440, 1.0) + f'<rect x="780" y="1360" width="20" height="140" fill="#E8D8B0"/>')
    man = person(260, 1970, 880, "#0A0406", "coat", None, la=(100, 92), ra=(60, 40), face=1, beard=True)
    return dict(light="#FFC070", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.15, glow(790, 1300, 500, "#FFB050", .6), mode="screen", flicker=0.3),
                L(0.6, R(desk + man)),
                L(0.8, label(540, 520, "JEAN DE LÉRY", 120, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.81, label(540, 650, "GENEBRA · 1578", 64, GOLD, "Anton"), reveal=(2.4, 0.3, "center"), rough=False)])
S[9] = s9

def s10():
    fleet = "".join(R(nau(x, y, s, "#0A0608", sails="#C8C0B8", cross=True)) for x, y, s in [(860, 1380, .32), (620, 1420, .42), (330, 1500, .55)])
    return dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, 30)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.6, "#3A1010"), (1, "#8A3A14")]) + glow(300, 1400, 800, "#FF6A20", .45)),
                L(0.15, Rr(sugarloaf(900, 1330, 420, 480, "#1E0A0C") + hills(1330, "#160808", 79, 6, 120, 240))),
                L(0.25, sea(1330, "#6A2A24", "#1A0A0C", "#FFB070")),
                L(0.4, R(isle(260, 1500, 560, 130, "#0A0405") + fort(260, 1450, 1.0, "#0A0405", False))),
                L(0.45, fire(250, 1330, 150, 260, 5), flicker=0.25, rough=False),
                L(0.46, glow(260, 1300, 520, "#FFA050", .55), mode="screen", flicker=0.2),
                L(0.5, smoke_puffs(260, 1100, "#5A4A44", n=9, s=1.4, seed=10, drift=1), drift=(40, -90)),
                L(0.6, fleet, drift=(-40, 0)),
                L(0.9, label(540, 560, "MEM DE SÁ · MAR/1560", 60, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False)])
S[10] = s10

def s11():
    run = "".join(person(x, 1960 + (k % 2) * 20, h, "#060404", "shirt", c_, la=(-60, -100), ra=(-100, -80), face=1, prop=("rifle", -20) if c_ == "morion" else None) for k, (x, h, c_) in enumerate([(130, 700, "cocar"), (330, 660, "morion"), (540, 720, "cocar"), (760, 640, "morion"), (960, 680, "cocar")]))
    return dict(light="#C8A890", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#1A1418"), (0.6, "#6A3A34"), (1, "#C8683A")]) + glow(200, 1200, 700, "#FF8A40", .4)),
                L(0.2, R(jungle(1350, "#2A2024", 12, 240, 380, 711, 4)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#2A2024"/>'),
                L(0.4, smoke_puffs(200, 1250, "#8A8080", n=10, s=1.3, seed=11, drift=1), drift=(60, -80)),
                L(0.85, R(run) + ground(1940, "#140E0E", "#060404", 6, 1)),
                L(0.9, label(540, 520, "A GUERRA CONTINUA", 76, "#FFF4E0", "Anton"), reveal=(2.0, 0.3, "center"), rough=False)])
S[11] = s11

def s12():
    est = person(230, 1960, 840, "#0E0806", "coat", "morion", la=(100, 92), ra=(-30, -60), face=1, prop=("flag", "#F4F0E4", RED))
    tents = "".join(f'<path d="M{x-70},1520 L{x},1420 L{x+70},1520 Z" fill="#1A120C"/>' for x in (680, 820, 960))
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A7AB0"), (0.55, "#F4D0A0"), (1, "#F8B878")]) + sun(300, 1050, 90, halo_r=800)),
                L(0.05, godrays(300, 1050, "#FFF0C8", n=14, spread=180, a0=-90, op=.24, seed=712), mode="screen"),
                L(0.12, Rr(sugarloaf(880, 1360, 520, 600, "#6A7A78") + hills(1360, "#5A6A68", 713, 6, 130, 280))),
                L(0.25, sea(1360, "#B8C8C0", "#5A7888", "#FFF0D8")),
                L(0.4, R(f'<path d="M{X0},1500 C300,1470 700,1490 {X1},1520 L{X1},{Y1} L{X0},{Y1} Z" fill="#B89868"/>' + tents)),
                L(0.85, R(est) + ground(1950, "#8A6A48", "#5A4028", 6, 1)),
                L(0.9, label(540, 330, "1º DE MARÇO DE 1565", 66, "#1A0E08", "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.91, label(540, 430, "SÃO SEBASTIÃO DO RIO DE JANEIRO", 38, "#1A0E08", "Anton"), reveal=(3.2, 0.3, "center"), rough=False)])
S[12] = s12

def s13():
    sol = "".join(person(x, 1960, h, "#060404", "shirt", "morion", la=(100, 92), ra=(-30, -60), face=1, prop=("rifle", -20)) for x, h in ((120, 700), (330, 660), (540, 620)))
    pal = f'<g>{palisade(1500, "#2A1A10", X0, X1, 200, 713)}</g>'
    return dict(light="#FFD090", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.55, "#E8A878"), (1, "#F0C088")]) + sun(840, 1100, 90, halo_r=700)),
                L(0.12, Rr(sugarloaf(780, 1400, 560, 640, "#8A7A70"))),
                L(0.3, R(pal)),
                L(0.85, R(sol) + ground(1940, "#2A1A10", "#140A06", 6, 1)),
                L(0.9, label(540, 520, "BASE DE GUERRA", 88, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False)])
S[13] = s13

def s14():
    men = "".join(person(x, 1960 + (k % 2) * 25, h, "#060404", "shirt", c_, la=(-60, -100), ra=(-100, -80), face=1 if x < 540 else -1, prop=("rifle", -30) if c_ == "morion" else ("staff",)) for k, (x, h, c_) in enumerate([(100, 700, "morion"), (300, 640, "cocar"), (500, 720, "morion"), (700, 660, "cocar"), (900, 700, "cocar")]))
    arrows = "".join(arrow(100 + k * 200, 500 + (k % 3) * 80, 70 + k * 6, 260) for k in range(5))
    return dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, 40)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.55, "#6A1A10"), (1, "#E8682A")]) + glow(540, 1200, 900, "#FFA050", .45)),
                L(0.15, Rr(hills(1400, "#3A0E0C", 714, 4, 300, 520))),
                L(0.4, smoke_puffs(540, 1200, "#5A4A44", n=10, s=1.5, seed=14, drift=1), drift=(0, -80)),
                L(0.5, arrows, drift=(30, 120), rough=False),
                L(0.85, R(men) + ground(1950, "#0A0404", "#030102", 6, 2)),
                L(0.9, label(540, 480, "20 DE JANEIRO DE 1567", 60, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.91, label(540, 590, "DIA DE SÃO SEBASTIÃO", 44, GOLD, "Anton"), reveal=(2.8, 0.3, "center"), rough=False)])
S[14] = s14

def s15():
    ar = person(540, 1980, 1000, "#080404", "shirt", "cocar", la=(100, 92), ra=(-50, -70), face=1, prop=("staff",))
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.14, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A2A48"), (0.5, "#D8805A"), (1, "#F0A860")]) + sun(540, 1100, 110, halo_r=900)),
                L(0.05, godrays(540, 1100, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=715), mode="screen"),
                L(0.25, R(jungle(1440, "#5A3A40", 12, 220, 340, 715, 4)) + f'<rect x="{X0}" y="1430" width="{BW}" height="800" fill="#4A2A28"/>'),
                L(0.8, R(ar) + ground(1960, "#2A1814", "#140A08", 6, 1)),
                L(0.82, label(540, 420, "ARARIBÓIA", 150, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.83, label(540, 540, "CHEFE TEMIMINÓ", 64, GOLD, "Anton"), reveal=(2.4, 0.3, "center"), rough=False)])
S[15] = s15

def s16():
    kn = person(480, 1900, 900, "#0E0806", "coat", "morion", la=(100, 92), ra=(-60, -80), face=1, kneel=True)
    return dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, 40)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.6, "#3A0E10"), (1, "#8A2A18")]) + glow(540, 1400, 800, "#FF6A20", .4)),
                L(0.2, R(jungle(1350, "#140608", 12, 300, 500, 716, 4)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#1A0A08"/>'),
                L(0.6, R(kn)),
                L(0.65, arrow(900, 640, 138.6, 545, "#F4E8D0"), reveal=(0.4, 0.25, "center"), rough=False),
                L(0.9, label(540, 340, "UMA FLECHA NO ROSTO", 64, "#FFF4E0", "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.91, label(540, 440, "MORREU UM MÊS DEPOIS", 44, GOLD, "Anton"), reveal=(2.6, 0.3, "center"), rough=False)])
S[16] = s16

def s17():
    town = (taipa_wall(1500, "#5A4A38", 60, 1020, 80) + church(300, 1440, 0.6, "#4A3A2A") + "".join(f'<g transform="translate({x},1440)"><rect x="-50" y="-80" width="100" height="80" fill="#5A4A3A"/><path d="M-60,-80 L0,-130 L60,-80 Z" fill="#7A3A20"/></g>' for x in (560, 760, 940)))
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.55, "#F0B080"), (1, "#F8C890")]) + sun(540, 1040, 100, halo_r=900)),
                L(0.05, godrays(540, 1040, "#FFF0C8", n=16, spread=190, a0=-90, op=.26, seed=717), mode="screen"),
                L(0.12, Rr(sugarloaf(860, 1400, 560, 600, "#8A6A60") + hills(1400, "#7A5A54", 717, 6, 130, 280))),
                L(0.3, R(town)),
                L(0.45, sea(1560, "#C88068", "#3A2A40", "#FFE0B8")),
                L(0.6, label(540, 520, "O RIO NASCEU", 130, "#FFF4E0", "Anton"), rough=False),
                L(0.61, label(540, 660, "DE UMA GUERRA", 130, GOLD, "Anton"), reveal=(1.2, 0.3, "center"), rough=False)])
S[17] = s17

S[18] = lambda: bay_dusk((1.0, 1.0, (0, 30), (0, 30)), 71)
SC = S
