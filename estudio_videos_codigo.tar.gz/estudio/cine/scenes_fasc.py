"""Fascismo explicado (1919 a 1945, com Brasil): humor com os ditadores, seriedade com as vítimas. Sem suástica nem saudação."""
from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep5 import parchment, stamp, label, crown, RED, GOLD, INKB
from scenes_ep7 import hills
import scenes_pol3 as P3
import scenes_pol4 as P4
import random, math
PAPER = "#F4F1EA"; GREEN = "#1E3A22"

def fasces(x, y, s, col="#2A1A10", band=GOLD):
    rods = "".join(f'<rect x="{-70 + k*20}" y="-360" width="16" height="720" rx="8" fill="{col}"/>' for k in range(8))
    straps = "".join(f'<rect x="-80" y="{yy}" width="160" height="22" fill="{band}"/>' for yy in (-260, -40, 180))
    axe = f'<path d="M70,-380 C190,-420 230,-300 210,-240 C170,-280 120,-280 80,-270 Z" fill="#8A8A90"/><rect x="60" y="-400" width="22" height="160" fill="{col}"/>'
    return f'<g transform="translate({x},{y}) scale({s})">{rods}{straps}{axe}</g>'

def duomo(y, col):
    spires = "".join(f'<path d="M{x},{y-180-h} L{x+14},{y-180} L{x-14},{y-180} Z" fill="{col}"/><rect x="{x-8}" y="{y-180}" width="16" height="180" fill="{col}"/>' for x, h in ((300, 120), (380, 160), (460, 200), (540, 260), (620, 200), (700, 160), (780, 120)))
    return f'<rect x="260" y="{y-180}" width="560" height="180" fill="{col}"/><path d="M260,{y-180} L540,{y-300} L820,{y-180} Z" fill="{col}"/>' + spires + f'<rect x="{X0}" y="{y}" width="{BW}" height="700" fill="{col}"/>'

def colosseum(x, y, s, col):
    arches = "".join(f'<path d="M{-300+k*75},{-ry} L{-300+k*75},{-ry+90} Q{-262+k*75},{-ry+50} {-225+k*75},{-ry+90} L{-225+k*75},{-ry} Z" fill="{mix(col,"#000000",.5)}"/>' for ry in (300, 190, 80) for k in range(8))
    return f'<g transform="translate({x},{y}) scale({s})"><path d="M-330,0 L-330,-330 Q0,-380 330,-330 L330,0 Z" fill="{col}"/>{arches}</g>'

def sleeper(x, y, s, col):
    win = "".join(f'<rect x="{-260+k*110}" y="-170" width="70" height="60" rx="8" fill="#FFE8A8" opacity=".85"/>' for k in range(5))
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-300" y="-220" width="600" height="190" rx="18" fill="{col}"/>{win}'
            f'<rect x="-150" y="-80" width="300" height="40" rx="6" fill="#E8DCC0"/><text x="0" y="-50" font-family="Anton" font-size="34" text-anchor="middle" fill="#2A1A10">VAGÃO-LEITO</text>'
            + "".join(f'<circle cx="{cx}" cy="-20" r="34" fill="#1A1414"/>' for cx in (-220, -140, 140, 220)) + '</g>')

def poster(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-260" y="-380" width="520" height="760" fill="#E8D8B8" stroke="#2A1A10" stroke-width="8"/>'
            f'<path d="M-150,250 C-170,40 -110,-90 0,-120 C110,-90 170,40 150,250 Z" fill="#1A1210"/><path d="M-90,-120 C-110,-260 110,-260 90,-120 C80,-60 60,-30 0,-20 C-60,-30 -80,-60 -90,-120 Z" fill="#1A1210"/>'
            f'<rect x="-260" y="270" width="520" height="110" fill="{RED}"/><text x="0" y="345" font-family="Anton" font-size="46" text-anchor="middle" fill="{PAPER}">CRER · OBEDECER · COMBATER</text></g>')

def school(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-380" y="-420" width="760" height="420" fill="{col}"/><path d="M-420,-420 L0,-560 L420,-420 Z" fill="{col}"/>'
            f'<rect x="-90" y="-260" width="180" height="260" fill="#1A1A1E"/>' + "".join(f'<rect x="{xx}" y="-360" width="100" height="90" fill="#9A9AA0"/>' for xx in (-330, -200, 100, 230))
            + f'<rect x="-160" y="-500" width="320" height="56" fill="#D8D0C4"/><text x="0" y="-460" font-family="Old Standard TT" font-weight="700" font-size="36" text-anchor="middle" fill="#2A2A2E">SCUOLA</text></g>')

def palace(x, y, s, col):
    cols = "".join(f'<rect x="{-260+k*75}" y="-260" width="34" height="260" fill="{mix(col,"#000000",.35)}"/>' for k in range(8))
    return f'<g transform="translate({x},{y}) scale({s})"><rect x="-320" y="-300" width="640" height="300" fill="{col}"/><path d="M-340,-300 L0,-400 L340,-300 Z" fill="{col}"/>{cols}</g>'

def book14(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-230" y="-300" width="460" height="600" rx="14" fill="#2A2A3A" stroke="{GOLD}" stroke-width="8"/>'
            f'<text x="0" y="-60" font-family="Anton" font-size="220" text-anchor="middle" fill="{GOLD}">14</text>'
            f'<text x="0" y="30" font-family="Anton" font-size="60" text-anchor="middle" fill="{PAPER}">SINAIS</text>'
            f'<text x="0" y="200" font-family="Old Standard TT" font-style="italic" font-size="40" text-anchor="middle" fill="{PAPER}">Umberto Eco · 1995</text></g>')

def dark(c0="#0A0808", c1="#2A1414", c2="#4A1E14", gl="#C8582A"):
    return sky([(0, c0), (0.6, c1), (1, c2)]) + glow(540, 900, 800, gl, .3)

def crowd(n, y, h, col, seed, hat=None):
    r = random.Random(seed)
    return "".join(person(r.uniform(-60, 1140), y + r.uniform(-20, 30), h * r.uniform(.8, 1.1), col, "shirt", hat, la=(100, 92), ra=(80, 85), face=r.choice([1, -1])) for _ in range(n))

S = {}
S[1] = lambda: dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="embers",
    layers=[L(0.0, dark()), L(0.6, R(crowd(14, 1960, 520, "#060404", 1)) + ground(1950, "#0A0404", "#030102", 6, 1)),
            L(0.7, label(540, 900, "FASCISMO", 190, PAPER, "Anton"), reveal=(3.0, 0.2, "center"), rough=False),
            L(0.71, P4.chip(540, 1060, "O QUE FOI DE VERDADE?", GOLD, 46), reveal=(3.6, 0.2, "center"), rough=False)])
S[2] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -20)), particles="dust",
    layers=[L(0.0, sky([(0, "#3A3A40"), (0.6, "#8A7A68"), (1, "#C8A880")]) + sun(800, 1000, 70, halo_r=600, op=.5)),
            L(0.2, Rr(duomo(1350, "#4A4440"))),
            L(0.8, R(person(540, 1960, 820, "#0A0806", "coat", None, la=(100, 92), ra=(80, 85), face=1)) + ground(1950, "#2A2420", "#141210", 4, 1)),
            L(0.85, label(540, 440, "MILÃO · 1919", 100, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.86, label(540, 550, "BENITO MUSSOLINI · FASCI DE COMBATE", 44, GOLD, "Anton"), reveal=(4.2, 0.3, "center"), rough=False)])
S[3] = lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
    layers=[L(0.0, parchment(dark=True)), L(0.3, fasces(540, 1000, 1.0), rough=False),
            L(0.5, label(540, 470, "FASCES = FEIXE", 96, PAPER, "Anton"), rough=False),
            L(0.51, P4.chip(310, 1460, "SOZINHO: QUEBRA", PAPER, 38) + P4.chip(770, 1460, "JUNTO: NÃO QUEBRA", GOLD, 38), reveal=(3.8, 0.2, "center"), rough=False),
            L(0.52, label(540, 600, "lindo, né? calma...", 56, "#D8C8A8", "Caveat"), reveal=(6.4, 0.3, "center"), rough=False)])
S[4] = lambda: dict(light="#C8A890", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
    layers=[L(0.0, sky([(0, "#1A1418"), (0.6, "#4A3434"), (1, "#7A5A48")])),
            L(0.85, R("".join(person(x, 1960 + (k % 2) * 20, h, "#050404", "shirt", None, la=(100, 92), ra=(-40, -70), face=1, prop=("staff",)) for k, (x, h) in enumerate(((140, 720), (360, 680), (580, 740), (800, 690), (1000, 720))))) + ground(1940, "#140E0E", "#060404", 6, 1)),
            L(0.9, label(540, 440, "CAMISAS PRETAS", 100, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.91, P4.chip(540, 600, "FÃ-CLUBE (COM PORRETE)", GOLD, 44), reveal=(3.6, 0.2, "center"), rough=False)])
S[5] = lambda: dict(light="#FFD090", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -20)), particles="dust",
    layers=[L(0.0, sky([(0, "#4A5A78"), (0.6, "#D8A878"), (1, "#F0C090")]) + sun(760, 1150, 90, halo_r=700)),
            L(0.2, R(colosseum(780, 1400, 0.8, "#8A6A50")) + f'<rect x="{X0}" y="1395" width="{BW}" height="800" fill="#7A6048"/>'),
            L(0.7, R(crowd(12, 1960, 560, "#060404", 5)) + ground(1950, "#2A1A10", "#140A06", 6, 1)),
            L(0.8, label(540, 440, "1922 · MARCHA SOBRE ROMA", 58, "#1A0E08", "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.81, crown(300, 760, 0.8) + stamp(560, 780, "NÃO BARROU", -6, 90), reveal=(3.6, 0.2, "center"), rough=False)])
S[6] = lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
    layers=[L(0.0, sky([(0, "#14182A"), (0.6, "#3A3A5A"), (1, "#6A5A6A")]) + sun(840, 700, 60, core="#F4F0E0", halo="#C8C8E0", halo_r=400, op=.6)),
            L(0.2, Rr(hills(1400, "#2A2A3A", 6, 6, 120, 260))),
            L(0.5, R(rails(540, 1400, 2100, "#1A1414")) + R(locomotive(250, 1500, 0.8, "#0A0A0E", lamp="#FFE9B0") + sleeper(820, 1500, 0.9, "#3A1A14"))),
            L(0.6, label(860, 1140, "z z z", 70, PAPER, "Caveat"), drift=(20, -40), reveal=(1.6, 0.4, "center"), rough=False),
            L(0.8, label(540, 440, "O CHEFE DA MARCHA", 80, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.81, label(540, 550, "...FOI DE TREM", 80, GOLD, "Anton"), reveal=(2.0, 0.3, "center"), rough=False)])
S[7] = lambda: dict(light="#C8C0B8", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
    layers=[L(0.0, sky([(0, "#0A0A0E"), (1, "#1E1A1E")]) + glow(540, 1000, 700, "#8A7A6A", .3)),
            L(0.3, R(P3.newspaper(540, 1150, 1.2, -3, "1924"))),
            L(0.6, label(540, 440, "GIACOMO MATTEOTTI", 84, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.61, label(540, 550, "DENUNCIOU · FOI ASSASSINADO", 52, "#C8B8A8", "Anton"), reveal=(5.6, 0.3, "center"), rough=False)])
S[8] = lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
    layers=[L(0.0, parchment(dark=True)),
            L(0.3, P3.newspaper(330, 1150, 0.8, -8, "JORNAL") + P3.newspaper(760, 1200, 0.8, 6, "PARTIDO"), rough=False),
            L(0.4, stamp(330, 1100, "CALADO", -10, 90) + stamp(760, 1150, "PROIBIDO", 6, 90), reveal=(3.2, 0.2, "center"), rough=False),
            L(0.5, label(540, 470, "FECHOU TUDO", 120, PAPER, "Anton"), rough=False)])
S[9] = lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
    layers=[L(0.0, dark("#0A0808", "#2A1A14", "#3A2014", "#C87A3A")), L(0.3, poster(540, 1180, 0.9), rough=False),
            L(0.4, P4.chip(540, 420, "LÍDER QUE NUNCA ERRA", PAPER, 40), reveal=(0.4, 0.2, "center"), rough=False),
            L(0.41, P4.chip(540, 510, "UM INIMIGO PRA CULPAR", PAPER, 40), reveal=(1.8, 0.2, "center"), rough=False),
            L(0.42, P4.chip(540, 600, "PROPAGANDA 24H", PAPER, 40), reveal=(3.4, 0.2, "center"), rough=False),
            L(0.43, P4.chip(540, 690, "DISCORDOU = TRAIDOR", GOLD, 40), reveal=(4.6, 0.2, "center"), rough=False)])
S[10] = lambda: dict(light="#B8B8C0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -20)), particles=None,
    layers=[L(0.0, sky([(0, "#2A2A30"), (1, "#4A4A52")])),
            L(0.3, R(school(540, 1500, 1.0, "#6A6A72")) + ground(1500, "#3A3A40", "#2A2A30", 4, 1)),
            L(0.6, R("".join(person(x, 1900, h, "#121216", "shirt", None, la=(100, 92), ra=(80, 85), face=-1) for x, h in ((780, 330), (880, 300), (980, 340))))),
            L(0.7, label(540, 440, "1938 · LEIS RACIAIS", 84, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.71, label(540, 550, "crianças judias expulsas das escolas", 44, "#D8D8DC", "Montserrat"), reveal=(2.0, 0.3, "center"), rough=False)])
S[11] = lambda: dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, 30)), particles="embers",
    layers=[L(0.0, sky([(0, "#0A0408"), (0.6, "#3A1010"), (1, "#8A3A14")]) + glow(540, 1300, 800, "#FF6A20", .4)),
            L(0.2, R(f'<path d="M{X0},1400 L100,1300 L160,1400 L300,1250 L340,1400 L520,1320 L600,1400 L760,1280 L820,1400 L1000,1300 L{X1},1400 L{X1},{Y1} L{X0},{Y1} Z" fill="#140808"/>')),
            L(0.4, smoke_puffs(540, 1200, "#4A3A34", n=12, s=1.6, seed=11, drift=1), drift=(0, -80)),
            L(0.45, fire(300, 1420, 120, 200, 3) + fire(800, 1420, 140, 220, 4), flicker=0.25, rough=False),
            L(0.7, label(540, 440, "SEGUNDA GUERRA", 96, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.71, label(540, 560, "1945 · FIM DO REGIME", 64, GOLD, "Anton"), reveal=(4.8, 0.3, "center"), rough=False)])
S[12] = lambda: dict(light="#D8E8C8", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -20)), particles="dust",
    layers=[L(0.0, sky([(0, "#2A4A6A"), (0.6, "#A8C0A0"), (1, "#E8D8A8")]) + sun(800, 1050, 80, halo_r=700)),
            L(0.2, R(palace(720, 1420, 0.9, "#6A6A60")) + f'<rect x="{X0}" y="1415" width="{BW}" height="800" fill="#5A6048"/>'),
            L(0.8, R("".join(person(x, 1960 + (k % 2) * 20, h, GREEN, "shirt", None, la=(100, 92), ra=(80, 85), face=1) for k, (x, h) in enumerate(((120, 700), (300, 660), (480, 720))))) + ground(1950, "#2A3020", "#141810", 4, 1)),
            L(0.85, label(540, 440, "BRASIL · INTEGRALISTAS", 64, "#1A1A10", "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.86, P4.chip(540, 590, "CAMISAS VERDES", "#3A6A3A", 44, "#F4F1EA"), reveal=(1.4, 0.2, "center"), rough=False),
            L(0.87, stamp(720, 1080, "DEU ERRADO · 1938", -6, 70), reveal=(5.8, 0.15, "center"), rough=False)])
S[13] = lambda: dict(light="#E8F0F8", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="ash",
    layers=[L(0.0, sky([(0, "#8AA0B8"), (0.6, "#C8D4E0"), (1, "#E8EEF4")])),
            L(0.2, f'<path d="M{X0},1500 L200,1200 L420,900 L560,980 L760,1180 L{X1},1500 L{X1},{Y1} L{X0},{Y1} Z" fill="#F4F6F8"/><path d="M420,900 L500,1000 L460,1060 L560,980 Z" fill="#C8D0D8"/>', rough=False),
            L(0.6, R("".join(person(x, y, h, "#2A3428", "coat", "kepi", la=(100, 92), ra=(-30, -60), face=1, prop=("rifle", -40)) for x, y, h in ((160, 1960, 640), (360, 1880, 560), (560, 1800, 480))))),
            L(0.8, label(540, 440, "25 MIL BRASILEIROS", 84, "#1A2A3A", "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.81, label(540, 550, "CONTRA O FASCISMO", 72, "#2A6A3A", "Anton"), reveal=(1.6, 0.3, "center"), rough=False),
            L(0.82, P4.chip(540, 700, "MONTE CASTELO · FEV/1945", GOLD, 40), reveal=(5.6, 0.2, "center"), rough=False)])
S[14] = lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
    layers=[L(0.0, dark("#0A0A12", "#1A1A2A", "#2A2A3A", "#6A6AA0")), L(0.3, book14(540, 1080, 1.0), rough=False),
            L(0.5, label(540, 470, "BASTA UM SINAL", 100, PAPER, "Anton"), reveal=(4.8, 0.3, "center"), rough=False)])
S[15] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -10)), particles="dust",
    layers=[L(0.0, dark("#0A0808", "#1E1414", "#2A1A14", "#C8783A")),
            L(0.4, label(540, 800, "AGORA VOCÊ SABE", 110, PAPER, "Anton"), rough=False),
            L(0.41, P4.chip(540, 980, "MANDA PRO AMIGO 👀", GOLD, 52), reveal=(1.6, 0.2, "center"), rough=False)])
SC = S
