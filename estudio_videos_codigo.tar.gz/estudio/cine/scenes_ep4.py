from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep1 import caatinga, maloca
from scenes_ep2 import jtree, palm, jungle, canopy_top
from scenes_ep3 import lagoon
import random, math

SAIL = "#EFE4CC"; RED = "#B0261A"
def nau(x, y, s, col, sails=SAIL, cross=True, flip=1):
    g = [f'<g transform="translate({x},{y}) scale({s*flip},{s})">']
    g.append(f'<path d="M-330,-40 Q-300,60 -120,80 L240,80 Q360,60 400,-70 L340,-60 Q300,-10 220,-10 L-200,-10 Q-280,-20 -330,-40 Z" fill="{col}"/>')
    g.append(f'<path d="M-330,-40 L-360,-140 L-230,-130 L-200,-10 Z" fill="{col}"/><path d="M340,-60 L330,-150 L420,-150 L400,-70 Z" fill="{col}"/>')
    g.append("".join(f'<rect x="{-260+k*60}" y="10" width="22" height="16" fill="{mix(col,"#000000",.4)}"/>' for k in range(9)))
    for mx, h, sw in ((-80, 560, 220), (120, 640, 250), (300, 420, 150)):
        g.append(f'<rect x="{mx-6}" y="{-10-h}" width="12" height="{h}" fill="{col}"/>')
        for k, (yy, w2) in enumerate(((-h + 60, sw * 0.8), (-h * 0.55, sw))):
            top = -10 + yy; bot = top + h * 0.38
            g.append(f'<path d="M{mx-w2/2},{top} Q{mx},{top+20} {mx+w2/2},{top} Q{mx+w2/2+25},{(top+bot)/2} {mx+w2/2},{bot} Q{mx},{bot+30} {mx-w2/2},{bot} Q{mx-w2/2+20},{(top+bot)/2} {mx-w2/2},{top} Z" fill="{sails}"/>')
            g.append(f'<line x1="{mx-w2/2-10}" y1="{top}" x2="{mx+w2/2+10}" y2="{top}" stroke="{col}" stroke-width="7"/>')
            if cross and k == 1:
                cy = (top + bot) / 2 + 10; c = w2 * 0.18
                g.append(f'<path d="M{mx-c*0.35},{cy-c} L{mx+c*0.35},{cy-c} L{mx+c*0.2},{cy-c*0.3} L{mx+c},{cy-c*0.35} L{mx+c},{cy+c*0.35} L{mx+c*0.2},{cy+c*0.3} L{mx+c*0.35},{cy+c} L{mx-c*0.35},{cy+c} L{mx-c*0.2},{cy+c*0.3} L{mx-c},{cy+c*0.35} L{mx-c},{cy-c*0.35} L{mx-c*0.2},{cy-c*0.3} Z" fill="{RED}"/>')
    g.append(f'<path d="M126,-650 L200,-630 L126,-610 Z" fill="{RED}"/><line x1="-330" y1="-40" x2="120" y2="-640" stroke="{col}" stroke-width="3"/><line x1="400" y1="-70" x2="120" y2="-640" stroke="{col}" stroke-width="3"/>')
    g.append('</g>')
    return "".join(g)

def sea(y, c1, c2, glint="#FFE8C8", n=22):
    i = gid("sea")
    return (f'<defs><linearGradient id="{i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient></defs><rect x="{X0}" y="{y}" width="{BW}" height="{Y1-y}" fill="url(#{i})"/>'
            + "".join(f'<path d="M{X0 + (k*137)%300 - 300},{y+10+ (k**1.5)*5:.0f} ' + " ".join(f"q{40+k*3},-{3+k*0.4:.1f} {80+k*6},0" for _ in range(30)) + f'" stroke="{glint}" stroke-width="{1.5+k*0.15:.1f}" fill="none" opacity="{max(0.06,0.45-k*0.018):.2f}"/>' for k in range(n)))

def hammock(x, y, w, col, person_=True):
    g = f'<path d="M{x-w/2},{y} Q{x},{y+w*0.45} {x+w/2},{y}" stroke="{col}" stroke-width="{w*0.05:.0f}" fill="none"/><path d="M{x-w/2},{y} Q{x},{y+w*0.5} {x+w/2},{y} Q{x},{y+w*0.3} {x-w/2},{y} Z" fill="{col}"/>'
    g += f'<line x1="{x-w/2}" y1="{y}" x2="{x-w/2-w*0.12}" y2="{y-w*0.2}" stroke="{col}" stroke-width="4"/><line x1="{x+w/2}" y1="{y}" x2="{x+w/2+w*0.12}" y2="{y-w*0.2}" stroke="{col}" stroke-width="4"/>'
    if person_: g += f'<ellipse cx="{x-w*0.28}" cy="{y+w*0.12}" rx="{w*0.07}" ry="{w*0.06}" fill="{col}"/>'
    return g

def batel(x, y, s, col, rowers=4):
    g = f'<g transform="translate({x},{y}) scale({s})"><path d="M-260,0 Q0,40 260,0 L230,40 Q0,70 -230,40 Z" fill="{col}"/>'
    for k in range(rowers):
        px = -170 + k * 110
        g += person(px, 10, 150, col, "shirt", "morion" if k % 2 else "brim", la=(40, 70), ra=(50, 80), ll=(-20, 80), rl=(10, 90), face=1)
        g += f'<line x1="{px+40}" y1="-40" x2="{px+90}" y2="70" stroke="{col}" stroke-width="7"/>'
    return g + '</g>'

def torre_belem(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-120" y="-200" width="240" height="200" fill="{col}"/><rect x="-80" y="-520" width="160" height="330" fill="{col}"/>'
            + "".join(f'<path d="M{-80+k*40},-520 l20,-30 l20,30 Z" fill="{col}"/>' for k in range(4)) + "".join(f'<circle cx="{c}" cy="-540" r="18" fill="{col}"/><rect x="{c-10}" y="-560" width="20" height="30" fill="{col}"/>' for c in (-80, 80))
            + f'<rect x="-40" y="-420" width="80" height="80" rx="40" fill="{mix(col,"#000000",.4)}"/></g>')

def cross_big(x, y, s, col):
    return f'<g transform="translate({x},{y}) scale({s})"><rect x="-22" y="-700" width="44" height="700" fill="{col}"/><rect x="-190" y="-560" width="380" height="40" fill="{col}"/></g>'

S = {}
def dusk_ship(cam):
    return dict(light="#FFD8A0", rim_dx=5, cam=cam, particles="dust",
        layers=[L(0.0, sky([(0, "#2A2E4A"), (0.45, "#C8705A"), (0.75, "#F0A060"), (1, "#F8C890")]) + sun(760, 1180, 90, halo_r=800)),
                L(0.05, godrays(760, 1180, "#FFEFC8", n=15, spread=180, a0=-90, op=.26, seed=41), mode="screen"),
                L(0.1, clouds(760, "#F8C8A0", .5, seed=41, scale=1.5), drift=(40, 0)),
                L(0.25, sea(1200, "#C88068", "#3A2A40", "#FFE0B8") + ridge(1205, "#5A3040", 25, 42, 80)),
                L(0.5, R(nau(430, 1330, 0.95, "#140C10", sails="#E8D2B8", cross=False)), drift=(60, 0)),
                L(0.95, sea(1750, "#6A4048", "#1A1018", "#FFD0A8", 10))])
S[1] = lambda: dusk_ship((1.0, 1.12, (0, 20), (20, -20)))
def s2():
    pin = person(640, 1850, 820, "#0E0806", "coat", "morion", la=(100, 90), ra=(-30, -60), prop=("staff",), beard=True, face=-1)
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#8AA8C0"), (0.55, "#F0D0A0"), (1, "#F0B070")]) + sun(260, 1050, 80, halo_r=700)),
                L(0.2, sea(1180, "#9AB0B8", "#5A7888", "#FFF0D8")),
                L(0.3, R(nau(760, 1260, 0.45, "#1E1A1E", sails="#E8DCC8", cross=False))),
                L(0.5, R(f'<path d="M{X0},1400 C200,1320 500,1350 700,1380 C900,1410 1100,1390 {X1},1420 L{X1},{Y1} L{X0},{Y1} Z" fill="#D8B888"/>' + palm(120, 1420, 700, "#2A1E14", 42) + palm(240, 1430, 560, "#2A1E14", 43))),
                L(0.8, R(pin) + ground(1830, "#C8A070", "#8A6A48", 8, 2))])
S[2] = s2
def s3():
    parch = sky([(0, "#E9D8B0"), (1, "#D6BE8A")]) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>'
    sam = "M120,700 C220,640 330,660 380,760 C430,860 420,1000 360,1120 C300,1240 260,1330 220,1420 C180,1330 150,1200 130,1080 C100,900 90,780 120,700 Z"
    afr = "M760,640 C860,600 980,640 1040,760 C1080,880 1060,1060 1000,1200 C960,1300 900,1360 860,1380 C850,1260 820,1120 760,1000 C720,900 700,760 760,640 Z"
    eur = "M720,300 C800,260 940,280 1000,360 C1020,420 960,470 880,480 C800,490 740,430 720,300 Z"
    base = (parch + f'<path d="{sam}" fill="#C8B080" stroke="#5A3A26" stroke-width="5"/><path d="{afr}" fill="#C8B080" stroke="#5A3A26" stroke-width="5"/><path d="{eur}" fill="#C8B080" stroke="#5A3A26" stroke-width="5"/>'
            + f'<text x="260" y="1560" font-family="Old Standard TT" font-weight="700" font-size="44" text-anchor="middle" fill="#4A2E1C">NOVO MUNDO</text><text x="900" y="1500" font-family="Old Standard TT" font-weight="700" font-size="44" text-anchor="middle" fill="#4A2E1C">ÁFRICA</text>'
            + f'<g transform="translate(540,1720)"><circle r="80" fill="none" stroke="#4A2E1C" stroke-width="4"/><path d="M0,-96 L14,0 L0,96 L-14,0 Z" fill="#4A2E1C"/></g>')
    line = (f'<line x1="470" y1="{Y0}" x2="470" y2="{Y1}" stroke="{RED}" stroke-width="10" stroke-dasharray="36 18"/>'
            f'<rect x="{X0}" y="{Y0}" width="{470-X0}" height="{BH}" fill="#E8B040" opacity=".16"/><rect x="470" y="{Y0}" width="{X1-470}" height="{BH}" fill="#40A060" opacity=".14"/>'
            f'<text x="440" y="560" font-family="Anton" font-size="64" text-anchor="end" fill="#8A5A10">ESPANHA</text><text x="500" y="560" font-family="Anton" font-size="64" fill="#1E6A3A">PORTUGAL</text>')
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, -40), (0, 40)), particles="dust",
        layers=[L(0.0, base, rough=False), L(0.05, line, reveal=(0.2, 1.6, "center"), rough=False)])
S[3] = s3
def s4():
    fleet = "".join(nau(x, y, s, mix("#2A2A34", "#8A8A94", 1 - s), sails=mix("#EFE4CC", "#C8C0B8", 1 - s)) for x, y, s in [(900, 1200, 0.22), (760, 1215, 0.25), (1020, 1230, 0.28), (620, 1250, 0.33), (860, 1270, 0.36), (380, 1290, 0.42), (700, 1330, 0.5)])
    return dict(light="#FFF0D0", rim_dx=4, cam=(1.0, 1.12, (-30, 0), (30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C0D8"), (0.6, "#F0E4C8"), (1, "#F8D8A8")]) + sun(820, 800, 70, halo_r=700)),
                L(0.05, godrays(820, 800, "#FFF8E0", n=12, spread=160, a0=-90, op=.2, seed=44), mode="screen"),
                L(0.2, sea(1180, "#B0C4CC", "#6A8898", "#FFF6E0") + ridge(1185, "#8A9AA4", 30, 44)),
                L(0.4, R(fleet), drift=(80, 0)),
                L(0.8, R(torre_belem(170, 1780, 1.5, "#1A1614")) + sea(1760, "#4A5A68", "#1A2028", "#FFF0D0", 10))])
S[4] = s4
def s5():
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.14, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A3A5A"), (0.5, "#D8805A"), (1, "#F0B070")]) + sun(420, 1150, 80, halo_r=700)),
                L(0.05, godrays(420, 1150, "#FFEFC8", n=12, spread=150, a0=-90, op=.25, seed=45), mode="screen"),
                L(0.2, f'<path d="M{X0},1250 C200,1240 350,1150 520,900 C600,800 720,790 790,880 C900,1030 1000,1200 {X1},1230 L{X1},{Y1} L{X0},{Y1} Z" fill="#3A2A30"/>' + canopy_top(["#2E2228", "#382A30"], 45, 1180, 1260, 60, 30, 60)),
                L(0.3, sea(1250, "#B87060", "#3A2030", "#FFD8B0")),
                L(0.85, R(nau(860, 2050, 1.25, "#0A0608", sails="#D8C0A8") + person(260, 1900, 620, "#0A0608", "shirt", "brim", la=(100, 90), ra=(-70, -60), face=1)))])
S[5] = s5
def s6():
    r = random.Random(6); ppl = "".join(person(r.uniform(80, 1000), 1500 + r.uniform(0, 90), r.uniform(120, 170), "#1A120C", r.choice(["shirt", "dress"]), r.choice(["hair", "cocar", "hair"]), face=r.choice([1, -1])) for _ in range(22))
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8C890"), (0.5, "#F0B070"), (1, "#E89060")]) + sun(760, 1000, 90, halo_r=700)),
                L(0.05, godrays(760, 1000, "#FFEFC8", n=12, spread=160, a0=-90, op=.24, seed=46), mode="screen"),
                L(0.25, jungle(1300, "#9A6048", 14, 240, 380, 46, 5)),
                L(0.45, R(maloca(220, 1480, 0.9, "#4A3020") + maloca(620, 1460, 1.1, "#4A3020") + maloca(960, 1490, 0.8, "#4A3020")) + ground(1470, "#C89A68", "#8A6A48", 5, 1)),
                L(0.5, smoke_puffs(420, 1400, "#E8DCD0", n=6, s=0.7, seed=46, drift=1), drift=(20, -50)),
                L(0.7, R(ppl))])
S[6] = s6
def s7():
    inside = f'<path d="M{X0},{Y0} L{X1},{Y0} L{X1},{Y1} L{X0},{Y1} Z M-40,1900 C-40,1100 200,500 540,420 C880,500 1120,1100 1120,1900 Z" fill="#1A120C" fill-rule="evenodd"/>' + "".join(f'<path d="M-40,{1900-k*20} C{-40+k*10},{1100} {200+k*20},{500+k*8} 540,{420+k*6}" stroke="#2A1E14" stroke-width="6" fill="none"/>' for k in range(0, 20, 3))
    return dict(light="#FFB070", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#3A2618"), (1, "#5A3A22")]) + glow(540, 1500, 800, "#FF9A50", .45)),
                L(0.3, R(hammock(300, 1050, 320, "#0E0806") + hammock(760, 980, 300, "#0E0806") + hammock(560, 1250, 340, "#0E0806", False))),
                L(0.4, glow(540, 1700, 400, "#FFB060", .55), mode="screen", flicker=0.2),
                L(0.45, fire(490, 1730, 100, 150, 7), flicker=0.2, rough=False),
                L(0.6, R(person(250, 1850, 540, "#0A0604", "dress", "hair", la=(40, 10), ra=(60, 20), ll=(-10, 80), rl=(10, 95), face=1) + person(830, 1860, 560, "#0A0604", "shirt", "cocar", la=(100, 90), ra=(80, 85), face=-1)) + ground(1840, "#1E140C", "#0E0806", 6, 1)),
                L(1.0, inside, rough=False)])
S[7] = s7
def s8():
    return dict(light="#FFE6B8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#98B4C8"), (0.6, "#F0DCB8"), (1, "#F4C890")]) + sun(820, 900, 70, halo_r=600)),
                L(0.2, sea(1150, "#A8C0C8", "#6A8898", "#FFF6E0") + R(nau(760, 1230, 0.4, "#1E1A1E", sails="#E8DCC8"))),
                L(0.35, R(batel(420, 1360, 0.8, "#161214"))),
                L(0.5, f'<path d="M{X0},1420 C300,1380 700,1400 {X1},1440 L{X1},{Y1} L{X0},{Y1} Z" fill="#E0C898"/>'),
                L(0.8, R(person(180, 1900, 700, "#120A06", "shirt", "cocar", la=(100, 90), ra=(-10, -40), prop=("staff",), face=1)
                         + person(430, 1920, 640, "#120A06", "shirt", "cocar", la=(120, 100), ra=(-30, -50), face=1)
                         + person(830, 1920, 700, "#120A06", "coat", "brim", la=(160, 190), ra=(100, 90), face=-1)
                         + f'<g transform="translate(610,1340) rotate(-10)">' + "".join(f'<path d="M0,0 L{-50+k*14},-120 L{-40+k*14},-120 Z" fill="{["#C82A1E","#E8B030","#2A8A4A","#1E5AA8"][k%4]}"/>' for k in range(8)) + '</g>'))])
S[8] = s8
def s9():
    txt = ["Eram pardos, todos nus,", "sem coisa alguma que lhes", "cobrisse suas vergonhas.", "Nas mãos traziam arcos", "com suas setas..."]
    letter = f'<g transform="rotate(-3 540 1000)"><rect x="140" y="520" width="800" height="900" fill="#EFE0BC"/>' + "".join(f'<text x="200" y="{660+i*110}" font-family="Caveat" font-weight="700" font-size="66" fill="#2A1B12">{l}</text>' for i, l in enumerate(txt)) + '</g>'
    return dict(light="#FFC070", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1A10"), (1, "#3E2616")]) + "".join(f'<rect x="{X0}" y="{y}" width="{BW}" height="22" fill="#4A3020" opacity=".6"/>' for y in range(Y0, Y1, 70)) + glow(820, 400, 900, "#FFC66E", .55)),
                L(0.2, f'<g transform="rotate(-3 540 1000)"><rect x="140" y="520" width="800" height="900" fill="#EFE0BC"/></g>', rough=False),
                L(0.21, letter, reveal=(0.2, 3.5, "ltr"), rough=False),
                L(0.4, f'<rect x="800" y="320" width="70" height="200" rx="10" fill="#F1E4C3"/><path d="M835,262 q22,34 0,62 q-22,-28 0,-62" fill="#FFB347"/>' + f'<g transform="translate(860,1350) rotate(-35)"><path d="M0,0 C20,-160 60,-300 40,-520 C20,-380 -10,-200 0,0 Z" fill="#E9DDC4"/></g>', flicker=0.1, rough=False)])
S[9] = s9
def s10():
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.14, (0, 40), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A3A58"), (0.5, "#D8805A"), (1, "#F0A860")]) + sun(540, 1220, 110, halo_r=900)),
                L(0.05, godrays(540, 1220, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=410), mode="screen"),
                L(0.25, sea(1300, "#C87860", "#4A2A38", "#FFD8B0")),
                L(0.5, f'<path d="M{X0},1520 C300,1470 700,1480 {X1},1530 L{X1},{Y1} L{X0},{Y1} Z" fill="#2A1A14"/>' + R(cross_big(540, 1530, 1.2, "#120A08"))),
                L(0.8, R("".join(person(x, 1900, h, "#0A0604", o, hat, la=(100, 90), ra=(80, 85), face=f) for x, h, o, hat, f in [(120, 560, "coat", "brim", 1), (270, 520, "coat", "morion", 1), (820, 540, "shirt", "cocar", -1), (960, 500, "shirt", "hair", -1)])) + ground(1880, "#140A08", "#0A0604", 6, 1))])
S[10] = s10
def s11():
    altar = f'<rect x="420" y="1340" width="240" height="90" fill="#1A120C"/><rect x="530" y="1180" width="20" height="160" fill="#1A120C"/><rect x="490" y="1220" width="100" height="16" fill="#1A120C"/>'
    return dict(light="#FFF0D0", rim_dx=-5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C4D8"), (0.6, "#F0E4C8"), (1, "#F8D8A8")]) + sun(820, 800, 70, halo_r=700)),
                L(0.05, godrays(820, 800, "#FFF8E0", n=12, spread=160, a0=-110, op=.22, seed=411), mode="screen"),
                L(0.2, sea(1250, "#A8C0C8", "#6A8898", "#FFF6E0")),
                L(0.4, f'<ellipse cx="540" cy="1460" rx="520" ry="90" fill="#C8A878"/>' + R(altar + person(540, 1440, 240, "#1A120C", "robe", None, la=(-120, -100), ra=(-60, -80), face=-1) + "".join(person(200 + k * 70, 1470, 150, "#1A120C", "coat", "brim" if k % 2 else "morion", face=1) for k in range(5)))),
                L(0.8, R("".join(person(760 + k * 110, 1920, 460 + k * 30, "#0A0604", "shirt", "cocar" if k % 2 else "hair", face=-1) for k in range(3))) + ground(1900, "#D8B888", "#A88858", 6, 1))])
S[11] = s11
def s12():
    sick = "".join(hammock(x, y, 280, "#06080C") for x, y in [(280, 1200), (760, 1150), (520, 1400)])
    return dict(light="#9AB0C8", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#0A0E18"), (1, "#1A2230")]) + glow(540, 900, 700, "#4A6A8A", .35)),
                L(0.3, R(sick)),
                L(0.5, fogband(1300, "#6A8A7A", .5, 400, 12) + fogband(1000, "#5A7A6A", .35, 300, 13), drift=(80, -20)),
                L(0.8, R(person(540, 1920, 700, "#030406", "dress", "hair", la=(60, 20), ra=(120, 160), face=1)) + ground(1900, "#0A0E14", "#040608", 4, 1))])
S[12] = s12
def s13():
    return dict(light="#E8D0B8", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="ash",
        layers=[L(0.0, sky([(0, "#3A3448"), (0.6, "#8A6A68"), (1, "#B08A78")])),
                L(0.2, jungle(1300, "#5A4448", 14, 240, 360, 413, 4)),
                L(0.45, R(maloca(260, 1520, 0.9, "#1E1618") + maloca(700, 1500, 1.2, "#1E1618") + f'<path d="M660,1500 L660,1420 Q700,1395 740,1420 L740,1500 Z" fill="#050304"/>') + ground(1500, "#4A3A38", "#2A2020", 5, 1)),
                L(0.6, fogband(1500, "#8A7A80", .45, 260, 13), drift=(60, 0)),
                L(0.85, R(cross_big(160, 1950, 0.5, "#0A0808") + cross_big(900, 1950, 0.4, "#0A0808")) + ground(1900, "#1A1414", "#0A0808", 6, 2))])
S[13] = s13
def s14():
    r = random.Random(14); dots = []; lit = []
    for k in range(1175):
        x = 90 + (k % 34) * 27; y = 440 + (k // 34) * 36
        dots.append(f'<circle cx="{x}" cy="{y}" r="9" fill="#F5C833"/>')
    base = sky([(0, "#0A0E18"), (1, "#141A28")]) + "".join(dots)
    order = list(range(1175)); r.shuffle(order); dim = set(order[:880])
    cover = "".join(f'<circle cx="{90+(k%34)*27}" cy="{440+(k//34)*36}" r="10" fill="#1A2030"/>' for k in sorted(dim))
    return dict(light="#FFE6B0", rim_dx=4, cam=(1.0, 1.06, (0, -30), (0, 30)), particles=None,
        layers=[L(0.0, base, rough=False), L(0.05, cover, reveal=(0.4, 3.0, "ltr"), rough=False)])
S[14] = s14
def s15():
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.1, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A7A98"), (0.5, "#F0B888"), (1, "#F8D8A8")]) + sun(540, 1100, 110, halo_r=900)),
                L(0.05, godrays(540, 1100, "#FFF3D0", n=16, spread=190, a0=-90, op=.28, seed=415), mode="screen"),
                L(0.25, jungle(1300, "#B87A58", 14, 240, 360, 415, 5)),
                L(0.8, R("".join(person(100 + k * 176, 1920 + (k % 2) * 20, 620 + (k % 3) * 40, "#140A06", "shirt" if k % 2 else "dress", ["cocar", "hair", "cocar", "hair", "cocar", "hair"][k], la=(100, 90), ra=(80, 85) if k != 2 else (-60, -90), face=1 if k < 3 else -1) for k in range(6))) + ground(1900, "#3A2418", "#1A0E08", 8, 2))])
S[15] = s15
def s16():
    return dict(light="#FFD8A0", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A2E4A"), (0.45, "#C8705A"), (0.75, "#F0A060"), (1, "#F8C890")]) + sun(540, 1180, 100, halo_r=800)),
                L(0.05, godrays(540, 1180, "#FFEFC8", n=15, spread=180, a0=-90, op=.26, seed=416), mode="screen"),
                L(0.25, sea(1200, "#C88068", "#3A2A40", "#FFE0B8")),
                L(0.45, R(nau(820, 1290, 0.55, "#140C10", sails="#E8D2B8"))),
                L(0.6, R(f'<path d="M{X0},1450 C200,1400 300,1420 460,1480 L460,{Y1} L{X0},{Y1} Z" fill="#1A1010"/>' + maloca(160, 1450, 0.7, "#1A1010") + palm(360, 1470, 700, "#1A1010", 416))),
                L(0.85, R(person(220, 1920, 640, "#0A0606", "shirt", "cocar", la=(100, 90), ra=(80, 85), face=1)) + ground(1900, "#140A0A", "#0A0606", 6, 1))])
S[16] = s16
S[17] = lambda: dusk_ship((1.0, 1.0, (0, 20), (0, 20)))
SC = S
