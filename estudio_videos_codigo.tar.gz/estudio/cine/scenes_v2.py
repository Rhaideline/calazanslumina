from art import *
import random, math
INK = "#120E0B"

def L(depth, svg, mode="normal", drift=(0, 0), flicker=0, reveal=None, rough=True):
    return dict(depth=depth, svg=svg, mode=mode, drift=drift, flicker=flicker, reveal=reveal, rough=rough)

def R(svg): return f'<g filter="url(#roughrim)">{svg}</g>'
def Rr(svg): return f'<g filter="url(#rough)">{svg}</g>'

SC = {}

# 1 HOOK: locomotive emerging from misty araucaria forest
def s1():
    fog_c = "#9FB0A8"
    return dict(light="#FFE6B0", rim_dx=4, cam=(1.0, 1.12, (-30, 10), (35, -15)), particles="ash",
        layers=[
        L(0.0, sky([(0, "#2E3A3C"), (0.5, "#5E6E68"), (1, "#8C9A90")]) + glow(760, 900, 700, "#E8D8B0", .35) + clouds(500, "#B8C4BC", .35, seed=2)),
        L(0.2, Rr(forest(1150, mix(fog_c, "#2E3A36", .35), n=12, hmin=300, hmax=460, seed=11)) + f'<rect x="{X0}" y="1170" width="{BW}" height="900" fill="{mix(fog_c,"#2E3A36",.35)}"/>' + fogband(1150, "#C8D2CA", .55, 220, 3)),
        L(0.4, Rr(forest(1260, mix(fog_c, "#1E2622", .65), n=9, hmin=420, hmax=640, seed=12)) + fogband(1320, "#B8C4BC", .5, 200, 5)),
        L(0.6, ground(1420, "#262A26", "#141614", 8, 3) + f'<rect x="{X0}" y="1418" width="{BW}" height="14" fill="#3A3A36"/>' + R(locomotive(420, 1415, 0.95, INK, lamp="#FFE9B0"))),
        L(0.6, glow(820, 1190, 260, "#FFE6A8", .75) + f'<path d="M820,1190 L1400,980 L1400,1420 Z" fill="#FFF0C8" opacity=".22" filter="url(#blur14)"/>', mode="screen", flicker=0.05),
        L(0.62, smoke_puffs(700, 1000, "#D8DCD6", n=9, s=1.3, seed=4, drift=-1), drift=(-30, -60)),
        L(1.0, R(araucaria(-40, 2150, 1900, "#0A0806", 91, lean=0.4) + araucaria(1150, 2150, 1700, "#0A0806", 92, lean=-0.5)) + ground(1830, "#0A0806", "#050403", 25, 9)),
        ])
SC[1] = s1

# 2 TITLE: golden sea of araucarias
def s2():
    return dict(light="#FFE0A0", rim_dx=4, cam=(1.0, 1.1, (0, 40), (0, -20)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#F7D9A0"), (0.45, "#F0A866"), (0.75, "#D9724A"), (1, "#8A3A34")]) + sun(540, 1080, 110, halo_r=700)),
        L(0.05, godrays(540, 1080, "#FFEFC8", n=15, spread=170, a0=-90, op=0.28, seed=3), mode="screen"),
        L(0.1, clouds(700, "#FFE2B8", .45, seed=5, scale=1.3), drift=(40, 0)),
        L(0.25, forest(1250, "#C2685A", n=16, hmin=180, hmax=280, seed=21) + f'<rect x="{X0}" y="1250" width="{BW}" height="900" fill="#C2685A"/>' + haze(1100, 1300, "#F0A866", .5)),
        L(0.45, forest(1430, "#8A3E38", n=12, hmin=300, hmax=420, seed=22) + f'<rect x="{X0}" y="1430" width="{BW}" height="700" fill="#8A3E38"/>'),
        L(0.7, R(forest(1680, "#4A1E1C", n=8, hmin=460, hmax=640, seed=23)) + f'<rect x="{X0}" y="1670" width="{BW}" height="500" fill="#4A1E1C"/>'),
        L(1.0, R(araucaria(1000, 2200, 2000, "#180A08", 93, lean=-0.3)) + ground(1900, "#180A08", "#0A0404", 20, 2)),
        ])
SC[2] = s2

# 3 MAP: antique parchment, contested zone reveal
def s3():
    parch = sky([(0, "#E9D8B0"), (1, "#D6BE8A")]) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>'
    frame = f'<rect x="40" y="220" width="1000" height="1480" fill="none" stroke="#5A3A26" stroke-width="6"/><rect x="60" y="240" width="960" height="1440" fill="none" stroke="#5A3A26" stroke-width="2"/>'
    pr = "M120,420 C300,380 600,360 960,380 L990,980 C820,1000 700,1010 560,1040 C420,1010 260,1000 100,1020 Z"
    sc = "M100,1020 C260,1000 420,1010 560,1040 C700,1010 820,1000 990,980 L1000,1560 C700,1600 400,1600 90,1600 Z"
    trees = "".join(araucaria(x, y, 60, "#6A5A3A", 300 + i) for i, (x, y) in enumerate([(random.Random(k).randint(160, 940), random.Random(k + 9).randint(500, 1500)) for k in range(45)]))
    railw = f'<path d="M480,300 C500,600 470,900 520,1200 C540,1400 500,1600 520,1700" fill="none" stroke="#2A1A10" stroke-width="10"/>' + "".join(f'<line x1="{505 + 8*math.sin(k/3):.0f}" y1="{320+k*28}" x2="{535+8*math.sin(k/3):.0f}" y2="{320+k*28}" stroke="#2A1A10" stroke-width="4"/>' for k in range(49))
    base = (parch + frame + f'<path d="{pr}" fill="#E2CFA0" stroke="#5A3A26" stroke-width="5"/><path d="{sc}" fill="#DCC690" stroke="#5A3A26" stroke-width="5"/>' + trees + railw +
            f'<text x="760" y="560" font-family="Old Standard TT" font-weight="700" font-size="64" text-anchor="middle" fill="#4A2E1C" letter-spacing="6">PARANÁ</text>'
            f'<text x="300" y="1470" font-family="Old Standard TT" font-weight="700" font-size="54" text-anchor="middle" fill="#4A2E1C" letter-spacing="4">SANTA</text><text x="300" y="1530" font-family="Old Standard TT" font-weight="700" font-size="54" text-anchor="middle" fill="#4A2E1C" letter-spacing="4">CATARINA</text>'
            f'<g transform="translate(880,1560)"><circle r="70" fill="none" stroke="#4A2E1C" stroke-width="4"/><path d="M0,-86 L14,0 L0,86 L-14,0 Z" fill="#4A2E1C"/><path d="M-86,0 L0,10 L86,0 L0,-10 Z" fill="#4A2E1C" opacity=".6"/><text y="-96" font-family="Old Standard TT" font-size="34" text-anchor="middle" fill="#4A2E1C">N</text></g>'
            f'<text x="540" y="300" font-family="Old Standard TT" font-style="italic" font-size="40" text-anchor="middle" fill="#4A2E1C">Carta da região em litígio · c. 1912</text>')
    zone = (f'<path d="M100,1020 C260,1000 420,1010 560,1040 C700,1010 820,1000 990,980 L995,1260 C800,1240 600,1300 400,1270 C260,1250 180,1270 95,1280 Z" fill="#B0301E" opacity=".38"/>'
            f'<path d="M100,1020 C260,1000 420,1010 560,1040 C700,1010 820,1000 990,980" fill="none" stroke="#9A1E10" stroke-width="10" stroke-dasharray="30 14"/>'
            f'<text x="700" y="1170" font-family="Anton" font-size="96" text-anchor="middle" fill="#7A1408" letter-spacing="4">CONTESTADO</text>')
    return dict(light="#FFE6B0", rim_dx=4, cam=(1.0, 1.08, (0, 30), (20, 60)), particles="dust",
        layers=[L(0.0, base, rough=False), L(0.1, zone, reveal=(0.6, 2.4, "ltr"), rough=False)])
SC[3] = s3

# 4 RAILWAY CONSTRUCTION through forest
def s4():
    return dict(light="#FFE4A8", rim_dx=5, cam=(1.0, 1.14, (0, 0), (0, -40)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#D8E2D2"), (0.6, "#F2E6C4"), (1, "#F6D8A0")]) + sun(540, 980, 60, halo_r=500)),
        L(0.05, godrays(540, 980, "#FFF3D0", n=13, spread=160, a0=-90, op=0.25, seed=7), mode="screen"),
        L(0.25, forest(1060, "#8EA08A", n=14, hmin=260, hmax=400, seed=41) + f'<rect x="{X0}" y="1060" width="{BW}" height="900" fill="#8EA08A"/>' + fogband(1060, "#F2EEDC", .6, 150, 2)),
        L(0.45, R(forest(1150, "#44573F", n=4, hmin=700, hmax=900, seed=42, x0=X0, x1=330) + forest(1150, "#44573F", n=4, hmin=700, hmax=900, seed=43, x0=750, x1=X1))),
        L(0.6, ground(1000, "#8A7A5A", "#4A3E2A", 4, 1) + rails(540, 1000, 2120, "#2A241C", "#4A3422", width=1300, n=30)),
        L(0.8, R(person(260, 1500, 380, INK, "shirt", "brim", la=(-120, -60), ra=(-50, -20), prop=("hammer", -70), lean=-15, face=1, ll=(70, 110), rl=(110, 80))
                 + person(820, 1560, 420, INK, "shirt", "straw" if False else "brim", la=(60, 100), ra=(40, 90), lean=30, face=-1, ll=(75, 100), rl=(110, 95))
                 + f'<g transform="translate(900,1720)"><rect x="-120" y="-120" width="240" height="120" fill="{INK}"/></g>')),
        L(1.0, R(person(-20, 2150, 900, "#080604", "shirt", "brim", la=(100, 80), ra=(-80, -110), prop=("hammer", -100), face=1))
               + f'<g transform="translate(890,1920)"><rect x="-190" y="-200" width="380" height="200" fill="#1E1812"/><text x="0" y="-110" font-family="Old Standard TT" font-weight="700" font-size="36" text-anchor="middle" fill="#C8B488">BRAZIL RAILWAY</text><text x="0" y="-60" font-family="Old Standard TT" font-weight="700" font-size="36" text-anchor="middle" fill="#C8B488">COMPANY</text></g>'),
        ])
SC[4] = s4

# 5 AERIAL: 15 km each side
def s5():
    r = random.Random(5); crowns = []
    for k in range(700):
        x, y = r.uniform(X0, X1), r.uniform(Y0, Y1); rr = r.uniform(18, 34); c = r.choice(["#2E4A30", "#3A5A3A", "#28402A", "#44663F"])
        crowns.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{rr:.0f}" fill="{c}"/><circle cx="{x-rr*0.3:.0f}" cy="{y-rr*0.3:.0f}" r="{rr*0.45:.0f}" fill="{mix(c,"#9ABA7A",.35)}"/>')
    base = f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#1E3020"/>' + "".join(crowns)
    track = f'<rect x="500" y="{Y0}" width="80" height="{BH}" fill="#8A7458"/><rect x="522" y="{Y0}" width="8" height="{BH}" fill="#2A241C"/><rect x="550" y="{Y0}" width="8" height="{BH}" fill="#2A241C"/>' + "".join(f'<rect x="512" y="{y}" width="56" height="8" fill="#3A2A1C"/>' for y in range(Y0, Y1, 26))
    bands = (f'<rect x="120" y="{Y0}" width="380" height="{BH}" fill="#C0301E" opacity=".26"/><rect x="580" y="{Y0}" width="380" height="{BH}" fill="#C0301E" opacity=".26"/>'
             f'<line x1="120" y1="{Y0}" x2="120" y2="{Y1}" stroke="#FFE2C8" stroke-width="6" stroke-dasharray="24 14"/><line x1="960" y1="{Y0}" x2="960" y2="{Y1}" stroke="#FFE2C8" stroke-width="6" stroke-dasharray="24 14"/>'
             f'<path d="M130,760 L490,760 M130,745 L130,775 M490,745 L490,775" stroke="#FFF3E0" stroke-width="6"/><path d="M590,760 L950,760 M590,745 L590,775 M950,745 L950,775" stroke="#FFF3E0" stroke-width="6"/>'
             f'<text x="310" y="730" font-family="Anton" font-size="92" text-anchor="middle" fill="#FFF3E0">15 KM</text><text x="770" y="730" font-family="Anton" font-size="92" text-anchor="middle" fill="#FFF3E0">15 KM</text>')
    return dict(light="#FFE6B0", rim_dx=4, cam=(1.1, 1.0, (0, 60), (0, -60)), particles=None,
        layers=[L(0.0, base, rough=False), L(0.05, track, rough=False), L(0.1, bands, reveal=(0.8, 1.8, "center"), rough=False),
                L(0.8, clouds(600, "#FFFFFF", .35, seed=8, scale=1.6), drift=(-60, 30))])
SC[5] = s5

# 6 EXPULSION at dawn
def s6():
    return dict(light="#FFD9A0", rim_dx=6, cam=(1.0, 1.1, (40, 0), (-40, -10)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#8E9CA0"), (0.55, "#D8C8A8"), (1, "#F0C890")]) + sun(180, 1180, 70, halo_r=600)),
        L(0.2, forest(1200, "#8A9088", n=14, hmin=260, hmax=380, seed=61) + f'<rect x="{X0}" y="1200" width="{BW}" height="900" fill="#8A9088"/>' + fogband(1230, "#EEE6D6", .6, 200, 6)),
        L(0.4, R(cabin(760, 1420, 1.25, "#3A2E24", win="#F2B65A") + forest(1400, "#3A423A", n=3, hmin=560, hmax=700, seed=62, x0=880, x1=X1)) + ground(1400, "#5A5446", "#3A362C", 10, 2)),
        L(0.45, smoke_puffs(860, 1020, "#E6E0D6", n=8, s=0.9, seed=9, drift=1), drift=(40, -50)),
        L(0.6, R(person(960, 1620, 400, INK, "coat", "kepi", la=(100, 90), ra=(70, 30), prop=("rifle", -80, True), face=-1)
                 + f'<g transform="translate(700,1600) rotate(6)"><rect x="-8" y="-200" width="16" height="200" fill="{INK}"/><rect x="-130" y="-250" width="260" height="90" fill="#D9CCAE"/><text x="0" y="-215" font-family="Old Standard TT" font-weight="700" font-size="30" text-anchor="middle" fill="{INK}">PROPRIEDADE DA</text><text x="0" y="-178" font-family="Old Standard TT" font-weight="700" font-size="30" text-anchor="middle" fill="{INK}">COMPANHIA</text></g>')),
        L(0.9, R(person(150, 1950, 720, "#0A0806", "poncho", "brim", la=(110, 100), ra=(-60, -100), prop=("bundle",), ll=(70, 115), rl=(115, 80), face=-1)
                 + person(420, 1960, 650, "#0A0806", "dress", "scarf", la=(100, 80), ra=(95, 95), face=-1)
                 + person(560, 1960, 360, "#0A0806", "shirt", "hair", la=(-150, -140), ra=(100, 90), face=-1, ll=(75, 110), rl=(110, 80))) + ground(1940, "#1A1612", "#0A0806", 15, 4)),
        ])
SC[6] = s6

# 7 LOGGING: araucaria falls, logs on train
def s7():
    fall = f'<g transform="rotate(28 700 1480)">{araucaria(700, 1480, 1100, INK, 71)}</g>'
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (30, -20)), particles="sawdust",
        layers=[
        L(0.0, sky([(0, "#C8C4B0"), (0.6, "#E6D6B0"), (1, "#E8C48A")]) + sun(820, 800, 60, halo_r=500)),
        L(0.2, forest(1230, "#9A9A80", n=14, hmin=240, hmax=360, seed=71) + f'<rect x="{X0}" y="1230" width="{BW}" height="900" fill="#9A9A80"/>'),
        L(0.35, R(railcar_logs(-80, 1400, 0.9, "#3A3428") + railcar_logs(330, 1400, 0.9, "#3A3428") + railcar_logs(740, 1400, 0.9, "#3A3428")) + f'<rect x="{X0}" y="1430" width="{BW}" height="10" fill="#3A3428"/>' + ground(1440, "#6A5E44", "#4A3E2A", 6, 3)),
        L(0.6, R(fall + stump(640, 1560, 1.3, INK, "#C79A62"))),
        L(0.85, R(person(330, 1800, 540, "#0A0806", "shirt", "brim", la=(-40, -10), ra=(-20, 10), lean=40, face=1, ll=(70, 100), rl=(110, 95))
                  + f'<line x1="440" y1="1360" x2="640" y2="1420" stroke="#0A0806" stroke-width="10"/>'
                  + person(930, 1820, 560, "#0A0806", "shirt", "brim", la=(160, 190), ra=(-150, -170), lean=-30, face=-1)) + ground(1780, "#241E16", "#120E0A", 12, 5)),
        ])
SC[7] = s7

# 8 STUMPS FIELD: the forest became profit
def s8():
    r = random.Random(8)
    st_far = "".join(stump(r.uniform(X0, X1), 1250 + k * 3, 0.35, "#5A5046", "#9A8060") for k in range(30))
    st_mid = "".join(stump(r.uniform(X0, X1), 1420 + r.uniform(0, 60), 0.7, "#3A3228", "#B08A5A") for k in range(14))
    logs = "".join(f'<circle cx="{620+c*62+(rr%2)*31}" cy="{1640-rr*56}" r="30" fill="#9A6A3E" stroke="#2A1A10" stroke-width="5"/><circle cx="{700+c*62+(rr%2)*31}" cy="{1640-rr*56}" r="12" fill="none" stroke="#C79A62" stroke-width="3"/>' for rr in range(7) for c in range(8 - rr))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (-40, 0), (40, -10)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#9AA0A0"), (0.6, "#C8C0B0"), (1, "#D8C8A8")])),
        L(0.15, forest(1180, "#8A8C80", n=6, hmin=200, hmax=280, seed=81, x0=700, x1=X1) + ridge(1200, "#8A8278", 30, 3) + haze(1100, 1250, "#D8D0C0", .5)),
        L(0.3, st_far + f'<rect x="{X0}" y="1255" width="{BW}" height="900" fill="#6A6050" opacity=".0"/>'),
        L(0.5, ground(1400, "#6A5E4A", "#4A402E", 12, 7) + R(st_mid)),
        L(0.7, R(logs)),
        L(1.0, ground(1860, "#1A140E", "#0A0806", 20, 8) + R(stump(250, 1880, 4.2, "#1A140E", "#C79A62") + stump(-40, 1800, 2.6, "#1A140E", "#C79A62") + stump(980, 1860, 3.0, "#1A140E", "#C79A62") + person(700, 1890, 560, "#0A0806", "poncho", "brim", la=(100, 95), ra=(85, 95), face=-1))),
        ])
SC[8] = s8

# 9 MONK José Maria in misty forest with god rays
def s9():
    kneel = lambda x, y, h, f: person(x, y, h, "#0E0C0A", "dress", "scarf", la=(60, -60), ra=(40, -80), face=f, lean=h * 0.04 * f)
    return dict(light="#FFF0C8", rim_dx=-5, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#B8C8B0"), (0.6, "#DCE0C8"), (1, "#E8E0C0")]) + glow(260, 400, 900, "#FFF6DA", .6)),
        L(0.1, godrays(200, 200, "#FFF8E0", n=10, spread=40, a0=62, op=0.35, seed=9), mode="screen"),
        L(0.25, forest(1150, "#9AAA90", n=12, hmin=420, hmax=600, seed=91) + f'<rect x="{X0}" y="1150" width="{BW}" height="900" fill="#9AAA90"/>' + fogband(1200, "#F2F2E6", .55, 240, 9)),
        L(0.45, R(forest(1350, "#4A5A44", n=6, hmin=700, hmax=900, seed=92)) + ground(1340, "#5A6248", "#3A4030", 8, 2) + fogband(1400, "#E8ECE0", .35, 160, 10)),
        L(0.7, R(person(560, 1720, 760, INK, "robe", "brim", la=(100, 95), ra=(20, -40), prop=("herbs", "#8FBF6A"), beard=True, face=1))),
        L(0.9, R(kneel(180, 1930, 480, 1) + kneel(930, 1940, 500, -1) + person(760, 1960, 360, "#0E0C0A", "shirt", "hair", la=(-100, -120), ra=(-80, -60), face=-1)) + ground(1900, "#1E2018", "#0E100A", 12, 4)),
        ])
SC[9] = s9

# 10 BATTLE OF IRANI
def s10():
    flashes = "".join(glow(x, y, 120, "#FFE08A", .9) for x, y in [(720, 1340), (860, 1360), (980, 1330)])
    return dict(light="#FFB070", rim_dx=5, cam=(1.0, 1.12, (30, 0), (-20, -20)), particles="ash",
        layers=[
        L(0.0, sky([(0, "#3A2A28"), (0.5, "#8A4A36"), (1, "#C8683A")]) + glow(540, 1200, 800, "#FF9A50", .45)),
        L(0.2, forest(1200, "#5A3A30", n=12, hmin=320, hmax=460, seed=101) + f'<rect x="{X0}" y="1200" width="{BW}" height="900" fill="#5A3A30"/>'),
        L(0.35, clouds(1100, "#B8A090", .55, seed=11, scale=1.4), drift=(-50, -20)),
        L(0.5, R("".join(person(640 + k * 120, 1500 + (k % 2) * 30, 330, "#140C0A", "coat", "kepi", la=(160, 170), ra=(-170, -175), prop=("rifle", 180, True), face=-1) for k in range(4))) + ground(1480, "#3A2620", "#241814", 8, 1)),
        L(0.52, flashes, mode="screen", flicker=0.6),
        L(0.85, R(person(160, 1900, 640, "#080404", "poncho", "brim", la=(120, 100), ra=(-40, -70), prop=("facao", -40), lean=60, ll=(60, 110), rl=(125, 80), face=1)
                  + person(430, 1960, 700, "#080404", "shirt", "brim", la=(140, 110), ra=(-60, -80), prop=("facao", -60), lean=70, ll=(55, 105), rl=(130, 85), face=1)) + ground(1880, "#140A08", "#080404", 20, 3)),
        L(0.9, clouds(1500, "#8A7060", .4, seed=12, scale=1.2), drift=(60, -10)),
        ])
SC[10] = s10

# 11 HOLY CITY on hill
def s11():
    r = random.Random(11); cabins = ""; flags = ""
    for k in range(26):
        x = r.uniform(120, 960); t = abs(x - 540) / 420; y = 1320 + t * t * 200 + r.uniform(-20, 40)
        cabins += cabin(x, y, r.uniform(0.28, 0.4), "#3A2A1E")
    for x, y in [(300, 1330), (540, 1180), (780, 1330), (420, 1250), (660, 1240)]:
        flags += f'<line x1="{x}" y1="{y}" x2="{x}" y2="{y-220}" stroke="{INK}" stroke-width="7"/><path d="M{x},{y-220} C{x+40},{y-235} {x+80},{y-200} {x+110},{y-215} L{x+108},{y-150} C{x+80},{y-135} {x+40},{y-170} {x},{y-155} Z" fill="#F7F3EA"/><rect x="{x+48}" y="{y-205}" width="10" height="44" fill="#2F7A3F"/><rect x="{x+32}" y="{y-189}" width="42" height="10" fill="#2F7A3F"/>'
    hill = f'<path d="M{X0},1560 C200,1300 400,1200 540,1190 C700,1200 900,1300 {X1},1560 L{X1},{Y1} L{X0},{Y1} Z" fill="#4A3E2C"/>'
    return dict(light="#FFE6B0", rim_dx=-4, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#F4D8A8"), (0.55, "#F0B878"), (1, "#E09A60")]) + sun(820, 700, 80, halo_r=700)),
        L(0.05, godrays(820, 700, "#FFF3D0", n=12, spread=120, a0=120, op=0.25, seed=11), mode="screen"),
        L(0.2, forest(1300, "#B8805A", n=14, hmin=260, hmax=420, seed=111) + haze(1100, 1320, "#F0B878", .5)),
        L(0.45, hill + R(cabins) + R(flags) + R(forest(1500, "#3A2E20", n=3, hmin=500, hmax=620, seed=112, x0=X0, x1=180) + forest(1500, "#3A2E20", n=3, hmin=500, hmax=620, seed=113, x0=920, x1=X1))),
        L(0.8, R("".join(person(220 + k * 160, 1880 + (k % 2) * 30, 380, "#140E0A", ["poncho", "dress", "shirt", "dress", "poncho"][k], ["brim", "scarf", "brim", "scarf", "brim"][k], ll=(80, 105), rl=(105, 85), face=1) for k in range(5))) + ground(1860, "#241A12", "#120C08", 15, 2)),
        ])
SC[11] = s11

# 12 MARIA ROSA heroic
def s12():
    rock = f'<path d="M520,1560 C560,1420 680,1380 820,1400 C960,1420 1080,1480 1190,1560 L1190,2115 L520,2115 Z" fill="#141210"/>'
    return dict(light="#FFF0D0", rim_dx=6, cam=(1.0, 1.1, (0, 40), (0, -20)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#5E6E80"), (0.5, "#C8B8A8"), (1, "#F0C898")]) + sun(700, 1100, 80, halo_r=900)),
        L(0.05, godrays(700, 1100, "#FFF0D0", n=16, spread=200, a0=-90, op=0.22, seed=12), mode="screen"),
        L(0.15, clouds(500, "#E8DCD0", .55, seed=13, scale=1.5), drift=(60, 0)),
        L(0.3, forest(1500, "#6A6A68", n=14, hmin=240, hmax=360, seed=121) + f'<rect x="{X0}" y="1500" width="{BW}" height="700" fill="#6A6A68"/>' + fogband(1520, "#E8E0D6", .45, 180, 12)),
        L(0.6, R("".join(person(80 + k * 90, 1780 + (k % 3) * 20, 230, "#1E1C1A", ["poncho", "dress", "shirt"][k % 3], ["brim", "scarf", "brim"][k % 3], la=(-130, -150) if k % 2 else (100, 90), ra=(-60, -30), face=1) for k in range(5))) + ground(1780, "#2A2826", "#1A1816", 10, 5)),
        L(0.8, R(rock + person(800, 1420, 640, "#0E0C0A", "dress", "hair", la=(110, 95), ra=(-50, -80), prop=("flag", "#F7F3EA", "#2F7A3F"), face=-1))),
        ])
SC[12] = s12

# 13 ARMY marching column
def s13():
    col = []
    for k in range(11):
        t = (k / 10) ** 1.6; y = lerp(1260, 1900, t); h = lerp(70, 520, t)
        for sgn in (-1, 1):
            x = 540 + sgn * lerp(26, 400, t)
            col.append(person(x, y, h, mix("#6A6E70", "#0E0E0E", t), "coat", "kepi", la=(95, 90), ra=(60, 30), prop=("rifle", -85, True), ll=(85, 100) if k % 2 else (100, 85), rl=(100, 85) if k % 2 else (85, 100), face=1 if sgn < 0 else -1))
    road = f'<path d="M520,1240 L560,1240 L1000,2115 L80,2115 Z" fill="#5A5446"/>'
    return dict(light="#E8ECF0", rim_dx=4, cam=(1.0, 1.14, (0, -20), (0, 20)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#5A6068"), (0.6, "#9AA0A2"), (1, "#C0BCB0")]) + glow(540, 1150, 600, "#F0EEE6", .5)),
        L(0.2, forest(1250, "#7E8480", n=14, hmin=240, hmax=360, seed=131) + f'<rect x="{X0}" y="1250" width="{BW}" height="900" fill="#7E8480"/>'),
        L(0.4, ground(1240, "#6A665A", "#4A463C", 4, 2) + road + R(forest(1600, "#3A3C38", n=3, hmin=800, hmax=1000, seed=132, x0=X0, x1=150) + forest(1600, "#3A3C38", n=3, hmin=800, hmax=1000, seed=133, x0=930, x1=X1))),
        L(0.7, R("".join(col))),
        ])
SC[13] = s13

# 14 BIPLANE over the forest
def s14():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -20)), particles=None,
        layers=[
        L(0.0, sky([(0, "#E8C8A0"), (0.5, "#F0A870"), (1, "#C86850")]) + sun(760, 1150, 90, halo_r=700)),
        L(0.1, clouds(900, "#FFE0C0", .55, seed=14, scale=1.6), drift=(-60, 0)),
        L(0.3, forest(1400, "#9A5A4A", n=18, hmin=200, hmax=300, seed=141) + f'<rect x="{X0}" y="1400" width="{BW}" height="900" fill="#9A5A4A"/>' + fogband(1420, "#F0C8A8", .5, 200, 14)),
        L(0.5, forest(1650, "#5A2E28", n=12, hmin=320, hmax=440, seed=142) + f'<rect x="{X0}" y="1650" width="{BW}" height="600" fill="#5A2E28"/>'),
        L(0.55, R(biplane(260, 900, 2.2, INK)), drift=(360, -80)),
        L(0.8, R(forest(2000, "#240E0C", n=7, hmin=560, hmax=720, seed=143))),
        L(0.95, clouds(1800, "#FFD8B8", .35, seed=15, scale=1.8), drift=(-120, 0)),
        ])
SC[14] = s14

# 15 SIEGE in winter night
def s15():
    huddle = "".join(person(x, 1840, h, "#06080A", o, hat, la=(60, 10), ra=(120, 170), face=f) for x, h, o, hat, f in [(300, 460, "poncho", "brim", 1), (430, 380, "dress", "scarf", 1), (720, 440, "poncho", "brim", -1), (840, 300, "shirt", "hair", -1)])
    return dict(light="#FFB070", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="snow",
        layers=[
        L(0.0, sky([(0, "#0A1020"), (0.6, "#1E2A40"), (1, "#3A4860")]) + sun(820, 420, 70, core="#EEF2F6", halo="#9AB0CA", halo_r=400, op=0.5)),
        L(0.2, forest(1300, "#18202C", n=14, hmin=300, hmax=460, seed=151) + f'<rect x="{X0}" y="1300" width="{BW}" height="900" fill="#18202C"/>'),
        L(0.4, palisade(1520, "#0C1018", h=260, seed=3) + ground(1510, "#2A3040", "#1A1E28", 6, 3) + f'<rect x="{X0}" y="1505" width="{BW}" height="30" fill="#DDE4EE" opacity=".25"/>'),
        L(0.6, glow(560, 1800, 420, "#FF9A50", .55), mode="screen", flicker=0.18),
        L(0.62, fire(520, 1840, 80, 90, 3), flicker=0.2, rough=False),
        L(0.75, R(huddle) + ground(1830, "#10141C", "#080A0E", 8, 6) + f'<ellipse cx="560" cy="1845" rx="500" ry="30" fill="#DDE4EE" opacity=".2"/>'),
        ])
SC[15] = s15

# 16 BURNING REDUTO
def s16():
    return dict(light="#FFB060", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="embers",
        layers=[
        L(0.0, sky([(0, "#140606"), (0.5, "#5A1A0E"), (1, "#C8481C")])),
        L(0.2, glow(540, 1300, 900, "#FF7A2E", .55), mode="screen", flicker=0.12),
        L(0.3, fire(X0, 1450, BW, 520, 16), flicker=0.15, rough=False),
        L(0.35, clouds(900, "#3A2420", .6, seed=16, scale=1.5), drift=(20, -80)),
        L(0.5, R(palisade(1600, "#0A0404", h=300, seed=5) + "".join(cabin(x, 1560, .6, "#0A0404") for x in (240, 560, 880)) + forest(1560, "#0A0404", n=3, hmin=700, hmax=900, seed=161))),
        L(0.8, ground(1700, "#140806", "#060202", 20, 7) + R("".join(person(x, 1960, h, "#040202", "poncho", "brim", la=(100, 90), ra=(80, 90), face=-1) for x, h in [(200, 560), (880, 600)]))),
        ])
SC[16] = s16

# 17 ADEODATO captured
def s17():
    return dict(light="#F0EEE6", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#7A7C7C"), (0.6, "#B8B6AE"), (1, "#C8C2B4")]) + glow(540, 1100, 600, "#F4F0E6", .6)),
        L(0.2, forest(1250, "#9C9A92", n=12, hmin=400, hmax=560, seed=171) + f'<rect x="{X0}" y="1250" width="{BW}" height="900" fill="#9C9A92"/>' + fogband(1300, "#EEEAE0", .6, 240, 17)),
        L(0.45, R(forest(1450, "#50504C", n=6, hmin=800, hmax=1000, seed=172)) + ground(1440, "#6A665C", "#4A463E", 8, 1) + fogband(1500, "#E8E4DA", .35, 180, 18)),
        L(0.75, R(person(540, 1900, 820, "#0A0A0A", "poncho", "brim", la=(70, 20), ra=(110, 160), beard=True, face=1)
                  + person(210, 1880, 740, "#141414", "coat", "kepi", la=(100, 90), ra=(60, 20), prop=("rifle", -80, True), face=1)
                  + person(880, 1880, 740, "#141414", "coat", "kepi", la=(100, 90), ra=(120, 160), prop=("rifle", -100, True), face=-1)) + ground(1870, "#242420", "#121210", 10, 3)),
        ])
SC[17] = s17

# 18 CROSSES in mist + crows
def s18():
    r = random.Random(18); cr = []
    for k in range(60):
        row = k // 12; y = 1300 + row * 120 + r.uniform(-20, 20); s = 0.5 + row * 0.35
        cr.append(cross(r.uniform(X0 + 40, X1 - 40), y, s, mix("#6A6A64", "#141412", row / 4)))
    birds = "".join(f'<path d="M{x},{y} q{20*s},-{16*s} {40*s},0 q{20*s},-{16*s} {40*s},0" fill="none" stroke="{INK}" stroke-width="{5*s}"/>' for x, y, s in [(200, 500, 1.2), (380, 420, 0.9), (600, 560, 1.4), (760, 450, 1.0), (300, 650, 0.8)])
    return dict(light="#F0EEE6", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#8A8C8C"), (0.6, "#BDBCB6"), (1, "#CFCBC0")])),
        L(0.2, forest(1200, "#A4A29A", n=12, hmin=260, hmax=380, seed=181) + f'<rect x="{X0}" y="1200" width="{BW}" height="900" fill="#A4A29A"/>' + fogband(1230, "#F0EEE8", .6, 200, 19)),
        L(0.5, ground(1260, "#7A766C", "#3A3830", 30, 5) + R("".join(cr))),
        L(0.55, fogband(1500, "#EEECE6", .35, 220, 20), drift=(80, 0)),
        L(0.3, R(birds), drift=(140, -40)),
        ])
SC[18] = s18

# 19 ABANDONED STATION overgrown
def s19():
    r = random.Random(19)
    grass = "".join(f'<path d="M{x:.0f},{y:.0f} q{r.uniform(-8,8):.0f},-{h:.0f} {r.uniform(-18,18):.0f},-{h*1.3:.0f}" stroke="{c}" stroke-width="{w:.0f}" fill="none" stroke-linecap="round"/>' for x, y, h, c, w in [(r.uniform(X0, X1), r.uniform(1700, 2100), r.uniform(40, 140), r.choice(["#2A2A18", "#3A3A20", "#1A1A10"]), r.uniform(4, 9)) for _ in range(260)])
    station = (f'<g transform="translate(540,1450)"><rect x="-380" y="-360" width="760" height="360" fill="#8A7460"/><path d="M-440,-350 L0,-560 L440,-350 Z" fill="#5A4636"/><path d="M-440,-350 L-300,-380 L-60,-500 Z" fill="#3A2E24"/>'
               + "".join(f'<rect x="{-320+k*130}" y="-270" width="80" height="170" fill="#2A241E"/><path d="M{-320+k*130},-270 l30,60 l20,-40 l30,80" stroke="#8A7460" stroke-width="5" fill="none"/>' for k in range(5))
               + f'<rect x="-220" y="-330" width="440" height="56" fill="#D8CCB0"/><text x="0" y="-288" font-family="Old Standard TT" font-weight="700" font-size="40" text-anchor="middle" fill="#3A2E24" letter-spacing="6">ESTAÇÃO</text>'
               + "".join(f'<path d="M{-380+k*60},-360 q{r.uniform(-20,20):.0f},{r.uniform(60,160):.0f} {r.uniform(-10,10):.0f},{r.uniform(160,300):.0f}" stroke="#3A4A28" stroke-width="10" fill="none"/>' for k in range(6)) + '</g>')
    return dict(light="#FFE0A8", rim_dx=-5, cam=(1.0, 1.1, (-30, 0), (30, -20)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#E8C898"), (0.6, "#F0B070"), (1, "#E09058")]) + sun(180, 1100, 80, halo_r=700)),
        L(0.05, godrays(180, 1100, "#FFF0C8", n=12, spread=90, a0=-20, op=0.22, seed=19), mode="screen"),
        L(0.2, forest(1250, "#B88060", n=12, hmin=300, hmax=420, seed=191) + f'<rect x="{X0}" y="1250" width="{BW}" height="900" fill="#B88060"/>'),
        L(0.45, ground(1440, "#6A5A3A", "#4A3E28", 6, 3) + R(station)),
        L(0.7, rails(560, 1520, 2120, "#4A2E1C", "#3A2A1C", width=1500, n=24) + R(grass)),
        ])
SC[19] = s19

# 20 LONE ARAUCARIA heroic
def s20():
    return dict(light="#FFE0A0", rim_dx=5, cam=(1.0, 1.1, (0, 40), (0, -30)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#4A5A78"), (0.45, "#D89A78"), (0.75, "#F0A060"), (1, "#C86040")]) + sun(540, 1250, 120, halo_r=900)),
        L(0.05, godrays(540, 1250, "#FFEFC8", n=18, spread=200, a0=-90, op=0.3, seed=20), mode="screen"),
        L(0.1, clouds(600, "#F8D8C0", .5, seed=21, scale=1.6), drift=(50, 0)),
        L(0.3, forest(1500, "#9A4A3E", n=16, hmin=160, hmax=240, seed=201) + f'<rect x="{X0}" y="1500" width="{BW}" height="700" fill="#9A4A3E"/>'),
        L(0.6, R(f'<path d="M{X0},1760 C200,1560 800,1560 {X1},1760 L{X1},{Y1} L{X0},{Y1} Z" fill="#200C0A"/>' + araucaria(540, 1600, 1350, "#200C0A", 202))),
        L(0.5, R("".join(f'<path d="M{x},{y} q14,-12 28,0 q14,-12 28,0" fill="none" stroke="#200C0A" stroke-width="4"/>' for x, y in [(200, 700), (300, 640), (820, 760), (900, 700)])), drift=(120, -40)),
        ])
SC[20] = s20

# 21 END CARD: Rio 1904 Bota-Abaixo
def s21():
    bl = lambda x, w, h, c: f'<rect x="{x}" y="{1500-h}" width="{w}" height="{h}" fill="{c}"/>' + "".join(f'<rect x="{x+20+j*56}" y="{1500-h+40+k*90}" width="30" height="54" fill="{mix(c,"#000000",.35)}"/>' for j in range(int((w-30)//56)) for k in range(int((h-60)//90)))
    ruin = f'<path d="M380,1500 L380,1120 L440,1080 L480,1170 L540,1060 L600,1180 L660,1100 L700,1500 Z" fill="#6A4A34"/>'
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[
        L(0.0, sky([(0, "#A8C4D8"), (0.6, "#E8DCC0"), (1, "#F0D0A0")])),
        L(0.15, f'<g transform="translate(0,1150)"><path d="M700,0 C715,-230 760,-360 830,-370 C900,-360 935,-220 950,0 Z" fill="#8A9AA4"/><path d="M520,0 C560,-120 620,-150 680,-120 C700,-100 720,-60 740,0 Z" fill="#8A9AA4"/></g>' + haze(900, 1200, "#E8DCC0", .5)),
        L(0.3, bl(-100, 360, 520, "#C8A07A") + bl(760, 420, 600, "#B88A68") + ruin + ground(1490, "#8A6A50", "#5A4430", 4, 1)),
        L(0.35, clouds(1250, "#E0D0B8", .7, seed=22, scale=1.2), drift=(30, -70)),
        L(0.8, R("".join(person(160 + k * 250, 1900, 560, "#140E0A", "shirt", "brim", la=(-120, -160), ra=(-70, -40), lean=-20, face=1) + f'<line x1="{160+k*250+70}" y1="{1900-640}" x2="{160+k*250+190}" y2="{1900-420}" stroke="#140E0A" stroke-width="14"/><path d="M{160+k*250+40},{1900-660} L{160+k*250+110},{1900-610}" stroke="#140E0A" stroke-width="16"/>' for k in range(4))) + ground(1880, "#2A1E14", "#140E0A", 12, 2)),
        ])
SC[21] = s21
