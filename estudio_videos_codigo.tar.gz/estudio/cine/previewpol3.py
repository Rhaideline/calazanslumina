import sys, numpy as np, cv2
from scenes_pol3 import SC
from cine import render_layers, Particles
from cine2 import Scene, compose, post
ids = [int(a) for a in sys.argv[1:]] or sorted(SC)
render_layers(SC, ids, "layers_pol3")
tiles = []
for n in ids:
    sc = Scene(n, SC[n](), "layers_pol3"); fr = compose(sc, 0.9, 12.0)
    img = post(fr, 3.0, Particles(sc.sc.get("particles"), n), 10)
    cv2.imwrite(f"prevpol3/p{n:02d}.jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    tiles.append(cv2.resize(img, (270, 480)))
while len(tiles) % 6: tiles.append(np.zeros_like(tiles[0]))
rows = [np.hstack(tiles[i:i+6]) for i in range(0, len(tiles), 6)]
cv2.imwrite("prevpol3/sheet.jpg", cv2.cvtColor(np.vstack(rows), cv2.COLOR_RGB2BGR))
