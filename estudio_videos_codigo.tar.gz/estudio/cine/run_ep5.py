import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../ep5"; meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {8: 5, 11: 3}; flash = {8: [1, .3], 11: [0, .25], 13: [1, .12]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_ep5", "layers_cap", EP, str(a), str(b), f"ep5_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
m = meta[16]; s = m["start"]; d = m["speech"]
extra = [f"Dialogue: 2,{ts(s + d * f)},{ts(s + m['dur'] - 0.05)},Big,,0,0,0,,{{\\pos(540,{y})\\fs118\\fscx40\\fscy40\\t(0,160,\\fscx110\\fscy110)\\t(160,260,\\fscx100\\fscy100)}}{w}" for f, y, w in [(0.45, 640, "ACEITAVA?"), (0.7, 800, "OU RECUSAVA?")]]
m = meta[17]
extra.append(f"Dialogue: 3,{ts(m['start'])},{ts(total)},Chap,,0,0,0,,{{\\pos(40,150)\\fad(150,0)}}PRÓXIMO EPISÓDIO · O REI MUDA O JOGO")
make_ass(meta, total, "PORTUGAL FATIOU\\NO BRASIL\\NIGUAL PIZZA", "HISTÓRIA DO BRASIL · EPISÓDIO 5",
         {2: "CAPÍTULO 1 · O PLANO", 8: "CAPÍTULO 2 · O DESASTRE", 13: "CAPÍTULO 3 · O MAPA ERRADO"},
         {2: "1530", 4: "15 FAIXAS", 8: "900 HOMENS", 12: "SÓ 2", 14: "2013", 16: "1759"},
         extra, "ep5.ass")
make_audio(meta, total, EP, "ep5_mix.wav", booms=(8, 11, 13), sea=(2, 8, 10), fire=(11,), drum_boost=(1, 4, 8, 12, 13, 18))
for p in procs: p.wait()
open("ep5_list.txt", "w").write("".join(f"file 'ep5_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep5_list.txt", "-c", "copy", "ep5_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep5_raw.mp4", "-i", "ep5_mix.wav", "-vf", "ass=ep5.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1750k", "-maxrate", "2600k", "-bufsize", "4500k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "/home/claude/Historia_do_Brasil_Ep5.mp4"], check=True)
print("done", total)
