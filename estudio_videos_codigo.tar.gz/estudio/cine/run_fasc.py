import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../roteiros/fasc"; OUT = "../saida/Fascismo_Explicado.mp4"
meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {4: 3}; flash = {1: [0, .2], 7: [0, .15], 11: [1, .15]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_fasc", "layers_fasc", EP, str(a), str(b), f"fasc_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
extra = [f"Dialogue: 1,{ts(0)},{ts(total)},Cap,,0,0,0,,{{\\an2\\pos(540,1790)\\fnMontserrat\\fs28\\bord2\\shad0\\alpha&H30&}}Conteúdo produzido com auxílio de inteligência artificial · fontes na legenda"]
make_ass(meta, total, "O QUE FOI O\\NFASCISMO?", "HISTÓRIA SEM ENROLAÇÃO",
         {2: "1919 · O COMEÇO", 5: "1922 · O PODER", 10: "1938 · O PIOR", 12: "E O BRASIL?"}, {}, extra, "fasc.ass")
make_audio(meta, total, EP, "fasc_mix.wav", booms=(1, 7, 11), sea=(), fire=(11,), drum_boost=(1, 4, 11))
for p in procs: p.wait()
open("fasc_list.txt", "w").write("".join(f"file 'fasc_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "fasc_list.txt", "-c", "copy", "fasc_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "fasc_raw.mp4", "-i", "fasc_mix.wav", "-vf", "ass=fasc.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1900k", "-maxrate", "2800k", "-bufsize", "4800k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", OUT], check=True)
print("done", total)
