import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../roteiros/pol4"; OUT = "../saida/Reel_2turno_Historia_do_Perdao.mp4"
meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {2: 4}; flash = {2: [1, .15], 4: [0, .2], 8: [0, .2]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_pol4", "layers_pol4", EP, str(a), str(b), f"pol4_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
SRC = {1: "FONTE: Lei 6.683/1979 · STF 2025", 2: "FONTE: STF, set/2025", 3: "FONTE: entrevistas de Flávio · InfoMoney · SBT News",
       4: "FONTE: Polícia Federal · A Pública", 5: "FONTE: Intercept Brasil", 6: "FONTE: PF · A Pública · Carta Capital",
       7: "FONTE: Aos Fatos · Intercept Brasil", 8: "FONTE: STF, inquérito do min. André Mendonça · CNN Brasil",
       9: "FONTE: plano de governo de Flávio · Agência Brasil", 10: "FONTE: plano de governo de Flávio · Agência Brasil",
       11: "FONTE: Folha · Gazeta SP (aposentadorias aos 75 anos)", 13: "FONTE: tse.jus.br"}
extra = [f"Dialogue: 1,{ts(m['start'])},{ts(m['start'] + m['dur'])},Cap,,0,0,0,,{{\\an2\\pos(540,1690)\\fnMontserrat\\fs38\\bord3\\shad0\\fad(120,120)}}{SRC[m['i']]}" for m in meta if m["i"] in SRC]
extra.append(f"Dialogue: 1,{ts(0)},{ts(total)},Cap,,0,0,0,,{{\\an2\\pos(540,1790)\\fnMontserrat\\fs30\\bord2\\shad0\\alpha&H30&}}Conteúdo produzido com auxílio de inteligência artificial")
make_ass(meta, total, "O PERDÃO QUE O\\NBRASIL JÁ DEU", "2º TURNO · 25 DE OUTUBRO",
         {2: "2025 · A PRIMEIRA VEZ", 4: "O BANQUEIRO", 9: "O PLANO DE GOVERNO"}, {}, extra, "pol4.ass")
make_audio(meta, total, EP, "pol4_mix.wav", booms=(2, 4, 8), sea=(), fire=(), drum_boost=(2, 4, 8, 11, 12))
for p in procs: p.wait()
open("pol4_list.txt", "w").write("".join(f"file 'pol4_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "pol4_list.txt", "-c", "copy", "pol4_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "pol4_raw.mp4", "-i", "pol4_mix.wav", "-vf", "ass=pol4.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1600k", "-maxrate", "2600k", "-bufsize", "4500k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", OUT], check=True)
print("done", total)
