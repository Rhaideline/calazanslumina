from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep1 import caatinga, maloca
import random, math

def jtree(x, y, h, col, seed=1):
    r = random.Random(seed); tw = h * 0.035
    g = [f'<path d="M{x-tw*2.2},{y} Q{x-tw},{y-h*0.1} {x-tw*0.7},{y-h*0.3} L{x-tw*0.5},{y-h*0.75} L{x+tw*0.5},{y-h*0.75} L{x+tw*0.7},{y-h*0.3} Q{x+tw},{y-h*0.1} {x+tw*2.2},{y} Z" fill="{col}"/>']
    for k in range(9):
        a = r.uniform(-1, 1); cx = x + a * h * 0.28; cy = y - h * (0.78 + r.uniform(-0.08, 0.12)) - (1 - abs(a)) * h * 0.08
        g.append(f'<ellipse cx="{cx:.0f}" cy="{cy:.0f}" rx="{h*r.uniform(0.12,0.2):.0f}" ry="{h*r.uniform(0.07,0.11):.0f}" fill="{col}"/>')
    g.append(f'<path d="M{x},{y-h*0.6} Q{x+h*0.1},{y-h*0.7} {x+h*0.2},{y-h*0.78} M{x},{y-h*0.65} Q{x-h*0.1},{y-h*0.72} {x-h*0.2},{y-h*0.8}" stroke="{col}" stroke-width="{tw*0.7:.0f}" fill="none"/>')
    return "".join(g)

def palm(x, y, h, col, seed=1):
    r = random.Random(seed); g = [f'<path d="M{x-4},{y} Q{x+h*0.03},{y-h*0.5} {x+h*0.02},{y-h} L{x+h*0.02+6},{y-h} Q{x+h*0.03+6},{y-h*0.5} {x+4},{y} Z" fill="{col}"/>']
    tx, ty = x + h * 0.02, y - h
    for k in range(9):
        a = math.radians(-180 + k * 22 + r.uniform(-6, 6)); L_ = h * 0.28
        ex, ey = tx + L_ * math.cos(a), ty + L_ * math.sin(a) + L_ * 0.35
        g.append(f'<path d="M{tx:.0f},{ty:.0f} Q{tx+L_*0.6*math.cos(a):.0f},{ty+L_*0.6*math.sin(a)-L_*0.1:.0f} {ex:.0f},{ey:.0f}" stroke="{col}" stroke-width="{h*0.012:.1f}" fill="none"/>')
        for j in range(8):
            t = 0.2 + j * 0.1; px, py = tx + (ex - tx) * t, ty + (ey - ty) * t - math.sin(t * 3.14) * L_ * 0.12
            g.append(f'<line x1="{px:.0f}" y1="{py:.0f}" x2="{px+8:.0f}" y2="{py+h*0.06:.0f}" stroke="{col}" stroke-width="{h*0.006:.1f}"/>')
    return "".join(g)

def jungle(y, col, n=10, hmin=400, hmax=700, seed=1, palms=3):
    r = random.Random(seed); g = []
    for i in range(n): g.append(jtree(X0 + (X1 - X0) * (i + r.uniform(0, 1)) / n, y + r.uniform(-20, 20), r.uniform(hmin, hmax), col, seed * 50 + i))
    for i in range(palms): g.append(palm(r.uniform(X0, X1), y + r.uniform(0, 30), r.uniform(hmin * 0.8, hmax * 0.9), col, seed * 70 + i))
    return "".join(g) + f'<rect x="{X0}" y="{y}" width="{BW}" height="{Y1-y}" fill="{col}"/>'

def canopy_top(col_list, seed=1, y0=Y0, y1=Y1, n=500, rmin=30, rmax=80):
    r = random.Random(seed)
    return "".join((lambda x, y, rr, c: f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{rr:.0f}" fill="{c}"/><circle cx="{x-rr*0.3:.0f}" cy="{y-rr*0.3:.0f}" r="{rr*0.5:.0f}" fill="{mix(c,"#C8E0A0",.25)}"/>')(r.uniform(X0, X1), r.uniform(y0, y1), r.uniform(rmin, rmax), r.choice(col_list)) for _ in range(n))

def manioc(x, y, h, col):
    g = [f'<path d="M{x},{y} L{x+h*0.05},{y-h}" stroke="{col}" stroke-width="{h*0.025:.0f}"/>']
    for k in range(4):
        cx, cy = x + h * 0.05 * (1 - k * 0.2), y - h * (0.55 + k * 0.15)
        for j in range(7):
            a = math.radians(-160 + j * 23 + k * 7); L_ = h * 0.22
            ex, ey = cx + L_ * math.cos(a), cy + L_ * math.sin(a)
            g.append(f'<path d="M{cx:.0f},{cy:.0f} Q{cx+L_*0.5*math.cos(a-0.25):.0f},{cy+L_*0.5*math.sin(a-0.25):.0f} {ex:.0f},{ey:.0f} Q{cx+L_*0.5*math.cos(a+0.25):.0f},{cy+L_*0.5*math.sin(a+0.25):.0f} {cx:.0f},{cy:.0f} Z" fill="{col}"/>')
    return "".join(g)

def roots(x, y, s, col="#C88A58"):
    return "".join(f'<path transform="translate({x},{y}) rotate({a}) scale({s})" d="M0,0 C20,40 30,140 10,230 C0,250 -10,250 -12,230 C-20,140 -18,40 0,0 Z" fill="{col}" stroke="#6A3E1E" stroke-width="4"/>' for a in (-40, -15, 10, 35))

def tipiti(x, y, s, col="#B8905A", dark="#6A4A2A"):
    return (f'<g transform="translate({x},{y}) scale({s})"><line x1="0" y1="-200" x2="0" y2="0" stroke="{dark}" stroke-width="10"/><rect x="-40" y="0" width="80" height="520" rx="40" fill="{col}"/>'
            + "".join(f'<line x1="-40" y1="{k*26}" x2="40" y2="{k*26+40}" stroke="{dark}" stroke-width="4"/><line x1="40" y1="{k*26}" x2="-40" y2="{k*26+40}" stroke="{dark}" stroke-width="4"/>' for k in range(19))
            + f'<line x1="0" y1="520" x2="0" y2="640" stroke="{dark}" stroke-width="10"/><rect x="-60" y="640" width="120" height="70" rx="14" fill="{dark}"/></g>')

def oca(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-260,0 C-260,-120 -170,-230 0,-240 C170,-230 260,-120 260,0 Z" fill="{col}"/>'
            + "".join(f'<path d="M{-250+k*25},0 C{-240+k*22},-90 {-150+k*12},-190 0,-236" stroke="{mix(col,"#000000",.2)}" stroke-width="3" fill="none"/>' for k in range(20))
            + f'<path d="M-30,0 L-30,-80 Q0,-100 30,-80 L30,0 Z" fill="{mix(col,"#000000",.55)}"/></g>')

def plane_small(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-150,0 C-120,-18 120,-20 170,-6 L180,8 C120,18 -120,18 -150,8 Z" fill="{col}"/>'
            f'<path d="M-40,-4 L-10,-110 L40,-110 L30,-4 Z" fill="{col}"/><path d="M-40,8 L-10,110 L40,110 L30,8 Z" fill="{col}" opacity=".8"/>'
            f'<path d="M-140,0 L-170,-50 L-140,-50 L-110,-4 Z" fill="{col}"/></g>')

S = {}
def e1():
    smokes = "".join(f'<path d="M{x},{y} C{x-20},{y-120} {x+30},{y-220} {x},{y-360}" stroke="#E8ECE8" stroke-width="{w}" fill="none" opacity=".45" filter="url(#blur6)"/>' for x, y, w in [(260, 1260, 22), (720, 1330, 26), (900, 1190, 18)])
    return dict(light="#FFF0C8", rim_dx=4, cam=(1.0, 1.1, (0, 40), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#8AA0A8"), (0.5, "#E8D8B0"), (1, "#F0C890")]) + sun(700, 980, 80, halo_r=700)),
                L(0.05, godrays(700, 980, "#FFF3D0", n=12, spread=150, a0=-90, op=.22, seed=1), mode="screen"),
                L(0.2, canopy_top(["#6A8A5A", "#7A9A64", "#5E7E52"], 1, 1050, 1300, 160, 30, 60) + fogband(1080, "#FFFFFF", .55, 200, 1)),
                L(0.35, f'<path d="M{X0},1560 C200,1480 400,1600 560,1520 C720,1440 900,1560 {X1},1480 L{X1},1560 C900,1640 700,1520 560,1600 C400,1680 200,1560 {X0},1640 Z" fill="#E8C898" opacity=".85"/>' + smokes),
                L(0.55, canopy_top(["#3A5A34", "#2E4A2A", "#44663C"], 2, 1400, 1900, 170, 50, 110)),
                L(0.9, canopy_top(["#1A2E1A", "#16281A", "#22381E"], 3, 1780, 2115, 60, 110, 190), drift=(0, -30))])
S[1] = e1
def e2():
    canoe = f'<path d="M340,1520 Q540,1560 760,1520 L740,1545 Q540,1580 360,1545 Z" fill="{INK}"/>' + person(470, 1525, 150, INK, "shirt", "hair", la=(40, 60), ra=(40, 70), ll=(-10, 80), rl=(10, 95), face=1) + f'<line x1="520" y1="1420" x2="600" y2="1570" stroke="{INK}" stroke-width="6"/>'
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.1, (0, 30), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8B880"), (0.5, "#F0A060"), (1, "#E08A58")]) + sun(540, 1150, 100, halo_r=800)),
                L(0.05, godrays(540, 1150, "#FFEFC8", n=14, spread=170, a0=-90, op=.26, seed=2), mode="screen"),
                L(0.25, jungle(1260, "#9A6048", 14, 220, 360, 21, 4)),
                L(0.4, f'<rect x="{X0}" y="1380" width="{BW}" height="800" fill="#C88A60"/>' + "".join(f'<path d="M{X0},{1400+k*28} q300,-6 650,0 t650,0" stroke="#FFE0B0" stroke-width="3" fill="none" opacity="{0.5-k*0.03:.2f}"/>' for k in range(15)) + R(canoe), drift=(40, 0)),
                L(0.8, R(jungle(1800, "#2A140E", 5, 800, 1100, 22, 2)) if False else R(palm(40, 2100, 1300, "#1E0E0A", 23) + palm(1060, 2100, 1100, "#1E0E0A", 24) + jtree(-60, 2100, 1600, "#1E0E0A", 25)))])
S[2] = e2
def e3():
    section = (f'<rect x="{X0}" y="1250" width="{BW}" height="900" fill="#8A4A2A"/>' + "".join(f'<ellipse cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+1).randint(1300,2100)}" rx="{random.Random(k+2).randint(8,30)}" ry="{random.Random(k+3).randint(4,12)}" fill="#6A3A20" opacity=".6"/>' for k in range(90))
               + roots(300, 1260, 1.3) + roots(700, 1260, 1.2))
    return dict(light="#FFF0C8", rim_dx=5, cam=(1.0, 1.1, (0, -30), (0, 40)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C8D8"), (0.6, "#E8E0C0"), (1, "#F0D0A0")]) + sun(820, 600, 70, halo_r=500)),
                L(0.2, jungle(1150, "#7A9A6A", 12, 280, 420, 31, 3)),
                L(0.5, section, rough=False),
                L(0.6, R(manioc(300, 1260, 520, "#2A3A1E") + manioc(700, 1260, 480, "#2A3A1E") + person(900, 1260, 380, "#1A1410", "dress", "hair", la=(80, 60), ra=(100, 120), face=-1)))])
S[3] = e3
def e4():
    beam = f'<rect x="{X0}" y="560" width="{BW}" height="30" fill="#2A1A10"/>'
    return dict(light="#FFB060", rim_dx=5, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#2A1C14"), (1, "#4A3020")]) + glow(620, 1500, 900, "#FF9A50", .5)),
                L(0.2, glow(640, 1640, 500, "#FFB060", .6), mode="screen", flicker=0.2),
                L(0.3, fire(520, 1700, 240, 160, 4), flicker=0.2, rough=False),
                L(0.5, beam + tipiti(300, 590, 1.0) + f'<ellipse cx="640" cy="1600" rx="230" ry="36" fill="#1A120C"/><ellipse cx="640" cy="1590" rx="200" ry="24" fill="#E8D8B0"/>' + R(person(820, 1850, 620, "#0E0806", "dress", "hair", la=(120, 170), ra=(140, 180), face=-1)) + ground(1700, "#1A120C", "#0E0806", 6, 2))])
S[4] = e4
def e5():
    r = random.Random(5); dots = "".join(f'<circle cx="{540+400*math.cos(a)*math.cos(b):.0f}" cy="{960+400*math.sin(b):.0f}" r="{r.uniform(4,10):.0f}" fill="#FFD27A"/>' for a, b in [(r.uniform(-1.5, 1.5), r.uniform(-1.2, 1.2)) for _ in range(160)])
    globe = f'<circle cx="540" cy="960" r="400" fill="#1E3A5A"/>' + "".join(f'<ellipse cx="540" cy="960" rx="{400*abs(math.cos(k*0.35)):.0f}" ry="400" fill="none" stroke="#3A5A7A" stroke-width="3"/>' for k in range(9)) + "".join(f'<ellipse cx="540" cy="{960+400*math.sin(k*0.35-1.4):.0f}" rx="{400*math.cos(k*0.35-1.4):.0f}" ry="{40*math.cos(k*0.35-1.4):.0f}" fill="none" stroke="#3A5A7A" stroke-width="3"/>' for k in range(9))
    return dict(light="#C8F0FF", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#06101C"), (1, "#0E2034")]) + glow(540, 960, 700, "#3A7AB8", .4)), L(0.3, globe, rough=False), L(0.32, dots, mode="screen", rough=False, flicker=0.1)])
S[5] = e5
def e6():
    peanuts = "".join(f'<g transform="translate({x},{y}) rotate({a})"><ellipse cx="-22" cy="0" rx="30" ry="22" fill="#D8B078"/><ellipse cx="22" cy="0" rx="30" ry="22" fill="#D8B078"/></g>' for x, y, a in [(220, 1500, 20), (300, 1560, -30), (180, 1600, 60)])
    pupunha = "".join(f'<circle cx="{560+ (k%5)*42 - (k//5)*10}" cy="{1250 + (k//5)*40}" r="26" fill="{["#E0602A","#F08A30","#C8401E"][k%3]}"/>' for k in range(25))
    pepper = "".join(f'<path d="M{x},{y} q30,-10 70,30 q-30,20 -70,-30" fill="#D8201E" transform="rotate({a} {x} {y})"/>' for x, y, a in [(760, 1560, 10), (820, 1610, 40), (720, 1640, -20)])
    urucum = "".join(f'<g transform="translate({x},{y})"><path d="M0,-70 C50,-30 50,30 0,70 C-50,30 -50,-30 0,-70 Z" fill="#B8281E"/>' + "".join(f'<line x1="{30*math.cos(t):.0f}" y1="{55*math.sin(t):.0f}" x2="{44*math.cos(t):.0f}" y2="{70*math.sin(t):.0f}" stroke="#B8281E" stroke-width="4"/>' for t in [i * 0.5 for i in range(13)]) + '</g>' for x, y in [(860, 1320), (960, 1400)])
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A2418"), (1, "#5A3822")]) + glow(560, 1350, 800, "#FFCF8A", .45)),
                L(0.4, f'<ellipse cx="560" cy="1620" rx="560" ry="120" fill="#2A1A10"/>' + manioc(120, 1700, 420, "#2A3A1E") + peanuts + f'<path d="M520,1300 L700,1180" stroke="#5A3A1E" stroke-width="10"/>' + pupunha + pepper + urucum, rough=False)])
S[6] = e6
def e7():
    sherds = "".join(f'<path d="M{x},{y} l40,-10 l20,30 l-50,15 Z" fill="#B87A48" transform="rotate({a} {x} {y})"/>' for x, y, a in [(random.Random(k).randint(80, 1000), random.Random(k + 1).randint(1350, 1600), random.Random(k + 2).randint(0, 90)) for k in range(14)])
    section = (f'<rect x="{X0}" y="1300" width="{BW}" height="360" fill="#1A1410"/>' + sherds + f'<rect x="{X0}" y="1660" width="{BW}" height="600" fill="#C8783A"/>'
               + "".join(f'<ellipse cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+5).randint(1700,2100)}" rx="{random.Random(k+2).randint(8,24)}" ry="6" fill="#A85A2A"/>' for k in range(60))
               + f'<text x="80" y="1460" font-family="Anton" font-size="62" fill="#E8D8B0">TERRA PRETA</text><text x="80" y="1790" font-family="Anton" font-size="52" fill="#5A2A10">SOLO COMUM</text>')
    return dict(light="#FFF0C8", rim_dx=5, cam=(1.0, 1.1, (0, -40), (0, 50)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C0A8"), (1, "#E8E0C0")])), L(0.2, jungle(1200, "#6A8A5A", 12, 300, 460, 71, 3)),
                L(0.5, section + R(manioc(760, 1300, 420, "#1E2E16") + manioc(930, 1300, 380, "#1E2E16")), rough=False)])
S[7] = e7
def e8():
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 0), (20, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#E0C090"), (0.6, "#F0B070"), (1, "#E09058")]) + sun(820, 1000, 80, halo_r=600)),
                L(0.2, jungle(1250, "#9A6A4A", 12, 260, 380, 81, 3)),
                L(0.45, R(oca(300, 1450, 0.9, "#6A4A2A") + oca(820, 1470, 0.7, "#6A4A2A")) + ground(1440, "#7A5A3A", "#5A3E28", 6, 1)),
                L(0.52, smoke_puffs(560, 1500, "#D8D0C8", n=7, s=0.8, seed=8, drift=1), drift=(20, -50)),
                L(0.75, f'<ellipse cx="560" cy="1700" rx="200" ry="60" fill="#140C08"/>' + R(person(360, 1780, 460, "#0E0806", "dress", "hair", la=(40, 60), ra=(20, 50), lean=40, face=1) + person(760, 1790, 480, "#0E0806", "shirt", "hair", la=(120, 90), ra=(150, 100), lean=-30, face=-1)) + ground(1760, "#2A1A10", "#140C08", 8, 2))])
S[8] = e8
def e9():
    r = random.Random(9); ring = "".join(oca(540 + 360 * math.cos(a), 1320 + 170 * math.sin(a), 0.28 + 0.1 * (math.sin(a) + 1) / 2, "#6A4A2A") for a in sorted([k * 2 * math.pi / 12 for k in range(12)], key=lambda a: math.sin(a)))
    people = "".join(person(540 + r.uniform(-200, 200), 1320 + r.uniform(-60, 80), r.uniform(60, 90), "#1A120C", r.choice(["shirt", "dress"]), "hair", face=r.choice([1, -1])) for _ in range(30))
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.12, (0, 40), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8C898"), (1, "#F0B070")]) + sun(300, 800, 70, halo_r=600)),
                L(0.2, jungle(1150, "#8A6A48", 14, 240, 380, 91, 4)),
                L(0.4, f'<ellipse cx="540" cy="1330" rx="560" ry="260" fill="#C8A070"/>' + f'<ellipse cx="540" cy="1330" rx="300" ry="130" fill="#D8B888"/>' + R(ring + people))])
S[9] = e9
def e10():
    beams = "".join(f'<path d="M540,640 L{540+k*120-600},{1500} L{540+k*120-560},{1500} Z" fill="#6AFF8A" opacity=".18"/>' for k in range(10))
    pts = "".join(f'<circle cx="{random.Random(k).randint(0,1080)}" cy="{random.Random(k+1).randint(1380,1560)}" r="3" fill="#8AFFA0"/>' for k in range(200))
    return dict(light="#E8F4E0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles=None,
        layers=[L(0.0, sky([(0, "#0E1A28"), (0.6, "#2A4A48"), (1, "#5A7A60")])),
                L(0.2, canopy_top(["#1E3A24", "#2A4A2A", "#16301C"], 10, 1350, 2115, 300, 50, 110)),
                L(0.4, beams + pts, mode="screen", flicker=0.2, rough=False),
                L(0.5, R(plane_small(540, 640, 1.4, "#0A0E10")), drift=(80, 0))])
S[10] = e10
def e11():
    base = f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#16301C"/>' + canopy_top(["#1E3A24", "#2A4A2A", "#16301C"], 11, Y0, Y1, 900, 30, 70)
    works = f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#0A1A10" opacity=".75"/>' + "".join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="#8AFFA0" stroke-width="10"/>' for x, y, r in [(300, 600, 150), (760, 900, 210), (380, 1350, 180), (820, 1600, 130)]) + f'<rect x="560" y="400" width="300" height="300" fill="none" stroke="#8AFFA0" stroke-width="10"/><path d="M300,750 L380,1170 M760,1110 L820,1470 M450,1350 L620,900" stroke="#8AFFA0" stroke-width="6" stroke-dasharray="20 12"/>'
    return dict(light="#E8F4E0", rim_dx=4, cam=(1.05, 1.0, (0, 40), (0, -40)), particles=None,
        layers=[L(0.0, base, rough=False), L(0.1, works, reveal=(0.4, 3.0, "ltr"), rough=False)])
S[11] = e11
def e12():
    return dict(light="#FFF0C8", rim_dx=-5, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#B8D0B0"), (0.6, "#E8E8C8"), (1, "#E8D8A8")]) + glow(260, 400, 900, "#FFF6DA", .55)),
                L(0.1, godrays(200, 200, "#FFF8E0", n=10, spread=40, a0=62, op=.32, seed=12), mode="screen"),
                L(0.3, jungle(1250, "#8AA07A", 12, 400, 600, 121, 5) + fogband(1250, "#F2F2E6", .5, 220, 12)),
                L(0.6, R(jtree(260, 1900, 1500, "#1E2A18", 122) + palm(640, 1900, 1100, "#1E2A18", 123) + palm(760, 1900, 1000, "#1E2A18", 124) + jtree(960, 1900, 1200, "#1E2A18", 125)) + ground(1880, "#2A3420", "#1A2014", 10, 3))])
S[12] = e12
def e13():
    past = f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#A8B060"/>' + "".join(f'<ellipse cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+1).randint(Y0,Y1)}" rx="{random.Random(k+2).randint(60,200)}" ry="{random.Random(k+3).randint(20,60)}" fill="#98A058" opacity=".6"/>' for k in range(60))
    glyph = (f'<circle cx="400" cy="800" r="300" fill="none" stroke="#6A4A2A" stroke-width="40"/><circle cx="400" cy="800" r="300" fill="none" stroke="#C89A60" stroke-width="12"/>'
             f'<rect x="520" y="1200" width="440" height="440" fill="none" stroke="#6A4A2A" stroke-width="40"/><rect x="520" y="1200" width="440" height="440" fill="none" stroke="#C89A60" stroke-width="12"/>'
             f'<circle cx="740" cy="1420" r="150" fill="none" stroke="#6A4A2A" stroke-width="30"/><path d="M620,1000 L680,1200" stroke="#6A4A2A" stroke-width="30"/>')
    trees = canopy_top(["#1E3A24", "#2A4A2A"], 13, Y0, 250, 120, 50, 90) + canopy_top(["#1E3A24", "#2A4A2A"], 14, 1750, Y1, 120, 50, 90)
    return dict(light="#FFF0C8", rim_dx=4, cam=(1.06, 1.0, (0, 40), (0, -40)), particles=None,
        layers=[L(0.0, past, rough=False), L(0.05, glyph, reveal=(0.5, 3.0, "ltr")), L(0.2, trees, rough=False)])
S[13] = e13
def e14():
    return dict(light="#FFB070", rim_dx=5, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#2A2040"), (0.6, "#A85A48"), (1, "#E0904A")])),
                L(0.2, jungle(1250, "#4A2A28", 14, 260, 380, 141, 4)),
                L(0.4, f'<ellipse cx="540" cy="1500" rx="560" ry="200" fill="none" stroke="#2A1810" stroke-width="40"/><ellipse cx="540" cy="1500" rx="560" ry="200" fill="#6A4030"/>' + glow(540, 1500, 400, "#FF9A50", .5)),
                L(0.45, fire(490, 1510, 100, 170, 14), flicker=0.2, rough=False),
                L(0.6, R("".join(person(540 + 380 * math.cos(a), 1500 + 150 * math.sin(a), 180 + 60 * (math.sin(a) + 1) / 2, "#140A08", "shirt", "hair", la=(-120, -140), ra=(-60, -40), face=1 if math.cos(a) < 0 else -1) for a in sorted([k * 2 * math.pi / 14 for k in range(14)], key=lambda a: math.sin(a)))))])
S[14] = e14
def e15():
    base = f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#2A4A2A"/>' + canopy_top(["#244426", "#2E5230", "#1E3A20"], 15, Y0, Y1, 700, 30, 60)
    plazas = [(300, 500), (760, 800), (360, 1250), (800, 1550)]
    plan_ = f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#0E1A10" opacity=".35"/>'
    for (x1, y1), (x2, y2) in zip(plazas, plazas[1:]): plan_ += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#D8B878" stroke-width="22"/>'
    for x, y in plazas:
        plan_ += f'<circle cx="{x}" cy="{y}" r="150" fill="#C8A070"/><circle cx="{x}" cy="{y}" r="210" fill="none" stroke="#5A3A20" stroke-width="18" stroke-dasharray="40 16"/>' + "".join(f'<circle cx="{x+120*math.cos(k*0.52):.0f}" cy="{y+120*math.sin(k*0.52):.0f}" r="16" fill="#6A4A2A"/>' for k in range(12))
    plan_ += f'<ellipse cx="820" cy="300" rx="130" ry="70" fill="#3A7A98"/><ellipse cx="220" cy="1700" rx="120" ry="60" fill="#3A7A98"/>'
    return dict(light="#FFF0C8", rim_dx=4, cam=(1.06, 1.0, (0, 60), (0, -40)), particles=None,
        layers=[L(0.0, base, rough=False), L(0.1, plan_, reveal=(0.4, 3.5, "ltr"), rough=False)])
S[15] = e15
def e16():
    return dict(light="#FFE6B0", rim_dx=-5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8C090"), (0.6, "#F0A870"), (1, "#E09058")]) + sun(200, 1050, 80, halo_r=700)),
                L(0.05, godrays(200, 1050, "#FFEFC8", n=12, spread=90, a0=-20, op=.24, seed=16), mode="screen"),
                L(0.25, jungle(1300, "#9A6048", 14, 260, 380, 161, 4)),
                L(0.5, R(oca(220, 1560, 0.7, "#4A3020") + oca(620, 1520, 0.9, "#4A3020") + oca(980, 1580, 0.6, "#4A3020")) + ground(1550, "#8A6040", "#5A3E28", 6, 1)),
                L(0.8, R("".join(person(160 + k * 200, 1920 + (k % 2) * 20, 480 + (k % 3) * 40, "#140A08", "shirt" if k % 2 else "dress", "hair", la=(100, 90), ra=(80, 85), face=1 if k < 3 else -1) for k in range(5))) + ground(1900, "#2A1A10", "#140A08", 10, 2))])
S[16] = e16
def e17():
    return dict(light="#E8F0E0", rim_dx=4, cam=(1.0, 1.12, (-20, 0), (20, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A7A70"), (0.6, "#A8B8A8"), (1, "#C8D0C0")])),
                L(0.2, jungle(1150, "#8A9A88", 12, 500, 700, 171, 4) + fogband(1200, "#E8ECE4", .6, 260, 17)),
                L(0.45, R(jungle(1400, "#4A5A48", 7, 800, 1000, 172, 3)) + fogband(1450, "#DDE4DA", .4, 200, 18)),
                L(0.8, R(person(560, 1880, 820, "#0A0C0A", "shirt", "brim", la=(100, 110), ra=(-40, -80), prop=("facao", -60), face=1) + palm(80, 2100, 1400, "#0A0C0A", 173) + jtree(1100, 2100, 1600, "#0A0C0A", 174)) + ground(1860, "#1A201A", "#0A0C0A", 10, 3))])
S[17] = e17
def e18():
    return dict(light="#FFF0C8", rim_dx=6, cam=(1.0, 1.1, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#E0C890"), (0.5, "#F0B070"), (1, "#E89060")]) + sun(700, 1100, 110, halo_r=900)),
                L(0.05, godrays(700, 1100, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=18), mode="screen"),
                L(0.2, canopy_top(["#A87A50", "#B8885A"], 18, 1250, 1400, 120, 40, 70) + fogband(1260, "#FFE8C8", .5, 180, 19)),
                L(0.4, canopy_top(["#6A4A30", "#7A5638", "#5E4028"], 19, 1380, 1700, 150, 60, 110)),
                L(0.8, R(person(760, 1950, 900, "#140A06", "shirt", "hair", la=(100, 90), ra=(80, 85), face=-1) + jtree(-80, 2100, 1800, "#140A06", 181)) + canopy_top(["#1E1208", "#241608"], 20, 1750, 2115, 50, 120, 200))])
S[18] = e18
def e19():
    mound = f'<path d="M100,1500 C200,1300 350,1150 540,1130 C730,1150 880,1300 980,1500 Z" fill="#E8DCC4"/>' + "".join(f'<path d="M{random.Random(k).randint(200,880)},{random.Random(k+1).randint(1200,1480)} q10,-8 20,0" stroke="#B8A888" stroke-width="4" fill="none"/>' for k in range(160))
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A6A88"), (0.5, "#E8A888"), (1, "#F0C8A0")]) + sun(820, 1100, 80, halo_r=700)),
                L(0.2, f'<rect x="{X0}" y="1250" width="{BW}" height="900" fill="#6A8AA0"/>' + "".join(f'<path d="M{X0},{1270+k*30} q300,-6 650,0 t650,0" stroke="#FFE8C8" stroke-width="3" fill="none" opacity="{0.5-k*0.03:.2f}"/>' for k in range(12))),
                L(0.45, R(mound) + ground(1490, "#D8C8A0", "#B8A078", 6, 2)),
                L(0.8, R(person(300, 1900, 520, "#1A120C", "shirt", "hair", la=(100, 90), ra=(-60, -90), prop=("staff",), face=1)) + ground(1880, "#3A2E20", "#1A140C", 10, 2))])
S[19] = e19
SC = S
