from art import *
from scenes_v2 import L, R, Rr, INK
import random, math

def cliffs(y, col, seed=1, h=520, n=5, flat=True):
    r = random.Random(seed); g = []; x = X0
    while x < X1:
        w = r.uniform(180, 380); hh = h * r.uniform(0.6, 1.1)
        top = y - hh
        g.append(f'<path d="M{x-10:.0f},{y} L{x+10:.0f},{top+30:.0f} Q{x+w*0.1:.0f},{top:.0f} {x+w*0.3:.0f},{top+r.uniform(-15,15):.0f} L{x+w*0.75:.0f},{top+r.uniform(-15,15):.0f} Q{x+w*0.9:.0f},{top:.0f} {x+w+5:.0f},{top+40:.0f} L{x+w+10:.0f},{y} Z" fill="{col}"/>')
        for k in range(4):
            yy = top + hh * (0.2 + k * 0.2)
            g.append(f'<line x1="{x+15:.0f}" y1="{yy:.0f}" x2="{x+w:.0f}" y2="{yy+r.uniform(-6,6):.0f}" stroke="{mix(col,"#000000",0.18)}" stroke-width="{r.uniform(2,5):.1f}"/>')
        x += w * r.uniform(0.7, 0.95)
    return f'<rect x="{X0}" y="{y}" width="{BW}" height="{Y1-y}" fill="{col}"/>' + "".join(g)

def caatinga(y, col, n=14, seed=1, hmin=60, hmax=160):
    r = random.Random(seed); g = []
    for i in range(n):
        x = r.uniform(X0, X1); h = r.uniform(hmin, hmax)
        g.append(f'<g stroke="{col}" stroke-linecap="round" fill="none">' + "".join(f'<path d="M{x:.0f},{y} q{r.uniform(-30,30):.0f},-{h*0.5:.0f} {r.uniform(-h*0.5,h*0.5):.0f},-{h*r.uniform(0.7,1):.0f}" stroke-width="{r.uniform(3,7):.1f}"/>' for _ in range(5)) + '</g>')
        g.append(f'<ellipse cx="{x:.0f}" cy="{y-h*0.8:.0f}" rx="{h*0.5:.0f}" ry="{h*0.25:.0f}" fill="{col}" opacity=".85"/>')
    return "".join(g)

def mammoth(x, y, s, col, face=1):
    return (f'<g transform="translate({x},{y}) scale({s*face},{s})">'
            f'<path d="M-160,-60 C-170,-200 -60,-260 40,-250 C120,-245 170,-200 190,-150 C230,-140 250,-90 240,-40 C236,20 230,80 250,150 L215,150 C200,90 196,40 190,0 L150,-10 L150,150 L110,150 L105,-20 L-60,-20 L-70,150 L-110,150 L-115,-10 L-130,150 L-165,150 Z" fill="{col}"/>'
            f'<path d="M240,-60 C280,0 270,90 300,140 C305,150 290,158 285,148 C250,90 250,20 225,-20 Z" fill="{col}"/>'
            f'<path d="M225,-30 C300,-20 330,40 300,90" fill="none" stroke="#E8DCC4" stroke-width="12" stroke-linecap="round"/>'
            + "".join(f'<path d="M{-150+k*28},-40 l-6,70" stroke="{col}" stroke-width="10"/>' for k in range(10)) + '</g>')

def sloth(x, y, s, col, face=1):
    return (f'<g transform="translate({x},{y}) scale({s*face},{s})">'
            f'<path d="M-150,0 C-190,-60 -200,-160 -170,-260 C-140,-360 -70,-420 10,-430 C70,-436 110,-400 115,-350 C120,-280 100,-200 90,-120 C85,-70 90,-30 110,0 L60,0 L40,-50 L-60,-50 L-80,0 Z" fill="{col}"/>'
            f'<path d="M-160,-40 C-230,-30 -290,0 -320,40 L-280,48 C-240,20 -200,10 -150,5 Z" fill="{col}"/>'
            f'<path d="M60,-420 C80,-470 130,-490 170,-470 C200,-455 210,-430 200,-410 C185,-395 150,-395 120,-385 C95,-378 70,-380 60,-400 Z" fill="{col}"/>'
            f'<path d="M60,-330 C140,-400 200,-500 230,-600" stroke="{col}" stroke-width="54" fill="none" stroke-linecap="round"/>'
            f'<path d="M230,-600 l20,-55 M230,-600 l45,-30 M230,-600 l52,0" stroke="{col}" stroke-width="12" stroke-linecap="round"/>'
            f'<path d="M-40,-300 C-10,-240 20,-200 40,-160" stroke="{col}" stroke-width="46" fill="none" stroke-linecap="round"/>'
            f'<path d="M40,-160 l30,20 M40,-160 l38,6" stroke="{col}" stroke-width="10" stroke-linecap="round"/></g>')

def rockart(x, y, s, col="#A8321E", seed=1):
    r = random.Random(seed); g = []
    def stick(px, py, k=1.0, arms=0):
        return (f'<circle cx="{px}" cy="{py}" r="{7*k:.0f}" fill="{col}"/><line x1="{px}" y1="{py+7*k:.0f}" x2="{px}" y2="{py+40*k:.0f}" stroke="{col}" stroke-width="{5*k:.0f}"/>'
                f'<path d="M{px-18*k:.0f},{py+(10 if arms else 26)*k:.0f} L{px},{py+18*k:.0f} L{px+18*k:.0f},{py+(10 if arms else 26)*k:.0f}" stroke="{col}" stroke-width="{4*k:.0f}" fill="none"/>'
                f'<path d="M{px-12*k:.0f},{py+62*k:.0f} L{px},{py+40*k:.0f} L{px+12*k:.0f},{py+62*k:.0f}" stroke="{col}" stroke-width="{4*k:.0f}" fill="none"/>')
    def deer(px, py, k=1.0):
        return (f'<path d="M{px},{py} q{40*k:.0f},-12 {80*k:.0f},0 l{12*k:.0f},-24 l{8*k:.0f},6 l-{6*k:.0f},{22*k:.0f} q-{6*k:.0f},{14*k:.0f} -{16*k:.0f},{12*k:.0f} L{px},{py+10*k:.0f} Z" fill="{col}"/>'
                + "".join(f'<line x1="{px+dx*k:.0f}" y1="{py+6*k:.0f}" x2="{px+dx*k+r.uniform(-6,6):.0f}" y2="{py+40*k:.0f}" stroke="{col}" stroke-width="{4*k:.0f}"/>' for dx in (6, 18, 60, 72))
                + f'<path d="M{px+92*k:.0f},{py-24*k:.0f} l-4,-{18*k:.0f} M{px+92*k:.0f},{py-24*k:.0f} l8,-{16*k:.0f}" stroke="{col}" stroke-width="{3*k:.0f}"/>')
    g.append(f'<g transform="translate({x},{y}) scale({s})" opacity=".88">')
    g.append(deer(0, 0, 1.2) + deer(140, 40, 0.9) + deer(-40, 120, 1.0))
    for k in range(5): g.append(stick(-60 + k * 60, -150 + (k % 2) * 10, 1.0, k % 2))
    for k in range(3): g.append(stick(160 + k * 50, 150, 0.9, 1))
    g.append(f'<path d="M-100,260 q60,-30 120,0 t120,0" stroke="{col}" stroke-width="5" fill="none"/>')
    for k in range(4): g.append(f'<circle cx="{260 + k*18}" cy="{-120 + (k%2)*12}" r="6" fill="{col}"/>')
    g.append('</g>')
    return "".join(g)

def footprints(x0, y0, x1, y1, n, col, s=1.0):
    g = []
    for k in range(n):
        t = k / (n - 1); x = lerp(x0, x1, t) + (18 if k % 2 else -18) * s; y = lerp(y0, y1, t)
        a = math.degrees(math.atan2(y1 - y0, x1 - x0)) + 90
        g.append(f'<g transform="translate({x:.0f},{y:.0f}) rotate({a:.0f}) scale({s})"><ellipse cx="0" cy="0" rx="22" ry="44" fill="{col}"/>' + "".join(f'<circle cx="{-16+j*8}" cy="{-52+abs(j-2)*4}" r="{6 if j==0 else 5}" fill="{col}"/>' for j in range(5)) + '</g>')
    return "".join(g)

def helix(x, y, h, c1, c2):
    g = []
    for k in range(40):
        t = k / 39; yy = y - h / 2 + h * t; a = t * math.pi * 4
        x1, x2 = x + 120 * math.sin(a), x - 120 * math.sin(a)
        g.append(f'<line x1="{x1:.0f}" y1="{yy:.0f}" x2="{x2:.0f}" y2="{yy:.0f}" stroke="{c2}" stroke-width="5" opacity=".6"/>')
        g.append(f'<circle cx="{x1:.0f}" cy="{yy:.0f}" r="{10+4*math.cos(a):.0f}" fill="{c1}"/><circle cx="{x2:.0f}" cy="{yy:.0f}" r="{10-4*math.cos(a):.0f}" fill="{c1}"/>')
    return "".join(g)

def profile_head(x, y, s, col, hair=True):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-160,420 C-150,300 -110,230 -60,200 L-40,140 C-110,120 -150,40 -150,-40 C-150,-150 -70,-230 20,-230 C110,-230 160,-170 170,-90 C175,-50 190,-20 215,20 C222,32 212,42 195,44 C200,62 198,76 186,82 C194,98 188,112 172,116 C178,150 160,170 120,170 C95,170 80,175 75,200 L90,250 C160,280 210,340 220,420 Z" fill="{col}"/>'
            + (f'<path d="M-150,-40 C-170,-170 -60,-260 40,-240 C100,-230 140,-200 150,-160 C80,-200 0,-190 -40,-150 C-80,-100 -90,0 -60,120 C-120,110 -150,40 -150,-40 Z" fill="{col}"/><path d="M-110,60 C-170,160 -190,280 -180,360 C-150,280 -120,200 -80,140 Z" fill="{col}"/>' if hair else "") + '</g>')

def maloca(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-220,0 C-220,-160 -120,-250 0,-260 C120,-250 220,-160 220,0 Z" fill="{col}"/>'
            + "".join(f'<path d="M{-200+k*40},{-10} C{-190+k*38},{-120} {-100+k*20},{-220} 0,-250" stroke="{mix(col,"#000000",.25)}" stroke-width="3" fill="none"/>' for k in range(10))
            + f'<path d="M-30,0 L-30,-70 Q0,-95 30,-70 L30,0 Z" fill="{mix(col,"#000000",.5)}"/></g>')

def caravel(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-120,0 L120,0 L95,40 L-100,40 Z" fill="{col}"/><path d="M-120,0 L-140,-30 L-100,-10 Z" fill="{col}"/>'
            f'<line x1="-20" y1="0" x2="-20" y2="-200" stroke="{col}" stroke-width="7"/><line x1="50" y1="0" x2="50" y2="-150" stroke="{col}" stroke-width="6"/>'
            f'<path d="M-80,-180 Q-20,-150 40,-180 L30,-60 Q-20,-40 -70,-60 Z" fill="#E8DCC4"/><rect x="-55" y="-150" width="12" height="60" fill="#B0301E"/><rect x="-78" y="-126" width="58" height="12" fill="#B0301E"/>'
            f'<path d="M50,-150 L100,-60 L50,-60 Z" fill="#E8DCC4"/></g>')

SC = {}
# 1 HOOK: cave, fire, young woman
def e1():
    cave = f'<path d="M{X0},{Y0} L{X1},{Y0} L{X1},{Y1} L{X0},{Y1} Z M-40,1700 C-60,1100 60,500 380,380 C640,300 900,420 1060,700 C1180,920 1160,1400 1120,1700 Z" fill="#140C08" fill-rule="evenodd"/>'
    return dict(light="#FFB060", rim_dx=-4, cam=(1.0, 1.14, (0, 0), (-10, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#3A2418"), (1, "#5A3420")]) + rockart(560, 820, 1.1, "#8A3A22", 1) + glow(560, 1500, 900, "#FF8A3C", .5), rough=False),
                L(0.2, glow(560, 1560, 520, "#FFB060", .6), mode="screen", flicker=0.25),
                L(0.35, fire(470, 1640, 180, 240, 7), flicker=0.25, rough=False),
                L(0.6, R(person(300, 1720, 560, "#0A0604", "shirt", "hair", la=(40, 10), ra=(60, 20), ll=(-10, 80), rl=(10, 95), face=1) + f'<path d="M{X0},1720 L{X1},1720 L{X1},{Y1} L{X0},{Y1} Z" fill="#0E0806"/>')),
                L(1.0, cave, rough=False)])
SC[1] = e1
# 2 TITLE: Serra da Capivara canyons at sunrise
def e2():
    return dict(light="#FFE0A0", rim_dx=5, cam=(1.0, 1.1, (0, 40), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#F4C890"), (0.5, "#F0985A"), (1, "#C8583A")]) + sun(760, 1000, 100, halo_r=800)),
                L(0.05, godrays(760, 1000, "#FFEFC8", n=14, spread=180, a0=-90, op=.26, seed=2), mode="screen"),
                L(0.25, cliffs(1250, "#C87A58", 21, 420)),
                L(0.45, cliffs(1450, "#9A4A34", 22, 560) + caatinga(1450, "#6A3020", 16, 23)),
                L(0.75, R(cliffs(1720, "#4A1E14", 24, 700) + caatinga(1720, "#2A0E08", 12, 25, 90, 200)))])
SC[2] = e2
# 3 ICE AGE land bridge
def e3():
    return dict(light="#E8F4FF", rim_dx=4, cam=(1.0, 1.1, (0, 30), (0, -20)), particles="snow",
        layers=[L(0.0, sky([(0, "#2A3E58"), (0.5, "#7A9AB8"), (1, "#C8DAE8")]) + sun(300, 900, 60, core="#FFFFFF", halo="#DDEEFF", halo_r=500)),
                L(0.15, ridge(1100, "#E8F0F8", 140, 31, 70) + ridge(1150, "#B8CCDC", 90, 32)),
                L(0.35, f'<rect x="{X0}" y="1300" width="{BW}" height="900" fill="#3A6A88"/>' + f'<path d="M{X0},1400 C200,1300 400,1330 540,1320 C700,1310 900,1300 {X1},1380 L{X1},1560 C900,1500 700,1520 540,1520 C380,1520 200,1540 {X0},1580 Z" fill="#F0F6FA"/>'),
                L(0.6, R("".join(person(260 + k * 90, 1470 + (k % 2) * 10, 150, "#1A2430", "poncho", "hair", prop=("staff",), face=1) for k in range(5)))),
                L(0.9, ground(1800, "#DCE8F0", "#B8CCDC", 20, 3))])
SC[3] = e3
# 4 humans + mammoths in snow
def e4():
    return dict(light="#EEF6FF", rim_dx=4, cam=(1.0, 1.12, (-30, 0), (30, -20)), particles="snow",
        layers=[L(0.0, sky([(0, "#3A4E68"), (0.6, "#9AB4CA"), (1, "#DCE6EE")])),
                L(0.2, ridge(1150, "#D8E4EE", 160, 41, 60)),
                L(0.4, R(mammoth(700, 1300, 0.8, "#2A3440", -1) + mammoth(950, 1330, 0.55, "#3A4450", -1)) + ground(1440, "#E6EEF4", "#C8D6E2", 10, 4)),
                L(0.8, R(person(200, 1860, 620, "#0E141A", "poncho", "hair", la=(100, 95), ra=(60, -10), prop=("staff",), face=1, ll=(80, 110), rl=(110, 85))
                         + person(470, 1880, 540, "#0E141A", "poncho", "scarf", face=1, ll=(85, 105), rl=(105, 88))
                         + person(640, 1890, 330, "#0E141A", "shirt", "hair", face=1)) + ground(1860, "#F0F4F8", "#D0DCE6", 15, 5))])
SC[4] = e4
# 5 footprints in mud (reveal)
def e5():
    base = sky([(0, "#8A7458"), (1, "#6A5640")]) + "".join(f'<ellipse cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+5).randint(Y0,Y1)}" rx="{random.Random(k+9).randint(40,160)}" ry="{random.Random(k+13).randint(10,40)}" fill="#5A4834" opacity=".5"/>' for k in range(80))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.06, 1.0, (0, 60), (0, -40)), particles=None,
        layers=[L(0.0, base, rough=False), L(0.1, footprints(300, 1900, 760, 200, 14, "#3A2C1E", 1.4), reveal=(0.3, 4.0, "ltr"), rough=False)])
SC[5] = e5
# 6 soil layers / stratigraphy
def e6():
    lay = [("#C8A878", "HOJE"), ("#A8845A", "10 MIL ANOS"), ("#8A6844", "16 MIL ANOS"), ("#6E5236", "21 MIL ANOS"), ("#54402A", "25 MIL ANOS"), ("#3E2E1E", "?")]
    g = ""; y = 380
    for i, (c, t) in enumerate(lay):
        h = 230; g += f'<path d="M{X0},{y} Q540,{y-20+i*6} {X1},{y+10} L{X1},{y+h} L{X0},{y+h} Z" fill="{c}"/>'
        g += f'<text x="90" y="{y+130}" font-family="Anton" font-size="64" fill="#FFF3E0" opacity=".9">{t}</text>'
        y += h
    g += "".join(f'<ellipse cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+3).randint(400,1800)}" rx="{random.Random(k+6).randint(6,20)}" ry="{random.Random(k+8).randint(4,12)}" fill="#2A1E12" opacity=".5"/>' for k in range(120))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, -60), (0, 80)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8D8B8"), (1, "#C8B090")]) + g, rough=False),
                L(0.6, f'<g transform="translate(780,1500)"><circle r="160" fill="#FFF6DA" opacity=".25"/><circle r="160" fill="none" stroke="#1A1008" stroke-width="28"/><line x1="115" y1="115" x2="290" y2="290" stroke="#1A1008" stroke-width="46" stroke-linecap="round"/></g>')])
SC[6] = e6
# 7 giant sloth in cerrado dusk
def e7():
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.12, (20, 20), (-20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#5A4868"), (0.5, "#D88A5A"), (1, "#F0B070")]) + sun(820, 1250, 90, halo_r=700)),
                L(0.2, caatinga(1380, "#8A5040", 20, 71, 60, 120) + f'<rect x="{X0}" y="1370" width="{BW}" height="800" fill="#8A5040"/>'),
                L(0.5, R(sloth(470, 1640, 1.2, "#1E100C", 1) + f'<path d="M880,1640 C870,1400 860,1200 820,960 M850,1150 C900,1080 960,1040 1020,1000 M835,1050 C780,980 760,930 740,880" stroke="#1E100C" stroke-width="30" fill="none" stroke-linecap="round"/>' + "".join(f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="#1E100C"/>' for x, y, rx, ry in [(820,900,190,80),(700,880,110,55),(1000,960,150,60),(900,820,120,50)])) + ground(1630, "#3A2018", "#1E100C", 10, 2)),
                L(0.85, R(person(160, 1920, 420, "#0A0604", "poncho", "hair", prop=("staff",), face=1) + person(300, 1930, 380, "#0A0604", "shirt", "hair", face=1)) + ground(1900, "#140A06", "#0A0604", 12, 3))])
SC[7] = e7
# 8 bone pendants close-up
def e8():
    pend = ""
    for k, (x, y, a) in enumerate([(360, 1150, -12), (560, 1210, 6), (760, 1140, 18)]):
        pend += f'<g transform="translate({x},{y}) rotate({a})"><path d="M-70,-50 Q0,-80 70,-50 L60,60 Q0,85 -60,60 Z" fill="#E6D6B6"/><path d="M-70,-50 Q0,-80 70,-50 L60,60 Q0,85 -60,60 Z" fill="none" stroke="#9A8460" stroke-width="5"/><circle cx="0" cy="-40" r="11" fill="#2A1A10"/>' + "".join(f'<circle cx="{random.Random(k*9+j).randint(-40,40)}" cy="{random.Random(k*7+j).randint(-10,50)}" r="3" fill="#B8A07A"/>' for j in range(12)) + '</g>'
    cord = '<path d="M150,1000 C300,1110 420,1110 560,1170 C700,1110 820,1100 950,980" fill="none" stroke="#6A4A2A" stroke-width="7"/>'
    return dict(light="#FFE0A8", rim_dx=4, cam=(1.0, 1.15, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1C14"), (1, "#3E2A1C")]) + "".join(f'<path d="M{X0},{y} q300,-20 650,0 t650,0" stroke="#4A3222" stroke-width="{random.Random(y).randint(8,20)}" fill="none" opacity=".6"/>' for y in range(Y0, Y1, 60)) + glow(560, 1150, 700, "#FFCF8A", .45), rough=False),
                L(0.5, cord + pend, rough=False)])
SC[8] = e8
# 9 rock paintings revealed on canyon wall
def e9():
    wall = sky([(0, "#D8905E"), (1, "#B86A44")]) + "".join(f'<path d="M{X0},{y} Q540,{y+random.Random(y).randint(-30,30)} {X1},{y}" stroke="#A85C3A" stroke-width="{random.Random(y+1).randint(3,9)}" fill="none" opacity=".7"/>' for y in range(Y0, Y1, 70)) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>'
    return dict(light="#FFE0A8", rim_dx=4, cam=(1.0, 1.1, (-40, 0), (40, -20)), particles="dust",
        layers=[L(0.0, wall, rough=False), L(0.05, rockart(420, 820, 1.5, "#7A1E10", 9) + rockart(680, 1350, 1.1, "#8A2A14", 10), reveal=(0.3, 3.5, "ltr"), rough=False),
                L(0.3, glow(900, 400, 800, "#FFE8C0", .35), mode="screen")])
SC[9] = e9
# 10 wide canyon many sites + paintings
def e10():
    return dict(light="#FFE0A0", rim_dx=5, cam=(1.0, 1.1, (30, 0), (-30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8B880"), (1, "#F0C890")]) + sun(300, 800, 70, halo_r=600)),
                L(0.3, cliffs(1300, "#B8704E", 101, 600) + rockart(300, 1050, 0.6, "#6A1A0C", 11) + rockart(760, 1100, 0.5, "#6A1A0C", 12)),
                L(0.6, R(cliffs(1650, "#6A2E1E", 102, 500) + caatinga(1650, "#3A1810", 14, 103, 80, 180))),
                L(0.9, R(person(820, 1920, 560, "#0E0604", "shirt", "hair", la=(-60, -30), ra=(80, 90), face=-1)) + ground(1900, "#1E0C08", "#0E0604", 10, 4))])
SC[10] = e10
# 11 Pedra Furada arch + question
def e11():
    arch = f'<path d="M100,1500 C120,1000 300,700 540,680 C800,700 980,1000 1000,1500 L820,1500 C810,1180 700,1000 560,1000 C420,1000 310,1180 290,1500 Z" fill="#8A3A24"/>' + "".join(f'<path d="M{120+k*10},{1500-k*80} Q540,{680+k*30} {990-k*10},{1500-k*80}" stroke="#6A2A18" stroke-width="4" fill="none" opacity=".6"/>' for k in range(8))
    return dict(light="#FFD8A0", rim_dx=5, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A3A60"), (0.55, "#D8805A"), (1, "#F0A860")]) + sun(560, 1260, 100, halo_r=700)),
                L(0.05, godrays(560, 1260, "#FFEFC8", n=10, spread=80, a0=-90, op=.3, seed=11), mode="screen"),
                L(0.4, R(arch) + caatinga(1500, "#3A1810", 18, 111, 80, 170) + f'<rect x="{X0}" y="1495" width="{BW}" height="700" fill="#3A1810"/>')])
SC[11] = e11
# 12 Lapa Vermelha cave entrance, archaeologists 1970s
def e12():
    cave = f'<path d="M{X0},{Y0} L{X1},{Y0} L{X1},{Y1} L{X0},{Y1} Z M120,1600 C100,1200 220,820 520,760 C820,720 1000,1000 980,1600 Z" fill="#1C1A18" fill-rule="evenodd"/>' + "".join(f'<path d="M{random.Random(k).randint(X0,X1)},{random.Random(k+1).randint(Y0,700)} l{random.Random(k+2).randint(-40,40)},{random.Random(k+3).randint(60,200)}" stroke="#2E2C2A" stroke-width="5"/>' for k in range(40))
    return dict(light="#FFE8C0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#B8C8C8"), (0.6, "#E8DCB8"), (1, "#F0C890")]) + sun(700, 1150, 70, halo_r=600)),
                L(0.2, caatinga(1350, "#8A8060", 14, 121, 70, 150) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#8A8060"/>'),
                L(0.55, R(person(420, 1600, 420, "#0A0806", "shirt", "brim", la=(70, 110), ra=(50, 100), ll=(-30, 95), rl=(0, 100), lean=70, face=1, prop=("hammer", 100))
                         + person(760, 1600, 440, "#0A0806", "shirt", "hair", la=(80, 120), ra=(60, 120), ll=(-20, 95), rl=(10, 100), lean=60, face=-1)) + ground(1590, "#3A342C", "#2A2620", 8, 2)),
                L(0.6, glow(600, 1450, 260, "#FFE6B0", .6) + f'<circle cx="600" cy="1450" r="14" fill="#FFF6DA"/>', mode="screen", flicker=0.1),
                L(0.9, cave, rough=False)])
def lantern_like(x, y): return glow(x, y, 200, "#FFE6B0", .8) + f'<circle cx="{x}" cy="{y}" r="16" fill="#FFF6DA"/>'
SC[12] = e12
# 13 Luzia portrait profile
def e13():
    return dict(light="#FFE0B0", rim_dx=-6, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#1E2A3A"), (0.6, "#6A5A60"), (1, "#C8906A")]) + glow(760, 1100, 900, "#F4C890", .55)),
                L(0.1, godrays(900, 700, "#FFEFD0", n=9, spread=50, a0=150, op=.25, seed=13), mode="screen"),
                L(0.5, R(profile_head(500, 1200, 1.9, "#0E0A08")))])
SC[13] = e13
# 14 DNA helix
def e14():
    return dict(light="#C8F0FF", rim_dx=4, cam=(1.0, 1.12, (0, 40), (0, -40)), particles="dust",
        layers=[L(0.0, sky([(0, "#06121E"), (1, "#0E2438")]) + glow(540, 960, 800, "#3A9AC8", .35)),
                L(0.3, helix(540, 960, 1500, "#8AE0FF", "#3AA8D8"), mode="screen", rough=False),
                L(0.6, R(profile_head(230, 1650, 1.0, "#020608")))])
SC[14] = e14
# 15 Museu Nacional fire
def e15():
    pal = (f'<rect x="80" y="1100" width="920" height="420" fill="#0A0404"/><rect x="60" y="1080" width="960" height="40" fill="#0A0404"/><path d="M380,1080 L540,960 L700,1080 Z" fill="#0A0404"/>'
           + "".join(f'<rect x="{120+k*85}" y="1180" width="44" height="120" fill="#FF8A3C" opacity=".85"/><rect x="{120+k*85}" y="1350" width="44" height="120" fill="#FFB060" opacity=".7"/>' for k in range(11)))
    return dict(light="#FFB060", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0404"), (0.6, "#4A1408"), (1, "#A8380E")])),
                L(0.2, clouds(700, "#3A2018", .7, seed=15, scale=1.6), drift=(20, -90)),
                L(0.3, glow(540, 1100, 800, "#FF7A2E", .6), mode="screen", flicker=0.15),
                L(0.35, fire(80, 1100, 920, 380, 15), flicker=0.18, rough=False),
                L(0.5, R(pal) + ground(1510, "#140806", "#060202", 6, 1))])
SC[15] = e15
# 16 petroglyph engraved human figure
def e16():
    rock = sky([(0, "#7A7874"), (1, "#5A5854")]) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>' + "".join(f'<path d="M{random.Random(k).randint(X0,X1)},{random.Random(k+1).randint(Y0,Y1)} l{random.Random(k+2).randint(-120,120)},{random.Random(k+3).randint(-40,40)}" stroke="#4A4844" stroke-width="{random.Random(k+4).randint(2,6)}"/>' for k in range(60))
    glyph = (f'<g transform="translate(540,1000) scale(2.2)" fill="none" stroke="#2A2826" stroke-width="14" stroke-linecap="round" stroke-linejoin="round">'
             f'<circle cx="0" cy="-160" r="36"/><line x1="0" y1="-124" x2="0" y2="40"/><path d="M-90,-110 L0,-80 L90,-110"/><path d="M-90,-110 L-110,-160 M90,-110 L110,-160"/><path d="M-60,140 L0,40 L60,140"/><path d="M-60,140 L-80,150 M60,140 L80,150"/></g>')
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, rock, rough=False), L(0.05, glyph, reveal=(0.3, 2.5, "ltr"), rough=True),
                L(0.3, glow(760, 700, 700, "#FFB060", .4), mode="screen", flicker=0.15)])
SC[16] = e16
# 17 timeline: 27 mil anos vs 1500
def e17():
    g = f'<rect x="490" y="200" width="100" height="1500" rx="20" fill="#E8D8B8"/>'
    marks = [(0, "27 MIL ANOS"), (0.2, "21 MIL"), (0.41, "16 MIL"), (0.56, "12 MIL"), (0.6, "LUZIA · 11.400"), (0.68, "9 MIL")]
    for f, t in marks:
        y = 200 + f * 1500
        g += f'<line x1="440" y1="{y+10:.0f}" x2="640" y2="{y+10:.0f}" stroke="#2A1A10" stroke-width="6"/><text x="660" y="{y+30:.0f}" font-family="Anton" font-size="52" fill="#FFF3E0">{t}</text>'
    g += f'<rect x="490" y="1690" width="100" height="10" fill="#E0301E"/><text x="420" y="1720" font-family="Anton" font-size="70" text-anchor="end" fill="#FF5A3A">1500</text><path d="M430,1695 L480,1695" stroke="#FF5A3A" stroke-width="8"/>'
    bar = f'<rect x="500" y="210" width="80" height="1480" rx="14" fill="#C8783A"/>'
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.05, (0, -80), (0, 120)), particles="dust",
        layers=[L(0.0, sky([(0, "#1A1410"), (1, "#2A1E14")]) + glow(540, 960, 900, "#8A5A2A", .35) + g, rough=False),
                L(0.05, bar, reveal=(0.2, 3.0, "ltr"), rough=False)])
SC[17] = e17
# 18 people on the beach at sunrise, ship on horizon
def e18():
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A7A98"), (0.5, "#F0B888"), (1, "#F8D8A8")]) + sun(700, 1150, 90, halo_r=800)),
                L(0.05, godrays(700, 1150, "#FFF3D0", n=14, spread=160, a0=-90, op=.24, seed=18), mode="screen"),
                L(0.2, f'<rect x="{X0}" y="1160" width="{BW}" height="900" fill="#6A8AA0"/>' + "".join(f'<path d="M{X0},{1180+k*30} q300,-6 650,0 t650,0" stroke="#FFE8C8" stroke-width="3" fill="none" opacity="{0.5-k*0.03:.2f}"/>' for k in range(12))),
                L(0.3, R(caravel(880, 1160, 0.35, "#2A2A30")), drift=(-60, 0)),
                L(0.5, ground(1440, "#E8D0A0", "#C8A878", 6, 2) + R(maloca(180, 1440, 0.8, "#3A2A1C") + forest(1440, "#2A2016", n=2, hmin=500, hmax=600, seed=181, x0=X0, x1=60))),
                L(0.85, R("".join(person(160 + k * 170, 1880 + (k % 2) * 30, 520 + (k % 3) * 40, "#140C08", "shirt", "hair", la=(100, 90), ra=(80, 85) if k % 2 else (-40, -60), prop=("staff",) if k == 2 else None, face=1) for k in range(6))) + ground(1860, "#3A2A18", "#1A120A", 10, 3))])
SC[18] = e18
# 19 end card Amazon from above, mist
def e19():
    return dict(light="#FFF0C8", rim_dx=4, cam=(1.0, 1.1, (0, 40), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#C8D8C0"), (0.6, "#E8E4C8"), (1, "#F0DCA8")]) + sun(540, 900, 80, halo_r=700)),
                L(0.2, fogband(1100, "#FFFFFF", .6, 260, 19) + "".join(f'<circle cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+1).randint(1150,1400)}" r="{random.Random(k+2).randint(30,70)}" fill="#6A8A5A"/>' for k in range(120))),
                L(0.45, "".join(f'<circle cx="{random.Random(k+300).randint(X0,X1)}" cy="{random.Random(k+301).randint(1400,1750)}" r="{random.Random(k+302).randint(50,110)}" fill="{random.choice(["#3A5A34","#2E4A2A","#44663C"])}"/>' for k in range(110)) + fogband(1450, "#F4F4E8", .45, 200, 20)),
                L(0.8, "".join(f'<circle cx="{random.Random(k+600).randint(X0,X1)}" cy="{random.Random(k+601).randint(1750,2150)}" r="{random.Random(k+602).randint(90,180)}" fill="{random.choice(["#1E3A1E","#16301A","#28442A"])}"/>' for k in range(70)), drift=(0, -40))])
SC[19] = e19
