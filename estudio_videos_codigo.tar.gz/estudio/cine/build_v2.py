import json, subprocess, numpy as np, cv2, math
from scenes_v2 import SC
from cine import Scene, compose, post, Particles, OW, OH, FPS
CT = "../contestado"
meta = json.load(open(f"{CT}/timing.json")); TAIL = 1.5
total = meta[-1]["start"] + meta[-1]["dur"] + TAIL; meta[-1]["dur"] += TAIL
st = {m["i"]: m["start"] for m in meta}
NF = int(total * FPS); XF = 0.3
shake = {10: 9, 16: 7, 1: 3}; flash = {10: (1, .35), 16: (0, .3), 13: (1, .2)}
cache = {}
def get(n):
    if n not in cache:
        for k in list(cache):
            if k < n - 1: del cache[k]
        cache[n] = (Scene(n, SC[n]()), Particles(SC[n]().get("particles"), n))
    return cache[n]
def frame_for(m, tl):
    sc, pr = get(m["i"]); u = min(1, max(0, (tl + XF) / (m["dur"] + XF)))
    sh = shake.get(m["i"], 0) * max(0, 1 - tl) if tl < 1 else 0
    return compose(sc, u, tl, sh), pr
enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OW}x{OH}", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "yuv420p", "video_raw.mp4"], stdin=subprocess.PIPE)
for n in range(NF):
    t = n / FPS
    k = max(j for j, m in enumerate(meta) if m["start"] <= t + 1e-9)
    m = meta[k]; tl = t - m["start"]
    fr, pr = frame_for(m, tl)
    if k + 1 < len(meta):
        nx = meta[k + 1]; tn = nx["start"] - t
        if tn < XF:
            a = 1 - tn / XF; f2, _ = frame_for(nx, -tn); fr = fr * (1 - a) + f2 * a
    if m["i"] in flash and tl < 0.2:
        kind, amt = flash[m["i"]]; w = (1 - tl / 0.2) * amt
        fr = fr * (1 - w) + (np.array([1, 1, 1], np.float32) if kind else np.array([0.8, 0.12, 0.08], np.float32)) * w
    if t > total - 0.8: fr = fr * max(0, (total - t) / 0.8)
    if t < 0.4: fr = fr * (t / 0.4)
    enc.stdin.write(post(fr, t, pr, total).tobytes())
    if n % 300 == 0: print("frame", n, "/", NF, flush=True)
enc.stdin.close(); enc.wait()
# ASS: reuse captions + add big numbers
ass = open(f"{CT}/caps.ass").read()
def ts(x): return f"{int(x//3600)}:{int(x%3600//60):02d}:{x%60:05.2f}"
big = {11: "+20 MIL", 12: "15 ANOS", 13: "7 MIL", 17: "1916", 18: "10 A 20 MIL"}
lines = []
for sc, txt in big.items():
    m = meta[sc - 1]; fs = "\\fs190" if len(txt) > 8 else ""
    lines.append(f"Dialogue: 2,{ts(m['start']+0.3)},{ts(m['start']+m['dur']-0.1)},Big,,0,0,0,,{{\\pos(540,720){fs}\\fscx40\\fscy40\\t(0,180,\\fscx112\\fscy112)\\t(180,300,\\fscx100\\fscy100)\\fad(0,200)}}{txt}")
open("caps.ass", "w").write(ass.rstrip("\n") + "\n" + "\n".join(lines) + "\n")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "video_raw.mp4", "-i", f"{CT}/mix.wav", "-vf", "ass=caps.ass",
                "-c:v", "libx264", "-preset", "medium", "-crf", "24", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                "-ar", "44100", "-movflags", "+faststart", "-shortest", "/home/claude/Contestado_Parte5_v2_TikTok.mp4"], check=True)
print("done", total)
