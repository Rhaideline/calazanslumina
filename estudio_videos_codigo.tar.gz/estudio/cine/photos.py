"""Fotos licenciadas (Adobe Stock) tratadas para combinar com o estilo dos vídeos."""
import base64, io, os
import numpy as np
from PIL import Image, ImageFilter

DIR = os.path.join(os.path.dirname(__file__), "..", "fotos")

def _uri(im, fmt="PNG"):
    b = io.BytesIO()
    im.save(b, fmt, **({"quality": 86} if fmt == "JPEG" else {}))
    return f"data:image/{fmt.lower()};base64," + base64.b64encode(b.getvalue()).decode()

def _grade(im, tint, dark=0.62, sat=0.7, vig=0.55):
    a = np.asarray(im.convert("RGB"), np.float32) / 255
    g = a.mean(axis=2, keepdims=True); a = g + (a - g) * sat
    a = a * np.array(tint, np.float32) * dark
    h, w = a.shape[:2]; yy, xx = np.mgrid[0:h, 0:w]
    r = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    a = a * (1 - vig * np.clip(r - 0.4, 0, 1) ** 1.5)[..., None]
    return Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8))

def full_bg(name, cx, tint=(1.15, 0.95, 0.8), dark=0.7):
    """Recorte vertical cobrindo o canvas inteiro (1300x2310 a partir de -110,-195)."""
    im = Image.open(os.path.join(DIR, name)).convert("RGB"); W, H = im.size
    cw = int(H * 1300 / 2310); x0 = int(min(max(cx * W - cw / 2, 0), W - cw))
    im = im.crop((x0, 0, x0 + cw, H)).resize((1300, 2310), Image.LANCZOS).filter(ImageFilter.GaussianBlur(1.2))
    im = _grade(im, tint, dark)
    return f'<image x="-110" y="-195" width="1300" height="2310" href="{_uri(im, "JPEG")}"/>'

def band(name, y, box=None, tint=(0.8, 0.9, 1.15), dark=0.62, w=1300, fade=0.22):
    """Faixa horizontal com bordas em degradê (alpha), largura 1300 a partir de x=-110."""
    im = Image.open(os.path.join(DIR, name)).convert("RGB")
    if box: im = im.crop(box)
    h = int(w * im.size[1] / im.size[0]); im = _grade(im.resize((w, h), Image.LANCZOS), tint, dark)
    a = np.ones((h, w), np.float32); n = int(h * fade)
    ramp = np.linspace(0, 1, n) ** 1.3; a[:n] *= ramp[:, None]; a[-n:] *= ramp[::-1][:, None]
    a[:, :80] *= np.linspace(0, 1, 80)[None]; a[:, -80:] *= np.linspace(1, 0, 80)[None]
    rgba = np.dstack([np.asarray(im), (a * 255).astype(np.uint8)])
    return f'<image x="-110" y="{y}" width="{w}" height="{h}" href="{_uri(Image.fromarray(rgba, "RGBA"))}"/>'

def card(name, box, x, y, w, ang, credit):
    """Foto de imprensa recortada (só o rosto), em cartão com crédito de reprodução."""
    from PIL import ImageEnhance
    im = Image.open(os.path.join(DIR, name)).convert("RGB").crop(box)
    h = int(w * im.size[1] / im.size[0]); im = im.resize((int(w * 1.5), int(h * 1.5)), Image.LANCZOS)
    im = ImageEnhance.Contrast(ImageEnhance.Color(im).enhance(0.8)).enhance(1.06)
    tot = h + 36 + 60
    return (f'<g transform="translate({x},{y}) rotate({ang})"><rect x="{-w/2-8:.0f}" y="{-tot/2+14:.0f}" width="{w+36}" height="{tot}" fill="#000" opacity=".4"/>'
            f'<rect x="{-w/2-18:.0f}" y="{-tot/2:.0f}" width="{w+36}" height="{tot}" fill="#F2EEE4"/>'
            f'<image x="{-w/2:.0f}" y="{-tot/2+18:.0f}" width="{w}" height="{h}" href="{_uri(im, "JPEG")}"/>'
            f'<text x="0" y="{tot/2-20:.0f}" font-family="Montserrat" font-weight="700" font-size="22" letter-spacing="1.5" text-anchor="middle" fill="#6A5E4A">{credit}</text></g>')
