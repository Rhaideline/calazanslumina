import os, sys, json, math, subprocess, random
import numpy as np, cv2
from art import page, BX0, BY0, BW, BH
OW, OH, FPS = 1080, 1920, 30

def render_layers(SC, ids, outdir="layers"):
    from render import run
    jobs = []
    for n in ids:
        sc = SC[n]()
        for k, ly in enumerate(sc["layers"]):
            jobs.append((page(ly["svg"], sc["light"], sc["rim_dx"]), f"{outdir}/s{n:02d}_{k}.png"))
    run(jobs)

class Scene:
    def __init__(self, n, sc, outdir="layers"):
        self.n = n; self.sc = sc; self.layers = []
        for k, ly in enumerate(sc["layers"]):
            im = cv2.imread(f"{outdir}/s{n:02d}_{k}.png", cv2.IMREAD_UNCHANGED)
            im = cv2.cvtColor(im, cv2.COLOR_BGRA2RGBA)
            self.layers.append((ly, im))

def ease(t): return t * t * (3 - 2 * t)
def noise(t, seed=0): return (math.sin(t * 13.1 + seed) * 0.5 + math.sin(t * 7.3 + seed * 2) * 0.3 + math.sin(t * 23.7 + seed * 3) * 0.2)

def compose(scene, u, tl, shake=0):
    sc = scene.sc; z0, z1, p0, p1 = sc["cam"]; e = ease(u)
    z = z0 + (z1 - z0) * e; px = p0[0] + (p1[0] - p0[0]) * e; py = p0[1] + (p1[1] - p0[1]) * e
    if shake:
        px += shake * math.sin(tl * 57); py += shake * math.cos(tl * 49)
    out = np.zeros((OH, OW, 3), np.float32)
    for idx, (ly, im) in enumerate(scene.layers):
        k = 0.35 + 0.85 * ly["depth"]
        zd = max(1.0, 1 + (z - 1) * k) if z >= 1 else 1 + (z - 1) * k
        cdx = 540 + px * k + ly["drift"][0] * e; cdy = 960 + py * k + ly["drift"][1] * e
        M = np.float32([[1 / zd, 0, cdx - BX0 - 540 / zd], [0, 1 / zd, cdy - BY0 - 960 / zd]])
        src = im
        if ly.get("reveal"):
            t0, d, kind = ly["reveal"]; p = min(1, max(0, (tl - t0) / d)); p = ease(p)
            src = im.copy(); a = src[:, :, 3]
            if kind == "ltr": a[:, int(BW * p):] = 0
            elif kind == "rtl": a[:, :int(BW * (1 - p))] = 0
            elif kind == "center":
                c = 540 - BX0; hw = int(BW * p / 2); a[:, :max(0, c - hw)] = 0; a[:, c + hw:] = 0
        w = cv2.warpAffine(src, M, (OW, OH), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE if idx == 0 else cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
        rgb = w[:, :, :3].astype(np.float32) / 255; a = w[:, :, 3:4].astype(np.float32) / 255
        if ly.get("flicker"):
            rgb = np.clip(rgb * (1 + ly["flicker"] * noise(tl, idx)), 0, 1)
            if ly["mode"] == "screen": a = a * (1 + ly["flicker"] * 0.8 * noise(tl * 1.3, idx + 5))
        if ly["mode"] == "screen":
            out = 1 - (1 - out) * (1 - np.clip(rgb * a, 0, 1))
        else:
            out = out * (1 - a) + rgb * a
    return out

# ---- post ----
yy, xx = np.mgrid[0:OH, 0:OW].astype(np.float32)
VIG = np.clip(1 - 0.55 * (((xx - OW / 2) / (OW * 0.62)) ** 2 + ((yy - OH / 2) / (OH * 0.62)) ** 2), 0.25, 1)[..., None]
rng = np.random.default_rng(7)
GRAIN = [rng.normal(0, 0.045, (OH // 2, OW // 2)).astype(np.float32) for _ in range(6)]
GRAIN = [cv2.resize(g, (OW, OH), interpolation=cv2.INTER_LINEAR)[..., None] for g in GRAIN]

class Particles:
    def __init__(self, kind, seed=1):
        self.kind = kind; r = np.random.default_rng(seed)
        n = {"dust": 70, "ash": 90, "sawdust": 80, "snow": 260, "embers": 120}.get(kind, 0)
        self.x = r.uniform(0, OW, n); self.y = r.uniform(0, OH, n); self.ph = r.uniform(0, 6.28, n)
        self.s = r.uniform(0.5, 1.0, n)
    def draw(self, fr, t):
        k = self.kind
        if not k: return fr
        if k == "dust": vx, vy, col, rad, al = 6, -12, (1.0, 0.93, 0.78), 2.2, 0.45
        elif k == "ash": vx, vy, col, rad, al = -20, 35, (0.75, 0.72, 0.7), 2.4, 0.55
        elif k == "sawdust": vx, vy, col, rad, al = 15, 45, (0.95, 0.8, 0.55), 2.0, 0.6
        elif k == "snow": vx, vy, col, rad, al = 10, 90, (0.95, 0.97, 1.0), 3.2, 0.8
        else: vx, vy, col, rad, al = 12, -120, (1.0, 0.62, 0.25), 2.6, 0.9
        X = (self.x + vx * t * self.s + 25 * np.sin(t * 0.8 + self.ph)) % OW
        Y = (self.y + vy * t * self.s) % OH
        ov = np.zeros((OH, OW), np.uint8)
        for x, y, s in zip(X, Y, self.s):
            cv2.circle(ov, (int(x), int(y)), max(1, int(rad * (0.6 + s))), 255, -1, cv2.LINE_AA)
        a = (ov.astype(np.float32) / 255 * al)[..., None]
        if k == "embers":
            a = a * (0.6 + 0.4 * np.sin(t * 9 + 0))
        return fr * (1 - a) + np.array(col, np.float32) * a

def post(fr, t, parts, total):
    fr = parts.draw(fr, t) if parts else fr
    fr = fr * VIG
    fr = fr + GRAIN[int(t * 12) % 6]
    fr = np.clip(fr * 0.97 + 0.02, 0, 1)
    img = (fr * 255).astype(np.uint8)
    # progress bar
    img[0:10, :] = (img[0:10, :] * 0.6).astype(np.uint8)
    img[0:10, :int(OW * t / total)] = (245, 200, 51)
    return img
