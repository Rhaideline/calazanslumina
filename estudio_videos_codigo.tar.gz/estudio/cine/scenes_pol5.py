"""Três Reels curtos do 2º turno (A: anticorrupção, B: prontuário, C: 1979). Reaproveita cenas do pol3/pol4."""
from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep5 import parchment, stamp, label, RED, GOLD, INKB
import scenes_pol3 as P3
import scenes_pol4 as P4
import photos

PAPER = "#F4F1EA"
def use(S, n, alt=None):
    def g():
        d = S[n](); d.pop("alt", None); d.pop("split", None); d.pop("split_shot", None)
        if alt: d["alt"] = alt
        return d
    return g

def dark(gl="#8A3A2A"):
    return sky([(0, "#07070C"), (0.6, "#14101A"), (1, "#1E1418")]) + glow(540, 900, 800, gl, .28)

# ---------------- A: anticorrupção ----------------
def a1():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, dark("#7A2A20")),
                L(0.3, photos.card("recebidas/flavio_podio_icl.png", (20, 180, 430, 730), 540, 1150, 440, -2, "FOTO: REPRODUÇÃO · ICL NOTÍCIAS"), rough=False)])
def a7():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -10)), particles="dust",
        layers=[L(0.0, dark("#3A3A5A")), L(0.4, label(540, 860, "A PERGUNTA", 120, PAPER, "Anton"), rough=False),
                L(0.41, label(540, 1010, "É SUA", 150, GOLD, "Anton"), reveal=(1.0, 0.25, "center"), rough=False)])
def a8():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, photos.full_bg("congresso.jpg", 0.465, (0.9, 0.85, 0.9), 0.42), rough=False),
                L(0.4, label(540, 760, "ERA ISSO QUE", 104, PAPER, "Anton") + label(540, 890, "VOCÊ QUERIA", 104, PAPER, "Anton") + label(540, 1020, "COMBATER?", 130, GOLD, "Anton"), rough=False),
                L(0.5, label(540, 1560, "Investigação não é condenação · ele nega irregularidades", 30, "#D8D0C4", "Montserrat"), rough=False)])
SCA = {1: a1, 2: use(P4.S, 104), 3: use(P4.S, 4), 4: use(P4.S, 5, 105), 5: use(P4.S, 7, 107), 6: use(P4.S, 8, 108), 7: a7, 8: a8,
       105: use(P4.S, 105), 107: use(P4.S, 107), 108: use(P4.S, 108)}

# ---------------- B: prontuário ----------------
def baby(cx, cy, s, col="#6A4636", line="#2A1A16"):
    return (f'<g transform="translate({cx},{cy}) rotate(-22) scale({s})"><ellipse cx="0" cy="0" rx="120" ry="58" fill="{col}" stroke="{line}" stroke-width="6"/>'
            f'<path d="M-100,-10 Q-20,30 90,-20" stroke="{line}" stroke-width="5" fill="none" opacity=".6"/><circle cx="118" cy="-26" r="44" fill="{col}" stroke="{line}" stroke-width="6"/></g>')
def b1():
    win = (f'<rect x="620" y="420" width="340" height="560" rx="12" fill="#FFE8C0"/><rect x="620" y="420" width="340" height="560" rx="12" fill="none" stroke="#5A3A28" stroke-width="18"/>'
           f'<line x1="790" y1="420" x2="790" y2="980" stroke="#5A3A28" stroke-width="12"/><line x1="620" y1="700" x2="960" y2="700" stroke="#5A3A28" stroke-width="12"/>')
    mom = person(420, 1960, 1000, "#2A1A16", "dress", "hair", la=(75, 140), ra=(55, 160), face=1) + baby(460, 1240, 1.0)
    return dict(light="#FFD8A8", rim_dx=5, cam=(1.0, 1.08, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#C89A7A"), (0.6, "#E8C8A0"), (1, "#F0D8B8")]) + glow(790, 700, 600, "#FFF0D0", .6)),
                L(0.2, win + f'<rect x="{X0}" y="1500" width="{BW}" height="700" fill="#B88A68"/>', rough=False),
                L(0.6, R(mom) + ground(1950, "#8A6448", "#6A4A34", 4, 1)),
                L(0.7, P4.chip(760, 1150, "DIAGNÓSTICO", "#F4F1EA", 40), reveal=(0.2, 0.2, "center"), rough=False),
                L(0.71, P4.chip(760, 1250, "GRAVIDEZ", "#F4F1EA", 40), reveal=(1.4, 0.2, "center"), rough=False),
                L(0.72, P4.chip(760, 1350, "PÓS-PARTO", GOLD, 40), reveal=(2.6, 0.2, "center"), rough=False)])
def lock(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-120" y="-40" width="240" height="200" rx="26" fill="{col}"/>'
            f'<path d="M-76,-40 L-76,-110 Q0,-210 76,-110 L76,-40" stroke="{col}" stroke-width="34" fill="none"/><circle cx="0" cy="50" r="26" fill="#1A1A1E"/><rect x="-9" y="50" width="18" height="60" fill="#1A1A1E"/></g>')
def b2():
    return dict(light="#C8E0E8", rim_dx=4, cam=(1.0, 1.08, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#0A3A58"), (0.6, "#0A5A78"), (1, "#1A7A88")]) + glow(540, 900, 800, "#9AE0F0", .3)),
                L(0.3, lock(540, 980, 1.3, PAPER), rough=False),
                L(0.5, label(540, 520, "DADO DE SAÚDE", 96, PAPER, "Anton"), rough=False),
                L(0.51, label(540, 630, "= DADO SENSÍVEL", 70, GOLD, "Anton"), reveal=(1.2, 0.25, "center"), rough=False)])
def b4():
    return dict(light="#C8E0E8", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#0A1A28"), (0.6, "#0A2A3A"), (1, "#123848")]) + glow(540, 1000, 700, "#6AB0D0", .3)),
                L(0.3, P4.docfile(540, 1050, 1.3, "SEU PRONTUÁRIO"), rough=False),
                L(0.5, label(540, 520, "QUEM VAI TER", 100, PAPER, "Anton") + label(540, 640, "ACESSO?", 120, GOLD, "Anton"), rough=False)])
SCB = {1: b1, 2: b2, 3: use(P4.S, 10, 110), 4: b4, 5: use(P4.S, 13, 113), 110: use(P4.S, 110), 113: use(P4.S, 113)}

# ---------------- C: 1979 ----------------
def c5():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
        layers=[L(0.0, photos.full_bg("congresso.jpg", 0.465, (1.1, 0.95, 0.85), 0.5), rough=False),
                L(0.4, label(540, 820, "25/10", 260, GOLD, "Anton"), rough=False),
                L(0.41, label(540, 960, "VOCÊ DECIDE", 96, PAPER, "Anton"), reveal=(1.0, 0.25, "center"), rough=False)])
SCC = {1: use(P3.S, 6), 2: use(P3.S, 5), 3: use(P4.S, 2), 4: use(P4.S, 3, 103), 5: c5, 103: use(P4.S, 103)}
