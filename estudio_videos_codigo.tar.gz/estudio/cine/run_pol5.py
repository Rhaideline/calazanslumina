"""Renderiza os 3 Reels curtos (A, B, C). Uso: python3 run_pol5.py a b c"""
import json, subprocess, sys
import numpy as np, soundfile as sf
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
AI = "Conteúdo produzido com auxílio de inteligência artificial"
CFG = {
 "a": dict(out="Reel_2turno_A_Anticorrupcao.mp4", hook="VOCÊ VOTOU CONTRA\\NA CORRUPÇÃO?", soft=False, booms=(3, 6), boost=(3, 6),
           src={2: "FONTE: A Pública", 3: "FONTE: Polícia Federal · A Pública", 4: "FONTE: Intercept Brasil · Brasil de Fato",
                5: "FONTE: Folha · Intercept · Aos Fatos", 6: "FONTE: STF, inquérito do min. André Mendonça · CNN Brasil"}),
 "b": dict(out="Reel_2turno_B_Seu_Prontuario.mp4", hook="SEU PRONTUÁRIO NO\\NPLANO DE GOVERNO", soft=True,
           src={2: "FONTE: LGPD, Lei 13.709/2018, art. 5º, II", 3: "FONTE: plano de governo de Flávio · Agência Brasil", 5: "FONTE: tse.jus.br"}),
 "c": dict(out="Reel_2turno_C_1979.mp4", hook="1979 · 2025 · 2026", soft=False, booms=(3, 5), boost=(3, 4, 5),
           src={1: "FONTE: Lei 6.683/1979 · STF, ADPF 153 (2010)", 2: "FONTE: Comissão Nacional da Verdade (2014)",
                3: "FONTE: STF, 11/09/2025 · Poder360", 4: "FONTE: InfoMoney · SBT News", 5: "FONTE: tse.jus.br"}),
}
def soft_audio(meta, total, ep, out):
    v, sr = sf.read(f"{ep}/narracao.wav"); N = int(total * sr); t = np.arange(N) / sr
    pad = np.zeros(N)
    for f, a in ((130.81, .5), (196.0, .35), (261.63, .25), (329.63, .18)):
        pad += a * np.sin(2 * np.pi * f * t) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.09 * t + f))
    bell = np.zeros(N)
    for k, m in enumerate(meta):
        i0 = int(m["start"] * sr); L_ = min(N - i0, int(2.5 * sr)); tt = np.arange(L_) / sr
        f = (523.25, 659.25, 783.99, 659.25, 587.33)[k % 5]
        bell[i0:i0 + L_] += (np.sin(2 * np.pi * f * tt) + .3 * np.sin(4 * np.pi * f * tt)) * np.exp(-tt * 2.2)
    mus = pad / np.abs(pad).max() * .045 + bell / (np.abs(bell).max() + 1e-9) * .05
    mus *= np.minimum(1, t / 1.0) * np.minimum(1, (total - t) / 1.0)
    x = np.zeros(N); x[:len(v)] = v[:N]; y = x * .95 + mus
    sf.write(out, (y / np.abs(y).max() * .95).astype(np.float32), sr)
for key in sys.argv[1:]:
    c = CFG[key]; mod = f"scenes_pol5{key}"; ld = f"layers_pol5{key}"; EP = f"../roteiros/pol5{key}"
    meta, total = plan(EP, tail=0.4); NF = int(total * FPS)
    W = 2; step = NF // W + 1; procs = []
    for k in range(W):
        a, b = k * step, min(NF, (k + 1) * step)
        procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", mod, ld, EP, str(a), str(b), f"pol5{key}_part{k}.mp4", "{}", "{}"]))
    extra = [f"Dialogue: 1,{ts(m['start'])},{ts(m['start'] + m['dur'])},Cap,,0,0,0,,{{\\an2\\pos(540,1690)\\fnMontserrat\\fs38\\bord3\\shad0\\fad(120,120)}}{c['src'][m['i']]}" for m in meta if m["i"] in c["src"]]
    extra.append(f"Dialogue: 1,{ts(0)},{ts(total)},Cap,,0,0,0,,{{\\an2\\pos(540,1790)\\fnMontserrat\\fs30\\bord2\\shad0\\alpha&H30&}}{AI}")
    make_ass(meta, total, c["hook"], "2º TURNO · 25 DE OUTUBRO", {}, {}, extra, f"pol5{key}.ass")
    if c["soft"]: soft_audio(meta, total, EP, f"pol5{key}_mix.wav")
    else: make_audio(meta, total, EP, f"pol5{key}_mix.wav", booms=c["booms"], sea=(), fire=(), drum_boost=c["boost"])
    for p in procs: p.wait()
    open(f"pol5{key}_list.txt", "w").write("".join(f"file 'pol5{key}_part{k}.mp4'\n" for k in range(W)))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", f"pol5{key}_list.txt", "-c", "copy", f"pol5{key}_raw.mp4"], check=True)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"pol5{key}_raw.mp4", "-i", f"pol5{key}_mix.wav", "-vf", f"ass=pol5{key}.ass,hqdn3d=1.2:1.2:3:3",
                    "-c:v", "libx264", "-preset", "medium", "-b:v", "2400k", "-maxrate", "3500k", "-bufsize", "5000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                    "-movflags", "+faststart", "-shortest", f"../saida/{c['out']}"], check=True)
    print("done", key, round(total, 1), flush=True)
