import json, subprocess, sys
from ep_build import plan, make_ass, make_audio, FPS
EP = "../roteiros/ep2"; meta, total = plan(EP); NF = int(total * FPS)
shake = {11: 3, 13: 3}; flash = {11: [1, .2], 13: [1, .2]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build.py", "chunk", "scenes_ep2", "layers_ep2", EP, str(a), str(b), f"ep2w_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
make_ass(meta, total, "A FLORESTA\\NQUE FOI PLANTADA", "HISTÓRIA DO BRASIL · EPISÓDIO 2", 2,
         {3: "CAPÍTULO 1 · A RAIZ", 7: "CAPÍTULO 2 · A TERRA PRETA", 10: "CAPÍTULO 3 · O QUE O LASER VIU", 15: "CAPÍTULO 4 · AS CIDADES-JARDIM"},
         {3: "9 MIL ANOS", 5: "800 MILHÕES", 11: "+10 MIL", 12: "53 ESPÉCIES", 15: "1200 A 1600"},
         "EPISÓDIO 3:\\NMONTANHAS\\NDE CONCHAS", "ep2w.ass")
make_audio(meta, total, EP, "ep2w_mix.wav", booms=(2, 7, 10, 13, 15, 18), fire=(4, 14), drums_from=3, drum_boost=(3, 8, 9, 13, 14, 15, 16))
s_=open("ep2w.ass").read().replace("\\\\N","\\N"); open("ep2w.ass","w").write(s_)
for p in procs: p.wait()
open("ep2w_list.txt", "w").write("".join(f"file 'ep2w_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep2w_list.txt", "-c", "copy", "ep2w_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep2w_raw.mp4", "-i", "ep2w_mix.wav", "-vf", "ass=ep2w.ass,hqdn3d=1.5:1.5:4:4",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "6000k", "-maxrate", "9000k", "-bufsize", "12000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "../saida/wide/Ep2_16x9.mp4"], check=True)
print("done", total)
