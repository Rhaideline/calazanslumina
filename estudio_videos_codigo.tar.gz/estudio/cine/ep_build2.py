import json, sys, subprocess, importlib, math
import numpy as np, soundfile as sf
from ep_build import plan, ts, make_ass as _make_ass
FPS = 30; SPLIT = 4.2

def shots(meta):
    out = []
    for m in meta:
        if m["dur"] > SPLIT:
            h = m["dur"] * 0.5
            out.append(dict(i=m["i"], start=m["start"], dur=h, shot=0, sdur=m["dur"], s0=m["start"]))
            out.append(dict(i=m["i"], start=m["start"] + h, dur=m["dur"] - h, shot=1, sdur=m["dur"], s0=m["start"]))
        else:
            out.append(dict(i=m["i"], start=m["start"], dur=m["dur"], shot=0, sdur=m["dur"], s0=m["start"]))
    return out

def cam_for(sc, sh):
    z0, z1, p0, p1 = sc["cam"]
    if sh["shot"] == 0: return (z0, z0 + (z1 - z0) * 0.5, p0, ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2))
    zz = max(z0, z1) * 1.22
    return (zz, zz * 1.06, (p1[0] * 1.6, p1[1] * 1.6 - 20), (p1[0] * 1.9, p1[1] * 1.9 - 40))

def render_chunk(mod, layers_dir, epdir, n0, n1, out, shake, flash):
    import cv2
    from cine import Particles, OW, OH
    from cine2 import Scene, compose, post
    SC = importlib.import_module(mod).SC
    meta, total = plan(epdir, tail=0.2); SH = shots(meta); XF = 0.28; cache = {}
    from collections import OrderedDict
    cache = OrderedDict(); ovl = {}
    def get(n):
        if n in cache: cache.move_to_end(n); return cache[n]
        cache[n] = (Scene(n, SC[n](), layers_dir), Particles(SC[n]().get("particles"), n))
        while len(cache) > 5: cache.popitem(last=False)
        return cache[n]
    def overlay(key, lt, rt):
        if key in ovl: return ovl[key]
        from PIL import Image, ImageDraw, ImageFont
        im = Image.new("RGBA", (OW, OH), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        f = ImageFont.truetype("/usr/local/share/fonts/custom/Anton-Regular.ttf", 64)
        d.rectangle([537, 0, 543, OH], fill=(244, 241, 234, 255))
        for x, txt, col in ((270, lt, (138, 138, 146)), (810, rt, (230, 57, 70))):
            if not txt: continue
            w = d.textlength(txt, font=f); d.rounded_rectangle([x - w / 2 - 24, 1480, x + w / 2 + 24, 1580], 18, fill=(10, 10, 14, 230))
            d.text((x - w / 2, 1488), txt, font=f, fill=col + (255,))
        a = np.asarray(im).astype(np.float32) / 255; ovl[key] = a; return a
    def one(n, sh, tl, shot_kick=True):
        sc, pr = get(n); u = min(1, max(0, (tl + XF) / (sh["dur"] + XF)))
        cam = cam_for(sc.sc, sh)
        if shot_kick and sh["shot"] == 1 and 0 <= tl < 0.25:
            k = 1 + 0.07 * (1 - tl / 0.25) ** 2; cam = (cam[0] * k, cam[1] * k, cam[2], cam[3])
        shk = shake.get(n, 0) * max(0, 1 - tl) if (0 <= tl < 1 and sh["shot"] == 0) else 0
        return compose(sc, u, tl + sh["start"] - sh["s0"], shk, cam), pr
    def ff(sh, tl):
        base = get(sh["i"])[0].sc
        if "split" in base and (base.get("split_shot") is None or base.get("split_shot") == sh["shot"]):
            a, b, lt, rt = base["split"]
            A, pr = one(a, sh, tl); B, _ = one(b, sh, tl)
            def col(X):
                bgc = cv2.GaussianBlur(X[:, 270:810], (0, 0), 18) * 0.45
                sm = cv2.resize(X, (540, 960), interpolation=cv2.INTER_AREA); bgc[480:1440] = sm; return bgc
            fr = np.concatenate([col(A), col(B)], 1)
            o = overlay((a, b, lt, rt), lt, rt); fr = fr * (1 - o[:, :, 3:4]) + o[:, :, :3] * o[:, :, 3:4]
            return fr.astype(np.float32), pr
        if sh["shot"] == 1 and "alt" in base:
            return one(base["alt"], sh, tl)
        return one(sh["i"], sh, tl)
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OW}x{OH}", "-r", str(FPS), "-i", "-",
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    for n in range(n0, n1):
        t = n / FPS
        k = max(j for j, s in enumerate(SH) if s["start"] <= t + 1e-9); sh = SH[k]; tl = t - sh["start"]
        fr, pr = ff(sh, tl)
        if k + 1 < len(SH) and SH[k + 1]["i"] != sh["i"]:
            nx = SH[k + 1]; tn = nx["start"] - t
            if tn < XF:
                a = 1 - tn / XF; f2, _ = ff(nx, -tn); fr = fr * (1 - a) + f2 * a
        if sh["i"] in flash and sh["shot"] == 0 and tl < 0.2:
            kind, amt = flash[sh["i"]]; w = (1 - tl / 0.2) * amt
            fr = fr * (1 - w) + (np.array([1, 1, 1], np.float32) if kind else np.array([0.8, 0.12, 0.08], np.float32)) * w
        enc.stdin.write(post(fr, t, pr, total).tobytes())
    enc.stdin.close(); enc.wait()

def make_ass(meta, total, hook, tag, chap, big, extra, out):
    _make_ass(meta, total, "X", tag, 1, chap, big, "", out)
    s = open(out).read().split("\n")
    s = [l for l in s if not (",Title," in l)]
    s = [l.replace(",Tag,,0,0,0,,{\\fad(150,250)}", ",Tag,,0,0,0,,{\\fad(0,250)}") for l in s]
    lines = [f"Dialogue: 4,{ts(0)},{ts(2.9)},Title,,0,0,0,,{{\\pos(540,560)\\fad(0,200)}}{hook}"]
    tagl = [l for l in s if ",Tag," in l]
    s = [l for l in s if ",Tag," not in l]
    lines.append(f"Dialogue: 4,{ts(0)},{ts(2.9)},Tag,,0,0,0,,{{\\fad(0,200)}}{tag}")
    lines += extra
    open(out, "w").write("\n".join(s).rstrip("\n") + "\n" + "\n".join(lines) + "\n")

def make_audio(meta, total, epdir, out, booms=(), sea=(), fire=(), drum_boost=()):
    voice, sr = sf.read(f"{epdir}/narracao.wav"); N = int(total * sr); t = np.arange(N) / sr
    st = {m["i"]: m["start"] for m in meta}; nz = np.random.default_rng(3)
    def add(buf, i0, sig):
        if i0 < 0: sig = sig[-i0:]; i0 = 0
        e = min(N, i0 + len(sig)); buf[i0:e] += sig[:e - i0]
    pad = np.zeros(N)
    for f, a in ((73.42, .5), (110.0, .3), (146.83, .22), (174.61, .15), (220.0, .08)):
        for dd in (-0.3, 0.3): pad += a * np.sin(2 * np.pi * (f + dd) * t + dd)
    pad *= 0.65 + 0.35 * np.sin(2 * np.pi * 0.07 * t)
    def mem(f0, dec, L=0.35, nsz=0.15):
        tt = np.arange(int(L * sr)) / sr; e = np.exp(-tt * dec)
        return (np.sin(2 * np.pi * f0 * (1 + 0.5 * np.exp(-tt * 30)) * tt) + nsz * nz.standard_normal(len(tt)) * np.exp(-tt * 60)) * e
    LOW, MID, SH = mem(60, 8), mem(118, 12), mem(300, 40, 0.12, 2.5)
    drum = np.zeros(N); beat = 0.46; bar = 0.0
    pat = [(0, LOW, 1), (1, SH, .4), (1.5, MID, .6), (2, LOW, .8), (2.5, SH, .35), (3, MID, .5), (3.5, SH, .4)]
    while bar < total:
        sc = max(m["i"] for m in meta if m["start"] <= bar)
        inten = 0.95 if sc in drum_boost else 0.5
        for off, s_, a in pat:
            tt = bar + off * beat
            if tt < total: add(drum, int(tt * sr), s_ * a * inten)
        bar += 4 * beat
    fx = np.zeros(N)
    cuts = [s["start"] for s in shots(meta)][1:]
    for c in cuts:
        L = int(0.4 * sr); w = np.convolve(nz.standard_normal(L), np.ones(10) / 10, mode="same") * np.sin(np.pi * np.arange(L) / L) ** 2
        add(fx, int((c - 0.22) * sr), 0.28 * w)
    for sc in booms:
        tt = np.arange(int(2 * sr)) / sr
        add(fx, int(st[sc] * sr), 1.5 * np.sin(2 * np.pi * (60 * np.exp(-tt * 3) + 30) * tt) * np.exp(-tt * 2.4))
    amb = np.zeros(N)
    for sc in sea:
        m = meta[sc - 1]; L = int(m["dur"] * sr); tt = np.arange(L) / sr
        w = np.convolve(nz.standard_normal(L), np.ones(60) / 60, mode="same") * (0.55 + 0.45 * np.sin(2 * np.pi * 0.18 * tt)) * np.minimum(1, np.minimum(tt, tt[-1] - tt) / 0.3)
        add(amb, int(m["start"] * sr), w)
    for sc in fire:
        m = meta[sc - 1]; L = int(m["dur"] * sr); c = np.zeros(L)
        for k in range(int(m["dur"] * 25)):
            i0 = nz.integers(0, max(1, L - 800)); c[i0:i0 + 400] += nz.standard_normal(400) * np.exp(-np.arange(400) / 60) * nz.uniform(0.2, 1)
        add(amb, int(m["start"] * sr), 0.15 * c)
    def norm(x, g): return x / (np.abs(x).max() + 1e-9) * g
    music = norm(pad, .05) + norm(drum, .15) + norm(fx, .2) + norm(amb, .09)
    music *= np.minimum(1, (total - t) / 0.2)
    v = np.zeros(N); v[:len(voice)] = voice[:N]
    venv = np.convolve(np.abs(v), np.ones(int(0.2 * sr)) / int(0.2 * sr), mode="same")
    duck = 1 - 0.45 * np.clip(venv / (venv.max() * 0.3), 0, 1)
    sf.write(out, norm(v * 0.95 + music * duck, 0.95).astype(np.float32), sr)

if __name__ == "__main__" and sys.argv[1] == "chunk":
    _, _, mod, ld, ep, n0, n1, out, sh, fl = sys.argv
    render_chunk(mod, ld, ep, int(n0), int(n1), out, {int(k): v for k, v in json.loads(sh).items()}, {int(k): tuple(v) for k, v in json.loads(fl).items()})
