from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep1 import caatinga, maloca, caravel
from scenes_ep2 import jtree, palm, jungle, canopy_top
import random, math

SHELL = "#EDE3CF"
def shells(x0, x1, y0, y1, n, seed=1, cols=("#EDE3CF", "#E0D2B8", "#F4ECDC", "#D8C8A8")):
    r = random.Random(seed); g = []
    for _ in range(n):
        x, y, s, a = r.uniform(x0, x1), r.uniform(y0, y1), r.uniform(0.4, 1.2), r.uniform(0, 360); c = r.choice(cols)
        g.append(f'<g transform="translate({x:.0f},{y:.0f}) rotate({a:.0f}) scale({s:.2f})"><path d="M0,0 L-26,-30 Q0,-44 26,-30 Z" fill="{c}"/>' + "".join(f'<line x1="0" y1="0" x2="{-22+j*11}" y2="-34" stroke="{mix(c,"#6A5A40",.4)}" stroke-width="1.5"/>' for j in range(5)) + '</g>')
    return "".join(g)

def mound(cx, base_y, w, h, col=SHELL, seed=1):
    return f'<path d="M{cx-w/2},{base_y} C{cx-w*0.38},{base_y-h*0.7} {cx-w*0.2},{base_y-h} {cx},{base_y-h} C{cx+w*0.2},{base_y-h} {cx+w*0.38},{base_y-h*0.7} {cx+w/2},{base_y} Z" fill="{col}"/>'

def skeleton(x, y, s, col="#F6F0E2"):
    return (f'<g transform="translate({x},{y}) scale({s})" stroke="{col}" stroke-width="7" fill="none" stroke-linecap="round">'
            f'<circle cx="0" cy="0" r="22" fill="{col}" stroke="none"/><path d="M20,10 Q60,20 80,50"/><path d="M40,20 q-10,20 5,35 M55,28 q-10,20 5,35 M68,38 q-8,18 4,30"/>'
            f'<path d="M80,50 Q60,90 30,95 Q10,100 20,70"/><path d="M80,50 Q100,90 70,110"/><path d="M30,40 Q10,60 -5,45"/></g>')

def section(cx, base_y, w, h, seed=1, burials=3):
    r = random.Random(seed); cols = ["#E8DCC4", "#C8B898", "#DCCCAE", "#A89878", "#E4D8BE", "#B8A888"]
    g = [f'<clipPath id="sec{seed}"><path d="M{cx-w/2},{base_y} C{cx-w*0.38},{base_y-h*0.7} {cx-w*0.2},{base_y-h} {cx},{base_y-h} C{cx+w*0.2},{base_y-h} {cx+w*0.38},{base_y-h*0.7} {cx+w/2},{base_y} Z"/></clipPath><g clip-path="url(#sec{seed})">']
    k = 0; yy = base_y
    while yy > base_y - h - 20:
        th = r.uniform(30, 70); g.append(f'<path d="M{cx-w},{yy} Q{cx},{yy-th*0.6 + r.uniform(-10,10):.0f} {cx+w},{yy} L{cx+w},{yy-th:.0f} L{cx-w},{yy-th:.0f} Z" fill="{cols[k%len(cols)]}"/>')
        g.append(f'<rect x="{cx-w}" y="{yy-3:.0f}" width="{2*w}" height="4" fill="#6A5A40" opacity=".25"/>')
        yy -= th; k += 1
    g.append(shells(cx - w / 2, cx + w / 2, base_y - h, base_y, 70, seed + 5))
    for b in range(burials):
        g.append(skeleton(cx - w * 0.25 + b * w * 0.2 + r.uniform(-20, 20), base_y - h * (0.2 + 0.2 * b) - r.uniform(0, 20), 0.9, "#5A4A34"))
    g.append('</g>')
    return "".join(g)

def lagoon(y, c1, c2, glint="#FFE8C8"):
    return f'<rect x="{X0}" y="{y}" width="{BW}" height="{Y1-y}" fill="{c1}"/>' + "".join(f'<path d="M{X0},{y+12+k*28} q300,-6 650,0 t650,0" stroke="{glint}" stroke-width="3" fill="none" opacity="{max(0.05,0.5-k*0.035):.2f}"/>' for k in range(16))

def marajo_pattern(x, y, w, h, c="#1A0E0A", seed=1):
    g = []; r = random.Random(seed)
    for row in range(int(h // 60)):
        yy = y + row * 60 + 30
        for col in range(int(w // 60)):
            xx = x + col * 60 + 30; t = (row + col) % 3
            if t == 0: g.append(f'<path d="M{xx-22},{yy+22} L{xx-22},{yy-22} L{xx+22},{yy-22} L{xx+22},{yy+8} L{xx-8},{yy+8} L{xx-8},{yy-8}" fill="none" stroke="{c}" stroke-width="6"/>')
            elif t == 1: g.append(f'<path d="M{xx-24},{yy} Q{xx-12},{yy-20} {xx},{yy} T{xx+24},{yy}" fill="none" stroke="{c}" stroke-width="6"/><circle cx="{xx}" cy="{yy+16}" r="4" fill="{c}"/>')
            else: g.append(f'<rect x="{xx-18}" y="{yy-18}" width="36" height="36" fill="none" stroke="{c}" stroke-width="6"/><rect x="{xx-6}" y="{yy-6}" width="12" height="12" fill="{c}"/>')
    return "".join(g)

def urn(cx, cy, s, body="#E8D4B0", red="#A8321E", seed=1, face=True):
    cid = f"urn{seed}"
    shape = "M-180,-260 C-230,-240 -260,-120 -250,20 C-240,180 -150,300 0,310 C150,300 240,180 250,20 C260,-120 230,-240 180,-260 C120,-290 -120,-290 -180,-260 Z"
    g = [f'<g transform="translate({cx},{cy}) scale({s})"><defs><clipPath id="{cid}"><path d="{shape}"/></clipPath></defs><path d="{shape}" fill="{body}"/>',
         f'<g clip-path="url(#{cid})"><rect x="-260" y="-40" width="520" height="70" fill="{red}"/>' + marajo_pattern(-260, 40, 520, 280, "#1A0E0A", seed) + marajo_pattern(-260, -220, 520, 170, red, seed + 1) + '</g>',
         f'<ellipse cx="0" cy="-268" rx="185" ry="30" fill="{mix(body,"#000000",.25)}"/><path d="{shape}" fill="none" stroke="#5A3A20" stroke-width="6"/>']
    if face:
        g.append(f'<g transform="translate(0,-150)"><path d="M-70,-40 Q0,-70 70,-40 L50,60 Q0,80 -50,60 Z" fill="{body}" stroke="#1A0E0A" stroke-width="6"/><path d="M-45,-10 q20,-12 36,0 M9,-10 q20,-12 36,0" stroke="#1A0E0A" stroke-width="7" fill="none"/><path d="M0,0 L0,30 M-20,45 L20,45" stroke="#1A0E0A" stroke-width="6"/><path d="M-70,-40 L-100,0 M70,-40 L100,0" stroke="{red}" stroke-width="10"/></g>')
    g.append('</g>')
    return "".join(g)

S = {}
def e1():
    return dict(light="#FFE0B8", rim_dx=5, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A3858"), (0.55, "#D8906A"), (1, "#F0B888")]) + sun(760, 1150, 80, halo_r=700)),
                L(0.2, lagoon(1300, "#7A6A80", "#5A4A60")),
                L(0.4, R(mound(540, 1500, 1100, 560, "#D8CCB4")) + ground(1495, "#8A7A60", "#5A4E3A", 4, 1)),
                L(0.41, section(540, 1500, 1100, 560, 3, 3), reveal=(1.2, 2.5, "center"), rough=False),
                L(0.85, R(person(160, 1920, 420, "#140E0A", "shirt", "hair", prop=("staff",), face=1)) + ground(1900, "#2A2016", "#140E0A", 8, 2))])
S[1] = e1
def e2():
    mounds = mound(250, 1420, 420, 180, "#C8B8A0") + mound(700, 1440, 620, 280, "#D8C8B0") + mound(1000, 1410, 300, 120, "#C0B098")
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (0, 30), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8B888"), (0.5, "#F0A070"), (1, "#E88A60")]) + sun(540, 1100, 100, halo_r=800)),
                L(0.05, godrays(540, 1100, "#FFEFC8", n=14, spread=170, a0=-90, op=.26, seed=2), mode="screen"),
                L(0.2, ridge(1230, "#B88068", 60, 21) + caatinga(1260, "#9A6048", 14, 22, 50, 110)),
                L(0.35, lagoon(1300, "#D89A70", "#B87A58")),
                L(0.55, R(mounds) + f'<rect x="{X0}" y="1430" width="{BW}" height="700" fill="#7A6048"/>'),
                L(0.85, R(palm(40, 2100, 1100, "#1E120C", 21) + palm(1040, 2100, 900, "#1E120C", 22)) + ground(1880, "#2A1A10", "#140A06", 10, 3))])
S[2] = e2
def e3():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.14, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A2A30"), (1, "#3E3A38")]) + glow(540, 1150, 800, "#FFE0B0", .4)),
                L(0.4, shells(X0, X1, 1000, 2100, 700, 3), rough=False)])
S[3] = e3
def e4():
    carriers = "".join(person(300 + k * 110, 1440 - k * 70, 190, "#1A120C", "shirt", "hair", la=(-110, -80), ra=(-70, -100), ll=(70, 110), rl=(110, 85), lean=-10, face=1) + f'<ellipse cx="{300+k*110}" cy="{1440-k*70-205}" rx="34" ry="20" fill="#1A120C"/>' for k in range(4))
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (-20, 0), (20, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C0D0"), (0.6, "#F0DCB8"), (1, "#F0C898")]) + sun(820, 700, 70, halo_r=600)),
                L(0.2, lagoon(1250, "#8AA8B8", "#6A8898")),
                L(0.4, R(mound(640, 1520, 1000, 420, "#E0D4BC")) + R(carriers) + ground(1510, "#A89878", "#7A6A50", 4, 1)),
                L(0.8, R(f'<path d="M60,1800 Q260,1850 480,1800 L460,1830 Q260,1880 80,1830 Z" fill="#140E0A"/>' + person(200, 1805, 200, "#140E0A", "shirt", "hair", la=(40, 60), ra=(40, 70), ll=(-10, 80), rl=(10, 95), face=1)) + lagoon(1830, "#4A6878", "#2A4858"))])
S[4] = e4
def e5():
    ring = "".join(person(540 + 460 * math.cos(a), 1600 + 50 * math.sin(a), 250 + 50 * (math.sin(a) + 1) / 2, "#0A0806", "shirt", "hair", la=(100, 95), ra=(-60, -90) if k % 3 == 0 else (80, 85), face=1 if math.cos(a) < 0 else -1) for k, a in enumerate(sorted([k * 2 * math.pi / 12 for k in range(12)], key=lambda a: math.sin(a))))
    return dict(light="#FFB070", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0E1C"), (0.6, "#1E2238"), (1, "#3A3048")]) + "".join(f'<circle cx="{random.Random(k).randint(X0,X1)}" cy="{random.Random(k+1).randint(Y0,1000)}" r="{random.Random(k+2).choice([1.5,2,3])}" fill="#FFF3D0" opacity=".8"/>' for k in range(90))),
                L(0.3, R(mound(540, 1480, 1300, 520, "#3A3438"))),
                L(0.45, glow(540, 1560, 500, "#FF9A50", .55), mode="screen", flicker=0.2),
                L(0.5, fire(500, 1580, 80, 150, 5), flicker=0.2, rough=False),
                L(0.6, R(ring) + ground(1560, "#1A1618", "#0A0808", 4, 1))])
S[5] = e5
def e6():
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (0, 40), (0, -40)), particles="dust",
        layers=[L(0.0, sky([(0, "#98B0C8"), (0.6, "#E8DCC0"), (1, "#F0C8A0")])),
                L(0.3, R(mound(540, 1600, 1250, 900, "#E4D8C0")) + ground(1595, "#A89878", "#7A6A50", 4, 1)),
                L(0.35, f'<line x1="980" y1="700" x2="980" y2="1600" stroke="#B0301E" stroke-width="8"/><path d="M950,700 L1010,700 M950,1600 L1010,1600" stroke="#B0301E" stroke-width="8"/><text x="960" y="1140" font-family="Anton" font-size="64" text-anchor="end" fill="#B0301E">30 M</text>' + f'<line x1="-90" y1="1680" x2="1170" y2="1680" stroke="#B0301E" stroke-width="8"/>' + R(person(380, 1600, 70, "#140E0A", "shirt", "hair", face=1) + person(420, 1600, 64, "#140E0A", "dress", "hair", face=1)), rough=False)])
S[6] = e6
def e7():
    pyr = f'<path d="M600,1500 L840,1150 L1080,1500 Z" fill="#C89A60"/><path d="M840,1150 L1080,1500 L900,1500 Z" fill="#A87A48"/><path d="M880,1500 L1040,1280 L1190,1500 Z" fill="#B88A58"/>'
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#E8C898"), (1, "#F0D8B0")]) + sun(540, 800, 70, halo_r=500)),
                L(0.4, R(mound(300, 1500, 560, 300, "#E0D4BC") + pyr) + ground(1495, "#C8B08A", "#A89068", 4, 1) + f'<line x1="540" y1="1000" x2="540" y2="1700" stroke="#3A2A1C" stroke-width="5" stroke-dasharray="20 14"/>'
                 + f'<text x="300" y="1620" font-family="Anton" font-size="64" text-anchor="middle" fill="#3A2A1C">SAMBAQUI</text><text x="300" y="1690" font-family="Anton" font-size="44" text-anchor="middle" fill="#6A4A2A">ATÉ 8 MIL ANOS</text>'
                 + f'<text x="840" y="1620" font-family="Anton" font-size="64" text-anchor="middle" fill="#3A2A1C">PIRÂMIDES</text><text x="840" y="1690" font-family="Anton" font-size="44" text-anchor="middle" fill="#6A4A2A">CERCA DE 4.500 ANOS</text>', rough=False)])
S[7] = e7
def e8():
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, -40), (0, 40)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A2420"), (1, "#3A3028")]) + glow(540, 1200, 800, "#FFD8A0", .35)),
                L(0.3, section(540, 1800, 1400, 1100, 8, 7), rough=False)])
S[8] = e8
def e9():
    coast = "M820,300 C860,500 900,650 880,800 C860,950 780,1100 700,1250 C620,1400 560,1550 500,1700 C470,1780 420,1850 380,1900"
    dots = "".join(f'<circle cx="{x+random.Random(k).uniform(-20,20):.0f}" cy="{y:.0f}" r="10" fill="#E0301E"/>' for k, (x, y) in enumerate([(870 - (y - 300) * 0.25, y) for y in range(420, 1880, 38)]))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, -40), (0, 60)), particles="dust",
        layers=[L(0.0, sky([(0, "#E9D8B0"), (1, "#D6BE8A")]) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>' + f'<path d="{coast} L{X0},1900 L{X0},300 Z" fill="#D8C49C"/><path d="{coast} L{X1},1900 L{X1},300 Z" fill="#8AA8B0"/><path d="{coast}" fill="none" stroke="#5A3A26" stroke-width="6"/>', rough=False),
                L(0.1, dots, reveal=(0.4, 2.5, "ltr"), rough=False)])
S[9] = e9
def e10():
    kiln = f'<path d="M340,1600 L380,1000 Q540,920 700,1000 L740,1600 Z" fill="#2A1E16"/><path d="M470,1600 L470,1450 Q540,1400 610,1450 L610,1600 Z" fill="#FF8A3C"/>'
    return dict(light="#FFB070", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#2A2A30"), (0.6, "#5A4A48"), (1, "#8A6A58")])),
                L(0.2, smoke_puffs(560, 900, "#A8A098", n=10, s=1.4, seed=10, drift=1), drift=(40, -80)),
                L(0.4, R(kiln) + glow(540, 1520, 300, "#FF8A3C", .6) + ground(1595, "#3A302A", "#1E1814", 4, 1)),
                L(0.7, R(person(190, 1850, 520, "#0A0806", "shirt", "brim", la=(60, 20), ra=(40, 0), lean=40, face=1, ll=(60, 110), rl=(110, 90)) + f'<line x1="260" y1="1500" x2="420" y2="1760" stroke="#0A0806" stroke-width="12"/>' + person(900, 1860, 480, "#0A0806", "shirt", "brim", la=(-120, -60), ra=(-60, -30), face=-1)) + shells(600, 1100, 1700, 1860, 120, 10, ("#8A8070", "#9A9080")) + ground(1840, "#1E1814", "#0E0A08", 6, 2))])
S[10] = e10
def e11():
    return dict(light="#FFE6C0", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#A8C8D8"), (1, "#E8E0C8")])),
                L(0.3, R(mound(540, 1450, 1000, 380, "#E0D4BC")) + ground(1445, "#8AA070", "#6A8058", 4, 1)),
                L(0.6, R(f'<g transform="translate(760,1700) rotate(-4)"><rect x="-8" y="-240" width="16" height="240" fill="#2A1E14"/><rect x="-200" y="-330" width="400" height="140" fill="#F4ECDC" stroke="#2A1E14" stroke-width="6"/><text x="0" y="-275" font-family="Anton" font-size="46" text-anchor="middle" fill="#2A1E14">PATRIMÔNIO</text><text x="0" y="-222" font-family="Anton" font-size="38" text-anchor="middle" fill="#B0301E">LEI 3.924 · 1961</text></g>' + "".join(f'<rect x="{x}" y="1600" width="12" height="130" fill="#2A1E14"/>' for x in range(-100, 1200, 90)) + f'<rect x="-100" y="1630" width="1300" height="8" fill="#2A1E14"/><rect x="-100" y="1680" width="1300" height="8" fill="#2A1E14"/>') + ground(1720, "#4A5A38", "#2A3420", 6, 2))])
S[11] = e11
def e12():
    island = "M250,700 C450,560 780,600 900,780 C980,920 920,1180 760,1320 C580,1460 320,1420 220,1240 C120,1060 110,820 250,700 Z"
    return dict(light="#FFF0C8", rim_dx=4, cam=(1.06, 1.0, (0, 40), (0, -40)), particles=None,
        layers=[L(0.0, f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" fill="#8A7A58"/>' + "".join(f'<path d="M{X0},{y} q300,{random.Random(y).randint(-30,30)} 650,0 t650,0" stroke="#A89060" stroke-width="{random.Random(y+1).randint(4,14)}" fill="none" opacity=".5"/>' for y in range(Y0, Y1, 50)), rough=False),
                L(0.05, f'<path d="{island}" fill="#4A6A3A"/>' + canopy_top(["#3A5A2E", "#4A6A38"], 12, 650, 1350, 160, 20, 45) + f'<path d="M{X0},300 C200,400 300,450 250,700" stroke="#8A7A58" stroke-width="80" fill="none"/>', rough=False),
                L(0.3, clouds(900, "#FFFFFF", .35, seed=12, scale=1.4), drift=(-60, 0))])
S[12] = e12
def e13():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.14, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#1A0E0A"), (1, "#2E1A12")]) + glow(540, 1050, 800, "#FFCF8A", .45)),
                L(0.5, f'<ellipse cx="540" cy="1400" rx="340" ry="50" fill="#0A0604"/>' + urn(540, 1080, 1.1, seed=13), rough=False)])
S[13] = e13
def e14():
    houses = "".join(maloca(x, y, s, "#2A1E14") for x, y, s in [(300, 1380, 0.35), (760, 1300, 0.4), (520, 1330, 0.3)])
    rain = "".join(f'<line x1="{random.Random(k).randint(X0,X1)}" y1="{random.Random(k+1).randint(Y0,Y1)}" x2="{random.Random(k).randint(X0,X1)-20}" y2="{random.Random(k+1).randint(Y0,Y1)+60}" stroke="#C8D4DC" stroke-width="2" opacity=".35"/>' for k in range(220))
    return dict(light="#E8F0F4", rim_dx=4, cam=(1.0, 1.1, (0, 20), (0, -30)), particles=None,
        layers=[L(0.0, sky([(0, "#5A6A78"), (0.6, "#8A9AA4"), (1, "#A8B4B8")])),
                L(0.2, R(mound(300, 1440, 560, 140, "#5A4A38") + mound(760, 1400, 640, 200, "#5A4A38") + houses)),
                L(0.35, lagoon(1420, "#6A8090", "#4A6070", "#E0E8EC")),
                L(0.6, R(f'<path d="M160,1640 Q360,1690 580,1640 L560,1670 Q360,1720 180,1670 Z" fill="#1A1A1C"/>' + person(300, 1645, 220, "#1A1A1C", "shirt", "hair", la=(40, 60), ra=(40, 70), ll=(-10, 80), rl=(10, 95), face=1)), drift=(60, 0)),
                L(0.7, rain, drift=(-40, 120), rough=False)])
S[14] = e14
def e15():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, -20), (0, 30)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1A12"), (1, "#3E2618")]) + glow(540, 960, 900, "#FFCF8A", .45)),
                L(0.3, urn(540, 1000, 1.6, seed=15, face=True), rough=False),
                L(0.35, f'<g transform="translate(540,1000) scale(1.6)"><path d="M-240,120 C-160,60 -80,160 0,100 C80,40 160,150 240,90" stroke="#1A0E0A" stroke-width="16" fill="none"/><circle cx="240" cy="90" r="16" fill="#1A0E0A"/></g>', reveal=(0.5, 2.0, "ltr"), rough=False)])
S[15] = e15
def e16():
    tanga = f'<g transform="translate(540,1000) scale(2.2)"><path d="M-160,-110 Q0,-130 160,-110 Q60,40 0,160 Q-60,40 -160,-110 Z" fill="#E8D4B0" stroke="#5A3A20" stroke-width="5"/><clipPath id="tg"><path d="M-160,-110 Q0,-130 160,-110 Q60,40 0,160 Q-60,40 -160,-110 Z"/></clipPath><g clip-path="url(#tg)">{marajo_pattern(-160, -120, 320, 300, "#A8321E", 16)}</g><circle cx="-150" cy="-104" r="8" fill="#5A3A20"/><circle cx="150" cy="-104" r="8" fill="#5A3A20"/><circle cx="0" cy="150" r="8" fill="#5A3A20"/></g>'
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#1E1410"), (1, "#2E1E16")]) + glow(540, 1000, 700, "#FFCF8A", .45)), L(0.4, tanga, rough=False)])
S[16] = e16
def e17():
    case_ = "".join(f'<g><rect x="{x-150}" y="900" width="300" height="560" fill="#1A2428" opacity=".6" stroke="#8A9A9A" stroke-width="4"/>{urn(x, 1250, 0.45, seed=170+i)}<rect x="{x-170}" y="1460" width="340" height="120" fill="#2A2420"/></g>' for i, x in enumerate((220, 540, 860)))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (-30, 0), (30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A342E"), (1, "#4A423A")]) + "".join(f'<rect x="{x}" y="200" width="160" height="600" fill="#5A524A"/>' for x in range(-80, 1200, 280)) + glow(540, 700, 900, "#FFE8C0", .35)),
                L(0.4, case_ + ground(1580, "#2A2420", "#1A1614", 2, 1), rough=False),
                L(0.8, R(person(160, 1920, 520, "#0A0806", "shirt", "hair", face=1) + person(940, 1930, 480, "#0A0806", "dress", "hair", face=-1)))])
S[17] = e17
def e18():
    vase = urn(620, 1250, 0.6, seed=18, face=False)
    return dict(light="#FFB070", rim_dx=-4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1C14"), (1, "#4A3020")]) + glow(760, 900, 700, "#FFCF8A", .5)),
                L(0.3, f'<rect x="{X0}" y="1440" width="{BW}" height="700" fill="#3A2618"/>' + vase, rough=False),
                L(0.6, R(person(300, 1700, 640, "#0A0604", "shirt", "hair", la=(20, -10), ra=(10, -20), lean=40, face=1, ll=(-10, 80), rl=(10, 95))))])
S[18] = e18
def e19():
    return dict(light="#FFE0A0", rim_dx=5, cam=(1.0, 1.1, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A4A70"), (0.5, "#E0906A"), (1, "#F0B070")]) + sun(540, 1150, 110, halo_r=900)),
                L(0.05, godrays(540, 1150, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=19), mode="screen"),
                L(0.3, lagoon(1300, "#C88A68", "#8A5A48")),
                L(0.5, R(mound(280, 1560, 700, 360, "#2A1812") + urn(820, 1360, 0.55, "#2A1812", "#2A1812", 19, False)) + ground(1555, "#2A1812", "#140A08", 4, 1))])
S[19] = e19
def e20():
    return dict(light="#FFE6B0", rim_dx=5, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A7A98"), (0.5, "#F0B888"), (1, "#F8D8A8")]) + sun(700, 1150, 90, halo_r=800)),
                L(0.05, godrays(700, 1150, "#FFF3D0", n=14, spread=160, a0=-90, op=.24, seed=20), mode="screen"),
                L(0.2, lagoon(1160, "#6A8AA0", "#4A6A80")),
                L(0.3, R(caravel(560, 1160, 0.5, "#1E1E24") + caravel(820, 1170, 0.35, "#2A2A30") + caravel(300, 1175, 0.3, "#2A2A30")), drift=(-60, 0)),
                L(0.8, R(palm(60, 2100, 1300, "#140C08", 201) + palm(1020, 2100, 1100, "#140C08", 202)) + ground(1860, "#E0C898", "#B89868", 8, 2))])
S[20] = e20
SC = S
