import json, subprocess, sys
from ep_build import plan, make_ass, make_audio, FPS
EP = "../ep1"; meta, total = plan(EP); NF = int(total * FPS)
shake = {1: 2, 15: 6, 11: 3}; flash = {15: [0, .3], 14: [1, .25], 5: [1, .15]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build.py", "chunk", "scenes_ep1", "layers_ep1", EP, str(a), str(b), f"ep1_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
make_ass(meta, total, "O BRASIL ANTES\\\\NDO BRASIL", "HISTÓRIA DO BRASIL · EPISÓDIO 1", 2,
         {3: "CAPÍTULO 1 · A CHEGADA", 6: "CAPÍTULO 2 · AS PISTAS", 12: "CAPÍTULO 3 · LUZIA", 17: "CAPÍTULO 4 · A VERDADE"},
         {5: "21 MIL ANOS", 8: "25 MIL ANOS", 11: "50 MIL?", 13: "11.400 ANOS", 14: "100% INDÍGENA", 16: "+9 MIL ANOS"},
         "EPISÓDIO 2:\\\\NA FLORESTA\\\\NQUE FOI PLANTADA", "ep1.ass")
make_audio(meta, total, EP, "ep1_mix.wav", booms=(2, 7, 11, 14, 15, 17), fire=(1, 15), drums_from=3, drum_boost=(3, 4, 7, 9, 10, 17, 18))
for p in procs: p.wait()
open("ep1_list.txt", "w").write("".join(f"file 'ep1_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep1_list.txt", "-c", "copy", "ep1_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep1_raw.mp4", "-i", "ep1_mix.wav", "-vf", "ass=ep1.ass,hqdn3d=1.5:1.5:4:4",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1800k", "-maxrate", "2400k", "-bufsize", "4000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "/home/claude/Historia_do_Brasil_Ep1.mp4"], check=True)
print("done", total)
