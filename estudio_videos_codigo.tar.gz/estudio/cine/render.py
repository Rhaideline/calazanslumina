import asyncio, os, sys
from art import BW, BH
async def render_pages(jobs, scale=1.0):
    """jobs: list of (html, outpath)"""
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": BW, "height": BH}, device_scale_factor=scale)
        for html, out in jobs:
            os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
            await pg.set_content(html); await pg.wait_for_timeout(120)
            await pg.screenshot(path=out, omit_background=True, clip={"x": 0, "y": 0, "width": BW, "height": BH})
        await b.close()
def run(jobs, scale=1.0): asyncio.run(render_pages(jobs, scale))
