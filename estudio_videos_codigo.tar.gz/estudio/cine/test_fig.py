from art import *
from render import run
col = "#16120E"
b = sky([(0, "#F6C88A"), (0.55, "#E38B52"), (1, "#7A3A30")]) + sun(760, 900, 90) + godrays(760, 900, n=11, spread=120) + clouds(500, "#FFE2B8", .35, seed=3)
b += forest_depth(1050, 1350, "#B8705A", "#3A2018", rows=3, seed=4)
fg = (person(170, 1800, 560, col, "poncho", "brim", la=(100, 95), ra=(70, 60), prop=("facao", -70), face=1)
      + person(420, 1800, 600, col, "robe", "brim", ra=(40, -10), prop=("herbs", "#7FAE5A"), beard=True, face=1)
      + person(660, 1800, 520, col, "dress", "hair", ra=(-60, -95), prop=("flag", "#F7F3EA", "#2F7A3F"), face=1)
      + person(900, 1800, 580, col, "coat", "kepi", la=(100, 90), ra=(60, 20), prop=("rifle", -70, True), face=-1))
b += f'<g filter="url(#roughrim)">{fg}</g>' + locomotive(300, 1300, 0.5, col, lamp="#FFE08A")
run([(page(b, light="#FFD9A0", rim_dx=7), "test/fig.png")])
