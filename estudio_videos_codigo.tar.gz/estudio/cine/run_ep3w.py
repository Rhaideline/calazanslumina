import json, subprocess, sys
from ep_build import plan, make_ass, make_audio, FPS
EP = "../roteiros/ep3"; meta, total = plan(EP); NF = int(total * FPS)
shake = {10: 3, 7: 2}; flash = {1: [1, .15], 13: [1, .2]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build.py", "chunk", "scenes_ep3", "layers_ep3", EP, str(a), str(b), f"ep3w_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
make_ass(meta, total, "MONTANHAS\\NDE CONCHAS", "HISTÓRIA DO BRASIL · EPISÓDIO 3", 2,
         {3: "CAPÍTULO 1 · OS SAMBAQUIS", 8: "CAPÍTULO 2 · OS CEMITÉRIOS", 12: "CAPÍTULO 3 · MARAJÓ", 17: "CAPÍTULO 4 · O LEGADO"},
         {6: "30 METROS", 8: "1.000 ANOS", 9: "~1.000", 13: "400 A 1400", 14: "10 METROS", 17: "1871"},
         "EPISÓDIO 4:\\N22 DE ABRIL\\NDE 1500", "ep3w.ass")
make_audio(meta, total, EP, "ep3w_mix.wav", booms=(2, 6, 7, 10, 13, 19), fire=(5, 10), drums_from=3, drum_boost=(4, 5, 6, 13, 14, 15, 19))
s_=open("ep3w.ass").read().replace("\\\\N","\\N"); open("ep3w.ass","w").write(s_)
for p in procs: p.wait()
open("ep3w_list.txt", "w").write("".join(f"file 'ep3w_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep3w_list.txt", "-c", "copy", "ep3w_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep3w_raw.mp4", "-i", "ep3w_mix.wav", "-vf", "ass=ep3w.ass,hqdn3d=1.5:1.5:4:4",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "6000k", "-maxrate", "9000k", "-bufsize", "12000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "../saida/wide/Ep3_16x9.mp4"], check=True)
print("done", total)
