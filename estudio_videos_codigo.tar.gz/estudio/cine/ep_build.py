import json, re, sys, subprocess, importlib, math, os
import numpy as np, soundfile as sf
FPS = 30

def plan(epdir, tail=1.5):
    meta = json.load(open(f"{epdir}/timing.json"))
    total = meta[-1]["start"] + meta[-1]["dur"] + tail; meta[-1]["dur"] += tail
    return meta, total

def render_chunk(mod, layers_dir, epdir, n0, n1, out, shake, flash):
    import cv2
    from cine import Scene, compose, post, Particles, OW, OH
    SC = importlib.import_module(mod).SC
    meta, total = plan(epdir); XF = 0.3; cache = {}
    def get(n):
        if n not in cache:
            for k in list(cache):
                if k < n - 1: del cache[k]
            cache[n] = (Scene(n, SC[n](), layers_dir), Particles(SC[n]().get("particles"), n))
        return cache[n]
    def ff(m, tl):
        sc, pr = get(m["i"]); u = min(1, max(0, (tl + XF) / (m["dur"] + XF)))
        sh = shake.get(m["i"], 0) * max(0, 1 - tl) if 0 <= tl < 1 else 0
        return compose(sc, u, tl, sh), pr
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OW}x{OH}", "-r", str(FPS), "-i", "-",
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    for n in range(n0, n1):
        t = n / FPS
        k = max(j for j, m in enumerate(meta) if m["start"] <= t + 1e-9); m = meta[k]; tl = t - m["start"]
        fr, pr = ff(m, tl)
        if k + 1 < len(meta):
            nx = meta[k + 1]; tn = nx["start"] - t
            if tn < XF:
                a = 1 - tn / XF; f2, _ = ff(nx, -tn); fr = fr * (1 - a) + f2 * a
        if m["i"] in flash and tl < 0.2:
            kind, amt = flash[m["i"]]; w = (1 - tl / 0.2) * amt
            fr = fr * (1 - w) + (np.array([1, 1, 1], np.float32) if kind else np.array([0.8, 0.12, 0.08], np.float32)) * w
        if t > total - 0.8: fr = fr * max(0, (total - t) / 0.8)
        if t < 0.4: fr = fr * (t / 0.4)
        enc.stdin.write(post(fr, t, pr, total).tobytes())
    enc.stdin.close(); enc.wait()

def ts(x): x = max(0, x); return f"{int(x//3600)}:{int(x%3600//60):02d}:{x%60:05.2f}"

def make_ass(meta, total, title, tag, title_scene, chap, big, endtxt, out):
    st = {m["i"]: m["start"] for m in meta}; ev = []
    for m in meta:
        words = m["text"].upper().split()
        wts = [len(re.sub(r"[^\wÀ-ú%]", "", w)) + 2 + (4 if re.search(r"[,.:?]$", w) else 0) for w in words]
        tot = sum(wts); t0 = m["start"] + 0.05; span = m["speech"] - 0.1; acc = 0; times = []
        for w in wts: times.append((t0 + span * acc / tot, t0 + span * (acc + w) / tot)); acc += w
        chunks = []; cur = []
        for idx, w in enumerate(words):
            cur.append(idx)
            if len(cur) == 3 or re.search(r"[,.:?]$", w) or idx == len(words) - 1: chunks.append(cur); cur = []
        for ch in chunks:
            for idx in ch:
                pop = r"{\fscx70\fscy70\t(0,90,\fscx100\fscy100)}" if idx == ch[0] else ""
                txt = pop + " ".join((r"{\c&H33C8F5&\t(0,70,\fscx112\fscy112)\t(70,140,\fscx106\fscy106)}" + words[j] + r"{\c&HFFFFFF&\fscx100\fscy100}") if j == idx else words[j] for j in ch)
                ev.append([times[idx][0], times[idx][1], txt])
    ev.sort(key=lambda e: e[0])
    for a, b in zip(ev, ev[1:]): a[1] = min(b[0], a[1] + 0.5)
    ev[-1][1] += 0.6
    Lx = [f"Dialogue: 3,{ts(st[title_scene]+0.05)},{ts(st[title_scene+1]+0.2)},Title,,0,0,0,,{{\\pos(540,560)\\fad(150,250)\\fscx60\\fscy60\\t(0,160,\\fscx100\\fscy100)}}{title}",
          f"Dialogue: 3,{ts(st[title_scene]+0.05)},{ts(st[title_scene+1]+0.2)},Tag,,0,0,0,,{{\\fad(150,250)}}{tag}"]
    for sc, name in chap.items():
        Lx.append(f"Dialogue: 3,{ts(st[sc]+0.1)},{ts(st[sc]+2.8)},Chap,,0,0,0,,{{\\fad(200,300)\\move(-200,70,40,70,0,250)}}{name}")
    for sc, txt in big.items():
        m = meta[sc - 1]; fs = "\\fs180" if len(txt) > 9 else ""
        Lx.append(f"Dialogue: 2,{ts(m['start']+0.3)},{ts(m['start']+m['dur']-0.1)},Big,,0,0,0,,{{\\pos(540,720){fs}\\fscx40\\fscy40\\t(0,180,\\fscx112\\fscy112)\\t(180,300,\\fscx100\\fscy100)\\fad(0,200)}}{txt}")
    Lx.append(f"Dialogue: 3,{ts(st[len(meta)]+0.4)},{ts(total)},Title,,0,0,0,,{{\\pos(540,560)\\fad(250,300)\\fs92}}{endtxt}")
    head = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Anton,108,&H00FFFFFF,&H00FFFFFF,&H00000000,&H90000000,0,0,0,0,100,100,1,0,1,7,3,5,60,60,0,1
Style: Title,Anton,128,&H00111111,&H00111111,&H0033C8F5,&H0033C8F5,0,0,0,0,100,100,0,0,3,18,0,5,40,40,0,1
Style: Tag,Montserrat,40,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,1,0,0,0,100,100,3,0,1,4,2,8,40,40,150,1
Style: Chap,Montserrat,42,&H00111111,&H00111111,&H00FFFFFF,&H00FFFFFF,1,0,0,0,100,100,2,0,3,12,0,7,40,40,0,1
Style: Big,Anton,230,&H0033C8F5,&H0033C8F5,&H00000000,&HA0000000,0,0,0,0,100,100,2,0,1,12,6,5,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    open(out, "w").write(head + "\n".join(Lx) + "\n" + "\n".join(f"Dialogue: 1,{ts(a)},{ts(b)},Cap,,0,0,0,,{{\\pos(540,1300)}}{x}" for a, b, x in ev) + "\n")

def make_audio(meta, total, epdir, out, booms=(), fire=(), drums_from=3, drum_boost=()):
    voice, sr = sf.read(f"{epdir}/narracao.wav"); N = int(total * sr); t = np.arange(N) / sr
    st = {m["i"]: m["start"] for m in meta}; nz = np.random.default_rng(1)
    def add(buf, i0, sig):
        if i0 < 0: sig = sig[-i0:]; i0 = 0
        e = min(N, i0 + len(sig)); buf[i0:e] += sig[:e - i0]
    pad = np.zeros(N)
    for f, a in ((65.41, .5), (98.0, .3), (130.81, .25), (155.56, .15), (196.0, .1)):
        for dd in (-0.3, 0.3): pad += a * np.sin(2 * np.pi * (f + dd) * t + dd)
    pad *= 0.6 + 0.4 * np.sin(2 * np.pi * 0.06 * t)
    def mem(f0, dec, L=0.35, nsz=0.15):
        tt = np.arange(int(L * sr)) / sr; e = np.exp(-tt * dec)
        return (np.sin(2 * np.pi * f0 * (1 + 0.5 * np.exp(-tt * 30)) * tt) + nsz * nz.standard_normal(len(tt)) * np.exp(-tt * 60)) * e
    LOW, MID, SH = mem(62, 8), mem(120, 12), mem(300, 40, 0.12, 2.5)
    drum = np.zeros(N); beat = 0.52
    pat = [(0, LOW, 1), (1, SH, .4), (1.5, MID, .6), (2, LOW, .8), (2.5, SH, .35), (3, MID, .5), (3.5, SH, .4)]
    bar = st.get(drums_from, 0)
    while bar < total:
        sc = max(m["i"] for m in meta if m["start"] <= bar)
        inten = 0.9 if sc in drum_boost else 0.45
        for off, s, a in pat:
            tt = bar + off * beat
            if tt < total: add(drum, int(tt * sr), s * a * inten)
        bar += 4 * beat
    fx = np.zeros(N)
    for m in meta[1:]:
        L = int(0.5 * sr); w = np.convolve(nz.standard_normal(L), np.ones(12) / 12, mode="same") * np.sin(np.pi * np.arange(L) / L) ** 2
        add(fx, int((m["start"] - 0.3) * sr), 0.3 * w)
    for sc in booms:
        tt = np.arange(int(2 * sr)) / sr
        add(fx, int(st[sc] * sr), 1.5 * np.sin(2 * np.pi * (60 * np.exp(-tt * 3) + 30) * tt) * np.exp(-tt * 2.4))
    for sc in fire:
        m = meta[sc - 1]; L = int(m["dur"] * sr); c = np.zeros(L)
        for k in range(int(m["dur"] * 25)):
            i0 = nz.integers(0, max(1, L - 800)); c[i0:i0 + 400] += nz.standard_normal(400) * np.exp(-np.arange(400) / 60) * nz.uniform(0.2, 1)
        add(fx, int(m["start"] * sr), 0.12 * c)
    def norm(x, g): return x / (np.abs(x).max() + 1e-9) * g
    music = norm(pad, .05) + norm(drum, .15) + norm(fx, .22)
    music *= np.minimum(1, t / 1.0) * np.minimum(1, (total - t) / 1.2)
    v = np.zeros(N); v[:len(voice)] = voice[:N]
    venv = np.convolve(np.abs(v), np.ones(int(0.2 * sr)) / int(0.2 * sr), mode="same")
    duck = 1 - 0.45 * np.clip(venv / (venv.max() * 0.3), 0, 1)
    sf.write(out, norm(v * 0.95 + music * duck, 0.95).astype(np.float32), sr)

if __name__ == "__main__" and sys.argv[1] == "chunk":
    _, _, mod, ld, ep, n0, n1, out, sh, fl = sys.argv
    render_chunk(mod, ld, ep, int(n0), int(n1), out, {int(k): v for k, v in json.loads(sh).items()}, {int(k): tuple(v) for k, v in json.loads(fl).items()})
