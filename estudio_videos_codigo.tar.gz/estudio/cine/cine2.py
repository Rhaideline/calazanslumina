import numpy as np, cv2, math
from cine import Scene as _Scene, compose as _compose, Particles, OW, OH, VIG, GRAIN, ease
from art import hx

def _blur_rgba(im, sigma):
    f = im.astype(np.float32) / 255; a = f[:, :, 3:4]
    pm = f[:, :, :3] * a
    k = int(sigma * 3) * 2 + 1
    pm = cv2.GaussianBlur(pm, (k, k), sigma); ab = cv2.GaussianBlur(a, (k, k), sigma)[..., None]
    rgb = np.where(ab > 1e-4, pm / np.maximum(ab, 1e-4), 0)
    return (np.dstack([rgb, ab]) * 255).clip(0, 255).astype(np.uint8)

class Scene(_Scene):
    def __init__(self, n, sc, outdir):
        super().__init__(n, sc, outdir)
        light = np.array(hx(sc.get("light", "#FFE0B0")), np.float32) / 255
        from_left = sc.get("rim_dx", 4) > 0
        new = []
        for ly, im in self.layers:
            d = ly["depth"]
            if ly.get("rough", True) and 0.4 <= d < 0.99 and ly["mode"] == "normal":
                f = im.astype(np.float32) / 255; H, W = f.shape[:2]
                ramp = np.linspace(1, 0, W, dtype=np.float32) if from_left else np.linspace(0, 1, W, dtype=np.float32)
                vert = np.linspace(0.6, 1.0, H, dtype=np.float32)[:, None]
                lum = f[:, :, :3].mean(axis=2)
                m = (f[:, :, 3] * (lum < 0.3)) * (ramp[None, :] ** 2) * vert * 0.28
                f[:, :, :3] = np.clip(f[:, :, :3] + light[None, None, :] * m[..., None], 0, 1)
                im = (f * 255).astype(np.uint8)
            if 0.12 < d <= 0.3 and ly["mode"] == "normal": im = _blur_rgba(im, 1.6)
            elif d >= 0.95 and ly["mode"] == "normal": im = _blur_rgba(im, 5.0)
            new.append((ly, im))
        self.layers = new

def compose(scene, u, tl, shake=0, cam=None):
    if cam is not None:
        old = scene.sc["cam"]; scene.sc["cam"] = cam
        out = _compose(scene, u, tl, shake); scene.sc["cam"] = old; return out
    return _compose(scene, u, tl, shake)

rng = np.random.default_rng(11)
_tex = cv2.resize(rng.normal(0, 1, (OH // 4, OW // 4)).astype(np.float32), (OW, OH), interpolation=cv2.INTER_CUBIC)
CANVAS = (1 + 0.018 * _tex)[..., None]
yy, xx = np.mgrid[0:OH, 0:OW].astype(np.float32)
def leak(t):
    cx = OW * (0.1 + 0.8 * (0.5 + 0.5 * math.sin(t * 0.21))); cy = OH * (0.15 + 0.2 * math.sin(t * 0.13))
    r = np.exp(-(((xx - cx) / 700) ** 2 + ((yy - cy) / 900) ** 2))
    return r[..., None] * np.array([1.0, 0.62, 0.32], np.float32) * (0.07 + 0.04 * math.sin(t * 0.7))

def post(fr, t, parts, total, bar=True):
    fr = parts.draw(fr, t) if parts else fr
    small = cv2.resize(fr, (OW // 4, OH // 4), interpolation=cv2.INTER_AREA)
    lum = small.mean(axis=2, keepdims=True)
    br = small * np.clip((lum - 0.8) / 0.2, 0, 1)
    br = cv2.GaussianBlur(br, (0, 0), 10)
    fr = fr + cv2.resize(br, (OW, OH), interpolation=cv2.INTER_LINEAR) * 0.3
    fr = 1 - (1 - fr) * (1 - leak(t))
    fr = fr * CANVAS * VIG + GRAIN[int(t * 12) % 6] * 0.8
    fr = np.clip(fr * 0.97 + 0.02, 0, 1)
    img = (fr * 255).astype(np.uint8)
    if bar:
        img[0:10, :] = (img[0:10, :] * 0.6).astype(np.uint8)
        img[0:10, :int(OW * t / total)] = (245, 200, 51)
    return img
