import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../roteiros/ep7"; OUT = "../saida/Historia_do_Brasil_Ep7.mp4"
meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {10: 5, 14: 5, 16: 3}; flash = {1: [0, .2], 10: [1, .3], 14: [0, .25], 16: [1, .12]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_ep7", "layers_ep7", EP, str(a), str(b), f"ep7_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
m = meta[16]
extra = [f"Dialogue: 2,{ts(m['start'] + m['speech'] * 0.62)},{ts(m['start'] + m['dur'] - 0.05)},Big,,0,0,0,,{{\\pos(540,1000)\\fs110\\fscx40\\fscy40\\t(0,160,\\fscx110\\fscy110)\\t(160,260,\\fscx100\\fscy100)}}VOCÊ SABIA?"]
m = meta[17]
extra.append(f"Dialogue: 3,{ts(m['start'])},{ts(total)},Chap,,0,0,0,,{{\\pos(40,150)\\fad(150,0)}}SIGA PARA O EPISÓDIO 8")
make_ass(meta, total, "O RIO DE JANEIRO\\NJÁ FOI FRANCÊS", "HISTÓRIA DO BRASIL · EPISÓDIO 7",
         {2: "CAPÍTULO 1 · OS FRANCESES", 7: "CAPÍTULO 2 · A BRIGA", 10: "CAPÍTULO 3 · A GUERRA"},
         {4: "ALIANÇA", 14: "2 ANOS", 16: "1 MÊS"},
         extra, "ep7.ass")
make_audio(meta, total, EP, "ep7_mix.wav", booms=(1, 10, 16), sea=(2, 3, 6, 10, 12), fire=(10, 14, 16), drum_boost=(1, 10, 14, 16))
for p in procs: p.wait()
open("ep7_list.txt", "w").write("".join(f"file 'ep7_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "ep7_list.txt", "-c", "copy", "ep7_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "ep7_raw.mp4", "-i", "ep7_mix.wav", "-vf", "ass=ep7.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1750k", "-maxrate", "2600k", "-bufsize", "4500k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", OUT], check=True)
print("done", total)
