from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep5 import parchment, stamp, label, RED, GOLD, INKB
from scenes_pol3 import calendar, chairs, urna, stf_building, congresso
import random, math

PAPER = "#F4F1EA"
def night(c0="#0A0A12", c1="#2A1E2A", c2="#4A2A20", gl="#C89A5A"):
    return sky([(0, c0), (0.6, c1), (1, c2)]) + glow(540, 900, 700, gl, .3)

def chip(x, y, txt, col, size=44, fg="#111"):
    w = len(txt) * size * 0.56 + 56
    return (f'<g transform="translate({x},{y})"><rect x="{-w/2:.0f}" y="{-size*0.8:.0f}" width="{w:.0f}" height="{size*1.5:.0f}" rx="14" fill="{col}"/>'
            f'<text x="0" y="{size*0.38:.0f}" font-family="Anton" font-size="{size}" text-anchor="middle" fill="{fg}">{txt}</text></g>')

def jet(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-300,0 Q-280,-40 -200,-44 L180,-44 Q300,-40 340,0 Q300,34 180,38 L-200,38 Q-280,34 -300,0 Z" fill="{col}"/>'
            f'<path d="M-300,-10 L-360,-130 L-300,-130 L-210,-30 Z" fill="{col}"/><path d="M-20,-30 L120,-170 L170,-170 L110,-30 Z" fill="{col}"/><path d="M-20,30 L120,150 L170,150 L110,30 Z" fill="{col}"/>'
            + "".join(f'<ellipse cx="{150-k*50}" cy="-10" rx="16" ry="12" fill="{mix(col,"#FFE8B0",.5)}"/>' for k in range(6)) + '</g>')

def clap(x, y, s):
    stripes = "".join(f'<path d="M{-200+k*100},-40 l50,-70 l50,0 l-50,70 Z" fill="#F4F1EA"/>' for k in range(4))
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-210" y="-30" width="420" height="260" rx="10" fill="#1A1A1E" stroke="#F4F1EA" stroke-width="6"/>'
            f'<g transform="rotate(-12 -210 -30)"><rect x="-210" y="-110" width="420" height="70" fill="#1A1A1E" stroke="#F4F1EA" stroke-width="6"/>{stripes}</g>'
            f'<text x="0" y="120" font-family="Anton" font-size="70" text-anchor="middle" fill="#F4F1EA">DARK HORSE</text></g>')

def bubble(x, y, w, h, txt, mine=True, size=46):
    c = "#DDF3C8" if mine else "#F4F1EA"
    return (f'<g transform="translate({x},{y})"><rect x="{-w/2:.0f}" y="{-h/2:.0f}" width="{w}" height="{h}" rx="30" fill="{c}"/>'
            f'<text x="0" y="{size*0.35:.0f}" font-family="Montserrat" font-weight="700" font-size="{size}" text-anchor="middle" fill="#1A1A1E">{txt}</text></g>')

def rig(x, y, s, col):
    g = f'<g transform="translate({x},{y}) scale({s})"><path d="M-70,0 L0,-520 L70,0 Z" fill="none" stroke="{col}" stroke-width="14"/>'
    g += "".join(f'<line x1="{-62+k*8}" y1="{-k*70}" x2="{62-k*8}" y2="{-k*70}" stroke="{col}" stroke-width="9"/>' for k in range(1, 7))
    g += f'<rect x="-6" y="-520" width="12" height="720" fill="{col}"/>'
    g += "".join(f'<path d="M{dx},220 q-14,50 0,70 q14,-20 0,-70" fill="#58B0E0"/>' for dx in (-60, 0, 60)) + '</g>'
    return g

def cross_med(x, y, s, col):
    return f'<g transform="translate({x},{y}) scale({s})"><rect x="-60" y="-190" width="120" height="380" rx="20" fill="{col}"/><rect x="-190" y="-60" width="380" height="120" rx="20" fill="{col}"/></g>'

def docfile(x, y, s, txt):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-150" y="-200" width="300" height="400" rx="16" fill="#F4F1EA"/>'
            + "".join(f'<rect x="-110" y="{-120+k*44}" width="{220-(k%3)*50}" height="16" fill="#9A9488"/>' for k in range(6))
            + f'<text x="0" y="-150" font-family="Montserrat" font-weight="900" font-size="34" text-anchor="middle" fill="{RED}">{txt}</text></g>')

import textwrap
def news(x, y, ang, headline, credit, size=56, wrap=22, w=820, paper="#E9E2CF", ink="#151210", note="título da matéria"):
    lines = textwrap.wrap(headline, wrap); h = 200 + len(lines) * (size + 14) + 70
    i = gid("nw")
    body = "".join(f'<text x="0" y="{-h/2+150+k*(size+14)}" font-family="Old Standard TT" font-weight="700" font-size="{size}" text-anchor="middle" fill="{ink}">{ln}</text>' for k, ln in enumerate(lines))
    rule = "".join(f'<rect x="{-w/2+50}" y="{h/2-90+k*26}" width="{w-100-(k%3)*70}" height="10" fill="#B8AE98"/>' for k in range(3))
    return (f'<g transform="translate({x},{y}) rotate({ang})"><defs><filter id="{i}"><feTurbulence type="fractalNoise" baseFrequency=".7" numOctaves="3" seed="4"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .18"/></feComponentTransfer><feComposite in2="SourceGraphic" operator="in"/></filter></defs>'
            f'<rect x="{-w/2+10}" y="{-h/2+14}" width="{w}" height="{h}" fill="#000" opacity=".35"/>'
            f'<path d="M{-w/2},{-h/2} L{w/2},{-h/2+6} L{w/2-4},{h/2} L{-w/2+6},{h/2-4} Z" fill="{paper}"/>'
            f'<path d="M{-w/2},{-h/2} L{w/2},{-h/2+6} L{w/2-4},{h/2} L{-w/2+6},{h/2-4} Z" fill="#000" filter="url(#{i})"/>'
            f'<text x="{-w/2+40}" y="{-h/2+56}" font-family="Montserrat" font-weight="800" font-size="26" letter-spacing="3" fill="#6A5E4A">{credit}</text>'
            f'<text x="{w/2-40}" y="{h/2-22}" font-family="Montserrat" font-weight="600" font-size="20" text-anchor="end" fill="#8A7E6A">{note}</text>'
            f'<line x1="{-w/2+40}" y1="{-h/2+76}" x2="{w/2-40}" y2="{-h/2+76}" stroke="{ink}" stroke-width="3"/>{body}{rule}</g>')

def desk():
    return sky([(0, "#2A1A10"), (1, "#120A06")]) + glow(540, 800, 900, "#FFC070", .35) + "".join(f'<rect x="{X0}" y="{y}" width="{BW}" height="6" fill="#3A2416" opacity=".5"/>' for y in range(Y0, Y1, 46))

def alt(tag, items, title):
    lay = [L(0.0, desk())]
    for k, (y, ang, hl, cr, kw) in enumerate(items):
        lay.append(L(0.2 + k * 0.1, news(540, y, ang, hl, cr, **kw), reveal=(0.3 + k * 1.3, 0.25, "center"), rough=False))
    lay.append(L(0.6, label(540, 250, title, 70, "#F4F1EA", "Anton"), rough=False))
    return lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, -20), (0, 30)), particles="dust", layers=lay)

def timeline(items, y=1000):
    g = f'<line x1="170" y1="{y}" x2="910" y2="{y}" stroke="#C8C0B0" stroke-width="8"/>'
    for k, (yr, txt, col) in enumerate(items):
        x = 290 + k * 250
        g += f'<circle cx="{x}" cy="{y}" r="24" fill="{col}"/><text x="{x}" y="{y-56}" font-family="Anton" font-size="68" text-anchor="middle" fill="#F4F1EA">{yr}</text><text x="{x}" y="{y+84}" font-family="Montserrat" font-weight="800" font-size="30" text-anchor="middle" fill="{col}">{txt}</text>'
    return g

S = {}
def s1():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, night()),
                L(0.2, timeline([("1979", "PERDÃO", GOLD), ("2025", "CONDENAÇÃO", RED), ("2026", "DE NOVO?", "#6AA8E0")], 1000), reveal=(0.3, 3.2, "ltr"), rough=False)])
S[1] = s1

def s2():
    return dict(light="#C8D0E0", rim_dx=4, cam=(1.0, 1.14, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#1A2238"), (0.55, "#5A5A78"), (1, "#C89A78")]) + sun(300, 1150, 70, halo_r=600, op=.5)),
                L(0.3, R(stf_building(540, 1500, 1.15, "#0A0C14")) + ground(1500, "#14161E", "#0A0C12", 4, 1)),
                L(0.7, label(540, 440, "SUPREMO · SET/2025", 62, PAPER, "Anton"), rough=False),
                L(0.72, stamp(540, 800, "27 ANOS", -6, 150), reveal=(1.8, 0.2, "center"), rough=False)])
S[2] = s2

def s3():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, docfile(540, 1100, 1.5, "8 DE JANEIRO"), rough=False),
                L(0.4, stamp(540, 1100, "INDULTO", -10, 130), reveal=(4.2, 0.2, "center"), rough=False),
                L(0.5, label(540, 460, "PROMESSA DE FLÁVIO", 66, PAPER, "Anton"), rough=False),
                L(0.51, label(540, 560, "ANISTIA NA TRANSIÇÃO", 52, GOLD, "Anton"), reveal=(1.8, 0.3, "center"), rough=False)])
S[3] = s3

def s4():
    return dict(light="#C8D0E8", rim_dx=4, cam=(1.0, 1.12, (-20, 10), (20, -20)), particles="ash",
        layers=[L(0.0, sky([(0, "#06080E"), (0.6, "#14182A"), (1, "#2A2A3A")]) + glow(300, 1500, 500, "#3A6AE0", .35) + glow(800, 1500, 500, "#E03A3A", .35)),
                L(0.3, f'<rect x="{X0}" y="1560" width="{BW}" height="600" fill="#0A0C12"/>' + R(jet(620, 1500, 1.0, "#0E1018"))),
                L(0.35, glow(260, 1560, 300, "#3A6AE0", .5) + glow(820, 1560, 300, "#E03A3A", .5), mode="screen", flicker=0.6),
                L(0.7, label(540, 440, "DANIEL VORCARO", 78, PAPER, "Anton"), rough=False),
                L(0.71, label(540, 540, "BANCO MASTER", 56, GOLD, "Anton"), rough=False),
                L(0.72, chip(540, 700, "PRESO PELA PF · NOV/2025", "#E8E4DC", 38), reveal=(2.4, 0.2, "center"), rough=False)])
S[4] = s4

def s5():
    return dict(light="#FFD090", rim_dx=4, cam=(1.0, 1.1, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, night("#0A0810", "#2A1A28", "#3A2018", "#E0A060")),
                L(0.4, R(clap(540, 980, 1.45)), rough=True),
                L(0.7, label(540, 470, "US$ 24 MILHÕES", 100, GOLD, "Anton"), reveal=(1.0, 0.3, "center"), rough=False),
                L(0.71, label(540, 570, "FILME SOBRE O PAI · INTERCEPT", 44, PAPER, "Anton"), reveal=(1.6, 0.3, "center"), rough=False)])
S[5] = s5

def s6():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, label(540, 560, "PF INVESTIGA", 80, PAPER, "Anton"), rough=False),
                L(0.35, label(540, 900, "R$ 61 MILHÕES", 130, GOLD, "Anton"), reveal=(1.0, 0.3, "center"), rough=False),
                L(0.36, label(540, 1010, "repasses atribuídos ao banqueiro", 46, PAPER, "Montserrat"), reveal=(2.2, 0.3, "center"), rough=False),
                L(0.37, label(540, 1080, "a pedido de Flávio, segundo a investigação", 40, "#E8E0D0", "Montserrat"), reveal=(3.0, 0.3, "center"), rough=False)])
S[6] = s6

def s7():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, stamp(540, 640, "NEGOU", -6, 150), reveal=(0.4, 0.2, "center"), rough=False),
                L(0.31, stamp(540, 1000, "ADMITIU", 5, 150, GOLD), reveal=(3.2, 0.2, "center"), rough=False),
                L(0.4, label(540, 1500, "43 DECLARAÇÕES ENGANOSAS", 56, PAPER, "Anton"), reveal=(5.6, 0.3, "center"), rough=False),
                L(0.41, label(540, 1570, "contagem do Aos Fatos (checagem)", 40, "#E8E0D0", "Montserrat"), reveal=(6.0, 0.3, "center"), rough=False)])
S[7] = s7

def s8():
    return dict(light="#C8D0E0", rim_dx=4, cam=(1.0, 1.14, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#1A2238"), (0.55, "#4A4A68"), (1, "#8A7A78")])),
                L(0.3, R(stf_building(540, 1500, 1.15, "#0A0C14")) + ground(1500, "#14161E", "#0A0C12", 4, 1)),
                L(0.7, stamp(540, 560, "INVESTIGADO", -5, 110), reveal=(0.6, 0.2, "center"), rough=False),
                L(0.71, label(540, 740, "lavagem · evasão de divisas · corrupção", 40, PAPER, "Montserrat"), reveal=(2.0, 0.3, "center"), rough=False),
                L(0.72, chip(540, 900, "ELE NEGA IRREGULARIDADES", "#E8E4DC", 36), reveal=(4.2, 0.2, "center"), rough=False),
                L(0.73, chip(540, 1020, "INVESTIGAÇÃO NÃO É CONDENAÇÃO", GOLD, 36), reveal=(6.0, 0.2, "center"), rough=False)])
S[8] = s8

def s9():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A3A58"), (0.6, "#C89A78"), (1, "#F0B070")]) + sun(800, 1150, 80, halo_r=700)),
                L(0.3, f'<rect x="{X0}" y="1500" width="{BW}" height="700" fill="#3A2A20"/>' + R(rig(420, 1520, 1.2, "#120C08"))),
                L(0.7, label(540, 440, "PLANO DE GOVERNO", 62, PAPER, "Anton"), rough=False),
                L(0.71, label(540, 560, "LIBERAR O FRACKING", 76, GOLD, "Anton"), reveal=(0.8, 0.3, "center"), rough=False),
                L(0.72, chip(540, 700, "PROIBIDO: FRANÇA · ALEMANHA · IRLANDA", "#E8E4DC", 30), reveal=(3.2, 0.2, "center"), rough=False)])
S[9] = s9

def s10():
    return dict(light="#C8E0E8", rim_dx=4, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#0A3A58"), (0.6, "#0A5A78"), (1, "#1A7A88")]) + glow(540, 900, 800, "#9AE0F0", .3)),
                L(0.3, cross_med(330, 1000, 0.85, "#F4F1EA"), rough=False),
                L(0.35, f'<path d="M500,1000 L680,1000" stroke="{GOLD}" stroke-width="16" stroke-dasharray="26 18"/><path d="M660,960 L710,1000 L660,1040" stroke="{GOLD}" stroke-width="16" fill="none"/>', reveal=(2.2, 0.4, "ltr"), rough=False),
                L(0.36, docfile(800, 1000, 0.7, "REDE PRIVADA"), reveal=(2.6, 0.2, "center"), rough=False),
                L(0.7, label(540, 440, "DADOS DO SUS", 90, PAPER, "Anton"), rough=False),
                L(0.71, label(540, 560, "prontuário ligado ao seu CPF", 46, "#E8F0F4", "Montserrat"), reveal=(1.0, 0.3, "center"), rough=False)])
S[10] = s10

def s11():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, chairs(3, 1000), rough=False),
                L(0.5, label(540, 560, "3 VAGAS NO SUPREMO", 96, PAPER, "Anton"), rough=False),
                L(0.51, label(540, 680, "ATÉ 2030 · QUASE 1/3 DA CORTE", 50, GOLD, "Anton"), reveal=(1.4, 0.3, "center"), rough=False)])
S[11] = s11

def s12():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.3, timeline([("STF", "decisão", GOLD), ("PF", "inquérito", RED), ("PLANO", "76 páginas", "#6AA8E0")], 1000), reveal=(0.3, 3.4, "ltr"), rough=False),
                L(0.5, label(540, 520, "NÃO É TORCIDA", 110, PAPER, "Anton"), rough=False),
                L(0.51, label(540, 640, "É O QUE ESTÁ ESCRITO", 56, GOLD, "Anton"), reveal=(1.0, 0.3, "center"), rough=False)])
S[12] = s12

def s13():
    return dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, night("#0A0A12", "#1A2238", "#2A2A3A", "#6AA8E0")),
                L(0.3, R(urna(540, 1000, 1.1))),
                L(0.6, label(540, 480, "LEIA OS 2 PLANOS", 90, PAPER, "Anton"), rough=False),
                L(0.61, label(540, 590, "site do TSE · compare", 52, GOLD, "Anton"), reveal=(1.2, 0.3, "center"), rough=False)])
S[13] = s13

def s14():
    return dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.0, (0, 30), (0, 30)), particles="dust",
        layers=[L(0.0, night()),
                L(0.2, label(540, 900, "1979", 330, GOLD, "Anton"), reveal=(1.2, 0.2, "center"), rough=False)])
S[14] = s14

S[103] = alt(3, [(560, -3, "Flávio diz que buscará anistia para Bolsonaro ainda durante governo de transição", "INFOMONEY", {"size": 44, "wrap": 28}),
                 (980, 2, "8/1: “sem anistia, darei indulto a todo mundo”, diz Flávio", "SBT NEWS", {"size": 46, "wrap": 27})], "O QUE ELE DISSE")
S[104] = alt(4, [(900, -2, "Banco Master: a reconstrução completa de como uma fraude capturou a República", "A PÚBLICA · 03/2026", {"size": 56, "wrap": 22})], "O CASO MASTER")
S[105] = alt(5, [(900, -3, "Mensagens apreendidas pela PF mostram cobrança de Flávio Bolsonaro e Neymar Pai sobre Vorcaro", "BRASIL DE FATO · 21/09/2026", {"size": 52, "wrap": 24})], "MENSAGENS DA PF")
S[106] = alt(6, [(560, -2, "PF investigará se projetos e emendas de Flávio Bolsonaro beneficiaram o Master", "CARTA CAPITAL", {"size": 44, "wrap": 28}),
                 (980, 3, "STF abre inquérito para investigar Flávio Bolsonaro por repasses ligados ao Banco Master", "PORTAL SALVADOR FM", {"size": 44, "wrap": 28})], "A INVESTIGAÇÃO")
S[107] = alt(7, [(900, -3, "Flávio mentiu ao menos 43 vezes sobre elo com Vorcaro", "AOS FATOS", {"size": 64, "wrap": 20, "note": "título da checagem"})], "A CHECAGEM")
S[108] = alt(8, [(900, 2, "Flávio é investigado no STF sobre Dark Horse e relação com Vorcaro", "CNN BRASIL", {"size": 58, "wrap": 22})], "O INQUÉRITO")
S[109] = alt(9, [(560, -3, "permitir a exploração de gás não convencional por fracking, com cumprimento das exigências ambientais", "PLANO DE GOVERNO DE FLÁVIO · 2026", {"size": 42, "wrap": 30, "note": "trecho citado"}),
                 (980, 2, "Flávio Bolsonaro propõe enxugar Estado e endurecer ações de segurança", "AGÊNCIA BRASIL · 09/2026", {"size": 44, "wrap": 28})], "NO PLANO")
S[110] = alt(10, [(900, -2, "Implantar o prontuário eletrônico único vinculado ao CPF, interoperável entre redes pública e privada.", "PLANO DE GOVERNO DE FLÁVIO · 2026", {"size": 50, "wrap": 25, "note": "trecho citado"})], "DADOS DO SUS")
S[111] = alt(11, [(900, 2, "STF terá três aposentadorias até 2030; presidente eleito poderá indicar quase um terço da Corte", "FOLHA DE PERNAMBUCO", {"size": 52, "wrap": 24})], "O SUPREMO")
S[113] = alt(13, [(900, -2, "Flávio Bolsonaro (PL) e Lula (PT) vão disputar o 2º turno para a Presidência da República", "TRIBUNAL SUPERIOR ELEITORAL · 10/2026", {"size": 52, "wrap": 24, "note": "notícia oficial"})], "DIA 25 DE OUTUBRO")

def _with(f, **kw):
    def g():
        d = f(); d.update(kw); return d
    return g
for n in (3, 4, 5, 6, 7, 8, 9, 10, 11, 13):
    S[n] = _with(S[n], alt=100 + n)
SC = S
