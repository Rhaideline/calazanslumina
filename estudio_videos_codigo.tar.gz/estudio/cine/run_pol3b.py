import json, subprocess, sys
from ep_build import plan, ts
from ep_build2 import make_ass, make_audio, FPS
EP = "../pol3"; meta, total = plan(EP, tail=0.2); NF = int(total * FPS)
shake = {2: 4}; flash = {2: [1, .15], 6: [1, .12], 8: [1, .2], 11: [0, .25]}
W = 2; step = NF // W + 1; procs = []
for k in range(W):
    a, b = k * step, min(NF, (k + 1) * step)
    procs.append(subprocess.Popen([sys.executable, "ep_build2.py", "chunk", "scenes_pol3", "layers_pol3", EP, str(a), str(b), f"pol3b_part{k}.mp4", json.dumps(shake), json.dumps(flash)]))
extra = [f"Dialogue: 1,{ts(0)},{ts(total)},Chap,,0,0,0,,{{\\an2\\pos(540,1760)\\fs26\\bord0\\shad0\\alpha&H40&}}Conteúdo produzido com auxílio de inteligência artificial · fontes na legenda"]
make_ass(meta, total, "O QUE 1964 TEM A VER\\NCOM O DIA 25?", "2º TURNO · 25 DE OUTUBRO",
         {2: "1964 · O GOLPE", 6: "1979 · O PERDÃO", 8: "2025 · A PRIMEIRA VEZ", 12: "OS PRÓXIMOS 4 ANOS"},
         {},
         extra, "pol3.ass")
make_audio(meta, total, EP, "pol3_mix.wav", booms=(2, 4, 8, 11), sea=(), fire=(), drum_boost=(2, 8, 9, 11, 15, 16))
for p in procs: p.wait()
open("pol3b_list.txt", "w").write("".join(f"file 'pol3b_part{k}.mp4'\n" for k in range(W)))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "pol3b_list.txt", "-c", "copy", "pol3b_raw.mp4"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "pol3b_raw.mp4", "-i", "pol3_mix.wav", "-vf", "ass=pol3.ass,hqdn3d=1.2:1.2:3:3",
                "-c:v", "libx264", "-preset", "medium", "-b:v", "1600k", "-maxrate", "2600k", "-bufsize", "4500k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", "-shortest", "/home/claude/Reel_1964_e_2026_v2.mp4"], check=True)
print("done", total)
