from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep1 import maloca
from scenes_ep2 import jtree, palm, jungle
from scenes_ep4 import nau, sea, cross_big
import random, math

RED = "#B0261A"; GOLD = "#F5C21B"; INKB = "#3A2214"

# ---------- Brazil map ----------
BR = [(-51.6, 4.3), (-50.0, 1.8), (-49.0, 0.2), (-48.5, -1.0), (-46.5, -1.0), (-44.3, -2.5), (-41.8, -2.9), (-38.5, -3.7), (-36.5, -5.0), (-35.2, -5.8),
      (-34.8, -7.1), (-34.9, -8.1), (-35.7, -9.7), (-37.0, -10.9), (-38.5, -13.0), (-39.0, -14.8), (-39.0, -16.4), (-39.2, -17.8), (-40.3, -20.3),
      (-41.0, -22.0), (-42.0, -22.9), (-43.2, -23.0), (-45.0, -23.6), (-46.3, -24.0), (-48.5, -25.5), (-48.6, -27.6), (-49.5, -29.0), (-51.2, -31.0), (-53.4, -33.7),
      (-53.6, -33.0), (-55.6, -30.9), (-57.6, -30.2), (-56.0, -28.0), (-54.6, -25.6), (-54.3, -24.0), (-55.5, -22.6), (-57.8, -22.1), (-58.2, -19.8), (-57.5, -18.0),
      (-58.4, -16.3), (-60.2, -15.1), (-60.0, -13.4), (-62.0, -12.6), (-64.4, -12.4), (-65.3, -11.0), (-66.6, -9.9), (-70.5, -11.0), (-72.5, -9.9), (-73.8, -7.3),
      (-72.9, -5.2), (-70.0, -4.2), (-69.5, -1.0), (-70.0, 0.6), (-67.0, 2.0), (-64.2, 4.0), (-62.8, 4.0), (-60.7, 5.2), (-59.6, 2.0), (-56.5, 1.9), (-54.0, 2.3), (-52.0, 2.2)]
MK = 40.0; MX0 = 30 - (-56 + 74) * 40.0; MY0 = 260
def pj(lon, lat): return (MX0 + (lon + 74) * MK, MY0 + (5.3 - lat) * MK)
def br_path(): return "M" + " L".join(f"{pj(*p)[0]:.0f},{pj(*p)[1]:.0f}" for p in BR) + " Z"
TORD = -48.4
STRIPES = [0.0, -2.6, -4.0, -5.4, -6.6, -7.6, -9.0, -11.0, -13.2, -14.8, -16.4, -18.4, -21.2, -23.0, -24.5, -28.4]
PAL = ["#E8B04A", "#C86A3A", "#7A9A50", "#D88A5A", "#5A8AA8", "#C8A050", "#9A5A7A", "#E0A060", "#6A9A80", "#B85A3A", "#D8C060", "#7A7AB0", "#C87A5A", "#8AAA60", "#D89A40"]

def map_base(fill="#E2CFA0", stroke="#5A3A26", sw=6):
    return f'<path d="{br_path()}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"/>'

def stripes_h(op=0.85, lines=True):
    i = gid("clip"); x0 = pj(TORD, 0)[0]
    g = [f'<defs><clipPath id="{i}"><path d="{br_path()}"/></clipPath></defs><g clip-path="url(#{i})">']
    for k in range(15):
        y0 = pj(0, STRIPES[k])[1]; y1 = pj(0, STRIPES[k + 1])[1]
        if k == 0: y0 = pj(0, 6)[1]
        g.append(f'<rect x="{x0:.0f}" y="{y0:.0f}" width="900" height="{y1-y0:.0f}" fill="{PAL[k]}" opacity="{op}"/>')
        if lines: g.append(f'<line x1="{x0:.0f}" y1="{y1:.0f}" x2="1200" y2="{y1:.0f}" stroke="{INKB}" stroke-width="4"/>')
    g.append(f'<line x1="{x0:.0f}" y1="0" x2="{x0:.0f}" y2="1500" stroke="{INKB}" stroke-width="5" stroke-dasharray="18 10"/></g>')
    return "".join(g)

def stripes_new(op=0.85):
    # simplified reconstruction: northern lots split by meridians, eastern by parallels, southern slanted NW
    i = gid("clip"); x0 = pj(TORD, 0)[0]; g = [f'<defs><clipPath id="{i}"><path d="{br_path()}"/></clipPath></defs><g clip-path="url(#{i})">']
    north = [TORD, -44.5, -41.5, -38.5, -35.8]
    ytop = pj(0, 6)[1]; ycut = pj(0, -6.6)[1]
    for k in range(4):
        a = pj(north[k], 0)[0]; b = pj(north[k + 1], 0)[0] if k < 3 else 1200
        g.append(f'<rect x="{a:.0f}" y="{ytop:.0f}" width="{b-a:.0f}" height="{ycut-ytop:.0f}" fill="{PAL[k]}" opacity="{op}"/><line x1="{a:.0f}" y1="{ytop:.0f}" x2="{a:.0f}" y2="{ycut:.0f}" stroke="{INKB}" stroke-width="4"/>')
    g.append(f'<line x1="{x0:.0f}" y1="{ycut:.0f}" x2="1200" y2="{ycut:.0f}" stroke="{INKB}" stroke-width="4"/>')
    for k in range(4, 12):
        y0 = pj(0, STRIPES[k + 1] if k > 4 else -6.6)[1]; y1 = pj(0, STRIPES[k + 2])[1]
        g.append(f'<rect x="{x0:.0f}" y="{y0:.0f}" width="900" height="{y1-y0:.0f}" fill="{PAL[k]}" opacity="{op}"/><line x1="{x0:.0f}" y1="{y1:.0f}" x2="1200" y2="{y1:.0f}" stroke="{INKB}" stroke-width="4"/>')
    ys = pj(0, STRIPES[13])[1]
    for k, (la, lb) in enumerate(((-21.2 + 0.0, -23.0), (-23.0, -24.5), (-24.5, -28.4))):
        ya, yb = pj(0, la)[1], pj(0, lb)[1]
        g.append(f'<path d="M1200,{ya:.0f} L{x0:.0f},{ya-120:.0f} L{x0:.0f},{yb-120:.0f} L1200,{yb:.0f} Z" fill="{PAL[12+k]}" opacity="{op}"/><line x1="1200" y1="{yb:.0f}" x2="{x0:.0f}" y2="{yb-120:.0f}" stroke="{INKB}" stroke-width="4"/>')
    g.append(f'<line x1="{x0:.0f}" y1="0" x2="{x0:.0f}" y2="1500" stroke="{INKB}" stroke-width="5" stroke-dasharray="18 10"/></g>')
    return "".join(g)

def parchment(dark=False):
    c = [(0, "#ECDDB6"), (1, "#D4BA86")] if not dark else [(0, "#5A3E26"), (1, "#3A2616")]
    return sky(c) + f'<rect x="{X0}" y="{Y0}" width="{BW}" height="{BH}" filter="url(#grainy)" fill="#000"/>' + glow(540, 900, 900, "#FFF4D8", .35 if not dark else .2)

def stamp(x, y, txt, ang=-12, size=110, col=RED):
    w = len(txt) * size * 0.52 + 60
    return (f'<g transform="translate({x},{y}) rotate({ang})"><rect x="{-w/2}" y="{-size*0.75}" width="{w}" height="{size*1.35}" rx="14" fill="none" stroke="{col}" stroke-width="12"/>'
            f'<text x="0" y="{size*0.38}" font-family="Anton" font-size="{size}" text-anchor="middle" fill="{col}">{txt}</text></g>')

def label(x, y, txt, size=48, col=INKB, font="Old Standard TT", anchor="middle", weight=700):
    return f'<text x="{x}" y="{y}" font-family="{font}" font-weight="{weight}" font-size="{size}" text-anchor="{anchor}" fill="{col}">{txt}</text>'

def pizza_cutter(x, y, s, ang):
    return (f'<g transform="translate({x},{y}) rotate({ang}) scale({s})"><circle r="120" fill="#C8CED6" stroke="#4A4E54" stroke-width="10"/><circle r="100" fill="none" stroke="#F4F8FF" stroke-width="6" opacity=".7"/>'
            f'<circle r="26" fill="#4A4E54"/><path d="M-20,-10 L-60,-260 L-10,-270 L20,-10 Z" fill="#6A6E74"/><rect x="-62" y="-560" width="64" height="320" rx="30" fill="{RED}" transform="rotate(-6)"/></g>')

def crown(x, y, s, col=GOLD):
    return f'<g transform="translate({x},{y}) scale({s})"><path d="M-100,40 L-110,-60 L-55,-10 L0,-90 L55,-10 L110,-60 L100,40 Z" fill="{col}" stroke="#6A4A08" stroke-width="6"/>' + "".join(f'<circle cx="{cx}" cy="{cy}" r="12" fill="{RED}"/>' for cx, cy in ((-110, -66), (0, -96), (110, -66))) + '</g>'

def throne_room(glowc="#FFC070"):
    arches = "".join(f'<path d="M{x},1500 L{x},700 Q{x+110},560 {x+220},700 L{x+220},1500 Z" fill="#F4D8A0" opacity=".45"/>' for x in (-60, 430, 920))
    return sky([(0, "#2A140C"), (1, "#4A2414")]) + glow(540, 900, 900, glowc, .5) + arches + ground(1500, "#5A3A24", "#2A1A10", 4, 1)

def drapes():
    d = "".join(f'<path d="M{x},{Y0} C{x+40},500 {x-30},900 {x+20},1400 L{x+170},1400 C{x+140},900 {x+200},500 {x+160},{Y0} Z" fill="#7A140C"/>' for x in (-130, 990))
    return d + "".join(f'<path d="M{x},{Y0} C{x+20},600 {x-10},1000 {x+10},1400" stroke="#4A0806" stroke-width="10" fill="none"/>' for x in (-70, -30, 1040, 1080))

def chest(x, y, s, empty=True):
    g = (f'<g transform="translate({x},{y}) scale({s})"><path d="M-200,-120 Q0,-260 200,-120 L200,-110 L-200,-110 Z" fill="#5A3418" transform="rotate(-28 -200 -115)"/>'
         f'<rect x="-200" y="-120" width="400" height="220" rx="10" fill="#6A3E1C" stroke="#2A1A0C" stroke-width="8"/><rect x="-200" y="-60" width="400" height="20" fill="#C8A040"/><rect x="-20" y="-80" width="40" height="60" fill="#C8A040"/>'
         f'<rect x="-180" y="-118" width="360" height="30" fill="#1A0E06"/>')
    if empty:
        g += f'<path d="M-180,-120 L-120,-200 M-150,-118 L-120,-200 L-60,-118 M-120,-200 L-100,-118" stroke="#F4ECDC" stroke-width="2" fill="none" opacity=".8"/>'
    return g + '</g>'

def moth(x, y, s):
    return f'<g transform="translate({x},{y}) scale({s})"><ellipse cx="-22" cy="0" rx="26" ry="16" fill="#D8C8A8" transform="rotate(-20 -22 0)"/><ellipse cx="22" cy="0" rx="26" ry="16" fill="#D8C8A8" transform="rotate(20 22 0)"/><ellipse rx="6" ry="18" fill="#6A5A48"/></g>'

def fleur_nau(x, y, s):
    fl = "".join(f'<g transform="translate({x+dx*s},{y+dy*s}) scale({s*1.6})"><path d="M0,-30 C14,-14 14,8 0,26 C-14,8 -14,-14 0,-30 Z M-26,-6 C-10,-10 -4,10 -6,26 C-20,20 -30,8 -26,-6 Z M26,-6 C10,-10 4,10 6,26 C20,20 30,8 26,-6 Z" fill="#2A4AA8"/></g>' for dx, dy in ((-80, -330), (120, -360)))
    return R(nau(x, y, s, "#141020", sails="#ECEAF2", cross=False)) + fl

def engenho(x, y, s, col):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-260" y="-200" width="380" height="200" fill="{col}"/><path d="M-290,-200 L-70,-330 L150,-200 Z" fill="{col}"/>'
            f'<rect x="160" y="-420" width="60" height="420" fill="{col}"/><circle cx="-340" cy="-150" r="150" fill="none" stroke="{col}" stroke-width="22"/>'
            + "".join(f'<line x1="-340" y1="-150" x2="{-340+150*math.cos(a):.0f}" y2="{-150+150*math.sin(a):.0f}" stroke="{col}" stroke-width="14"/>' for a in [j * 0.785 for j in range(8)])
            + '</g>')

def cane(y, col, n=60, seed=1, h=160):
    r = random.Random(seed)
    return "".join(f'<path d="M{xx:.0f},{y} q{r.uniform(-10,10):.0f},-{h*0.5:.0f} {r.uniform(-30,30):.0f},-{h*r.uniform(0.8,1.2):.0f}" stroke="{col}" stroke-width="6" fill="none"/>' + f'<path d="M{xx:.0f},{y-h*0.7:.0f} q30,-10 60,10 M{xx:.0f},{y-h*0.6:.0f} q-30,-10 -60,10" stroke="{col}" stroke-width="4" fill="none"/>' for xx in [X0 + r.uniform(0, BW) for _ in range(n)])

def lightning(x, y):
    return f'<path d="M{x},{y} L{x-60},{y+260} L{x+10},{y+260} L{x-80},{y+560} L{x+90},{y+200} L{x+10},{y+200} L{x+70},{y} Z" fill="#F4F8FF"/>'

def waves(y, col, amp=60, seed=1, n=9):
    r = random.Random(seed); d = f"M{X0},{y}"
    for k in range(n):
        w = BW / n; d += f" q{w*0.25:.0f},-{amp*r.uniform(0.7,1.3):.0f} {w*0.5:.0f},0 q{w*0.25:.0f},{amp*0.5:.0f} {w*0.5:.0f},0"
    return f'<path d="{d} L{X1},{Y1} L{X0},{Y1} Z" fill="{col}"/>'

def sign_post(x, y, txt, ang, col="#C8A070", flip=1):
    w = len(txt) * 38 + 80
    return (f'<g transform="translate({x},{y}) rotate({ang})"><path d="M0,0 L{flip*w},0 L{flip*(w+50)},50 L{flip*w},100 L0,100 Z" fill="{col}" stroke="#2A1A10" stroke-width="6"/>'
            f'<text x="{flip*(w/2+10)}" y="70" font-family="Anton" font-size="66" text-anchor="middle" fill="#2A1A10">{txt}</text></g>')

# ---------- scenes ----------
S = {}
def hook(cam):
    base = parchment() + map_base()
    return dict(light="#FFE6C0", rim_dx=4, cam=cam, particles="dust",
        layers=[L(0.0, base, rough=False),
                L(0.05, stripes_h(.8), rough=False),
                L(0.1, crown(540, 150, 0.9), rough=False),
                L(0.4, R(pizza_cutter(780, 1150, 1.05, 35))),
                L(0.42, label(250, 1000, "1534", 150, RED, "Anton"), rough=False)])
S[1] = lambda: hook((1.0, 1.12, (0, 0), (0, -30)))

def s2():
    return dict(light="#FFD8A0", rim_dx=5, cam=(1.0, 1.12, (20, 20), (-20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A4A70"), (0.5, "#E8A070"), (1, "#F8C890")]) + sun(300, 1150, 90, halo_r=800)),
                L(0.05, godrays(300, 1150, "#FFEFC8", n=14, spread=180, a0=-90, op=.24, seed=52), mode="screen"),
                L(0.15, sea(1200, "#C88068", "#3A2A40", "#FFE0B8") + R(jungle(1210, "#4A3A40", 12, 200, 320, 52, 5))),
                L(0.4, fleur_nau(760, 1400, 0.55), drift=(-60, 0)),
                L(0.85, R(palm(1120, 2050, 1150, "#0A0606", 53) + person(170, 1960, 640, "#0A0606", "shirt", "cocar", la=(100, 90), ra=(-30, -40), face=1))
                        + waves(1800, "#1A1018", 30, 2))])
S[2] = s2

def s3():
    king = person(540, 1720, 820, "#A8180E", "robe", None, la=(70, 120), ra=(110, 60), face=1, beard=True)
    return dict(light="#FFC070", rim_dx=5, cam=(1.0, 1.12, (0, 10), (0, -30)), particles="dust",
        layers=[L(0.0, throne_room()),
                L(0.4, R(f'<rect x="380" y="1100" width="320" height="520" rx="20" fill="#3A1A10"/><rect x="360" y="1060" width="360" height="60" fill="{GOLD}" opacity=".8"/>' + king + crown(540, 900, 0.42))),
                L(0.6, R(chest(780, 1840, 0.9))),
                L(0.62, moth(790, 1560, 1.2), drift=(-40, -120)),
                L(0.9, drapes())])
S[3] = s3

def s4():
    base = parchment() + map_base()
    nums = "".join(label(1000, (pj(0, STRIPES[k])[1] + pj(0, STRIPES[k + 1])[1]) / 2 + 14, str(k + 1), 34, INKB, "Montserrat", "start", 800) for k in range(1, 15))
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, base, rough=False), L(0.05, stripes_h(.85), reveal=(0.4, 2.6, "ltr"), rough=False),
                L(0.1, label(540, 170, "15 FAIXAS · 12 DONATÁRIOS", 62, RED, "Anton"), rough=False)])
S[4] = s4

def s5():
    vila = "".join(f'<g transform="translate({x},{y}) scale({s})"><rect x="-60" y="-80" width="120" height="80" fill="#3A2418"/><path d="M-75,-80 L0,-140 L75,-80 Z" fill="#5A2A18"/></g>' for x, y, s in ((640, 1440, 0.8), (780, 1430, 0.7), (900, 1450, 0.9), (560, 1460, 0.6)))
    church = f'<g transform="translate(720,1440)"><rect x="-50" y="-180" width="100" height="180" fill="#3A2418"/><path d="M-60,-180 L0,-260 L60,-180 Z" fill="#5A2A18"/><rect x="-6" y="-320" width="12" height="70" fill="#3A2418"/><rect x="-26" y="-300" width="52" height="10" fill="#3A2418"/></g>'
    don = person(300, 1950, 900, "#120A06", "coat", "brim", la=(100, 90), ra=(-40, -70), face=1, beard=True, prop=("staff",))
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.12, (-20, 20), (20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#7AA0C8"), (0.6, "#F0D8A8"), (1, "#F4C080")]) + sun(820, 1000, 80, halo_r=700)),
                L(0.05, godrays(820, 1000, "#FFF4D0", n=12, spread=160, a0=-100, op=.22, seed=55), mode="screen"),
                L(0.2, R(jungle(1380, "#5A6A50", 12, 200, 320, 55, 4)) + f'<rect x="{X0}" y="1370" width="{BW}" height="800" fill="#B89A68"/>'),
                L(0.4, R(vila + church)),
                L(0.8, R(don) + ground(1930, "#3A2818", "#1E140C", 6, 1)),
                L(0.82, crown(318, 1060, 0.38), reveal=(0.4, 0.25, "center"), rough=False)])
S[5] = s5

def s6():
    dad = person(330, 1900, 760, "#140A06", "coat", "brim", la=(100, 92), ra=(-10, -20), face=1, beard=True, lean=-10)
    son = person(760, 1900, 700, "#140A06", "coat", None, la=(170, 190), ra=(100, 95), face=-1)
    scroll = f'<g transform="translate(545,1290) rotate(-8)"><rect x="-90" y="-26" width="180" height="52" fill="#EFE0BC" stroke="#3A2214" stroke-width="4"/><circle cx="0" cy="0" r="16" fill="{RED}"/></g>'
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.12, (0, 10), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#3A2A48"), (0.5, "#D8805A"), (1, "#F0A860")]) + sun(540, 1250, 110, halo_r=900)),
                L(0.05, godrays(540, 1250, "#FFEFC8", n=16, spread=190, a0=-90, op=.28, seed=56), mode="screen"),
                L(0.2, R(jungle(1420, "#5A3A40", 12, 200, 300, 56, 4)) + f'<rect x="{X0}" y="1410" width="{BW}" height="800" fill="#4A2A28"/>'),
                L(0.7, R(dad + son + scroll) + ground(1880, "#2A1814", "#140A08", 6, 1)),
                L(0.72, label(540, 600, "DE PAI PARA FILHO", 80, "#FFF4E0", "Anton"), reveal=(0.3, 0.4, "center"), rough=False)])
S[6] = s6

def s7():
    don = person(540, 1900, 820, "#140A06", "coat", "brim", la=(40, 10), ra=(140, 170), face=1)
    pockets = f'<path d="M420,1520 l-40,70 l60,10 Z M660,1520 l40,70 l-60,10 Z" fill="#EFE0BC"/>'
    lst = (f'<g transform="translate(540,620) rotate(-3)"><rect x="-380" y="-240" width="760" height="500" fill="#EFE0BC" stroke="#3A2214" stroke-width="6"/>'
           + "".join(f'<text x="-320" y="{-140+k*95}" font-family="Caveat" font-weight="700" font-size="74" fill="#2A1B12">☐ {t}</text>' for k, t in enumerate(["navio", "gente", "armas", "comida"]))
           + '</g>')
    return dict(light="#FFE0A8", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, parchment(dark=True)),
                L(0.2, lst, rough=False),
                L(0.25, stamp(560, 1000, "POR SUA CONTA", -10, 104), reveal=(0.55, 0.15, "center"), rough=False),
                L(0.6, R(don)),
                L(0.62, moth(700, 1300, 0.9), drift=(60, -200))])
S[7] = s7

def s8():
    return dict(light="#B8C8E0", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -20)), particles="ash",
        layers=[L(0.0, sky([(0, "#06080E"), (0.6, "#1E2838"), (1, "#3A4658")]) + glow(700, 500, 600, "#8AA0C8", .3)),
                L(0.05, lightning(760, 120), flicker=0.9, rough=False),
                L(0.2, waves(1250, "#2A3448", 90, 8)),
                L(0.45, f'<g transform="rotate(-22 540 1300)">' + R(nau(540, 1300, 0.85, "#05060A", sails="#8A90A0")) + '</g>', drift=(0, 30)),
                L(0.7, waves(1500, "#141A28", 140, 9), drift=(-60, 0)),
                L(0.95, waves(1800, "#0A0E16", 120, 10))])
S[8] = s8

def s9():
    window = (f'<rect x="560" y="420" width="440" height="620" fill="#9AC0D8"/><rect x="560" y="880" width="440" height="160" fill="#4A7A98"/>'
              + nau(800, 940, 0.2, "#1E1A1E", sails="#E8DCC8") + f'<rect x="560" y="420" width="440" height="620" fill="none" stroke="#2A1A10" stroke-width="22"/><line x1="780" y1="420" x2="780" y2="1040" stroke="#2A1A10" stroke-width="14"/>')
    desk = f'<rect x="{X0}" y="1420" width="{BW}" height="800" fill="#4A2A18"/><g transform="translate(330,1450) rotate(-4)"><rect x="-210" y="-50" width="420" height="120" fill="#EFE0BC"/></g>'
    quill = f'<g transform="translate(560,1450) rotate(35)"><path d="M0,0 C20,-160 60,-300 40,-520 C20,-380 -10,-200 0,0 Z" fill="#E9DDC4"/></g>'
    candle = f'<rect x="120" y="1220" width="60" height="200" rx="8" fill="#F1E4C3"/><path d="M150,1160 q22,34 0,62 q-22,-28 0,-62" fill="#FFB347"/>'
    return dict(light="#FFC878", rim_dx=-5, cam=(1.0, 1.12, (20, 20), (-20, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#2A1A10"), (1, "#3E2616")]) + "".join(f'<rect x="{X0}" y="{y}" width="{BW}" height="22" fill="#4A3020" opacity=".6"/>' for y in range(Y0, Y1, 70)) + window),
                L(0.05, glow(780, 700, 600, "#FFE8B0", .4), mode="screen"),
                L(0.4, R(desk + quill) + candle, flicker=0.05),
                L(0.42, glow(150, 1180, 260, "#FFB060", .5), mode="screen", flicker=0.2),
                L(0.75, R(person(300, 1950, 900, "#0E0806", "robe", None, la=(70, 40), ra=(40, 10), face=1, beard=True))),
                L(0.76, label(780, 360, "LISBOA", 64, "#F4E2B8", "Anton"), rough=False)])
S[9] = s9

def s10():
    sign = sign_post(120, 1260, "ÍNDIA", -4)
    return dict(light="#FFD090", rim_dx=5, cam=(1.0, 1.12, (-30, 20), (30, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.5, "#F0A878"), (1, "#F8C088")]) + sun(900, 1150, 90, halo_r=800)),
                L(0.05, godrays(900, 1150, "#FFEFC8", n=13, spread=170, a0=-90, op=.24, seed=510), mode="screen"),
                L(0.2, sea(1220, "#C88068", "#4A3048", "#FFE0B8")),
                L(0.35, R(nau(880, 1260, 0.3, "#1A1014", sails="#E8D2B8")), drift=(120, 0)),
                L(0.6, R(f'<path d="M{X0},1500 C200,1460 400,1480 600,1520 L600,{Y1} L{X0},{Y1} Z" fill="#2A1A14"/>' + maloca(80, 1500, 0.5, "#2A1A14") + f'<rect x="100" y="1260" width="14" height="260" fill="#2A1A10"/>' + sign)),
                L(0.85, R(person(300, 1960, 640, "#0A0606", "shirt", "brim", la=(100, 90), ra=(-20, -10), face=1) + palm(-80, 2100, 1100, "#0A0606", 511)) + ground(1940, "#140A0A", "#0A0606", 6, 1)),
                L(0.86, label(700, 600, "NUNCA MAIS VOLTOU", 76, "#FFF4E0", "Anton"), reveal=(0.4, 0.3, "center"), rough=False)])
S[10] = s10

def s11():
    r = random.Random(11); ppl = "".join(person(r.uniform(60, 1020), 1580 + r.uniform(0, 80), r.uniform(220, 300), "#0A0406", "shirt", r.choice(["cocar", "hair"]), la=(r.uniform(-140, 100), -100), ra=(r.uniform(-140, 100), -90), face=r.choice([1, -1])) for _ in range(12))
    return dict(light="#FF9A50", rim_dx=4, cam=(1.0, 1.12, (0, 0), (0, -30)), particles="embers",
        layers=[L(0.0, sky([(0, "#0A0408"), (0.6, "#2A0E10"), (1, "#5A1A10")]) + glow(540, 1500, 800, "#FF6A20", .4)),
                L(0.2, R(jungle(1400, "#140608", 12, 300, 500, 511, 4)) + f'<rect x="{X0}" y="1390" width="{BW}" height="800" fill="#140608"/>'),
                L(0.35, R(maloca(200, 1560, 0.9, "#1A0A08") + maloca(880, 1550, 1.0, "#1A0A08"))),
                L(0.45, fire(490, 1700, 140, 220, 11), flicker=0.25, rough=False),
                L(0.46, glow(540, 1650, 420, "#FFA050", .5), mode="screen", flicker=0.2),
                L(0.6, R(ppl)),
                L(0.9, R(person(980, 2000, 900, "#030102", "shirt", "cocar", la=(100, 90), ra=(80, 85), face=-1, prop=("staff",))) + ground(1980, "#0A0404", "#030102", 6, 2))])
S[11] = s11

def s12():
    return dict(light="#FFE0A0", rim_dx=5, cam=(1.0, 1.12, (0, 30), (0, -30)), particles="dust",
        layers=[L(0.0, sky([(0, "#6A90C0"), (0.6, "#F0D0A0"), (1, "#F8B878")]) + sun(820, 1000, 90, halo_r=800)),
                L(0.05, godrays(820, 1000, "#FFF4D0", n=14, spread=170, a0=-100, op=.24, seed=512), mode="screen"),
                L(0.2, R(jungle(1300, "#6A7A50", 12, 200, 300, 512, 3)) + f'<rect x="{X0}" y="1290" width="{BW}" height="800" fill="#8AA050"/>'),
                L(0.4, R(engenho(640, 1460, 0.9, "#2A1A12")), rough=True),
                L(0.42, smoke_puffs(800, 1020, "#EDE4D8", n=7, s=0.8, seed=12, drift=1), drift=(40, -80)),
                L(0.7, Rr(cane(1700, "#4A6A2A", 70, 12, 260)) + f'<rect x="{X0}" y="1690" width="{BW}" height="500" fill="#4A6A2A"/>'),
                L(0.72, label(540, 560, "SÓ 2 DERAM CERTO", 92, "#1A0E08", "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
                L(0.95, Rr(cane(2100, "#1E3010", 40, 13, 520)))])
S[12] = s12

def s13():
    base = parchment() + map_base()
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
        layers=[L(0.0, base + stripes_h(.85), rough=False),
                L(0.1, label(540, 170, "O MAPA DA ESCOLA", 70, INKB, "Anton"), rough=False),
                L(0.12, stamp(560, 820, "ERRADO", -14, 170), reveal=(0.5 * 5.9, 0.12, "center"), rough=False)])
S[13] = s13

def s14():
    base = parchment() + map_base()
    return dict(light="#FFE6C0", rim_dx=4, cam=(1.0, 1.1, (0, 40), (0, -60)), particles="dust",
        layers=[L(0.0, base, rough=False),
                L(0.05, stripes_new(.85), reveal=(0.3, 2.4, "ltr"), rough=False),
                L(0.1, label(540, 170, "RECONSTITUIÇÃO · USP 2013", 58, RED, "Anton"), rough=False),
                L(0.11, label(300, 560, "norte: divisas verticais", 56, RED, "Caveat") , rough=False)])
S[14] = s14

def s15():
    names = [("MARANHÃO", -45.0, -4.5), ("PERNAMBUCO", -37.5, -8.4), ("BAHIA", -41.5, -12.5), ("ESPÍRITO SANTO", -40.9, -19.6)]
    base = parchment(dark=True) + map_base("#5A4A36", "#C8A870", 5)
    lbls = "".join(f'<circle cx="{pj(lo,la)[0]:.0f}" cy="{pj(lo,la)[1]:.0f}" r="16" fill="{GOLD}"/>' + label(pj(lo, la)[0] - 30, pj(lo, la)[1] + 12, n, 46, GOLD, "Anton", "end") for n, lo, la in names)
    return dict(light="#FFD890", rim_dx=4, cam=(1.0, 1.1, (0, 0), (0, -30)), particles="dust",
        layers=[L(0.0, base, rough=False),
                L(0.05, lbls, reveal=(0.8, 3.0, "ltr"), rough=False),
                L(0.06, glow(800, 800, 500, "#FFD070", .25), mode="screen", flicker=0.05)])
S[15] = s15

def s16():
    pombal = person(380, 1950, 980, "#120A08", "coat", "hair", la=(100, 90), ra=(-10, -40), face=1)
    hx_, hy_, hr_ = 388, 1062, 61
    wig = (f'<path d="M{hx_-hr_*1.1},{hy_+hr_*0.2} C{hx_-hr_*1.3},{hy_-hr_*1.6} {hx_+hr_*1.2},{hy_-hr_*1.6} {hx_+hr_*0.9},{hy_-hr_*0.4} L{hx_+hr_*0.6},{hy_-hr_*0.3} C{hx_},{hy_-hr_*0.9} {hx_-hr_*0.6},{hy_-hr_*0.6} {hx_-hr_*0.7},{hy_+hr_*0.2} Z" fill="#E8E2D8"/>'
           + "".join(f'<circle cx="{hx_-hr_*0.95}" cy="{hy_+hr_*k*0.5}" r="{hr_*0.3}" fill="#E8E2D8"/>' for k in range(0, 3)))
    doc = (f'<g transform="translate(760,1180) rotate(6)"><rect x="-230" y="-300" width="460" height="600" fill="#EFE0BC" stroke="#3A2214" stroke-width="6"/>'
           f'<text x="0" y="-200" font-family="Old Standard TT" font-weight="700" font-size="44" text-anchor="middle" fill="#3A2214">CAPITANIAS</text>'
           + "".join(f'<line x1="-180" y1="{-130+k*50}" x2="180" y2="{-130+k*50}" stroke="#8A6A48" stroke-width="5"/>' for k in range(7)) + '</g>')
    return dict(light="#FFC878", rim_dx=5, cam=(1.0, 1.12, (0, 10), (0, -30)), particles="dust",
        layers=[L(0.0, throne_room("#FFD090")),
                L(0.4, R(doc)),
                L(0.42, stamp(760, 1240, "EXTINTO", 4, 120), reveal=(0.45, 0.12, "center"), rough=False),
                L(0.8, R(pombal) + wig),
                L(0.82, label(560, 520, "1759", 150, GOLD, "Anton"), rough=False)])
S[16] = s16

def s17():
    don = person(540, 1960, 820, "#0A0606", "coat", "brim", la=(100, 92), ra=(80, 88), face=1)
    return dict(light="#FFD890", rim_dx=5, cam=(1.0, 1.1, (0, 20), (0, -20)), particles="dust",
        layers=[L(0.0, sky([(0, "#4A5A88"), (0.55, "#F0B080"), (1, "#F8C890")]) + sun(540, 1100, 100, halo_r=900)),
                L(0.05, godrays(540, 1100, "#FFF0C8", n=16, spread=190, a0=-90, op=.26, seed=517), mode="screen"),
                L(0.2, R(jungle(1350, "#6A4A48", 12, 220, 340, 517, 4)) + f'<rect x="{X0}" y="1340" width="{BW}" height="800" fill="#B88A60"/>'),
                L(0.5, R(f'<rect x="530" y="1000" width="20" height="560" fill="#2A1A10"/>' + sign_post(550, 1020, "ACEITO", -6, "#7ABA60") + sign_post(530, 1160, "RECUSO", 6, "#E06A50", -1))),
                L(0.8, R(don) + ground(1940, "#2A1814", "#140A08", 6, 1))])
S[17] = s17

S[18] = lambda: hook((1.0, 1.0, (0, 0), (0, 0)))
SC = S
