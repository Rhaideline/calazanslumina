"""Gera run_epNw.py (16:9) a partir de run_epN.py: nomes intermediários próprios, saída em saida/wide e bitrate de vídeo longo."""
import re, sys
for n in sys.argv[1:]:
    s = open(f"run_ep{n}.py").read()
    for a in ("_part", "_list.txt", "_raw.mp4", "_mix.wav"):
        s = s.replace(f"ep{n}{a}", f"ep{n}w{a}")
    s = s.replace(f'"ep{n}.ass"', f'"ep{n}w.ass"').replace(f"'ep{n}.ass'", f"'ep{n}w.ass'").replace(f"ass=ep{n}.ass", f"ass=ep{n}w.ass").replace(f'open("ep{n}.ass")', f'open("ep{n}w.ass")').replace(f'open("ep{n}.ass","w")', f'open("ep{n}w.ass","w")')
    s = re.sub(r'"\.\./saida/[^"]*\.mp4"', f'"../saida/wide/Ep{n}_16x9.mp4"', s)
    s = re.sub(r'"-b:v", "\d+k", "-maxrate", "\d+k", "-bufsize", "\d+k"', '"-b:v", "6000k", "-maxrate", "9000k", "-bufsize", "12000k"', s)
    assert "_16x9.mp4" in s and f"ep{n}w.ass" in s, n
    open(f"run_ep{n}w.py", "w").write(s); print("ok", n)
