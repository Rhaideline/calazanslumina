"""Reel 'Nas palavras dele': frases reais de Flávio Bolsonaro ao lado dos fatos, com fonte e data."""
from art import *
from scenes_v2 import L, R, Rr, INK
from scenes_ep5 import parchment, stamp, label, RED, GOLD, INKB
import scenes_pol3 as P3
import scenes_pol4 as P4
import photos
import textwrap

PAPER = "#F4F1EA"
def dark(gl="#6A2A2A"):
    return sky([(0, "#07070C"), (0.6, "#14101A"), (1, "#1E1418")]) + glow(540, 900, 800, gl, .28)

def quote(text, attrib, size=84, wrap=16, y0=760, col=PAPER):
    lines = textwrap.wrap(text, wrap)
    g = f'<text x="140" y="{y0 - 60}" font-family="Old Standard TT" font-weight="700" font-size="260" fill="{GOLD}" opacity=".85">“</text>'
    g += "".join(f'<text x="540" y="{y0 + 40 + k * (size + 18)}" font-family="Old Standard TT" font-style="italic" font-weight="700" font-size="{size}" text-anchor="middle" fill="{col}">{ln}</text>' for k, ln in enumerate(lines))
    yb = y0 + 40 + len(lines) * (size + 18) + 40
    g += f'<line x1="380" y1="{yb}" x2="700" y2="{yb}" stroke="{GOLD}" stroke-width="4"/>'
    g += f'<text x="540" y="{yb + 60}" font-family="Montserrat" font-weight="800" font-size="30" letter-spacing="2" text-anchor="middle" fill="#D8D0C4">{attrib}</text>'
    return g

def medal(x, y, s):
    return (f'<g transform="translate({x},{y}) scale({s})"><path d="M-90,-300 L-30,-60 L30,-60 L90,-300 Z" fill="#2A5A9A"/><path d="M-30,-300 L0,-60 L30,-300 Z" fill="#E8E0D0" opacity=".8"/>'
            f'<circle cx="0" cy="40" r="120" fill="{GOLD}" stroke="#8A6A10" stroke-width="10"/><circle cx="0" cy="40" r="88" fill="none" stroke="#8A6A10" stroke-width="6"/>'
            f'<path d="M0,-25 L18,22 L68,22 L28,50 L42,98 L0,70 L-42,98 L-28,50 L-68,22 L-18,22 Z" fill="#8A6A10"/></g>')

def bars(x0, x1, y0, y1, col="#6A6A70"):
    return "".join(f'<rect x="{x}" y="{y0}" width="16" height="{y1 - y0}" fill="{col}"/>' for x in range(x0, x1, 70)) + f'<rect x="{x0 - 20}" y="{y0}" width="{x1 - x0 + 40}" height="22" fill="{col}"/><rect x="{x0 - 20}" y="{y1 - 22}" width="{x1 - x0 + 40}" height="22" fill="{col}"/>'

def book(x, y, s, title):
    return (f'<g transform="translate({x},{y}) scale({s})"><rect x="-230" y="-300" width="460" height="600" rx="16" fill="#1E3A2A" stroke="{GOLD}" stroke-width="8"/>'
            f'<rect x="-200" y="-270" width="400" height="540" fill="none" stroke="{GOLD}" stroke-width="3"/>'
            f'<text x="0" y="-60" font-family="Old Standard TT" font-weight="700" font-size="42" text-anchor="middle" fill="{GOLD}">{title}</text>'
            f'<text x="0" y="10" font-family="Old Standard TT" font-size="34" text-anchor="middle" fill="{GOLD}">DA REPÚBLICA</text>'
            f'<text x="0" y="60" font-family="Old Standard TT" font-size="34" text-anchor="middle" fill="{GOLD}">FEDERATIVA DO BRASIL</text></g>')

def door(x, y):
    return (f'<g transform="translate({x},{y})"><rect x="-200" y="-620" width="400" height="620" fill="#4A3020"/><rect x="-170" y="-590" width="340" height="560" fill="#5A3A26"/>'
            f'<circle cx="130" cy="-300" r="16" fill="{GOLD}"/><rect x="-150" y="-520" width="300" height="110" rx="8" fill="#D8C8A0"/>'
            f'<text x="0" y="-478" font-family="Montserrat" font-weight="800" font-size="24" text-anchor="middle" fill="#2A1A10">GABINETE</text>'
            f'<text x="0" y="-438" font-family="Montserrat" font-weight="700" font-size="22" text-anchor="middle" fill="#2A1A10">DEP. FLÁVIO BOLSONARO</text></g>')

S = {}
S[1] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.08, (0, 0), (0, -20)), particles="dust",
    layers=[L(0.0, dark("#7A2A20")),
            L(0.3, photos.card("recebidas/flavio_6out_goiania.png", (60, 330, 780, 900), 540, 1080, 640, -2, "FOTO: REPRODUÇÃO · PODER360 · 6/10/2026"), rough=False)])
S[2] = lambda: dict(light="#FFE0B0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
    layers=[L(0.0, sky([(0, "#2A140C"), (1, "#4A2414")]) + glow(540, 1000, 800, "#FFC070", .45)),
            L(0.3, medal(540, 1080, 1.6), rough=False),
            L(0.5, label(540, 440, "2005 · MEDALHA TIRADENTES", 66, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.51, label(540, 540, "MAIOR HONRARIA DA ALERJ", 50, GOLD, "Anton"), reveal=(1.6, 0.3, "center"), rough=False)])
S[3] = lambda: dict(light="#C8C8D0", rim_dx=4, cam=(1.0, 1.12, (0, 10), (0, -20)), particles="ash",
    layers=[L(0.0, dark("#3A3A5A")),
            L(0.4, R(person(540, 1700, 760, "#0A0A0E", "shirt", None, la=(100, 92), ra=(80, 85), face=1)), rough=True),
            L(0.6, bars(180, 920, 820, 1720), rough=False),
            L(0.7, label(540, 440, "PRESO · ACUSADO DE HOMICÍDIO", 56, PAPER, "Anton"), reveal=(0.4, 0.3, "center"), rough=False),
            L(0.71, P4.chip(540, 600, "MP-RJ: CHEFE DE MILÍCIA", GOLD, 40), reveal=(4.6, 0.2, "center"), rough=False)])
S[4] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.08, (0, 10), (0, -20)), particles="dust",
    layers=[L(0.0, sky([(0, "#3A2A20"), (1, "#5A3A28")]) + glow(540, 1000, 700, "#FFC070", .4)),
            L(0.3, door(540, 1460), rough=False),
            L(0.4, P4.chip(330, 1560, "A MÃE", PAPER, 42) + P4.chip(750, 1560, "A EX-MULHER", PAPER, 42), reveal=(0.8, 0.2, "center"), rough=False)])
S[5] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -10)), particles="dust",
    layers=[L(0.0, dark("#2A2A4A")), L(0.4, quote("Na época, era um policial exemplar.", "FLÁVIO · JORNAL NACIONAL · 28/08/2026"), rough=False)])
S[6] = lambda: dict(light="#C8D0E0", rim_dx=4, cam=(1.0, 1.12, (0, 20), (0, -30)), particles="dust",
    layers=[L(0.0, sky([(0, "#1A2238"), (0.55, "#4A4A68"), (1, "#8A7A78")])),
            L(0.3, R(P3.stf_building(540, 1500, 1.15, "#0A0C14")) + ground(1500, "#14161E", "#0A0C12", 4, 1)),
            L(0.6, label(540, 440, "2020 · DENUNCIADO", 80, PAPER, "Anton"), reveal=(0.3, 0.3, "center"), rough=False),
            L(0.61, stamp(540, 760, "ANULADO · 2021", -5, 66), reveal=(3.0, 0.15, "center"), rough=False),
            L(0.62, P4.chip(540, 960, "SEM CONDENAÇÃO · ELE NEGA", GOLD, 38), reveal=(5.0, 0.2, "center"), rough=False)])
S[7] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -10)), particles="dust",
    layers=[L(0.0, dark("#5A2A2A")), L(0.4, quote("É mentira.", "FLÁVIO AO INTERCEPT · 13/05/2026", 130, 16, 700), rough=False),
            L(0.5, stamp(540, 1120, "ADMITIU NO MESMO DIA", -5, 60), reveal=(5.6, 0.15, "center"), rough=False)])
S[8] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -10)), particles="dust",
    layers=[L(0.0, dark("#3A2A4A")), L(0.4, quote("Não tenho que justificar nada.", "FLÁVIO · SBT NEWS · 15/05/2026", 92, 15), rough=False)])
S[9] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.06, (0, 0), (0, -10)), particles="dust",
    layers=[L(0.0, dark("#5A3A1A")), L(0.4, quote("Sem anistia, darei indulto a todo mundo.", "FLÁVIO · SBT NEWS · 29/09/2026", 86, 17), rough=False)])
S[10] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
    layers=[L(0.0, dark("#2A4A3A")),
            L(0.3, book(540, 1080, 1.05, "CONSTITUIÇÃO"), rough=False),
            L(0.5, label(540, 440, "“MUDAR A CONSTITUIÇÃO”", 70, PAPER, "Anton"), reveal=(0.4, 0.3, "center"), rough=False),
            L(0.51, label(540, 530, "GOIÂNIA · 06/10/2026", 40, "#D8D0C4", "Montserrat"), rough=False),
            L(0.52, P4.chip(540, 1500, "NÃO DISSE O QUÊ", GOLD, 44), reveal=(3.6, 0.2, "center"), rough=False)])
S[11] = lambda: dict(light="#FFD8A0", rim_dx=4, cam=(1.0, 1.1, (0, 10), (0, -20)), particles="dust",
    layers=[L(0.0, photos.full_bg("congresso.jpg", 0.465, (0.95, 0.9, 0.95), 0.45), rough=False),
            L(0.4, label(540, 780, "AS PALAVRAS", 120, PAPER, "Anton") + label(540, 910, "SÃO DELE", 120, PAPER, "Anton"), rough=False),
            L(0.41, label(540, 1060, "25/10 · VOCÊ DECIDE", 70, GOLD, "Anton"), reveal=(3.0, 0.3, "center"), rough=False)])
SC = S
