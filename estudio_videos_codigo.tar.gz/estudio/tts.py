import sherpa_onnx, soundfile as sf, sys
def load(v):
    d=f"vits-piper-pt_BR-{v}-medium"
    cfg=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=f"{d}/pt_BR-{v}-medium.onnx",tokens=f"{d}/tokens.txt",data_dir=f"{d}/espeak-ng-data",length_scale=1.0),num_threads=2))
    return sherpa_onnx.OfflineTts(cfg)
if __name__=="__main__":
    t="Imagina acordar no Rio de Janeiro e ver os canhões de um dos navios de guerra mais poderosos do mundo apontados pra sua cidade. E o motivo? Chicotadas."
    for v in ["faber","cadu","jeff"]:
        a=load(v).generate(t,sid=0,speed=1.05); sf.write(f"test_{v}.wav",a.samples,a.sample_rate); print(v,len(a.samples)/a.sample_rate)
