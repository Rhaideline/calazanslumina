#!/usr/bin/env bash
# Prepara o ambiente do estúdio: dependências Python, fontes e voz Piper (faber).
set -e
cd "$(dirname "$0")"
pip install -q numpy opencv-python-headless soundfile sherpa-onnx playwright Pillow fonttools brotli
mkdir -p ~/.fonts voz
G=https://raw.githubusercontent.com/google/fonts/main
for f in ofl/anton/Anton-Regular.ttf ofl/bebasneue/BebasNeue-Regular.ttf "ofl/caveat/Caveat%5Bwght%5D.ttf" "ofl/montserrat/Montserrat%5Bwght%5D.ttf" "ofl/lora/Lora%5Bwght%5D.ttf"; do
  curl -sSL -o ~/.fonts/"$(basename "$f" | sed 's/%5B/[/;s/%5D/]/')" "$G/$f"
done
# Old Standard TT não está no repo google/fonts: vem do npm (@fontsource) e é convertida
T=$(mktemp -d); (cd $T && npm pack @fontsource/old-standard-tt >/dev/null 2>&1 && tar xzf *.tgz)
for n in 400-normal:Regular 700-normal:Bold 400-italic:Italic; do
  python3 -c "from fontTools.ttLib import TTFont; f=TTFont('$T/package/files/old-standard-tt-latin-${n%%:*}.woff2'); f.flavor=None; f.save('$HOME/.fonts/OldStandardTT-${n##*:}.ttf')"
done
fc-cache -f
[ -d voz/vits-piper-pt_BR-faber-medium ] || curl -sSL https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-pt_BR-faber-medium.tar.bz2 | tar xj -C voz
for d in roteiros/*/; do ln -sfn ../../voz/vits-piper-pt_BR-faber-medium "$d/vits-piper-pt_BR-faber-medium"; done
echo "pronto. Rode os scripts com PYTHONPATH=.. a partir de roteiros/epN (tts.py) e direto de cine/."
