# Canal Calazans Lumina · Vídeo longo 1 · História do Brasil

## Arquivos

- **Vídeo:** `Historia_do_Brasil_Longo_16x9.mp4` (1920x1080, 16:9, {DURACAO})
- **Capa:** `Capa_Longo_YouTube_1280x720.png` (tamanho exato que o YouTube pede, abaixo de 2 MB)

## Como publicar

- **Formato:** vídeo comum, não Shorts. Envie pelo computador (YouTube Studio), que aceita a capa personalizada e os capítulos.
- **Capítulos:** já estão na descrição abaixo. O YouTube cria os capítulos sozinho a partir dos tempos (o primeiro precisa ser 0:00, e cada um precisa ter pelo menos 10 segundos; os dois cuidados já foram tomados).
- **Tela final:** os últimos 20 segundos têm a metade direita livre. No YouTube Studio, em "Tela final", coloque "Inscrever-se" e "Vídeo mais recente" ou uma playlist nessa área.
- **Cards:** coloque um card no início de cada capítulo apontando para o Shorts do mesmo episódio.
- **Playlist:** "História do Brasil · a série". Coloque este vídeo em primeiro.
- **Conteúdo alterado ou sintético:** a narração é de voz sintética e as imagens são ilustrações. Não há imitação de pessoa real, então o selo não é obrigatório, mas vale marcar por transparência.
- **Público:** marque "Não é conteúdo para crianças". O tema é escolar, mas falamos de mortes, doenças e rituais.
- **Horário:** sábado ou domingo, entre 10h e 12h. Vídeo longo funciona melhor no fim de semana, quando a pessoa tem tempo para assistir.

---

## Título (escolha um)

```
A história do Brasil antes e depois de 1500 (o que a escola resumiu demais)
```

Alternativas:

```
O Brasil antes e depois de 1500: 11 mil anos em 15 minutos
```

```
11 mil anos de Brasil: dos primeiros povos à expulsão dos holandeses
```

---

## Descrição

```
Muito antes de Cabral, o Brasil já tinha milhões de pessoas, florestas plantadas e montanhas de conchas feitas à mão. Neste vídeo, a história do Brasil em 8 capítulos: dos primeiros povos, há mais de 11 mil anos, até a expulsão dos holandeses, em 1654.

CAPÍTULOS
{CAPITULOS}

FONTES
Cap. 1: Serra da Capivara (UNESCO, Patrimônio Mundial) · DNA do povo de Luzia (Cell e Science, 2018) · Museu Nacional/UFRJ · pegadas de White Sands, EUA (Science, 2021) · pingentes de preguiça-gigante de Santa Elina, MT (Proceedings of the Royal Society B, 2023).
Cap. 2: terra preta com o povo Kuikuro (Science Advances, 2023) · mais de 10 mil obras de terra na Amazônia (Science, 2023) · pesquisas de Michael Heckenberger no Alto Xingu · domesticação da mandioca no sudoeste da Amazônia.
Cap. 3: Lei nº 3.924/1961 (proteção dos sambaquis) · sambaqui Jabuticabeira II (SC) · Museu Paraense Emílio Goeldi (acervo marajoara).
Cap. 4: Carta de Pero Vaz de Caminha (1500) · Tratado de Tordesilhas (1494) · viagem de Vicente Pinzón (janeiro de 1500) · relatos dos jesuítas sobre a epidemia de varíola na Bahia (1563) · IBGE, Censo 2022 (povos e línguas indígenas).
Cap. 5: cartas de doação das capitanias · mapa refeito por Jorge Pimentel Cintra, USP (Anais do Museu Paulista, 2013) · fim do sistema com o Marquês de Pombal (1759).
Cap. 6: Regimento de Tomé de Sousa (1548) · chegada a Salvador em 29 de março de 1549 · morte do bispo Pero Fernandes Sardinha (1556) · Manifesto Antropófago, de Oswald de Andrade (Revista de Antropofagia, 1928).
Cap. 7: França Antártica e fundação do Rio (Revista do IGHMB) · Revista Pesquisa FAPESP · relatos de Jean de Léry e Hans Staden.
Cap. 8: invasão de 1630 e União Ibérica · Calabar (troca de lado em 1632, execução em Porto Calvo em 1635) · sinagoga Kahal Zur Israel, Recife (Revista Pesquisa FAPESP) · Batalhas dos Guararapes (ANPUH) · peça "Calabar: o elogio da traição", de Chico Buarque e Ruy Guerra (1973).

Onde as fontes divergem (datas, números, nomes), o vídeo usa só o que elas têm em comum.

Conteúdo produzido com auxílio de IA. Narração com voz sintética · ilustrações originais Calazans Lumina.

Se inscreve no canal: a série continua.

#historiadobrasil #historia #brasilcolonial #povosindigenas #enem
```

---

## Tags

```
história do brasil, brasil antes de 1500, descobrimento do brasil, povos indígenas, luzia, serra da capivara, amazônia, terra preta, sambaqui, cerâmica marajoara, pedro álvares cabral, pero vaz de caminha, capitanias hereditárias, tomé de sousa, bispo sardinha, caramuru, frança antártica, estácio de sá, invasões holandesas, calabar, história para enem, brasil colonial
```

---

## Comentário fixado

```
Qual capítulo te surpreendeu mais? Escreve o número aqui 👇 O mais votado vira o próximo vídeo longo.
```

---

## Pontos para você conferir antes de publicar

1. A capa diz "ANTES E DEPOIS DE 1500" porque o vídeo vai de 11 mil anos atrás até 1654. "Antes de 1500" sozinho prometeria menos do que o vídeo entrega.
2. Os episódios usados aqui são os mesmos dos Shorts, sem as frases finais de chamada ("No próximo episódio...", "Se inscreve...") que só fazem sentido no vertical. Os cartões de capítulo fazem a ligação.
3. Publicar o longo e os Shorts com o mesmo conteúdo é permitido e comum. O Shorts leva gente para o longo, e o longo soma horas assistidas para a monetização (o Programa de Parcerias pede mil inscritos e 4 mil horas de vídeo longo em 12 meses; visualização de Shorts não conta nessas horas).
4. A narração dos 8 episódios foi conferida por transcrição automática (Whisper): cada frase foi comparada com o roteiro.
