"""Monta o vídeo longo 16:9 'História do Brasil' a partir dos episódios horizontais (saida/wide/EpN_16x9.mp4)."""
import json, os, subprocess, sys, numpy as np, soundfile as sf
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
sys.path.insert(0, "..")
W, H, FPS, SR = 1920, 1080, 30, 48000
F = os.path.expanduser("~/.fonts/")
WIDE, ROT, OUT = "../saida/wide", "../roteiros", "../saida/wide/Historia_do_Brasil_Longo_16x9.mp4"
CAPS = [(1, "O Brasil antes do Brasil", "há mais de 11 mil anos"), (2, "A floresta que foi plantada", "há 9 mil anos"),
        (3, "Montanhas de conchas e urnas de barro", "há milhares de anos"), (4, "O encontro de 1500", "22 de abril de 1500"),
        (5, "As capitanias hereditárias", "a partir de 1534"), (6, "Salvador, Caramuru e o bispo Sardinha", "1549 a 1556"),
        (7, "O Rio de Janeiro já foi francês", "1555 a 1567"), (8, "Calabar e os holandeses", "1630 a 1654")]
ENC = ["-c:v", "libx264", "-preset", "medium", "-b:v", "6000k", "-maxrate", "9000k", "-bufsize", "12000k", "-pix_fmt", "yuv420p", "-r", str(FPS),
       "-c:a", "aac", "-b:a", "192k", "-ar", str(SR), "-ac", "2"]
def run(cmd): subprocess.run(cmd, check=True)
def font(name, size):
    f = ImageFont.truetype(F + name, size)
    try: f.set_variation_by_name("Bold")
    except Exception: pass
    return f
def bg_from(video, t, dark=0.38):
    run(["ffmpeg", "-v", "error", "-y", "-ss", str(t), "-i", video, "-frames:v", "1", "_f.png"])
    im = Image.open("_f.png").convert("RGB").filter(ImageFilter.GaussianBlur(14))
    return ImageEnhance.Brightness(im).enhance(dark)
def center(d, y, txt, f, fill):
    w = d.textlength(txt, font=f); d.text(((W - w) / 2, y), txt, font=f, fill=fill)
def sfx(dur, boom=True):
    n = int(dur * SR); t = np.arange(n) / SR; rng = np.random.default_rng(3); x = np.zeros(n)
    L = int(0.6 * SR); w = np.convolve(rng.normal(0, 1, L), np.ones(40) / 40, "same") * np.sin(np.pi * np.arange(L) / L) ** 2; x[:L] += w * 0.5
    if boom: tt = t[:int(1.6 * SR)]; x[:len(tt)] += np.sin(2 * np.pi * (55 * np.exp(-tt * 3) + 28) * tt) * np.exp(-tt * 2.2) * 0.8
    x = x / (np.abs(x).max() + 1e-9) * 0.5; return np.stack([x, x], 1).astype(np.float32)
def card(png, dur, out, audio=None):
    a = "_a.wav"; sf.write(a, audio if audio is not None else sfx(dur), SR)
    run(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", png, "-i", a, "-t", str(dur), "-vf",
         f"scale=2112:1188,zoompan=z='1+0.04*on/{int(dur*FPS)}':d={int(dur*FPS)}:s={W}x{H}:fps={FPS},fade=t=in:st=0:d=0.35,fade=t=out:st={dur-0.35}:d=0.35",
         "-af", f"afade=t=out:st={dur-0.3}:d=0.3"] + ENC + ["-shortest", out])
def chapter_card(n, title, era, video, out):
    im = bg_from(video, 1.2); d = ImageDraw.Draw(im)
    tag = f"CAPÍTULO {n}"; ft = font("Montserrat[wght].ttf", 40); wt = d.textlength(tag, font=ft)
    d.rounded_rectangle([(W - wt) / 2 - 28, 330, (W + wt) / 2 + 28, 400], 14, fill=(245, 200, 51)); center(d, 340, tag, ft, (17, 17, 17))
    center(d, 440, title.upper(), font("Anton-Regular.ttf", 112), (244, 241, 234))
    center(d, 600, era, font("Lora[wght].ttf", 54), (230, 200, 140))
    im.save("_card.png"); card("_card.png", 2.6, out)
def intro(out):
    im = bg_from(f"{WIDE}/Ep4_16x9.mp4", 3.0, 0.32); d = ImageDraw.Draw(im)
    center(d, 330, "CALAZANS LUMINA APRESENTA", font("Montserrat[wght].ttf", 40), (245, 200, 51))
    center(d, 400, "HISTÓRIA DO BRASIL", font("Anton-Regular.ttf", 170), (244, 241, 234))
    center(d, 610, "do Brasil antes do Brasil à expulsão dos holandeses", font("Lora[wght].ttf", 50), (230, 200, 140))
    im.save("_intro.png")
    dur = 3.6; t = np.arange(int(dur * SR)) / SR  # trilha contínua: sem silêncio nos primeiros segundos
    pad = sum(np.sin(2 * np.pi * f * t) * g for f, g in ((55, .5), (110, .35), (164.8, .25), (220, .15))) * 0.22 * np.minimum(1, t / 0.4)
    a = sfx(dur); a[:, 0] += pad; a[:, 1] += pad
    card("_intro.png", dur, out, (a / np.abs(a).max() * 0.6).astype(np.float32))
def outro(out):
    from tts import load_kokoro
    txt = ("Se você chegou até aqui, já sabe mais da história do Brasil do que muita gente. "
           "A série continua. Se inscreve no canal, e me conta nos comentários: qual parte você não sabia?")
    a = load_kokoro().generate(txt, sid=43, speed=1.05); v = np.array(a.samples, np.float32)
    v = np.interp(np.arange(0, len(v), a.sample_rate / SR), np.arange(len(v)), v)
    dur = max(20.0, len(v) / SR + 6); n = int(dur * SR); t = np.arange(n) / SR
    pad = sum(np.sin(2 * np.pi * f * t) * g for f, g in ((110, .5), (164.8, .3), (220, .2))) * 0.06 * np.minimum(1, t / 1.5) * np.minimum(1, (dur - t) / 2)
    mix = pad.copy(); mix[int(0.6 * SR):int(0.6 * SR) + len(v)] += v[:n - int(0.6 * SR)] * 0.9
    mix = np.stack([mix, mix], 1).astype(np.float32)
    im = bg_from(f"{WIDE}/Ep8_16x9.mp4", 1.5, 0.3); d = ImageDraw.Draw(im)
    d.text((120, 300), "OBRIGADO POR", font=font("Anton-Regular.ttf", 110), fill=(244, 241, 234))
    d.text((120, 420), "ASSISTIR", font=font("Anton-Regular.ttf", 110), fill=(245, 200, 51))
    d.text((120, 580), "A série continua. Se inscreve no canal", font=font("Montserrat[wght].ttf", 40), fill=(230, 220, 200))
    d.text((120, 640), "e comenta: qual parte você não sabia?", font=font("Montserrat[wght].ttf", 40), fill=(230, 220, 200))
    d.text((120, 900), "CALAZANS LUMINA", font=font("Montserrat[wght].ttf", 34), fill=(245, 200, 51))
    im.save("_outro.png"); card("_outro.png", dur, out, mix)
def episode(n, out):
    meta = json.load(open(f"{ROT}/ep{n}/timing.json")); end = meta[-1]["start"] + 0.1
    run(["ffmpeg", "-v", "error", "-y", "-i", f"{WIDE}/Ep{n}_16x9.mp4", "-t", f"{end:.2f}", "-vf", f"fade=t=out:st={end-0.4:.2f}:d=0.4",
         "-af", f"afade=t=in:st=0:d=0.2,afade=t=out:st={end-0.4:.2f}:d=0.4"] + ENC + [out])
def dur(f): return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]).decode())
if __name__ == "__main__":
    parts, chapters, t = [], [], 0.0
    intro("p00_intro.mp4"); parts.append("p00_intro.mp4"); t += dur("p00_intro.mp4")
    for n, title, era in CAPS:
        c, e = f"p{n:02d}a_card.mp4", f"p{n:02d}b_ep.mp4"
        chapter_card(n, title, era, f"{WIDE}/Ep{n}_16x9.mp4", c); episode(n, e)
        chapters.append((t, f"Capítulo {n}: {title}")); parts += [c, e]; t += dur(c) + dur(e)
    outro("p99_outro.mp4"); chapters.append((t, "Encerramento")); parts.append("p99_outro.mp4"); t += dur("p99_outro.mp4")
    open("lista.txt", "w").write("".join(f"file '{p}'\n" for p in parts))
    run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "lista.txt", "-c", "copy", "_cat.mp4"])
    # volume no padrão do YouTube (-14 LUFS, pico -1,5 dBTP), vídeo copiado sem recompressão
    run(["ffmpeg", "-v", "error", "-y", "-i", "_cat.mp4", "-c:v", "copy", "-af", "loudnorm=I=-14:TP=-1.5:LRA=7", "-ar", str(SR),
         "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", OUT])
    with open("capitulos.txt", "w") as f:
        # YouTube exige o primeiro capítulo em 0:00 e capítulos de 10 s ou mais: a abertura (3,6 s) entra no capítulo 1
        for k, (s, name) in enumerate(chapters):
            s = 0 if k == 0 else s; f.write(f"{int(s // 60)}:{int(s % 60):02d} {name}\n")
    print(open("capitulos.txt").read()); print("total", round(t, 1), "s")
